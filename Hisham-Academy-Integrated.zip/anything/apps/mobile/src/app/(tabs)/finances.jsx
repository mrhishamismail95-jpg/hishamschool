import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Linking,
} from "react-native";
import {
  DollarSign,
  Users,
  MessageCircle,
  Plus,
  ChevronDown,
  ChevronUp,
} from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useStore } from "@/utils/store";

export default function FinancesScreen() {
  const insets = useSafeAreaInsets();
  const { students, payments, addPayment, deletePayment, fetchData } =
    useStore();
  const [selectedMonth, setSelectedMonth] = React.useState(
    new Date().toISOString().slice(0, 7),
  );
  const [collapsed, setCollapsed] = React.useState({});

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const toggleGroup = (g) => setCollapsed((p) => ({ ...p, [g]: !p[g] }));

  const getPaymentForMonth = (studentId) =>
    payments.find(
      (p) => p.studentId === studentId && p.date?.startsWith(selectedMonth),
    );

  const handleMarkPaid = (student) => {
    Alert.alert(
      "تسجيل دفعة",
      `${student.name}\nالمبلغ: ${Number(student.price || 0).toLocaleString()} ج.م`,
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "✓ تأكيد الدفع",
          onPress: async () => {
            await addPayment({
              studentId: student.id,
              studentName: student.name,
              amount: Number(student.price || 0),
              type: "subscription",
              status: "paid",
              month: selectedMonth,
              group: student.group,
            });
          },
        },
      ],
    );
  };

  const handleRemovePayment = (student) => {
    const payment = getPaymentForMonth(student.id);
    if (!payment) return;
    Alert.alert("حذف الدفعة", `هل تريد حذف دفعة ${student.name}؟`, [
      { text: "إلغاء", style: "cancel" },
      {
        text: "حذف",
        style: "destructive",
        onPress: () => deletePayment(payment.id),
      },
    ]);
  };

  const handleWhatsApp = (student) => {
    const msg = `مرحباً ${student.name}، يرجى سداد رسوم شهر ${selectedMonth}. المبلغ المطلوب: ${student.price || 0} ج.م`;
    const url = `whatsapp://send?phone=2${String(student.phone || "").replace(/^0/, "")}&text=${encodeURIComponent(msg)}`;
    Linking.openURL(url).catch(() => Alert.alert("تنبيه", "واتساب غير مثبت"));
  };

  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];
  const ungrouped = students.filter((s) => !s.group);
  const allGroupNames = [
    ...groups,
    ...(ungrouped.length > 0 ? ["بدون مجموعة"] : []),
  ];

  const getGroupStudents = (g) =>
    g === "بدون مجموعة" ? ungrouped : students.filter((s) => s.group === g);

  const getGroupStats = (groupStudents) => {
    const totalExpected = groupStudents.reduce(
      (acc, s) => acc + Number(s.price || 0),
      0,
    );
    const paidList = groupStudents.filter((s) => getPaymentForMonth(s.id));
    const collected = paidList.reduce((acc, s) => {
      const p = getPaymentForMonth(s.id);
      return acc + Number(p?.amount || 0);
    }, 0);
    return {
      totalExpected,
      collected,
      paidCount: paidList.length,
      pendingCount: groupStudents.length - paidList.length,
    };
  };

  const monthPayments = payments.filter((p) =>
    p.date?.startsWith(selectedMonth),
  );
  const totalRevenue = monthPayments.reduce(
    (acc, p) => acc + Number(p.amount || 0),
    0,
  );
  const paidStudents = new Set(monthPayments.map((p) => p.studentId)).size;
  const totalExpected = students.reduce(
    (acc, s) => acc + Number(s.price || 0),
    0,
  );

  const months = [];
  for (let i = 0; i < 6; i++) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    months.push(d.toISOString().slice(0, 7));
  }

  const monthLabel = (m) =>
    new Date(m + "-01").toLocaleDateString("ar-EG", {
      month: "long",
      year: "numeric",
    });

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      <View
        style={{
          paddingHorizontal: 20,
          paddingTop: 16,
          paddingBottom: 14,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
      >
        <Text style={{ fontSize: 24, fontWeight: "800", color: "#1F2937" }}>
          المالية
        </Text>
        <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 2 }}>
          تتبع مدفوعات كل مجموعة
        </Text>
      </View>

      {/* Month Selector */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{
          flexGrow: 0,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
        contentContainerStyle={{
          paddingHorizontal: 12,
          paddingVertical: 10,
          gap: 8,
        }}
      >
        {months.map((m) => (
          <TouchableOpacity
            key={m}
            onPress={() => setSelectedMonth(m)}
            style={{
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 20,
              backgroundColor: selectedMonth === m ? "#7C3AED" : "#F3F4F6",
            }}
          >
            <Text
              style={{
                fontSize: 12,
                fontWeight: "600",
                color: selectedMonth === m ? "#fff" : "#6B7280",
              }}
            >
              {monthLabel(m)}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 12,
          paddingBottom: insets.bottom + 90,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Revenue Card */}
        <View
          style={{
            backgroundColor: "#7C3AED",
            borderRadius: 20,
            padding: 20,
            marginBottom: 14,
          }}
        >
          <Text style={{ fontSize: 13, color: "#DDD6FE" }}>
            {monthLabel(selectedMonth)}
          </Text>
          <Text
            style={{
              fontSize: 34,
              fontWeight: "800",
              color: "#fff",
              marginVertical: 8,
            }}
          >
            {totalRevenue.toLocaleString()} ج.م
          </Text>
          <View style={{ flexDirection: "row", gap: 16 }}>
            <View
              style={{
                flex: 1,
                backgroundColor: "rgba(255,255,255,0.15)",
                borderRadius: 12,
                padding: 10,
                alignItems: "center",
              }}
            >
              <Text
                style={{ fontSize: 20, fontWeight: "800", color: "#A7F3D0" }}
              >
                {paidStudents}
              </Text>
              <Text style={{ fontSize: 11, color: "#DDD6FE" }}>دفعوا</Text>
            </View>
            <View
              style={{
                flex: 1,
                backgroundColor: "rgba(255,255,255,0.15)",
                borderRadius: 12,
                padding: 10,
                alignItems: "center",
              }}
            >
              <Text
                style={{ fontSize: 20, fontWeight: "800", color: "#FCA5A5" }}
              >
                {students.length - paidStudents}
              </Text>
              <Text style={{ fontSize: 11, color: "#DDD6FE" }}>لم يدفعوا</Text>
            </View>
            <View
              style={{
                flex: 1,
                backgroundColor: "rgba(255,255,255,0.15)",
                borderRadius: 12,
                padding: 10,
                alignItems: "center",
              }}
            >
              <Text
                style={{ fontSize: 14, fontWeight: "800", color: "#FDE68A" }}
              >
                {totalExpected.toLocaleString()}
              </Text>
              <Text style={{ fontSize: 11, color: "#DDD6FE" }}>المتوقع</Text>
            </View>
          </View>
        </View>

        {/* Groups */}
        {allGroupNames.length === 0 ? (
          <View style={{ alignItems: "center", paddingVertical: 60 }}>
            <DollarSign size={48} color="#E5E7EB" />
            <Text style={{ fontSize: 15, color: "#9CA3AF", marginTop: 12 }}>
              لا يوجد طلاب بعد
            </Text>
          </View>
        ) : (
          allGroupNames.map((groupName) => {
            const groupStudents = getGroupStudents(groupName);
            const stats = getGroupStats(groupStudents);
            const isCollapsed = collapsed[groupName];
            const pct =
              stats.totalExpected > 0
                ? Math.round((stats.collected / stats.totalExpected) * 100)
                : 0;
            const barColor =
              pct >= 80 ? "#10B981" : pct >= 50 ? "#F59E0B" : "#EF4444";

            return (
              <View
                key={groupName}
                style={{
                  backgroundColor: "#fff",
                  borderRadius: 18,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor: "#F3F4F6",
                  overflow: "hidden",
                }}
              >
                <TouchableOpacity
                  onPress={() => toggleGroup(groupName)}
                  style={{
                    padding: 16,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    borderBottomWidth: isCollapsed ? 0 : 1,
                    borderBottomColor: "#F3F4F6",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 10,
                    }}
                  >
                    <View
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 12,
                        backgroundColor: "#F5F3FF",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Users size={20} color="#7C3AED" />
                    </View>
                    <View>
                      <Text
                        style={{
                          fontSize: 15,
                          fontWeight: "700",
                          color: "#1F2937",
                        }}
                      >
                        {groupName}
                      </Text>
                      <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                        {groupStudents.length} طالب ·{" "}
                        <Text style={{ color: "#10B981", fontWeight: "600" }}>
                          {stats.paidCount} دفعوا
                        </Text>
                        {stats.pendingCount > 0 && (
                          <Text style={{ color: "#EF4444" }}>
                            {" "}
                            · {stats.pendingCount} متبقي
                          </Text>
                        )}
                      </Text>
                    </View>
                  </View>
                  <View
                    style={{
                      alignItems: "flex-end",
                      gap: 4,
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 10,
                    }}
                  >
                    <View>
                      <Text
                        style={{
                          fontSize: 13,
                          fontWeight: "700",
                          color: "#10B981",
                        }}
                      >
                        {stats.collected.toLocaleString()} ج
                      </Text>
                      <View
                        style={{
                          height: 4,
                          backgroundColor: "#E5E7EB",
                          borderRadius: 2,
                          width: 50,
                          marginTop: 3,
                        }}
                      >
                        <View
                          style={{
                            height: 4,
                            borderRadius: 2,
                            backgroundColor: barColor,
                            width: `${pct}%`,
                          }}
                        />
                      </View>
                    </View>
                    {isCollapsed ? (
                      <ChevronDown size={18} color="#9CA3AF" />
                    ) : (
                      <ChevronUp size={18} color="#9CA3AF" />
                    )}
                  </View>
                </TouchableOpacity>

                {!isCollapsed && (
                  <View style={{ padding: 10, gap: 8 }}>
                    {groupStudents.map((student) => {
                      const payment = getPaymentForMonth(student.id);
                      const isPaid = !!payment;

                      return (
                        <View
                          key={student.id}
                          style={{
                            borderRadius: 14,
                            padding: 14,
                            borderWidth: 1,
                            backgroundColor: isPaid ? "#F0FDF4" : "#FEF2F2",
                            borderColor: isPaid ? "#BBF7D0" : "#FECACA",
                          }}
                        >
                          <View
                            style={{
                              flexDirection: "row",
                              alignItems: "center",
                              justifyContent: "space-between",
                              marginBottom: 10,
                            }}
                          >
                            <View
                              style={{
                                flexDirection: "row",
                                alignItems: "center",
                                gap: 10,
                                flex: 1,
                              }}
                            >
                              <View
                                style={{
                                  width: 38,
                                  height: 38,
                                  borderRadius: 19,
                                  backgroundColor: isPaid
                                    ? "#D1FAE5"
                                    : "#FEE2E2",
                                  alignItems: "center",
                                  justifyContent: "center",
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 16,
                                    fontWeight: "800",
                                    color: isPaid ? "#065F46" : "#991B1B",
                                  }}
                                >
                                  {student.name?.[0]}
                                </Text>
                              </View>
                              <View style={{ flex: 1 }}>
                                <Text
                                  style={{
                                    fontSize: 14,
                                    fontWeight: "700",
                                    color: "#1F2937",
                                  }}
                                >
                                  {student.name}
                                </Text>
                                <Text
                                  style={{ fontSize: 11, color: "#9CA3AF" }}
                                >
                                  {student.code}
                                </Text>
                              </View>
                            </View>
                            <View style={{ alignItems: "flex-end" }}>
                              <Text
                                style={{
                                  fontSize: 15,
                                  fontWeight: "800",
                                  color: "#7C3AED",
                                }}
                              >
                                {Number(student.price || 0).toLocaleString()} ج
                              </Text>
                              <View
                                style={{
                                  marginTop: 3,
                                  backgroundColor: isPaid
                                    ? "#D1FAE5"
                                    : "#FEE2E2",
                                  paddingHorizontal: 8,
                                  paddingVertical: 2,
                                  borderRadius: 8,
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 10,
                                    fontWeight: "700",
                                    color: isPaid ? "#065F46" : "#991B1B",
                                  }}
                                >
                                  {isPaid ? "مدفوع ✓" : "غير مدفوع"}
                                </Text>
                              </View>
                            </View>
                          </View>

                          <View style={{ flexDirection: "row", gap: 8 }}>
                            {isPaid ? (
                              <TouchableOpacity
                                onPress={() => handleRemovePayment(student)}
                                style={{
                                  flex: 1,
                                  backgroundColor: "#FEE2E2",
                                  borderRadius: 10,
                                  padding: 10,
                                  alignItems: "center",
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 12,
                                    fontWeight: "700",
                                    color: "#991B1B",
                                  }}
                                >
                                  إلغاء الدفعة
                                </Text>
                              </TouchableOpacity>
                            ) : (
                              <TouchableOpacity
                                onPress={() => handleMarkPaid(student)}
                                style={{
                                  flex: 1,
                                  backgroundColor: "#3B82F6",
                                  borderRadius: 10,
                                  padding: 10,
                                  flexDirection: "row",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  gap: 6,
                                }}
                              >
                                <Plus size={14} color="#fff" />
                                <Text
                                  style={{
                                    fontSize: 12,
                                    fontWeight: "700",
                                    color: "#fff",
                                  }}
                                >
                                  تسجيل دفعة
                                </Text>
                              </TouchableOpacity>
                            )}
                            {student.phone ? (
                              <TouchableOpacity
                                onPress={() => handleWhatsApp(student)}
                                style={{
                                  backgroundColor: "#D1FAE5",
                                  borderRadius: 10,
                                  padding: 10,
                                  alignItems: "center",
                                  justifyContent: "center",
                                  width: 40,
                                }}
                              >
                                <MessageCircle size={16} color="#059669" />
                              </TouchableOpacity>
                            ) : null}
                          </View>
                        </View>
                      );
                    })}

                    {/* Group Summary */}
                    <View
                      style={{
                        backgroundColor: "#F5F3FF",
                        borderRadius: 12,
                        padding: 12,
                        flexDirection: "row",
                        justifyContent: "space-around",
                        marginTop: 4,
                      }}
                    >
                      <View style={{ alignItems: "center" }}>
                        <Text style={{ fontSize: 11, color: "#7C3AED" }}>
                          المتوقع
                        </Text>
                        <Text
                          style={{
                            fontSize: 13,
                            fontWeight: "700",
                            color: "#5B21B6",
                          }}
                        >
                          {stats.totalExpected.toLocaleString()}
                        </Text>
                      </View>
                      <View style={{ width: 1, backgroundColor: "#DDD6FE" }} />
                      <View style={{ alignItems: "center" }}>
                        <Text style={{ fontSize: 11, color: "#10B981" }}>
                          محصَّل
                        </Text>
                        <Text
                          style={{
                            fontSize: 13,
                            fontWeight: "700",
                            color: "#065F46",
                          }}
                        >
                          {stats.collected.toLocaleString()}
                        </Text>
                      </View>
                      <View style={{ width: 1, backgroundColor: "#DDD6FE" }} />
                      <View style={{ alignItems: "center" }}>
                        <Text style={{ fontSize: 11, color: "#EF4444" }}>
                          متبقي
                        </Text>
                        <Text
                          style={{
                            fontSize: 13,
                            fontWeight: "700",
                            color: "#991B1B",
                          }}
                        >
                          {(
                            stats.totalExpected - stats.collected
                          ).toLocaleString()}
                        </Text>
                      </View>
                      <View style={{ width: 1, backgroundColor: "#DDD6FE" }} />
                      <View style={{ alignItems: "center" }}>
                        <Text style={{ fontSize: 11, color: "#6B7280" }}>
                          نسبة
                        </Text>
                        <Text
                          style={{
                            fontSize: 13,
                            fontWeight: "700",
                            color: barColor,
                          }}
                        >
                          {pct}%
                        </Text>
                      </View>
                    </View>
                  </View>
                )}
              </View>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}
