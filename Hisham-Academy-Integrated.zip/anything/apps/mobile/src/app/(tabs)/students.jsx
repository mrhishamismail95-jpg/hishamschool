import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
  Linking,
  Platform,
  KeyboardAvoidingView,
} from "react-native";
import {
  Search,
  Plus,
  Phone,
  GraduationCap,
  Users,
  X,
  MessageCircle,
  Edit2,
  Trash2,
  Hash,
  ChevronRight,
} from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useStore } from "@/utils/store";

// ─── Grade Data ───────────────────────────────────────────────────────────────
const GRADE_LEVELS = {
  ابتدائي: [
    "الأول الابتدائي",
    "الثاني الابتدائي",
    "الثالث الابتدائي",
    "الرابع الابتدائي",
    "الخامس الابتدائي",
    "السادس الابتدائي",
  ],
  إعدادي: ["الأول الإعدادي", "الثاني الإعدادي", "الثالث الإعدادي"],
  ثانوي: ["الأول الثانوي", "الثاني الثانوي", "الثالث الثانوي"],
  "لغات ابتدائي": [
    "الأول الابتدائي لغات",
    "الثاني الابتدائي لغات",
    "الثالث الابتدائي لغات",
    "الرابع الابتدائي لغات",
    "الخامس الابتدائي لغات",
    "السادس الابتدائي لغات",
  ],
  "لغات إعدادي": [
    "الأول الإعدادي لغات",
    "الثاني الإعدادي لغات",
    "الثالث الإعدادي لغات",
  ],
  "لغات ثانوي": [
    "الأول الثانوي لغات",
    "الثاني الثانوي لغات",
    "الثالث الثانوي لغات",
  ],
};

const EMPTY_FORM = {
  name: "",
  phone: "",
  parentPhone: "",
  grade: "",
  group: "",
  price: "",
  sessionPackage: "8",
  notes: "",
};

// ─── Add/Edit Modal ───────────────────────────────────────────────────────────
function StudentModal({ visible, onClose, student }) {
  const addStudent = useStore((s) => s.addStudent);
  const updateStudent = useStore((s) => s.updateStudent);

  const [form, setForm] = React.useState(EMPTY_FORM);
  const [category, setCategory] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const insets = useSafeAreaInsets();

  // Reset form when modal opens
  React.useEffect(() => {
    if (!visible) return;
    if (student) {
      setForm({
        name: student.name || "",
        phone: student.phone || "",
        parentPhone: student.parentPhone || "",
        grade: student.grade || "",
        group: student.group || "",
        price: student.price ? String(student.price) : "",
        sessionPackage: student.sessionPackage
          ? String(student.sessionPackage)
          : "8",
        notes: student.notes || "",
      });
      // detect category
      let found = "";
      for (const [cat, grades] of Object.entries(GRADE_LEVELS)) {
        if (grades.includes(student.grade)) {
          found = cat;
          break;
        }
      }
      setCategory(found);
    } else {
      setForm(EMPTY_FORM);
      setCategory("");
    }
  }, [visible, student]);

  const upd = (key, val) => setForm((prev) => ({ ...prev, [key]: val }));

  const handleSave = async () => {
    if (!form.name.trim()) {
      Alert.alert("تنبيه", "من فضلك أدخل اسم الطالب");
      return;
    }
    setSaving(true);
    try {
      if (student) {
        await updateStudent({ ...student, ...form });
      } else {
        await addStudent({ ...form });
      }
      onClose();
    } catch (e) {
      console.error("Save error:", e);
      Alert.alert("خطأ", "حدث خطأ أثناء الحفظ، حاول مجدداً");
    } finally {
      setSaving(false);
    }
  };

  const pricePerSession =
    form.price && form.sessionPackage && Number(form.sessionPackage) > 0
      ? Math.round(Number(form.price) / Number(form.sessionPackage))
      : null;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View
          style={{ flex: 1, backgroundColor: "#fff", paddingTop: insets.top }}
        >
          <StatusBar style="dark" />

          {/* Header */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              paddingHorizontal: 20,
              paddingVertical: 16,
              borderBottomWidth: 1,
              borderBottomColor: "#F3F4F6",
            }}
          >
            <Text style={{ fontSize: 20, fontWeight: "800", color: "#1F2937" }}>
              {student ? "تعديل الطالب" : "طالب جديد"}
            </Text>
            <TouchableOpacity
              onPress={onClose}
              style={{
                padding: 8,
                backgroundColor: "#F3F4F6",
                borderRadius: 20,
              }}
            >
              <X size={20} color="#6B7280" />
            </TouchableOpacity>
          </View>

          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{ padding: 20, paddingBottom: 40 }}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {/* Auto code notice */}
            {!student && (
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 8,
                  backgroundColor: "#EFF6FF",
                  borderRadius: 12,
                  padding: 12,
                  marginBottom: 20,
                }}
              >
                <Hash size={15} color="#3B82F6" />
                <Text style={{ fontSize: 12, color: "#1D4ED8", flex: 1 }}>
                  سيتم توليد كود مميز للطالب تلقائياً عند الحفظ
                </Text>
              </View>
            )}

            {student?.code && (
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  backgroundColor: "#F9FAFB",
                  borderRadius: 12,
                  padding: 12,
                  marginBottom: 20,
                }}
              >
                <Text style={{ fontSize: 13, color: "#6B7280" }}>
                  كود الطالب
                </Text>
                <Text
                  style={{ fontSize: 14, fontWeight: "700", color: "#1F2937" }}
                >
                  {student.code}
                </Text>
              </View>
            )}

            {/* Name */}
            <Field label="اسم الطالب *">
              <TextInput
                value={form.name}
                onChangeText={(v) => upd("name", v)}
                placeholder="مثال: محمد أحمد علي"
                placeholderTextColor="#9CA3AF"
                style={inputStyle}
                textAlign="right"
                autoFocus={!student}
              />
            </Field>

            {/* Phone */}
            <Field label="رقم هاتف الطالب">
              <TextInput
                value={form.phone}
                onChangeText={(v) => upd("phone", v)}
                placeholder="01xxxxxxxxx"
                placeholderTextColor="#9CA3AF"
                keyboardType="phone-pad"
                style={inputStyle}
                textAlign="right"
              />
            </Field>

            {/* Parent Phone */}
            <Field label="رقم ولي الأمر">
              <TextInput
                value={form.parentPhone}
                onChangeText={(v) => upd("parentPhone", v)}
                placeholder="01xxxxxxxxx"
                placeholderTextColor="#9CA3AF"
                keyboardType="phone-pad"
                style={inputStyle}
                textAlign="right"
              />
            </Field>

            {/* Group */}
            <Field label="المجموعة / الكروب">
              <TextInput
                value={form.group}
                onChangeText={(v) => upd("group", v)}
                placeholder="مثال: السبت 4 عصراً"
                placeholderTextColor="#9CA3AF"
                style={inputStyle}
                textAlign="right"
              />
            </Field>

            {/* Grade Category */}
            <Field label="المرحلة الدراسية">
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={{ flexGrow: 0 }}
                contentContainerStyle={{ gap: 8, paddingVertical: 2 }}
              >
                {Object.keys(GRADE_LEVELS).map((cat) => (
                  <TouchableOpacity
                    key={cat}
                    onPress={() => {
                      setCategory(cat);
                      upd("grade", "");
                    }}
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: 9,
                      borderRadius: 20,
                      backgroundColor: category === cat ? "#3B82F6" : "#F3F4F6",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "600",
                        color: category === cat ? "#fff" : "#6B7280",
                      }}
                    >
                      {cat}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </Field>

            {/* Grade Select */}
            {category !== "" && (
              <Field label="الصف الدراسي">
                <View
                  style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}
                >
                  {GRADE_LEVELS[category].map((g) => (
                    <TouchableOpacity
                      key={g}
                      onPress={() => upd("grade", g)}
                      style={{
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 10,
                        backgroundColor:
                          form.grade === g ? "#3B82F6" : "#F3F4F6",
                        borderWidth: 1.5,
                        borderColor:
                          form.grade === g ? "#3B82F6" : "transparent",
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 12,
                          fontWeight: "600",
                          color: form.grade === g ? "#fff" : "#6B7280",
                        }}
                      >
                        {g}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </Field>
            )}

            {/* Price + Sessions */}
            <View style={{ flexDirection: "row", gap: 12 }}>
              <View style={{ flex: 1 }}>
                <Field label="سعر الباقة (ج.م)">
                  <TextInput
                    value={form.price}
                    onChangeText={(v) => upd("price", v)}
                    placeholder="800"
                    placeholderTextColor="#9CA3AF"
                    keyboardType="numeric"
                    style={inputStyle}
                    textAlign="right"
                  />
                </Field>
              </View>
              <View style={{ flex: 1 }}>
                <Field label="عدد الحصص">
                  <View style={{ flexDirection: "row", gap: 6 }}>
                    {["8", "12"].map((pkg) => (
                      <TouchableOpacity
                        key={pkg}
                        onPress={() => upd("sessionPackage", pkg)}
                        style={{
                          flex: 1,
                          paddingVertical: 13,
                          borderRadius: 12,
                          alignItems: "center",
                          backgroundColor:
                            form.sessionPackage === pkg ? "#3B82F6" : "#F3F4F6",
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 14,
                            fontWeight: "700",
                            color:
                              form.sessionPackage === pkg ? "#fff" : "#6B7280",
                          }}
                        >
                          {pkg}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </Field>
              </View>
            </View>

            {/* Price per session display */}
            {pricePerSession !== null && (
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  backgroundColor: "#EFF6FF",
                  borderRadius: 12,
                  padding: 12,
                  marginBottom: 16,
                  marginTop: -4,
                }}
              >
                <Text style={{ fontSize: 13, color: "#3B82F6" }}>
                  سعر الحصة الواحدة
                </Text>
                <Text
                  style={{ fontSize: 14, fontWeight: "800", color: "#1D4ED8" }}
                >
                  {pricePerSession} ج.م
                </Text>
              </View>
            )}

            {/* Notes */}
            <Field label="ملاحظات">
              <TextInput
                value={form.notes}
                onChangeText={(v) => upd("notes", v)}
                placeholder="أي ملاحظات إضافية..."
                placeholderTextColor="#9CA3AF"
                multiline
                numberOfLines={3}
                style={[inputStyle, { height: 80, paddingTop: 12 }]}
                textAlign="right"
                textAlignVertical="top"
              />
            </Field>

            {/* Save Button */}
            <TouchableOpacity
              onPress={handleSave}
              disabled={saving}
              activeOpacity={0.85}
              style={{
                backgroundColor: saving ? "#93C5FD" : "#3B82F6",
                borderRadius: 16,
                padding: 18,
                alignItems: "center",
                marginTop: 8,
                shadowColor: "#3B82F6",
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.3,
                shadowRadius: 8,
                elevation: 4,
              }}
            >
              <Text style={{ fontSize: 17, fontWeight: "800", color: "#fff" }}>
                {saving
                  ? "جاري الحفظ..."
                  : student
                    ? "حفظ التعديلات"
                    : "✓ إضافة الطالب"}
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Helper Components ────────────────────────────────────────────────────────
function Field({ label, children }) {
  return (
    <View style={{ marginBottom: 16 }}>
      <Text
        style={{
          fontSize: 13,
          fontWeight: "700",
          color: "#374151",
          marginBottom: 8,
        }}
      >
        {label}
      </Text>
      {children}
    </View>
  );
}

const inputStyle = {
  backgroundColor: "#F9FAFB",
  borderWidth: 1.5,
  borderColor: "#E5E7EB",
  borderRadius: 12,
  paddingHorizontal: 14,
  paddingVertical: 13,
  fontSize: 14,
  color: "#1F2937",
};

// ─── Student Card ─────────────────────────────────────────────────────────────
function StudentCard({ student, onEdit, onDelete, onWhatsApp }) {
  const pkg = Number(student.sessionPackage) || 8;
  const pricePerSession = student.price
    ? Math.round(Number(student.price) / pkg)
    : null;

  return (
    <View
      style={{
        backgroundColor: "#fff",
        borderRadius: 18,
        padding: 16,
        borderWidth: 1,
        borderColor: "#F0F0F0",
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.06,
        shadowRadius: 8,
        elevation: 2,
        marginBottom: 10,
      }}
    >
      {/* Top row */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "flex-start",
          justifyContent: "space-between",
          marginBottom: 12,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            flex: 1,
          }}
        >
          {/* Avatar */}
          <View
            style={{
              width: 50,
              height: 50,
              borderRadius: 16,
              backgroundColor: "#3B82F6",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ fontSize: 22, fontWeight: "800", color: "#fff" }}>
              {student.name?.[0] || "؟"}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text
              style={{ fontSize: 16, fontWeight: "700", color: "#111827" }}
              numberOfLines={1}
            >
              {student.name}
            </Text>
            {student.code ? (
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 4,
                  marginTop: 3,
                  backgroundColor: "#F3F4F6",
                  paddingHorizontal: 8,
                  paddingVertical: 2,
                  borderRadius: 6,
                  alignSelf: "flex-start",
                }}
              >
                <Hash size={10} color="#9CA3AF" />
                <Text
                  style={{ fontSize: 11, color: "#6B7280", fontWeight: "600" }}
                >
                  {student.code}
                </Text>
              </View>
            ) : null}
          </View>
        </View>
        {/* Edit/Delete */}
        <View style={{ flexDirection: "row", gap: 4 }}>
          <TouchableOpacity
            onPress={onEdit}
            style={{ padding: 8, backgroundColor: "#EFF6FF", borderRadius: 10 }}
          >
            <Edit2 size={15} color="#3B82F6" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={onDelete}
            style={{ padding: 8, backgroundColor: "#FEF2F2", borderRadius: 10 }}
          >
            <Trash2 size={15} color="#EF4444" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Info rows */}
      <View style={{ gap: 6, marginBottom: 12 }}>
        {student.grade ? (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <GraduationCap size={14} color="#9CA3AF" />
            <Text style={{ fontSize: 13, color: "#6B7280" }}>
              {student.grade}
            </Text>
          </View>
        ) : null}
        {student.group ? (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <Users size={14} color="#9CA3AF" />
            <Text style={{ fontSize: 13, color: "#6B7280" }} numberOfLines={1}>
              {student.group}
            </Text>
          </View>
        ) : null}
        {student.phone ? (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <Phone size={14} color="#9CA3AF" />
            <Text style={{ fontSize: 13, color: "#6B7280" }}>
              {student.phone}
            </Text>
          </View>
        ) : null}
      </View>

      {/* Price box */}
      {student.price ? (
        <View
          style={{
            backgroundColor: "#EFF6FF",
            borderRadius: 12,
            padding: 12,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 12,
          }}
        >
          <View>
            <Text style={{ fontSize: 10, color: "#60A5FA", marginBottom: 2 }}>
              الباقة
            </Text>
            <Text style={{ fontSize: 15, fontWeight: "800", color: "#1E40AF" }}>
              {Number(student.price).toLocaleString()} ج.م
            </Text>
          </View>
          <View style={{ alignItems: "center" }}>
            <Text style={{ fontSize: 10, color: "#60A5FA", marginBottom: 2 }}>
              الحصص
            </Text>
            <Text style={{ fontSize: 15, fontWeight: "800", color: "#1E40AF" }}>
              {pkg}
            </Text>
          </View>
          {pricePerSession ? (
            <View style={{ alignItems: "flex-end" }}>
              <Text style={{ fontSize: 10, color: "#60A5FA", marginBottom: 2 }}>
                سعر الحصة
              </Text>
              <Text
                style={{ fontSize: 15, fontWeight: "800", color: "#1E40AF" }}
              >
                {pricePerSession} ج
              </Text>
            </View>
          ) : null}
        </View>
      ) : null}

      {/* WhatsApp button */}
      {student.phone ? (
        <TouchableOpacity
          onPress={onWhatsApp}
          activeOpacity={0.8}
          style={{
            backgroundColor: "#ECFDF5",
            borderRadius: 12,
            padding: 12,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <MessageCircle size={16} color="#10B981" />
          <Text style={{ fontSize: 13, fontWeight: "700", color: "#059669" }}>
            تواصل عبر واتساب
          </Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function StudentsScreen() {
  const insets = useSafeAreaInsets();

  // Subscribe to store individually to avoid stale closures
  const students = useStore((s) => s.students);
  const deleteStudent = useStore((s) => s.deleteStudent);
  const fetchData = useStore((s) => s.fetchData);

  const [search, setSearch] = React.useState("");
  const [filterGroup, setFilterGroup] = React.useState("الكل");
  const [modalVisible, setModalVisible] = React.useState(false);
  const [editingStudent, setEditingStudent] = React.useState(null);

  // Load data on mount
  React.useEffect(() => {
    fetchData();
  }, []);

  const groups = [
    "الكل",
    ...new Set(students.map((s) => s.group).filter(Boolean)),
  ];

  const filtered = React.useMemo(() => {
    return students.filter((s) => {
      const q = search.toLowerCase();
      const matchSearch =
        !q ||
        s.name?.toLowerCase().includes(q) ||
        s.phone?.includes(q) ||
        s.code?.toLowerCase().includes(q);
      const matchGroup = filterGroup === "الكل" || s.group === filterGroup;
      return matchSearch && matchGroup;
    });
  }, [students, search, filterGroup]);

  const openAdd = () => {
    setEditingStudent(null);
    setModalVisible(true);
  };

  const openEdit = (s) => {
    setEditingStudent(s);
    setModalVisible(true);
  };

  const handleDelete = (student) => {
    Alert.alert(
      "حذف الطالب",
      `هل أنت متأكد من حذف "${student.name}"؟\nلا يمكن التراجع عن هذا الإجراء.`,
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "حذف",
          style: "destructive",
          onPress: () => deleteStudent(student.id),
        },
      ],
    );
  };

  const handleWhatsApp = (phone) => {
    const url = `whatsapp://send?phone=2${String(phone).replace(/^0/, "")}`;
    Linking.openURL(url).catch(() =>
      Alert.alert("تنبيه", "تأكد من تثبيت واتساب على جهازك"),
    );
  };

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* ── Header ── */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingTop: 16,
          paddingBottom: 14,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F0F0F0",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <View>
          <Text style={{ fontSize: 26, fontWeight: "800", color: "#111827" }}>
            الطلاب
          </Text>
          <Text style={{ fontSize: 13, color: "#9CA3AF", marginTop: 1 }}>
            {students.length} طالب مسجّل
          </Text>
        </View>
        <TouchableOpacity
          onPress={openAdd}
          activeOpacity={0.85}
          style={{
            backgroundColor: "#3B82F6",
            borderRadius: 14,
            paddingHorizontal: 18,
            paddingVertical: 11,
            flexDirection: "row",
            alignItems: "center",
            gap: 7,
            shadowColor: "#3B82F6",
            shadowOffset: { width: 0, height: 3 },
            shadowOpacity: 0.35,
            shadowRadius: 6,
            elevation: 4,
          }}
        >
          <Plus size={19} color="#fff" />
          <Text style={{ color: "#fff", fontWeight: "800", fontSize: 14 }}>
            إضافة
          </Text>
        </TouchableOpacity>
      </View>

      {/* ── Search ── */}
      <View
        style={{
          paddingHorizontal: 12,
          paddingVertical: 10,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F0F0F0",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#F3F4F6",
            borderRadius: 12,
            paddingHorizontal: 12,
            paddingVertical: 10,
          }}
        >
          <Search size={17} color="#9CA3AF" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="بحث بالاسم أو الكود أو الهاتف..."
            placeholderTextColor="#9CA3AF"
            style={{
              flex: 1,
              marginRight: 8,
              fontSize: 14,
              color: "#1F2937",
              textAlign: "right",
            }}
          />
          {search !== "" && (
            <TouchableOpacity onPress={() => setSearch("")}>
              <X size={16} color="#9CA3AF" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* ── Group Filter ── */}
      {groups.length > 1 && (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{
            flexGrow: 0,
            backgroundColor: "#fff",
            borderBottomWidth: 1,
            borderBottomColor: "#F0F0F0",
          }}
          contentContainerStyle={{
            paddingHorizontal: 12,
            paddingVertical: 10,
            gap: 8,
          }}
        >
          {groups.map((g) => (
            <TouchableOpacity
              key={g}
              onPress={() => setFilterGroup(g)}
              style={{
                paddingHorizontal: 14,
                paddingVertical: 8,
                borderRadius: 20,
                backgroundColor: filterGroup === g ? "#3B82F6" : "#F3F4F6",
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "700",
                  color: filterGroup === g ? "#fff" : "#6B7280",
                }}
              >
                {g}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* ── Student List ── */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 12,
          paddingBottom: insets.bottom + 100,
        }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {filtered.length === 0 ? (
          <View style={{ alignItems: "center", paddingVertical: 80 }}>
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 24,
                backgroundColor: "#F3F4F6",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 16,
              }}
            >
              <Users size={36} color="#D1D5DB" />
            </View>
            <Text
              style={{
                fontSize: 18,
                fontWeight: "700",
                color: "#111827",
                marginBottom: 8,
              }}
            >
              {students.length === 0 ? "لا يوجد طلاب بعد" : "لا توجد نتائج"}
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: "#9CA3AF",
                textAlign: "center",
                marginBottom: 24,
              }}
            >
              {students.length === 0
                ? "اضغط على زر «إضافة» لإضافة أول طالب"
                : "جرّب تغيير كلمة البحث"}
            </Text>
            {students.length === 0 && (
              <TouchableOpacity
                onPress={openAdd}
                style={{
                  backgroundColor: "#3B82F6",
                  borderRadius: 14,
                  paddingHorizontal: 28,
                  paddingVertical: 14,
                }}
              >
                <Text
                  style={{ color: "#fff", fontWeight: "800", fontSize: 15 }}
                >
                  إضافة أول طالب
                </Text>
              </TouchableOpacity>
            )}
          </View>
        ) : (
          filtered.map((student) => (
            <StudentCard
              key={student.id}
              student={student}
              onEdit={() => openEdit(student)}
              onDelete={() => handleDelete(student)}
              onWhatsApp={() => handleWhatsApp(student.phone)}
            />
          ))
        )}
      </ScrollView>

      {/* ── Modal ── */}
      <StudentModal
        visible={modalVisible}
        onClose={() => {
          setModalVisible(false);
          setEditingStudent(null);
        }}
        student={editingStudent}
      />
    </View>
  );
}
