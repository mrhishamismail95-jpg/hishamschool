import React from "react";
import { View, Text, ScrollView, TouchableOpacity, Alert } from "react-native";
import {
  Database,
  Download,
  Upload,
  Users,
  Calendar,
  DollarSign,
  FileText,
  Info,
  Trash2,
} from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useStore } from "@/utils/store";
import * as Clipboard from "expo-clipboard";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const {
    students,
    attendance,
    payments,
    exams,
    fetchData,
    exportBackup,
    importBackup,
  } = useStore();

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleExport = async () => {
    try {
      const json = await exportBackup();
      await Clipboard.setStringAsync(json);
      Alert.alert(
        "✅ تم التصدير بنجاح",
        `تم نسخ البيانات إلى الحافظة:\n• ${students.length} طالب\n• ${attendance.length} سجل حضور\n• ${payments.length} دفعة\n\nألصق النص في ملف backup.json لحفظه.`,
        [{ text: "حسناً" }],
      );
    } catch (err) {
      Alert.alert("خطأ", "فشل تصدير البيانات");
    }
  };

  const handleClearData = () => {
    Alert.alert(
      "⚠️ تحذير — حذف كل البيانات",
      "سيتم حذف جميع الطلاب والحضور والمدفوعات والامتحانات بشكل نهائي لا يمكن التراجع عنه!\n\nهل أنت متأكد تماماً؟",
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "نعم، احذف كل شيء",
          style: "destructive",
          onPress: async () => {
            await importBackup(
              JSON.stringify({
                students: [],
                attendance: [],
                payments: [],
                exams: [],
              }),
            );
            Alert.alert("✓ تم", "تم مسح جميع البيانات بنجاح");
          },
        },
      ],
    );
  };

  const statCards = [
    {
      label: "الطلاب",
      value: students.length,
      icon: Users,
      color: "#3B82F6",
      bg: "#EFF6FF",
    },
    {
      label: "الحضور",
      value: attendance.length,
      icon: Calendar,
      color: "#10B981",
      bg: "#F0FDF4",
    },
    {
      label: "المدفوعات",
      value: payments.length,
      icon: DollarSign,
      color: "#8B5CF6",
      bg: "#F5F3FF",
    },
    {
      label: "الامتحانات",
      value: exams.length,
      icon: FileText,
      color: "#F59E0B",
      bg: "#FFFBEB",
    },
  ];

  const totalRecords =
    students.length + attendance.length + payments.length + exams.length;
  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      <View
        style={{
          paddingHorizontal: 20,
          paddingTop: 16,
          paddingBottom: 14,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
      >
        <Text style={{ fontSize: 24, fontWeight: "800", color: "#1F2937" }}>
          الإعدادات
        </Text>
        <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 2 }}>
          إدارة البيانات والنسخ الاحتياطي
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 90,
          gap: 14,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Stats Grid */}
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          {statCards.map((s) => (
            <View
              key={s.label}
              style={{
                backgroundColor: "#fff",
                borderRadius: 16,
                padding: 16,
                borderWidth: 1,
                borderColor: "#F3F4F6",
                width: "47%",
                alignItems: "center",
              }}
            >
              <View
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 13,
                  backgroundColor: s.bg,
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 10,
                }}
              >
                <s.icon size={22} color={s.color} />
              </View>
              <Text
                style={{ fontSize: 26, fontWeight: "800", color: "#1F2937" }}
              >
                {s.value}
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF", marginTop: 2 }}>
                {s.label}
              </Text>
            </View>
          ))}
        </View>

        {/* Backup Card */}
        <View
          style={{
            backgroundColor: "#fff",
            borderRadius: 20,
            padding: 20,
            borderWidth: 1,
            borderColor: "#F3F4F6",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 12,
              marginBottom: 16,
            }}
          >
            <View
              style={{
                width: 48,
                height: 48,
                borderRadius: 14,
                backgroundColor: "#EFF6FF",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Database size={24} color="#3B82F6" />
            </View>
            <View>
              <Text
                style={{ fontSize: 17, fontWeight: "700", color: "#1F2937" }}
              >
                النسخ الاحتياطي
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                {totalRecords} سجل إجمالي
              </Text>
            </View>
          </View>

          <TouchableOpacity
            onPress={handleExport}
            style={{
              backgroundColor: "#3B82F6",
              borderRadius: 14,
              padding: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
              marginBottom: 10,
            }}
          >
            <Download size={20} color="#fff" />
            <Text style={{ fontSize: 15, fontWeight: "700", color: "#fff" }}>
              تصدير ونسخ البيانات
            </Text>
          </TouchableOpacity>

          <View
            style={{
              backgroundColor: "#EFF6FF",
              borderRadius: 12,
              padding: 12,
              flexDirection: "row",
              alignItems: "flex-start",
              gap: 8,
            }}
          >
            <Info size={15} color="#3B82F6" />
            <Text
              style={{
                fontSize: 12,
                color: "#1D4ED8",
                flex: 1,
                lineHeight: 18,
              }}
            >
              جميع البيانات محفوظة محلياً على جهازك. استخدم التصدير لإنشاء نسخة
              احتياطية أو نقل البيانات للويب.
            </Text>
          </View>
        </View>

        {/* Groups Summary */}
        {groups.length > 0 && (
          <View
            style={{
              backgroundColor: "#fff",
              borderRadius: 20,
              padding: 20,
              borderWidth: 1,
              borderColor: "#F3F4F6",
            }}
          >
            <Text
              style={{
                fontSize: 16,
                fontWeight: "700",
                color: "#1F2937",
                marginBottom: 12,
              }}
            >
              المجموعات ({groups.length})
            </Text>
            {groups.map((group, i) => {
              const count = students.filter((s) => s.group === group).length;
              const monthlyRevenue = students
                .filter((s) => s.group === group)
                .reduce((acc, s) => acc + Number(s.price || 0), 0);
              return (
                <View
                  key={group}
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    paddingVertical: 12,
                    borderBottomWidth: i < groups.length - 1 ? 1 : 0,
                    borderBottomColor: "#F9FAFB",
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "600",
                        color: "#374151",
                      }}
                      numberOfLines={1}
                    >
                      {group}
                    </Text>
                    <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                      {monthlyRevenue.toLocaleString()} ج/شهر
                    </Text>
                  </View>
                  <View
                    style={{
                      backgroundColor: "#EFF6FF",
                      paddingHorizontal: 12,
                      paddingVertical: 5,
                      borderRadius: 20,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 13,
                        fontWeight: "700",
                        color: "#3B82F6",
                      }}
                    >
                      {count} طالب
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* Danger Zone */}
        <View
          style={{
            backgroundColor: "#fff",
            borderRadius: 20,
            padding: 20,
            borderWidth: 1,
            borderColor: "#FECACA",
          }}
        >
          <Text
            style={{
              fontSize: 15,
              fontWeight: "700",
              color: "#EF4444",
              marginBottom: 12,
            }}
          >
            ⚠️ منطقة الخطر
          </Text>
          <TouchableOpacity
            onPress={handleClearData}
            style={{
              backgroundColor: "#FEF2F2",
              borderRadius: 14,
              padding: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
              borderWidth: 1,
              borderColor: "#FECACA",
            }}
          >
            <Trash2 size={18} color="#EF4444" />
            <Text style={{ fontSize: 14, fontWeight: "700", color: "#EF4444" }}>
              حذف جميع البيانات نهائياً
            </Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={{ alignItems: "center", paddingVertical: 4 }}>
          <Text style={{ fontSize: 13, color: "#9CA3AF" }}>
            نظام إدارة الطلاب · الإصدار 1.0.0
          </Text>
          <Text style={{ fontSize: 12, color: "#D1D5DB", marginTop: 4 }}>
            بُني بكل ❤️ للمعلمين والمدرسين
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
