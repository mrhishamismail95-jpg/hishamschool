import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import {
  Users,
  CalendarCheck,
  Wallet,
  Clock,
  AlertCircle,
  TrendingUp,
  ArrowLeft,
} from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useStore } from "@/utils/store";
import { useRouter } from "expo-router";

const { width } = Dimensions.get("window");

function StatCard({ label, value, icon: Icon, bg, iconColor, sub }) {
  return (
    <View
      style={{
        backgroundColor: "#fff",
        borderRadius: 20,
        padding: 18,
        flex: 1,
        borderWidth: 1,
        borderColor: "#F3F4F6",
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.04,
        shadowRadius: 4,
        elevation: 2,
      }}
    >
      <View
        style={{
          width: 44,
          height: 44,
          borderRadius: 13,
          backgroundColor: bg,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 12,
        }}
      >
        <Icon size={22} color={iconColor} />
      </View>
      <Text style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 3 }}>
        {label}
      </Text>
      <Text
        style={{ fontSize: 22, fontWeight: "800", color: "#1F2937" }}
        numberOfLines={1}
      >
        {value}
      </Text>
      {sub ? (
        <Text style={{ fontSize: 11, color: "#10B981", marginTop: 3 }}>
          {sub}
        </Text>
      ) : null}
    </View>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { students, attendance, payments, fetchData } = useStore();

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const today = new Date().toISOString().split("T")[0];
  const todayRecords = attendance.filter((a) => a.date?.startsWith(today));
  const presentToday = todayRecords.filter(
    (a) => a.status === "present" || a.status === "late",
  ).length;
  const absentToday = todayRecords.filter((a) => a.status === "absent").length;
  const notMarked = students.length - todayRecords.length;

  const thisMonth = new Date().toISOString().slice(0, 7);
  const monthPayments = payments.filter((p) => p.date?.startsWith(thisMonth));
  const totalMonthRevenue = monthPayments.reduce(
    (acc, p) => acc + Number(p.amount || 0),
    0,
  );
  const paidCount = new Set(monthPayments.map((p) => p.studentId)).size;
  const unpaidCount = students.length - paidCount;

  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];

  // Students finishing sessions
  const lowSessions = students.filter((s) => {
    const pkg = Number(s.sessionPackage) || 8;
    const used = attendance.filter(
      (a) =>
        a.studentId === s.id && (a.status === "present" || a.status === "late"),
    ).length;
    return Math.max(0, pkg - used) <= 2;
  });

  const quickActions = [
    {
      label: "تسجيل الحضور",
      sub: "سجّل حضور طلابك الآن",
      color: "#3B82F6",
      icon: CalendarCheck,
      route: "/(tabs)/attendance",
    },
    {
      label: "إضافة طالب",
      sub: "أضف طالباً جديداً",
      color: "#10B981",
      icon: Users,
      route: "/(tabs)/students",
    },
    {
      label: "المدفوعات",
      sub: "تتبع مدفوعات الشهر",
      color: "#8B5CF6",
      icon: Wallet,
      route: "/(tabs)/finances",
    },
  ];

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingTop: 16,
          paddingBottom: 16,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
      >
        <Text style={{ fontSize: 26, fontWeight: "800", color: "#1F2937" }}>
          مرحباً 👋
        </Text>
        <Text style={{ fontSize: 13, color: "#9CA3AF", marginTop: 2 }}>
          {new Date().toLocaleDateString("ar-EG", {
            weekday: "long",
            day: "numeric",
            month: "long",
          })}
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 90,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Stats Row 1 */}
        <View style={{ flexDirection: "row", gap: 12, marginBottom: 12 }}>
          <StatCard
            label="إجمالي الطلاب"
            value={students.length}
            icon={Users}
            bg="#EFF6FF"
            iconColor="#3B82F6"
            sub={`${groups.length} مجموعة`}
          />
          <StatCard
            label="حضور اليوم"
            value={presentToday}
            icon={CalendarCheck}
            bg="#F0FDF4"
            iconColor="#10B981"
            sub={absentToday > 0 ? `${absentToday} غائب` : "لا غياب 🎉"}
          />
        </View>

        {/* Stats Row 2 */}
        <View style={{ flexDirection: "row", gap: 12, marginBottom: 20 }}>
          <StatCard
            label="إيرادات الشهر"
            value={`${totalMonthRevenue.toLocaleString()} ج`}
            icon={Wallet}
            bg="#F5F3FF"
            iconColor="#8B5CF6"
            sub={`${paidCount} دفعوا`}
          />
          <StatCard
            label="لم يدفعوا"
            value={unpaidCount}
            icon={Clock}
            bg="#FFF7ED"
            iconColor="#F59E0B"
            sub={unpaidCount > 0 ? "تذكير مطلوب" : "الكل دفع ✓"}
          />
        </View>

        {/* Today's Summary */}
        <View
          style={{
            backgroundColor: "#1E40AF",
            borderRadius: 20,
            padding: 20,
            marginBottom: 20,
            overflow: "hidden",
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "700",
              color: "#fff",
              marginBottom: 4,
            }}
          >
            ملخص اليوم
          </Text>
          <Text style={{ fontSize: 12, color: "#93C5FD", marginBottom: 16 }}>
            {today}
          </Text>
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            {[
              { label: "حضروا", value: presentToday, color: "#34D399" },
              { label: "غابوا", value: absentToday, color: "#F87171" },
              { label: "لم يُسجَّل", value: notMarked, color: "#FCD34D" },
            ].map((item) => (
              <View key={item.label} style={{ alignItems: "center" }}>
                <Text
                  style={{
                    fontSize: 28,
                    fontWeight: "800",
                    color: item.color,
                  }}
                >
                  {item.value}
                </Text>
                <Text style={{ fontSize: 11, color: "#93C5FD", marginTop: 2 }}>
                  {item.label}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Quick Actions */}
        <Text
          style={{
            fontSize: 17,
            fontWeight: "700",
            color: "#1F2937",
            marginBottom: 12,
          }}
        >
          إجراءات سريعة
        </Text>
        <View style={{ gap: 10, marginBottom: 20 }}>
          {quickActions.map((action) => (
            <TouchableOpacity
              key={action.label}
              onPress={() => router.push(action.route)}
              style={{
                backgroundColor: "#fff",
                borderRadius: 16,
                padding: 16,
                flexDirection: "row",
                alignItems: "center",
                gap: 14,
                borderWidth: 1,
                borderColor: "#F3F4F6",
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.04,
                shadowRadius: 3,
                elevation: 1,
              }}
            >
              <View
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 13,
                  backgroundColor: `${action.color}18`,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <action.icon size={22} color={action.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 15,
                    fontWeight: "700",
                    color: "#1F2937",
                    marginBottom: 2,
                  }}
                >
                  {action.label}
                </Text>
                <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                  {action.sub}
                </Text>
              </View>
              <ArrowLeft size={18} color="#D1D5DB" />
            </TouchableOpacity>
          ))}
        </View>

        {/* Alerts */}
        {lowSessions.length > 0 && (
          <View
            style={{
              backgroundColor: "#FFFBEB",
              borderRadius: 16,
              padding: 16,
              borderWidth: 1,
              borderColor: "#FDE68A",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                marginBottom: 10,
              }}
            >
              <AlertCircle size={18} color="#F59E0B" />
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "700",
                  color: "#92400E",
                }}
              >
                طلاب تنتهي حصصهم قريباً
              </Text>
            </View>
            {lowSessions.slice(0, 3).map((s) => {
              const pkg = Number(s.sessionPackage) || 8;
              const used = attendance.filter(
                (a) =>
                  a.studentId === s.id &&
                  (a.status === "present" || a.status === "late"),
              ).length;
              const remaining = Math.max(0, pkg - used);
              return (
                <View
                  key={s.id}
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    paddingVertical: 6,
                    borderTopWidth: 1,
                    borderTopColor: "#FDE68A",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 13,
                      fontWeight: "600",
                      color: "#1F2937",
                    }}
                  >
                    {s.name}
                  </Text>
                  <Text
                    style={{
                      fontSize: 12,
                      color: "#F59E0B",
                      fontWeight: "700",
                    }}
                  >
                    متبقي {remaining} {remaining === 0 ? "(انتهت!)" : ""}
                  </Text>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </View>
  );
}
