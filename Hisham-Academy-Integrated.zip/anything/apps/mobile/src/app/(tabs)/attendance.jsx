import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
} from "react-native";
import {
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Users,
  ChevronDown,
  ChevronUp,
  History,
  Calendar,
  AlertTriangle,
  X,
} from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useStore } from "@/utils/store";
import { Modal } from "react-native";

// ── Session History Modal ────────────────────────────────────
function HistoryModal({ visible, student, attendance, onClose }) {
  const insets = useSafeAreaInsets();
  if (!student) return null;

  const records = attendance
    .filter((a) => a.studentId === student.id)
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  const pkg = Number(student.sessionPackage) || 8;
  const sessionsUsed = records.filter(
    (r) => r.status === "present" || r.status === "late",
  ).length;
  const remaining = Math.max(0, pkg - sessionsUsed);
  const pct = Math.min(100, (sessionsUsed / pkg) * 100);

  const statusStyle = {
    present: { bg: "#D1FAE5", text: "#065F46", label: "✅ حاضر" },
    late: { bg: "#FED7AA", text: "#92400E", label: "⏱ متأخر" },
    absent: { bg: "#FEE2E2", text: "#991B1B", label: "❌ غائب" },
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View
        style={{ flex: 1, backgroundColor: "#fff", paddingTop: insets.top }}
      >
        <StatusBar style="dark" />

        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingHorizontal: 20,
            paddingVertical: 16,
            borderBottomWidth: 1,
            borderBottomColor: "#F3F4F6",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            <View
              style={{
                width: 44,
                height: 44,
                borderRadius: 14,
                backgroundColor: "#3B82F6",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ fontSize: 20, fontWeight: "800", color: "#fff" }}>
                {student.name?.[0]}
              </Text>
            </View>
            <View>
              <Text
                style={{ fontSize: 17, fontWeight: "800", color: "#1F2937" }}
              >
                {student.name}
              </Text>
              <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                {student.code} · {student.grade}
              </Text>
            </View>
          </View>
          <TouchableOpacity onPress={onClose} style={{ padding: 8 }}>
            <X size={22} color="#6B7280" />
          </TouchableOpacity>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            padding: 20,
            paddingBottom: insets.bottom + 20,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Stats */}
          <View style={{ flexDirection: "row", gap: 10, marginBottom: 16 }}>
            {[
              {
                label: "مستخدمة",
                value: sessionsUsed,
                color: "#3B82F6",
                bg: "#EFF6FF",
              },
              {
                label: "متبقية",
                value: remaining,
                color:
                  remaining === 0
                    ? "#EF4444"
                    : remaining <= 2
                      ? "#F59E0B"
                      : "#10B981",
                bg:
                  remaining === 0
                    ? "#FEF2F2"
                    : remaining <= 2
                      ? "#FFFBEB"
                      : "#F0FDF4",
              },
              { label: "الباقة", value: pkg, color: "#6B7280", bg: "#F9FAFB" },
            ].map((s) => (
              <View
                key={s.label}
                style={{
                  flex: 1,
                  backgroundColor: s.bg,
                  borderRadius: 14,
                  padding: 14,
                  alignItems: "center",
                }}
              >
                <Text
                  style={{ fontSize: 24, fontWeight: "800", color: s.color }}
                >
                  {s.value}
                </Text>
                <Text style={{ fontSize: 11, color: "#9CA3AF", marginTop: 3 }}>
                  {s.label}
                </Text>
              </View>
            ))}
          </View>

          {/* Progress */}
          <View style={{ marginBottom: 20 }}>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginBottom: 6,
              }}
            >
              <Text
                style={{ fontSize: 13, fontWeight: "600", color: "#374151" }}
              >
                تقدم الباقة
              </Text>
              <Text style={{ fontSize: 13, color: "#9CA3AF" }}>
                {Math.round(pct)}%
              </Text>
            </View>
            <View
              style={{
                height: 10,
                backgroundColor: "#E5E7EB",
                borderRadius: 5,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  height: 10,
                  borderRadius: 5,
                  backgroundColor:
                    remaining === 0
                      ? "#EF4444"
                      : remaining <= 2
                        ? "#F59E0B"
                        : "#10B981",
                  width: `${pct}%`,
                }}
              />
            </View>
          </View>

          {/* Warnings */}
          {remaining === 0 && (
            <View
              style={{
                backgroundColor: "#FEF2F2",
                borderRadius: 12,
                padding: 14,
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                marginBottom: 16,
              }}
            >
              <XCircle size={18} color="#EF4444" />
              <Text
                style={{ fontSize: 13, fontWeight: "700", color: "#991B1B" }}
              >
                انتهت الحصص — يجب التجديد
              </Text>
            </View>
          )}
          {remaining > 0 && remaining <= 2 && (
            <View
              style={{
                backgroundColor: "#FFFBEB",
                borderRadius: 12,
                padding: 14,
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                marginBottom: 16,
              }}
            >
              <AlertTriangle size={18} color="#F59E0B" />
              <Text style={{ fontSize: 13, color: "#92400E" }}>
                متبقي {remaining} حصة فقط — قريب من الانتهاء
              </Text>
            </View>
          )}

          {/* Log */}
          <Text
            style={{
              fontSize: 16,
              fontWeight: "700",
              color: "#1F2937",
              marginBottom: 12,
            }}
          >
            سجل الحصص ({records.length})
          </Text>

          {records.length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: 40 }}>
              <Calendar size={40} color="#E5E7EB" />
              <Text style={{ fontSize: 14, color: "#9CA3AF", marginTop: 12 }}>
                لا يوجد سجل حصص بعد
              </Text>
            </View>
          ) : (
            <View style={{ gap: 8 }}>
              {records.map((rec, idx) => {
                const st = statusStyle[rec.status] || {
                  bg: "#F3F4F6",
                  text: "#6B7280",
                  label: rec.status,
                };
                const dateObj = new Date(rec.date);
                return (
                  <View
                    key={rec.id || idx}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 12,
                      backgroundColor: "#F9FAFB",
                      borderRadius: 12,
                      padding: 14,
                    }}
                  >
                    <View
                      style={{
                        width: 32,
                        height: 32,
                        borderRadius: 16,
                        backgroundColor: "#E5E7EB",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 12,
                          fontWeight: "700",
                          color: "#6B7280",
                        }}
                      >
                        {idx + 1}
                      </Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontSize: 13,
                          fontWeight: "600",
                          color: "#1F2937",
                        }}
                      >
                        {dateObj.toLocaleDateString("ar-EG", {
                          weekday: "long",
                          day: "numeric",
                          month: "long",
                        })}
                      </Text>
                      <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                        {dateObj.toLocaleDateString("ar-EG")}
                      </Text>
                    </View>
                    <View
                      style={{
                        backgroundColor: st.bg,
                        paddingHorizontal: 10,
                        paddingVertical: 5,
                        borderRadius: 20,
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 12,
                          fontWeight: "700",
                          color: st.text,
                        }}
                      >
                        {st.label}
                      </Text>
                    </View>
                  </View>
                );
              })}
            </View>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

// ── Main Attendance Screen ───────────────────────────────────
export default function AttendanceScreen() {
  const insets = useSafeAreaInsets();
  const { students, attendance, markAttendance, fetchData } = useStore();
  const [date, setDate] = React.useState(
    new Date().toISOString().split("T")[0],
  );
  const [search, setSearch] = React.useState("");
  const [selectedGroup, setSelectedGroup] = React.useState("الكل");
  const [collapsed, setCollapsed] = React.useState({});
  const [historyStudent, setHistoryStudent] = React.useState(null);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const today = new Date().toISOString().split("T")[0];
  const allGroups = [
    "الكل",
    ...new Set(students.map((s) => s.group).filter(Boolean)),
  ];

  const filtered = students.filter((s) => {
    const matchGroup = selectedGroup === "الكل" || s.group === selectedGroup;
    const matchSearch =
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.code?.toLowerCase().includes(search.toLowerCase());
    return matchGroup && matchSearch;
  });

  const grouped = React.useMemo(() => {
    const g = {};
    filtered.forEach((s) => {
      const key = s.group || "بدون مجموعة";
      if (!g[key]) g[key] = [];
      g[key].push(s);
    });
    return g;
  }, [filtered]);

  const getStatusOnDate = (studentId) =>
    attendance.find(
      (a) => a.studentId === studentId && a.date?.startsWith(date),
    )?.status;

  const getSessionsUsed = (studentId) =>
    attendance.filter(
      (a) =>
        a.studentId === studentId &&
        (a.status === "present" || a.status === "late"),
    ).length;

  const handleMark = async (student, status) => {
    await markAttendance({
      studentId: student.id,
      status,
      date,
      studentName: student.name,
    });
  };

  const toggleGroup = (g) => setCollapsed((p) => ({ ...p, [g]: !p[g] }));

  const todayRecords = attendance.filter((a) => a.date?.startsWith(date));
  const presentCount = todayRecords.filter(
    (a) => a.status === "present" || a.status === "late",
  ).length;
  const absentCount = todayRecords.filter((a) => a.status === "absent").length;
  const notMarked = students.length - todayRecords.length;

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingTop: 16,
          paddingBottom: 14,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
      >
        <Text
          style={{
            fontSize: 24,
            fontWeight: "800",
            color: "#1F2937",
            marginBottom: 2,
          }}
        >
          تحضير الطلاب
        </Text>
        <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
          كل حصة تُسجَّل بتاريخها تلقائياً
        </Text>
      </View>

      {/* Date Banner */}
      <View
        style={{
          backgroundColor: "#1E40AF",
          paddingHorizontal: 20,
          paddingVertical: 16,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <Calendar size={18} color="#93C5FD" />
            <View>
              <Text style={{ fontSize: 13, fontWeight: "700", color: "#fff" }}>
                {date === today ? "اليوم" : date}
              </Text>
              <Text style={{ fontSize: 11, color: "#93C5FD" }}>
                {new Date(date + "T12:00:00").toLocaleDateString("ar-EG", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                })}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", gap: 16 }}>
            {[
              { label: "حضروا", value: presentCount, color: "#34D399" },
              { label: "غابوا", value: absentCount, color: "#F87171" },
              { label: "لم يُسجَّل", value: notMarked, color: "#FCD34D" },
            ].map((item) => (
              <View key={item.label} style={{ alignItems: "center" }}>
                <Text
                  style={{ fontSize: 20, fontWeight: "800", color: item.color }}
                >
                  {item.value}
                </Text>
                <Text style={{ fontSize: 10, color: "#93C5FD" }}>
                  {item.label}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Date nav buttons */}
        <View style={{ flexDirection: "row", gap: 8, marginTop: 14 }}>
          {[-2, -1, 0].map((offset) => {
            const d = new Date();
            d.setDate(d.getDate() + offset);
            const ds = d.toISOString().split("T")[0];
            const labels = { 0: "اليوم", "-1": "أمس", "-2": "أول أمس" };
            const isSelected = ds === date;
            return (
              <TouchableOpacity
                key={offset}
                onPress={() => setDate(ds)}
                style={{
                  flex: 1,
                  paddingVertical: 8,
                  borderRadius: 10,
                  alignItems: "center",
                  backgroundColor: isSelected
                    ? "#fff"
                    : "rgba(255,255,255,0.15)",
                }}
              >
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "700",
                    color: isSelected ? "#1E40AF" : "#93C5FD",
                  }}
                >
                  {labels[String(offset)]}
                </Text>
                <Text
                  style={{
                    fontSize: 10,
                    color: isSelected ? "#3B82F6" : "#60A5FA",
                    marginTop: 2,
                  }}
                >
                  {d.toLocaleDateString("ar-EG", {
                    day: "numeric",
                    month: "short",
                  })}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* Search */}
      <View
        style={{
          padding: 12,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#F3F4F6",
            borderRadius: 12,
            paddingHorizontal: 12,
            paddingVertical: 10,
          }}
        >
          <Search size={16} color="#9CA3AF" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="بحث بالاسم أو الكود..."
            placeholderTextColor="#9CA3AF"
            style={{
              flex: 1,
              marginRight: 8,
              fontSize: 13,
              color: "#1F2937",
              textAlign: "right",
            }}
          />
        </View>
      </View>

      {/* Group Filter */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{
          flexGrow: 0,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
        contentContainerStyle={{
          paddingHorizontal: 12,
          paddingVertical: 10,
          gap: 8,
        }}
      >
        {allGroups.map((g) => (
          <TouchableOpacity
            key={g}
            onPress={() => setSelectedGroup(g)}
            style={{
              paddingHorizontal: 14,
              paddingVertical: 7,
              borderRadius: 20,
              backgroundColor: selectedGroup === g ? "#3B82F6" : "#F3F4F6",
            }}
          >
            <Text
              style={{
                fontSize: 12,
                fontWeight: "600",
                color: selectedGroup === g ? "#fff" : "#6B7280",
              }}
            >
              {g}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 12,
          paddingBottom: insets.bottom + 90,
        }}
        showsVerticalScrollIndicator={false}
      >
        {Object.keys(grouped).length === 0 ? (
          <View style={{ alignItems: "center", paddingVertical: 60 }}>
            <Users size={48} color="#E5E7EB" />
            <Text style={{ fontSize: 15, color: "#9CA3AF", marginTop: 12 }}>
              لا يوجد طلاب
            </Text>
          </View>
        ) : (
          Object.entries(grouped).map(([groupName, groupStudents]) => {
            const isCollapsed = collapsed[groupName];
            const gPresent = groupStudents.filter((s) => {
              const st = getStatusOnDate(s.id);
              return st === "present" || st === "late";
            }).length;

            return (
              <View
                key={groupName}
                style={{
                  backgroundColor: "#fff",
                  borderRadius: 18,
                  marginBottom: 12,
                  borderWidth: 1,
                  borderColor: "#F3F4F6",
                  overflow: "hidden",
                }}
              >
                {/* Group Header */}
                <TouchableOpacity
                  onPress={() => toggleGroup(groupName)}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: 16,
                    borderBottomWidth: isCollapsed ? 0 : 1,
                    borderBottomColor: "#F3F4F6",
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 10,
                    }}
                  >
                    <View
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 12,
                        backgroundColor: "#EFF6FF",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Users size={20} color="#3B82F6" />
                    </View>
                    <View>
                      <Text
                        style={{
                          fontSize: 15,
                          fontWeight: "700",
                          color: "#1F2937",
                        }}
                      >
                        {groupName}
                      </Text>
                      <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                        {groupStudents.length} طالب ·{" "}
                        <Text style={{ color: "#10B981" }}>
                          {gPresent} حضروا
                        </Text>
                      </Text>
                    </View>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 8,
                    }}
                  >
                    <View
                      style={{
                        backgroundColor: "#EFF6FF",
                        paddingHorizontal: 10,
                        paddingVertical: 4,
                        borderRadius: 20,
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 12,
                          fontWeight: "700",
                          color: "#3B82F6",
                        }}
                      >
                        {gPresent}/{groupStudents.length}
                      </Text>
                    </View>
                    {isCollapsed ? (
                      <ChevronDown size={18} color="#9CA3AF" />
                    ) : (
                      <ChevronUp size={18} color="#9CA3AF" />
                    )}
                  </View>
                </TouchableOpacity>

                {/* Students */}
                {!isCollapsed && (
                  <View style={{ padding: 10, gap: 8 }}>
                    {groupStudents.map((student) => {
                      const pkg = Number(student.sessionPackage) || 8;
                      const used = getSessionsUsed(student.id);
                      const remaining = Math.max(0, pkg - used);
                      const status = getStatusOnDate(student.id);
                      const isFinished = remaining === 0;
                      const isLow = !isFinished && remaining <= 2;
                      const pct = Math.min(100, (used / pkg) * 100);

                      const cardBg =
                        status === "present"
                          ? "#F0FDF4"
                          : status === "late"
                            ? "#FFFBEB"
                            : status === "absent"
                              ? "#FEF2F2"
                              : "#F9FAFB";

                      const cardBorder =
                        status === "present"
                          ? "#BBF7D0"
                          : status === "late"
                            ? "#FDE68A"
                            : status === "absent"
                              ? "#FECACA"
                              : "#F3F4F6";

                      return (
                        <View
                          key={student.id}
                          style={{
                            backgroundColor: cardBg,
                            borderRadius: 14,
                            padding: 14,
                            borderWidth: 1,
                            borderColor: cardBorder,
                          }}
                        >
                          {/* Student info row */}
                          <View
                            style={{
                              flexDirection: "row",
                              alignItems: "center",
                              justifyContent: "space-between",
                              marginBottom: 10,
                            }}
                          >
                            <View
                              style={{
                                flexDirection: "row",
                                alignItems: "center",
                                gap: 10,
                                flex: 1,
                              }}
                            >
                              <View
                                style={{
                                  width: 40,
                                  height: 40,
                                  borderRadius: 20,
                                  backgroundColor: "#3B82F6",
                                  alignItems: "center",
                                  justifyContent: "center",
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 17,
                                    fontWeight: "800",
                                    color: "#fff",
                                  }}
                                >
                                  {student.name?.[0]}
                                </Text>
                              </View>
                              <View style={{ flex: 1 }}>
                                <Text
                                  style={{
                                    fontSize: 14,
                                    fontWeight: "700",
                                    color: "#1F2937",
                                  }}
                                >
                                  {student.name}
                                </Text>
                                <Text
                                  style={{ fontSize: 11, color: "#9CA3AF" }}
                                >
                                  {student.code} · {student.grade}
                                </Text>
                              </View>
                            </View>
                            {status ? (
                              <View
                                style={{
                                  paddingHorizontal: 10,
                                  paddingVertical: 4,
                                  borderRadius: 20,
                                  backgroundColor:
                                    status === "present"
                                      ? "#D1FAE5"
                                      : status === "late"
                                        ? "#FED7AA"
                                        : "#FEE2E2",
                                }}
                              >
                                <Text
                                  style={{
                                    fontSize: 11,
                                    fontWeight: "700",
                                    color:
                                      status === "present"
                                        ? "#065F46"
                                        : status === "late"
                                          ? "#92400E"
                                          : "#991B1B",
                                  }}
                                >
                                  {status === "present"
                                    ? "✅ حاضر"
                                    : status === "late"
                                      ? "⏱ متأخر"
                                      : "❌ غائب"}
                                </Text>
                              </View>
                            ) : null}
                          </View>

                          {/* Sessions progress */}
                          <View style={{ marginBottom: 10 }}>
                            <View
                              style={{
                                flexDirection: "row",
                                justifyContent: "space-between",
                                marginBottom: 5,
                              }}
                            >
                              <Text
                                style={{
                                  fontSize: 11,
                                  fontWeight: "700",
                                  color: isFinished
                                    ? "#EF4444"
                                    : isLow
                                      ? "#F59E0B"
                                      : "#10B981",
                                }}
                              >
                                {isFinished
                                  ? "انتهت الحصص!"
                                  : `متبقي ${remaining} حصة`}
                              </Text>
                              <View
                                style={{
                                  flexDirection: "row",
                                  alignItems: "center",
                                  gap: 6,
                                }}
                              >
                                <Text
                                  style={{ fontSize: 11, color: "#9CA3AF" }}
                                >
                                  {used}/{pkg}
                                </Text>
                                <TouchableOpacity
                                  onPress={() => setHistoryStudent(student)}
                                >
                                  <History size={14} color="#3B82F6" />
                                </TouchableOpacity>
                              </View>
                            </View>
                            <View
                              style={{
                                height: 6,
                                backgroundColor: "#E5E7EB",
                                borderRadius: 3,
                                overflow: "hidden",
                              }}
                            >
                              <View
                                style={{
                                  height: 6,
                                  borderRadius: 3,
                                  backgroundColor: isFinished
                                    ? "#EF4444"
                                    : isLow
                                      ? "#F59E0B"
                                      : "#10B981",
                                  width: `${pct}%`,
                                }}
                              />
                            </View>
                          </View>

                          {/* Buttons */}
                          <View style={{ flexDirection: "row", gap: 8 }}>
                            {[
                              {
                                s: "present",
                                label: "حاضر",
                                activeBg: "#10B981",
                                activeText: "#fff",
                                inactiveBg: "#D1FAE5",
                                inactiveText: "#065F46",
                                Icon: CheckCircle2,
                              },
                              {
                                s: "late",
                                label: "متأخر",
                                activeBg: "#F59E0B",
                                activeText: "#fff",
                                inactiveBg: "#FEF3C7",
                                inactiveText: "#92400E",
                                Icon: Clock,
                              },
                              {
                                s: "absent",
                                label: "غائب",
                                activeBg: "#EF4444",
                                activeText: "#fff",
                                inactiveBg: "#FEE2E2",
                                inactiveText: "#991B1B",
                                Icon: XCircle,
                              },
                            ].map(
                              ({
                                s,
                                label,
                                activeBg,
                                activeText,
                                inactiveBg,
                                inactiveText,
                                Icon,
                              }) => (
                                <TouchableOpacity
                                  key={s}
                                  onPress={() => handleMark(student, s)}
                                  style={{
                                    flex: 1,
                                    paddingVertical: 10,
                                    borderRadius: 10,
                                    flexDirection: "row",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    gap: 5,
                                    backgroundColor:
                                      status === s ? activeBg : inactiveBg,
                                  }}
                                >
                                  <Icon
                                    size={14}
                                    color={
                                      status === s ? activeText : inactiveText
                                    }
                                  />
                                  <Text
                                    style={{
                                      fontSize: 12,
                                      fontWeight: "700",
                                      color:
                                        status === s
                                          ? activeText
                                          : inactiveText,
                                    }}
                                  >
                                    {label}
                                  </Text>
                                </TouchableOpacity>
                              ),
                            )}
                          </View>
                        </View>
                      );
                    })}
                  </View>
                )}
              </View>
            );
          })
        )}
      </ScrollView>

      <HistoryModal
        visible={!!historyStudent}
        student={historyStudent}
        attendance={attendance}
        onClose={() => setHistoryStudent(null)}
      />
    </View>
  );
}
