import { create } from "zustand";
import AsyncStorage from "@react-native-async-storage/async-storage";

const KEYS = {
  students: "sms_students",
  attendance: "sms_attendance",
  payments: "sms_payments",
  exams: "sms_exams",
};

const save = async (key, data) => {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error("Save error", e);
  }
};

const load = async (key) => {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

const generateCode = (students) => {
  const max = students.reduce((m, s) => {
    const n = parseInt(s.code?.replace("ST-", "") || "0");
    return Math.max(m, isNaN(n) ? 0 : n);
  }, 0);
  return `ST-${String(max + 1).padStart(4, "0")}`;
};

export const useStore = create((set, get) => ({
  students: [],
  attendance: [],
  payments: [],
  exams: [],
  loading: false,

  fetchData: async () => {
    set({ loading: true });
    const [students, attendance, payments, exams] = await Promise.all([
      load(KEYS.students),
      load(KEYS.attendance),
      load(KEYS.payments),
      load(KEYS.exams),
    ]);
    set({ students, attendance, payments, exams, loading: false });
  },

  // ── Students ──────────────────────────────────────────────
  addStudent: async (student) => {
    const students = get().students;
    const code = generateCode(students);
    const newStudent = {
      ...student,
      id: Date.now(),
      code,
      createdAt: new Date().toISOString(),
    };
    const updated = [...students, newStudent];
    set({ students: updated });
    await save(KEYS.students, updated);
    return newStudent;
  },

  updateStudent: async (student) => {
    const updated = get().students.map((s) =>
      s.id === student.id ? student : s,
    );
    set({ students: updated });
    await save(KEYS.students, updated);
  },

  deleteStudent: async (id) => {
    const updated = get().students.filter((s) => s.id !== id);
    set({ students: updated });
    await save(KEYS.students, updated);
  },

  // ── Attendance ────────────────────────────────────────────
  markAttendance: async ({ studentId, status, date, studentName }) => {
    const all = get().attendance;
    const existing = all.find(
      (a) => a.studentId === studentId && a.date.startsWith(date),
    );
    let updated;
    if (existing) {
      updated = all.map((a) =>
        a.id === existing.id ? { ...existing, status } : a,
      );
    } else {
      const newRecord = {
        id: Date.now(),
        studentId,
        studentName,
        status,
        date: new Date(date + "T12:00:00").toISOString(),
      };
      updated = [...all, newRecord];
    }
    set({ attendance: updated });
    await save(KEYS.attendance, updated);
  },

  // ── Payments ──────────────────────────────────────────────
  addPayment: async (payment) => {
    const newPayment = {
      ...payment,
      id: Date.now(),
      date: new Date().toISOString(),
    };
    const updated = [...get().payments, newPayment];
    set({ payments: updated });
    await save(KEYS.payments, updated);
  },

  deletePayment: async (id) => {
    const updated = get().payments.filter((p) => p.id !== id);
    set({ payments: updated });
    await save(KEYS.payments, updated);
  },

  // ── Exams ─────────────────────────────────────────────────
  addExam: async (exam) => {
    const newExam = {
      ...exam,
      id: Date.now(),
      createdAt: new Date().toISOString(),
    };
    const updated = [...get().exams, newExam];
    set({ exams: updated });
    await save(KEYS.exams, updated);
  },

  deleteExam: async (id) => {
    const updated = get().exams.filter((e) => e.id !== id);
    set({ exams: updated });
    await save(KEYS.exams, updated);
  },

  // ── Backup ────────────────────────────────────────────────
  exportBackup: async () => {
    const { students, attendance, payments, exams } = get();
    return JSON.stringify(
      {
        version: "1.0",
        exportDate: new Date().toISOString(),
        students,
        attendance,
        payments,
        exams,
      },
      null,
      2,
    );
  },

  importBackup: async (jsonString) => {
    const data = JSON.parse(jsonString);
    const s = data.students || [];
    const a = data.attendance || [];
    const p = data.payments || [];
    const e = data.exams || [];
    await Promise.all([
      save(KEYS.students, s),
      save(KEYS.attendance, a),
      save(KEYS.payments, p),
      save(KEYS.exams, e),
    ]);
    set({ students: s, attendance: a, payments: p, exams: e });
  },
}));
