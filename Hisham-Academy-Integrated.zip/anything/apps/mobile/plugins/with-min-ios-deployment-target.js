const fs = require('node:fs');
const path = require('node:path');
const { withDangerousMod } = require('expo/config-plugins');

// Xcode 27 rejects a pod whose IPHONEOS_DEPLOYMENT_TARGET is below 15.0, and
// third-party podspecs still declare 9.0-13.4 (PurchasesHybridCommon 12.0,
// ReachabilitySwift 9.0, the reanimated/worklets podspecs). React Native's
// own post_install raises its pod library targets, but the Pods project
// itself, its aggregate targets and the resource bundles keep whatever the
// podspec asked for, which is what the image rejects. Raise every build
// configuration in the Pods project instead.
//
// Never lower a target, and never overwrite an xcconfig reference: the
// project-level value this hook writes is what `$(inherited)` resolves to.
const MIN_DEPLOYMENT_TARGET = '15.1';
const TAG = 'anything-min-ios-deployment-target';
const ANCHOR = 'post_install do |installer|';

const HOOK = `
    # @generated begin ${TAG} - do not modify
    anything_min_ios_target = '${MIN_DEPLOYMENT_TARGET}'
    anything_raise_ios_target = lambda do |build_configuration|
      current = build_configuration.build_settings['IPHONEOS_DEPLOYMENT_TARGET']
      next unless current.nil? || current.is_a?(String)
      if current.is_a?(String)
        next if current.include?('$(')
        next if current.to_f >= anything_min_ios_target.to_f
      end
      build_configuration.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = anything_min_ios_target
    end
    installer.pods_project.build_configurations.each(&anything_raise_ios_target)
    installer.pods_project.targets.each do |target|
      target.build_configurations.each(&anything_raise_ios_target)
    end
    # @generated end ${TAG}
`;

/**
 * Insert the hook at the top of the Podfile's existing post_install block.
 * Everything already in that block only raises deployment targets too, so
 * running first is equivalent to running last. A Podfile without the block,
 * or one already carrying the hook, is returned untouched.
 */
function patchPodfile(contents) {
  if (contents.includes(TAG)) {
    return contents;
  }
  const anchorIndex = contents.indexOf(ANCHOR);
  if (anchorIndex === -1) {
    return contents;
  }
  const insertAt = anchorIndex + ANCHOR.length;
  return contents.slice(0, insertAt) + HOOK + contents.slice(insertAt);
}

const withMinIosDeploymentTarget = (config) =>
  withDangerousMod(config, [
    'ios',
    (dangerousConfig) => {
      const podfilePath = path.join(
        dangerousConfig.modRequest.platformProjectRoot,
        'Podfile'
      );
      try {
        const contents = fs.readFileSync(podfilePath, 'utf8');
        const patched = patchPodfile(contents);
        if (patched !== contents) {
          fs.writeFileSync(podfilePath, patched);
        }
      } catch (error) {
        // A Podfile we cannot read or write builds exactly as it did before
        // this plugin existed, so never fail prebuild over it.
        console.warn(
          `[${TAG}] left the Podfile untouched: ${error.message}`
        );
      }
      return dangerousConfig;
    },
  ]);

module.exports = withMinIosDeploymentTarget;
module.exports.patchPodfile = patchPodfile;
module.exports.MIN_DEPLOYMENT_TARGET = MIN_DEPLOYMENT_TARGET;
module.exports.TAG = TAG;
