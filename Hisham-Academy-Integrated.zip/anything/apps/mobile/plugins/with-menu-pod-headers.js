const fs = require('node:fs');
const path = require('node:path');
const { withDangerousMod } = require('expo/config-plugins');

// @react-native-menu/menu 2.0.0 imports two React-Core headers with quoted
// includes. Both templates build pods with `useFrameworks: "static"`, where
// those headers only resolve as <React/…>, so on the SDK 58 / RN 0.88 /
// Xcode 27 image the pod stops compiling at MenuViewManager.mm:3 with
// `'RCTBridge.h' file not found`. 2.0.0 is still the latest release
// upstream, so there is no version to bump to.
//
// Both templates also carry an install-time patch for this (patch-package on
// V1, a yarn `patch:` resolution on V2). An install-time patch only applies
// if the manifest driving it survives, and on a publish it often does not: a
// stored project's package.json replaces the template's, and EAS installs
// from the stored one. Rewriting the headers during prebuild is independent
// of all of that — it runs on the EAS worker, after install and before the
// pod compiles, whatever the install did.
const TAG = 'anything-menu-pod-headers';

const MENU_PACKAGE = '@react-native-menu/menu';

const MANAGER_SOURCE = 'ios/MenuViewManager.mm';
const FABRIC_VIEW_SOURCE = 'ios/NewArch/MenuView.mm';

// The Fabric plugins header is generated into the app's own Pods target on
// the new architecture and is absent on the old one, so this keeps the
// quoted include as the fallback instead of replacing it outright.
const FABRIC_PLUGINS_IMPORT = [
  '#if __has_include(<React/RCTFabricComponentsPlugins.h>)',
  '#import <React/RCTFabricComponentsPlugins.h>',
  '#else',
  '#import "RCTFabricComponentsPlugins.h"',
  '#endif',
].join('\n');

/** Rewrite `#import "RCTBridge.h"` as a framework import. Idempotent. */
function patchMenuViewManager(contents) {
  return contents.replace(
    /^#import "RCTBridge\.h"$/m,
    '#import <React/RCTBridge.h>'
  );
}

/** Guard `#import "RCTFabricComponentsPlugins.h"`. Idempotent. */
function patchFabricMenuView(contents) {
  if (contents.includes('__has_include(<React/RCTFabricComponentsPlugins.h>)')) {
    return contents;
  }
  return contents.replace(
    /^#import "RCTFabricComponentsPlugins\.h"$/m,
    FABRIC_PLUGINS_IMPORT
  );
}

const SOURCE_PATCHES = [
  { source: MANAGER_SOURCE, patch: patchMenuViewManager },
  { source: FABRIC_VIEW_SOURCE, patch: patchFabricMenuView },
];

/**
 * Where the installed pod's sources live, or null when the app does not
 * depend on the menu package at all (most do not).
 */
function resolveMenuPodRoot(projectRoot) {
  try {
    return path.dirname(
      require.resolve(`${MENU_PACKAGE}/package.json`, { paths: [projectRoot] })
    );
  } catch (_error) {
    return null;
  }
}

/**
 * Rewrite in place. V2 installs with `nmMode: hardlinks-global`, so the file
 * in node_modules is a hardlink into yarn's global store and writing through
 * it would edit every other project sharing that inode. Unlink first to break
 * the link, then write our own copy.
 */
function rewriteSource(filePath, patch) {
  const contents = fs.readFileSync(filePath, 'utf8');
  const patched = patch(contents);
  if (patched === contents) {
    return false;
  }
  fs.rmSync(filePath);
  fs.writeFileSync(filePath, patched);
  return true;
}

const withMenuPodHeaders = (config) =>
  withDangerousMod(config, [
    'ios',
    (dangerousConfig) => {
      const podRoot = resolveMenuPodRoot(
        dangerousConfig.modRequest.projectRoot
      );
      if (!podRoot) {
        return dangerousConfig;
      }
      for (const { source, patch } of SOURCE_PATCHES) {
        try {
          rewriteSource(path.join(podRoot, source), patch);
        } catch (error) {
          // A source we cannot read or write compiles exactly as it did
          // before this plugin existed, so never fail prebuild over it.
          console.warn(`[${TAG}] left ${source} untouched: ${error.message}`);
        }
      }
      return dangerousConfig;
    },
  ]);

module.exports = withMenuPodHeaders;
module.exports.patchMenuViewManager = patchMenuViewManager;
module.exports.patchFabricMenuView = patchFabricMenuView;
module.exports.resolveMenuPodRoot = resolveMenuPodRoot;
module.exports.rewriteSource = rewriteSource;
module.exports.MENU_PACKAGE = MENU_PACKAGE;
module.exports.MANAGER_SOURCE = MANAGER_SOURCE;
module.exports.FABRIC_VIEW_SOURCE = FABRIC_VIEW_SOURCE;
module.exports.TAG = TAG;
