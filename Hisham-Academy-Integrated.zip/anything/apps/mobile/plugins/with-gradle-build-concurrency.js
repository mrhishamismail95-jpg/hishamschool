const {
  withGradleProperties,
  withProjectBuildGradle,
} = require('expo/config-plugins');

// Android builds on the EAS worker were dying with the Gradle daemon
// "disappearing unexpectedly" and no named compile error (2026-11-11: seven
// consecutive failures on one project). A daemon that vanishes without a
// Java OOM is the container killing it, which means the JVMs the build runs
// in parallel -- the Gradle daemon, the Kotlin daemon, and the per-module
// workers -- add up to more than the runner has. Raising -Xmx makes that
// worse, so cap the concurrency and the Kotlin daemon's heap instead and
// leave Expo's own org.gradle.jvmargs alone.
// R8 is the task the kills actually land on. Expo SDK 58's android template is
// the first to ship `android.enableMinifyInReleaseBuilds=true` (SDK 54 and 57
// have no such key, so `:app:minifyReleaseWithR8` never ran before), which
// lines up with the daemon deaths starting right after the SDK 58 / RN 0.88
// upgrade and with every failing build reaching the end of the native compiles
// before dying. Turn it back off: a generated app gets no obfuscation and a
// larger bundle, which is what the SDK 54 tree that still ships clean has
// always produced.
const TAG = 'anything-gradle-build-concurrency';

const PROPERTIES = {
  'org.gradle.parallel': 'false',
  'org.gradle.workers.max': '2',
  'kotlin.daemon.jvmargs': '-Xmx1g -XX:MaxMetaspaceSize=512m',
  'android.enableMinifyInReleaseBuilds': 'false',
  // AGP fails the build outright when the resource shrinker is on without
  // minification, so this one follows it down rather than being left to
  // whatever a project's expo-build-properties asked for.
  'android.enableShrinkResourcesInReleaseBuilds': 'false',
};

/**
 * Drop whatever `expo prebuild` wrote for these keys and re-append them under
 * a marker comment, so the generated gradle.properties says where they came
 * from and running twice over its own output changes nothing. Every other
 * item prebuild produced is passed through untouched.
 */
function applyProperties(items) {
  const kept = items.filter((item) => {
    if (item.type === 'comment') {
      return item.value !== TAG;
    }
    return !(item.key in PROPERTIES);
  });
  const owned = Object.entries(PROPERTIES).map(([key, value]) => ({
    type: 'property',
    key,
    value,
  }));
  return [...kept, { type: 'comment', value: TAG }, ...owned];
}

// The properties above bound how many Gradle *tasks* and worker JVMs run at
// once. Neither bounds the parallelism *inside* one task, which is where the
// kills actually land: on `:react-native-worklets` / `:expo-updates`
// `buildCMakeRelWithDebInfo`, AGP's externalNativeBuild shells out to ninja,
// and ninja picks its own job count from the core count. Several C++ compiles
// of that size at once is the spike the clamp cannot reach.
//
// CMake's own job pools bound it at the only place that sees it. Setting
// CMAKE_JOB_POOLS and CMAKE_JOB_POOL_{COMPILE,LINK} at configure time writes
// the pools into the generated build.ninja, so ninja honours them whatever -j
// it was invoked with. This costs build time, not money, and keeps the
// `medium` worker.
const CMAKE_JOB_POOL_ARGUMENTS = [
  '-DCMAKE_JOB_POOLS=compile=2;link=1',
  '-DCMAKE_JOB_POOL_COMPILE=compile',
  '-DCMAKE_JOB_POOL_LINK=link',
];

const BLOCK_START = `// ${TAG}`;
const BLOCK_END = `// ${TAG}-end`;

// Fail-soft on purpose. A module whose android extension does not look the way
// this expects keeps building exactly as it does today rather than failing a
// build that would otherwise pass -- the pools are a headroom optimization, not
// a correctness requirement. Names are prefixed so nothing here can collide
// with a declaration already in the project's root build.gradle.
const BLOCK = [
  BLOCK_START,
  '// Bound the C++ compile fan-out inside a single externalNativeBuild task;',
  '// org.gradle.parallel and org.gradle.workers.max do not reach ninja.',
  'allprojects { anythingProject ->',
  "  ['com.android.application', 'com.android.library'].each { anythingPluginId ->",
  '    anythingProject.plugins.withId(anythingPluginId) {',
  '      try {',
  '        anythingProject.android.defaultConfig.externalNativeBuild.cmake.arguments(',
  ...CMAKE_JOB_POOL_ARGUMENTS.map(
    (argument, index) =>
      `          '${argument}'${index === CMAKE_JOB_POOL_ARGUMENTS.length - 1 ? '' : ','}`
  ),
  '        )',
  '      } catch (Throwable anythingError) {',
  '        anythingProject.logger.warn(',
  `          '${TAG}: left ' + anythingProject.path + ' CMake job pools unset',`,
  '          anythingError',
  '        )',
  '      }',
  '    }',
  '  }',
  '}',
  BLOCK_END,
];

/**
 * Append the job-pool block to the root build.gradle, replacing an earlier copy
 * of itself if one is already there. `allprojects` only registers callbacks, so
 * appending is enough: subprojects are evaluated after the root project, and
 * `plugins.withId` fires when each one applies the Android plugin.
 */
function applyProjectBuildGradle(contents) {
  const kept = [];
  let insideBlock = false;
  for (const line of contents.split('\n')) {
    if (line.trim() === BLOCK_START) {
      insideBlock = true;
      continue;
    }
    if (insideBlock) {
      insideBlock = line.trim() !== BLOCK_END;
      continue;
    }
    kept.push(line);
  }
  while (kept.length > 0 && kept[kept.length - 1].trim() === '') {
    kept.pop();
  }
  return [...kept, '', ...BLOCK, ''].join('\n');
}

/**
 * Groovy only. Expo's template ships a Groovy root build.gradle; a project that
 * has moved to the Kotlin DSL gets left alone rather than handed Groovy syntax.
 */
function applyBuildGradle({ contents, language }) {
  if (language !== 'groovy') {
    return contents;
  }
  return applyProjectBuildGradle(contents);
}

const withGradleBuildConcurrency = (config) => {
  const withProperties = withGradleProperties(config, (gradleConfig) => ({
    ...gradleConfig,
    modResults: applyProperties(gradleConfig.modResults),
  }));
  return withProjectBuildGradle(withProperties, (gradleConfig) => ({
    ...gradleConfig,
    modResults: {
      ...gradleConfig.modResults,
      contents: applyBuildGradle(gradleConfig.modResults),
    },
  }));
};

module.exports = withGradleBuildConcurrency;
module.exports.applyProperties = applyProperties;
module.exports.applyProjectBuildGradle = applyProjectBuildGradle;
module.exports.applyBuildGradle = applyBuildGradle;
module.exports.CMAKE_JOB_POOL_ARGUMENTS = CMAKE_JOB_POOL_ARGUMENTS;
module.exports.PROPERTIES = PROPERTIES;
module.exports.TAG = TAG;
