const TEACHER_SESSION_KEY = "teacher_session_v1";

// findTeacher is now async and uses the DB API
export async function findTeacher(email, password) {
  try {
    const res = await fetch("/api/academy/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role: "teacher", email, password }),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error || "فشل تسجيل الدخول" };
    return data.user;
  } catch {
    return { error: "فشل الاتصال بالخادم" };
  }
}

export function getTeacherSession() {
  if (typeof window === "undefined") return null;
  try {
    return JSON.parse(sessionStorage.getItem(TEACHER_SESSION_KEY) || "null");
  } catch {
    return null;
  }
}

export function setTeacherSession(data) {
  sessionStorage.setItem(TEACHER_SESSION_KEY, JSON.stringify(data));
}

export function clearTeacherSession() {
  sessionStorage.removeItem(TEACHER_SESSION_KEY);
}
