// ══════════════════════════════════════════════════════
//  Portal & Registration Settings (localStorage)
// ══════════════════════════════════════════════════════

const KEY = "academy_portal_settings_v1";

export const DEFAULT_SETTINGS = {
  registrationOpen: true,
  portals: {
    teacher: true,
    student: true,
    parent: true,
  },
  prices: [
    {
      id: 1,
      label: "باقة 8 حصص",
      price: 400,
      discount: 0,
      note: "الباقة الشهرية العادية",
    },
    {
      id: 2,
      label: "باقة 12 حصة",
      price: 550,
      discount: 50,
      note: "وفر 50 جنيه",
    },
    {
      id: 3,
      label: "باقة 16 حصة",
      price: 700,
      discount: 100,
      note: "الأوفر — وفر 100 جنيه",
    },
  ],
  links: [
    {
      id: 1,
      label: "مجموعة الواتساب",
      url: "https://chat.whatsapp.com/CPbJ8ZCrXBU1EbkDzqYuYd",
      icon: "whatsapp",
      public: true,
    },
    {
      id: 2,
      label: "قناة تيليجرام",
      url: "https://t.me/+201550012054",
      icon: "telegram",
      public: true,
    },
  ],
  whatsappGroup: "https://chat.whatsapp.com/CPbJ8ZCrXBU1EbkDzqYuYd",
  telegramChannel: "https://t.me/+201550012054",
  academyName: "الأكاديمية التعليمية",
  adminPhone: "201550012054",
};

export function getSettings() {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings) {
  try {
    localStorage.setItem(KEY, JSON.stringify(settings));
  } catch {}
}

export function isRegistrationOpen() {
  return getSettings().registrationOpen !== false;
}

export function isPortalOpen(portal) {
  const s = getSettings();
  return s.portals?.[portal] !== false;
}

export function getPrices() {
  return getSettings().prices || DEFAULT_SETTINGS.prices;
}

export function getLinks() {
  return getSettings().links || DEFAULT_SETTINGS.links;
}
