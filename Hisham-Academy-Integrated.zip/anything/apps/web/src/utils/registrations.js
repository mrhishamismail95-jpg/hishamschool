export function getRegistrations() {
  try {
    return JSON.parse(localStorage.getItem("pending_registrations") || "[]");
  } catch {
    return [];
  }
}

export function saveRegistrations(regs) {
  localStorage.setItem("pending_registrations", JSON.stringify(regs));
}
