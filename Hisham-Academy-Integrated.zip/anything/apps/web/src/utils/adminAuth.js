// ── Default Credentials (stored/overridable in localStorage) ─────────────────
const DEFAULT_ADMIN = {
  email: "admin@school.com",
  password: "School@2024#Admin",
};
const SESSION_KEY = "admin_session_v1";
const CREDS_KEY = "admin_credentials_v1";

export function getCredentials() {
  try {
    const stored = localStorage.getItem(CREDS_KEY);
    return stored ? JSON.parse(stored) : DEFAULT_ADMIN;
  } catch {
    return DEFAULT_ADMIN;
  }
}

export function saveCredentials(creds) {
  localStorage.setItem(CREDS_KEY, JSON.stringify(creds));
}

export function getSession() {
  try {
    return JSON.parse(sessionStorage.getItem(SESSION_KEY) || "null");
  } catch {
    return null;
  }
}

export function setSession(data) {
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(data));
}

export function clearSession() {
  sessionStorage.removeItem(SESSION_KEY);
}
