import { create } from "zustand";

// ── API helpers ────────────────────────────────────────────────────────────────
async function callApi(path, options = {}) {
  const res = await fetch(`/api/academy${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `خطأ (${res.status})`);
  return data;
}
const apiGet = (path, params = {}) => {
  const cleaned = Object.fromEntries(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== ""),
  );
  const q = new URLSearchParams(cleaned).toString();
  return callApi(q ? `${path}?${q}` : path);
};
const apiPost = (path, body) =>
  callApi(path, { method: "POST", body: JSON.stringify(body) });
const apiPut = (path, body) =>
  callApi(path, { method: "PUT", body: JSON.stringify(body) });
const apiDel = (path) => callApi(path, { method: "DELETE" });

// Normalizers for consistent shape
const normAtt = (a) => ({
  ...a,
  studentId: a.student_id ?? a.studentId,
  date: (a.date || "").slice(0, 10),
});
const normPay = (p) => ({
  ...p,
  studentId: p.student_id ?? p.studentId,
  date: p.created_at || p.date,
});
const normNotif = (n) => ({ ...n, read: n.is_read ?? n.read });
const normExam = (e) => ({
  ...e,
  scores: Array.isArray(e.scores)
    ? Object.fromEntries(e.scores.map((s) => [s.student_id, s.score]))
    : e.scores || {},
});
const normHW = (h) => ({
  ...h,
  submissions: Array.isArray(h.submissions)
    ? h.submissions.map((s) => ({
        studentId: s.student_id ?? s.studentId,
        submittedAt: s.submitted_at ?? s.submittedAt,
      }))
    : h.submissions || [],
});

// ── Zustand Store ──────────────────────────────────────────────────────────────
export const useStore = create((set, get) => ({
  students: [],
  attendance: [],
  payments: [],
  exams: [],
  groups: [],
  homework: [],
  notifications: [],
  packages: [],
  settings: {},
  loading: false,
  error: null,

  fetchData: async () => {
    set({ loading: true, error: null });
    try {
      const results = await Promise.allSettled([
        apiGet("/students"),
        apiGet("/attendance"),
        apiGet("/payments"),
        apiGet("/exams"),
        apiGet("/groups", { active: "false" }),
        apiGet("/homework"),
        apiGet("/notifications"),
        apiGet("/packages"),
        apiGet("/settings"),
      ]);
      const ok = (r, key, fallback = []) =>
        r.status === "fulfilled" ? (r.value[key] ?? fallback) : fallback;
      set({
        students: ok(results[0], "students"),
        attendance: ok(results[1], "attendance").map(normAtt),
        payments: ok(results[2], "payments").map(normPay),
        exams: ok(results[3], "exams").map(normExam),
        groups: ok(results[4], "groups"),
        homework: ok(results[5], "homework").map(normHW),
        notifications: ok(results[6], "notifications").map(normNotif),
        packages: ok(results[7], "packages"),
        settings:
          results[8].status === "fulfilled"
            ? results[8].value.settings || {}
            : {},
        loading: false,
      });
    } catch (err) {
      console.error("fetchData:", err);
      set({ loading: false, error: err.message });
    }
  },

  // ── Students ───────────────────────────────────────────────────────────────
  addStudent: async (data) => {
    const { student } = await apiPost("/students", {
      name: data.name,
      phone: data.phone,
      grade: data.grade,
      gradeCategory: data.gradeCategory || data.grade_category,
      groupId: data.groupId || data.group_id || null,
      groupName: data.groupName || data.group || data.group_name,
      packageId: data.packageId || data.package_id || null,
      packageName: data.packageName || data.package_name,
      price: data.price,
      sessionPackage: data.sessionPackage || data.session_package || 8,
      parentName: data.parentName || data.parent_name,
      parentPhone: data.parentPhone || data.parent_phone,
      parentEmail: data.parentEmail || data.parent_email,
      notes: data.notes,
      status: data.status || "active",
    });
    set((s) => ({ students: [student, ...s.students] }));
    return student;
  },

  updateStudent: async (data) => {
    const { student } = await apiPut(`/students/${data.id}`, {
      name: data.name,
      phone: data.phone,
      grade: data.grade,
      gradeCategory: data.gradeCategory || data.grade_category,
      groupId: data.groupId ?? data.group_id,
      groupName: data.groupName || data.group || data.group_name,
      packageId: data.packageId ?? data.package_id,
      packageName: data.packageName || data.package_name,
      price: data.price,
      sessionPackage: data.sessionPackage || data.session_package,
      parentName: data.parentName || data.parent_name,
      parentPhone: data.parentPhone || data.parent_phone,
      parentEmail: data.parentEmail || data.parent_email,
      notes: data.notes,
      status: data.status,
    });
    set((s) => ({
      students: s.students.map((st) => (st.id === student.id ? student : st)),
    }));
    return student;
  },

  deleteStudent: async (id) => {
    await apiDel(`/students/${id}`);
    set((s) => ({ students: s.students.filter((st) => st.id !== id) }));
  },

  // ── Attendance ─────────────────────────────────────────────────────────────
  markAttendance: async (record) => {
    const { record: saved } = await apiPost("/attendance", {
      studentId: record.studentId,
      groupId: record.groupId || null,
      date: (record.date || "").slice(0, 10),
      status: record.status,
      notes: record.notes,
    });
    const normalized = normAtt(saved);
    set((s) => {
      const idx = s.attendance.findIndex(
        (a) =>
          a.studentId === normalized.studentId && a.date === normalized.date,
      );
      const updated = [...s.attendance];
      if (idx >= 0) updated[idx] = normalized;
      else updated.unshift(normalized);
      return { attendance: updated };
    });
    return normalized;
  },

  // ── Payments ───────────────────────────────────────────────────────────────
  addPayment: async (data) => {
    const { payment } = await apiPost("/payments", {
      studentId: data.studentId || data.student_id,
      amount: data.amount,
      paymentMethod: data.method || data.paymentMethod || "cash",
      paymentMonth:
        data.month || data.paymentMonth || new Date().toISOString().slice(0, 7),
      packageId: data.packageId || null,
      notes: data.notes,
    });
    const normalized = normPay(payment);
    set((s) => ({ payments: [normalized, ...s.payments] }));
    return normalized;
  },

  deletePayment: async (id) => {
    await apiDel(`/payments?id=${id}`);
    set((s) => ({ payments: s.payments.filter((p) => p.id !== id) }));
  },

  // ── Exams ──────────────────────────────────────────────────────────────────
  addExam: async (data) => {
    const { exam } = await apiPost("/exams", {
      title: data.title,
      subject: data.subject,
      grade: data.grade,
      groupId: data.groupId || data.group_id || null,
      groupName: data.groupName || data.group_name || data.group,
      examDate: data.examDate || data.date,
      maxScore: data.maxScore || data.max_score || 100,
      notes: data.notes,
    });
    set((s) => ({ exams: [normExam(exam), ...s.exams] }));
    return exam;
  },

  updateExam: async (data) => {
    const { exam } = await apiPut(`/exams/${data.id}`, data);
    const normalized = {
      ...normExam(exam),
      scores: data.scores || exam.scores || {},
    };
    set((s) => ({
      exams: s.exams.map((e) => (e.id === exam.id ? normalized : e)),
    }));
    return normalized;
  },

  deleteExam: async (id) => {
    await apiDel(`/exams/${id}`);
    set((s) => ({ exams: s.exams.filter((e) => e.id !== id) }));
  },

  // ── Homework ───────────────────────────────────────────────────────────────
  addHomework: async (data) => {
    const { homework } = await apiPost("/homework", {
      title: data.title,
      subject: data.subject,
      grade: data.grade,
      groupId: data.groupId || data.group_id || null,
      groupName: data.groupName || data.group_name || data.group,
      description: data.description,
      dueDate: data.dueDate || data.due_date,
    });
    set((s) => ({ homework: [normHW(homework), ...s.homework] }));
    return homework;
  },

  updateHomework: async (data) => {
    await apiPut(`/homework/${data.id}`, data);
    set((s) => ({
      homework: s.homework.map((h) =>
        h.id === data.id ? normHW({ ...h, ...data }) : h,
      ),
    }));
  },

  deleteHomework: async (id) => {
    await apiDel(`/homework/${id}`);
    set((s) => ({ homework: s.homework.filter((h) => h.id !== id) }));
  },

  // ── Groups ─────────────────────────────────────────────────────────────────
  addGroup: async (data) => {
    const { group } = await apiPost("/groups", data);
    set((s) => ({ groups: [...s.groups, group] }));
    return group;
  },

  updateGroup: async (data) => {
    const { group } = await apiPut(`/groups/${data.id}`, data);
    set((s) => ({
      groups: s.groups.map((g) => (g.id === group.id ? group : g)),
    }));
    return group;
  },

  deleteGroup: async (id) => {
    await apiDel(`/groups/${id}`);
    set((s) => ({ groups: s.groups.filter((g) => g.id !== id) }));
  },

  // ── Packages ───────────────────────────────────────────────────────────────
  addPackage: async (data) => {
    const { package: pkg } = await apiPost("/packages", data);
    set((s) => ({ packages: [...s.packages, pkg] }));
    return pkg;
  },

  // ── Notifications ──────────────────────────────────────────────────────────
  addNotification: async (data) => {
    const local = {
      ...data,
      id: Date.now(),
      read: false,
      is_read: false,
      created_at: new Date().toISOString(),
    };
    set((s) => ({ notifications: [local, ...s.notifications] }));
  },

  markNotificationRead: async (id) => {
    await apiPut("/notifications", { id }).catch(() => {});
    set((s) => ({
      notifications: s.notifications.map((n) =>
        n.id === id ? { ...n, read: true, is_read: true } : n,
      ),
    }));
  },

  deleteNotification: async (id) => {
    await apiDel(`/notifications?id=${id}`).catch(() => {});
    set((s) => ({ notifications: s.notifications.filter((n) => n.id !== id) }));
  },

  clearAllNotifications: async () => {
    await apiDel("/notifications").catch(() => {});
    set({ notifications: [] });
  },

  // ── Settings ──────────────────────────────────────────────────────────────
  saveSettings: async (newSettings) => {
    await apiPut("/settings", { settings: newSettings });
    set((s) => ({ settings: { ...s.settings, ...newSettings } }));
  },
}));
