// ── Teachers Storage ──────────────────────────────────────────────────────────
const TEACHERS_KEY = "teachers_list_v1";

export function getTeachersList() {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(TEACHERS_KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveTeachersList(list) {
  localStorage.setItem(TEACHERS_KEY, JSON.stringify(list));
}
