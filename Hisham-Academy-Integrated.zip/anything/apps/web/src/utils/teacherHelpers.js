export function calculateTeacherStats(
  students,
  attendance,
  payments,
  todayDate,
) {
  const todayAttendance = attendance.filter((a) =>
    a.date?.startsWith(todayDate),
  );
  const presentToday = todayAttendance.filter(
    (a) => a.status === "present" || a.status === "late",
  ).length;

  const thisMonth = todayDate.slice(0, 7);
  const paidThisMonth = new Set(
    payments
      .filter((p) => p.date?.startsWith(thisMonth))
      .map((p) => p.studentId),
  ).size;
  const unpaid = students.length - paidThisMonth;

  const lowSessions = students.filter((s) => {
    const pkg = Number(s.sessionPackage) || 8;
    const used = attendance.filter(
      (a) =>
        a.studentId === s.id && (a.status === "present" || a.status === "late"),
    ).length;
    return Math.max(0, pkg - used) <= 2;
  }).length;

  return {
    todayAttendance,
    presentToday,
    paidThisMonth,
    unpaid,
    lowSessions,
    thisMonth,
  };
}

export function getStudentSessionInfo(student, attendance) {
  const pkg = Number(student.sessionPackage) || 8;
  const used = attendance.filter(
    (a) =>
      a.studentId === student.id &&
      (a.status === "present" || a.status === "late"),
  ).length;
  const remaining = Math.max(0, pkg - used);

  return { pkg, used, remaining };
}

export function getStudentStatus(studentId, todayAttendance) {
  const rec = todayAttendance.find((a) => a.studentId === studentId);
  return rec?.status || null;
}

export function getUniqueGroups(students) {
  return [...new Set(students.map((s) => s.group).filter(Boolean))];
}
