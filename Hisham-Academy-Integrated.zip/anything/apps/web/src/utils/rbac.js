// ══════════════════════════════════════════════════════
//  RBAC — Role Based Access Control
//  Detects user role from sessionStorage + defines permissions
// ══════════════════════════════════════════════════════

export const ROLES = {
  ADMIN: "admin",
  TEACHER: "teacher",
  STUDENT: "student",
  PARENT: "parent",
  GUEST: "guest",
};

// ── Role Detection ────────────────────────────────────────────────────────────
export function getCurrentRole() {
  if (typeof window === "undefined") return ROLES.GUEST;
  try {
    if (sessionStorage.getItem("admin_session_v1")) return ROLES.ADMIN;
    if (sessionStorage.getItem("teacher_session_v1")) return ROLES.TEACHER;
    if (sessionStorage.getItem("parent_session_v1")) return ROLES.PARENT;
    if (sessionStorage.getItem("student_session_v1")) return ROLES.STUDENT;
  } catch {}
  return ROLES.GUEST;
}

export function getCurrentSession() {
  if (typeof window === "undefined") return null;
  try {
    const role = getCurrentRole();
    const keys = {
      [ROLES.ADMIN]: "admin_session_v1",
      [ROLES.TEACHER]: "teacher_session_v1",
      [ROLES.STUDENT]: "student_session_v1",
      [ROLES.PARENT]: "parent_session_v1",
    };
    const raw = sessionStorage.getItem(keys[role]);
    return raw ? { ...JSON.parse(raw), role } : null;
  } catch {
    return null;
  }
}

// ── Route Permissions ─────────────────────────────────────────────────────────
// true = all allowed, array = allowed roles
export const ROUTE_PERMISSIONS = {
  "/": true, // public landing — always accessible
  "/dashboard": [ROLES.ADMIN], // admin-only dashboard
  "/students": [ROLES.ADMIN, ROLES.TEACHER],
  "/attendance": [ROLES.ADMIN, ROLES.TEACHER],
  "/calendar": [ROLES.ADMIN, ROLES.TEACHER],
  "/homework": [ROLES.ADMIN, ROLES.TEACHER],
  "/schedule": [ROLES.ADMIN, ROLES.TEACHER],
  "/finances": [ROLES.ADMIN],
  "/exams": [ROLES.ADMIN, ROLES.TEACHER],
  "/archive": [ROLES.ADMIN],
  "/notifications": [ROLES.ADMIN, ROLES.TEACHER],
  "/settings": [ROLES.ADMIN],
  "/register": true,
  "/admin": true,
  "/teacher": true,
  "/student": true,
  "/bookings": [ROLES.TEACHER, ROLES.STUDENT],
  "/parent": true,
  "/unauthorized": true,
};

export function canAccess(path, role) {
  const perm = ROUTE_PERMISSIONS[path];
  if (!perm) return role === ROLES.ADMIN; // unknown routes: admin only
  if (perm === true) return true;
  return perm.includes(role);
}

// ── Navigation Config per Role ────────────────────────────────────────────────
export const ADMIN_NAV = [
  {
    key: "dashboard",
    label: "لوحة القيادة",
    icon: "LayoutDashboard",
    href: "/dashboard",
    single: true,
  },
  {
    key: "students",
    label: "الطلاب",
    icon: "Users",
    collapsible: true,
    children: [
      { label: "قائمة الطلاب", href: "/students", icon: "Users" },
      { label: "الحضور والغياب", href: "/attendance", icon: "CalendarCheck" },
      { label: "التسجيل الجديد", href: "/register", icon: "UserPlus" },
    ],
  },
  {
    key: "teachers",
    label: "المدرسون",
    icon: "BookOpen",
    collapsible: true,
    children: [
      {
        label: "قائمة المدرسين",
        href: "/admin",
        icon: "Shield",
        tab: "teachers",
      },
      { label: "الجداول", href: "/schedule", icon: "ClipboardList" },
      { label: "بوابة المعلم", href: "/teacher", icon: "BookOpen" },
    ],
  },
  {
    key: "academic",
    label: "أكاديمي",
    icon: "GraduationCap",
    collapsible: true,
    children: [
      { label: "الواجبات", href: "/homework", icon: "AlignLeft" },
      { label: "الامتحانات", href: "/exams", icon: "FileText" },
      { label: "التقويم", href: "/calendar", icon: "Calendar" },
      { label: "السبورة", href: "/whiteboard", icon: "PenTool" },
      { label: "الأرشيف", href: "/archive", icon: "Archive" },
    ],
  },
  {
    key: "finance",
    label: "المالية",
    icon: "Wallet",
    href: "/finances",
    single: true,
  },
  {
    key: "reports",
    label: "التقارير",
    icon: "BarChart2",
    collapsible: true,
    children: [
      { label: "تقارير الطلاب", href: "/students", icon: "Users" },
      { label: "تقارير الحضور", href: "/attendance", icon: "CalendarCheck" },
      { label: "التقارير المالية", href: "/finances", icon: "Wallet" },
    ],
  },
  {
    key: "settings",
    label: "الإعدادات",
    icon: "Settings",
    collapsible: true,
    children: [
      { label: "الإشعارات", href: "/notifications", icon: "Bell" },
      { label: "إعدادات النظام", href: "/settings", icon: "Settings" },
    ],
  },
];

export const TEACHER_NAV = [
  { key: "home", label: "الرئيسية", icon: "LayoutDashboard", href: "/teacher" },
  { key: "students", label: "طلابي", icon: "Users", href: "/students" },
  {
    key: "academic",
    label: "الدراسة",
    icon: "GraduationCap",
    collapsible: true,
    children: [
      { label: "التحضير", href: "/attendance", icon: "CalendarCheck" },
      { label: "الواجبات", href: "/homework", icon: "AlignLeft" },
      { label: "الامتحانات", href: "/exams", icon: "FileText" },
    ],
  },
  { key: "schedule", label: "الجدول", icon: "Calendar", href: "/schedule" },
  { key: "bookings", label: "الحصص والحجوزات", icon: "CalendarPlus", href: "/bookings" },
  { key: "whiteboard", label: "السبورة", icon: "PenTool", href: "/whiteboard" },
  {
    key: "notifications",
    label: "الإشعارات",
    icon: "Bell",
    href: "/notifications",
  },
];

export const STUDENT_NAV = [
  { key: "home", label: "الرئيسية", icon: "Home", href: "/student" },
  {
    key: "schedule",
    label: "الجدول",
    icon: "Calendar",
    href: "/student#schedule",
  },
  { key: "bookings", label: "احجز حصة", icon: "CalendarPlus", href: "/bookings" },
  {
    key: "homework",
    label: "واجباتي",
    icon: "AlignLeft",
    href: "/student#homework",
  },
  {
    key: "exams",
    label: "امتحاناتي",
    icon: "FileText",
    href: "/student#exams",
  },
  { key: "whiteboard", label: "السبورة", icon: "PenTool", href: "/whiteboard" },
  {
    key: "notifications",
    label: "الإشعارات",
    icon: "Bell",
    href: "/student#notifications",
  },
];
