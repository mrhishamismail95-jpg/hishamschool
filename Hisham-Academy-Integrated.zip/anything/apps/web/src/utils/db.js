const DB_NAME = "StudentManagerDB";
const DB_VERSION = 2; // bumped for new stores

export const initDB = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = (event) => {
      reject("Database error: " + event.target.errorCode);
    };

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // Students Store
      if (!db.objectStoreNames.contains("students")) {
        db.createObjectStore("students", {
          keyPath: "id",
          autoIncrement: true,
        });
      }

      // Attendance Store
      if (!db.objectStoreNames.contains("attendance")) {
        db.createObjectStore("attendance", {
          keyPath: "id",
          autoIncrement: true,
        });
      }

      // Payments Store
      if (!db.objectStoreNames.contains("payments")) {
        db.createObjectStore("payments", {
          keyPath: "id",
          autoIncrement: true,
        });
      }

      // Exams Store
      if (!db.objectStoreNames.contains("exams")) {
        db.createObjectStore("exams", { keyPath: "id", autoIncrement: true });
      }

      // Groups Store
      if (!db.objectStoreNames.contains("groups")) {
        db.createObjectStore("groups", { keyPath: "id", autoIncrement: true });
      }

      // Homework Store
      if (!db.objectStoreNames.contains("homework")) {
        db.createObjectStore("homework", {
          keyPath: "id",
          autoIncrement: true,
        });
      }

      // Notifications Store
      if (!db.objectStoreNames.contains("notifications")) {
        db.createObjectStore("notifications", {
          keyPath: "id",
          autoIncrement: true,
        });
      }
    };

    request.onsuccess = (event) => {
      resolve(event.target.result);
    };
  });
};

const getStore = async (storeName, mode = "readonly") => {
  const db = await initDB();
  const transaction = db.transaction(storeName, mode);
  return transaction.objectStore(storeName);
};

export const db = {
  // Generic CRUD
  async getAll(storeName) {
    const store = await getStore(storeName);
    return new Promise((resolve) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
    });
  },

  async add(storeName, item) {
    const store = await getStore(storeName, "readwrite");
    return new Promise((resolve) => {
      const request = store.add(item);
      request.onsuccess = () => resolve(request.result);
    });
  },

  async update(storeName, item) {
    const store = await getStore(storeName, "readwrite");
    return new Promise((resolve) => {
      const request = store.put(item);
      request.onsuccess = () => resolve(request.result);
    });
  },

  async delete(storeName, id) {
    const store = await getStore(storeName, "readwrite");
    return new Promise((resolve) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve(request.result);
    });
  },

  async getById(storeName, id) {
    const store = await getStore(storeName);
    return new Promise((resolve) => {
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
    });
  },
};
