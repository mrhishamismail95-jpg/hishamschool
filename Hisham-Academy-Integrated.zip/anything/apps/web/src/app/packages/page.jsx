"use client";
import React, { useState, useEffect } from "react";
import {
  Package,
  Plus,
  Edit2,
  Trash2,
  Save,
  X,
  Loader2,
  DollarSign,
  Calendar,
  CheckCircle2,
  XCircle,
  Tag,
} from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";

function PackageModal({ pkg, onClose, onSave }) {
  const [name, setName] = useState(pkg?.name || "");
  const [sessionsCount, setSessionsCount] = useState(pkg?.sessions_count || 8);
  const [price, setPrice] = useState(pkg?.price || "");
  const [discount, setDiscount] = useState(pkg?.discount || "");
  const [description, setDescription] = useState(pkg?.description || "");
  const [features, setFeatures] = useState(pkg?.features || "");
  const [saving, setSaving] = useState(false);

  const inp =
    "w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-[#0a2463] focus:outline-none text-sm";
  const lbl = "block text-xs font-bold text-gray-600 mb-1.5";

  const handleSave = async () => {
    if (!name.trim()) return toast.error("اسم الباقة مطلوب");
    setSaving(true);
    try {
      await onSave({
        id: pkg?.id,
        name: name.trim(),
        sessionsCount: Number(sessionsCount),
        price: price ? Number(price) : 0,
        discount: discount ? Number(discount) : 0,
        description,
        features,
        active: true,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Package size={24} className="text-purple-600" />
            </div>
            <div>
              <h3 className="text-xl font-black text-gray-800">
                {pkg ? "تعديل الباقة" : "باقة جديدة"}
              </h3>
              <p className="text-xs text-gray-500">
                أدخل بيانات الباقة التعليمية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-xl transition-all"
          >
            <X size={20} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className={lbl}>اسم الباقة *</label>
            <input
              className={inp}
              placeholder="باقة الـ 8 حصص"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={lbl}>عدد الحصص *</label>
              <input
                type="number"
                className={inp}
                value={sessionsCount}
                onChange={(e) => setSessionsCount(e.target.value)}
                min="1"
              />
            </div>
            <div>
              <label className={lbl}>السعر (ج.م) *</label>
              <input
                type="number"
                className={inp}
                placeholder="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className={lbl}>الخصم (ج.م)</label>
            <input
              type="number"
              className={inp}
              placeholder="0"
              value={discount}
              onChange={(e) => setDiscount(e.target.value)}
            />
          </div>

          <div>
            <label className={lbl}>الوصف</label>
            <textarea
              className={`${inp} h-20 resize-none`}
              placeholder="وصف الباقة..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div>
            <label className={lbl}>المميزات (اختياري)</label>
            <textarea
              className={`${inp} h-16 resize-none`}
              placeholder="مثال: حصص أسبوعية، متابعة يومية..."
              value={features}
              onChange={(e) => setFeatures(e.target.value)}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 flex items-center justify-center gap-2 bg-[#0a2463] hover:bg-[#0d2d7a] disabled:opacity-60 text-white py-3.5 rounded-xl font-bold"
            >
              {saving ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <Save size={18} />
              )}
              {saving ? "جاري الحفظ..." : "حفظ"}
            </button>
            <button
              onClick={onClose}
              className="px-6 py-3.5 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition-all"
            >
              إلغاء
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function PackagesPage() {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingPkg, setEditingPkg] = useState(null);

  useEffect(() => {
    loadPackages();
  }, []);

  const loadPackages = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/academy/packages");
      const data = await res.json();
      setPackages(data.packages || []);
    } catch (err) {
      console.error(err);
      toast.error("فشل تحميل الباقات");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (data) => {
    try {
      const url = data.id
        ? `/api/academy/packages/${data.id}`
        : "/api/academy/packages";
      const method = data.id ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("فشل الحفظ");
      toast.success(data.id ? "تم التعديل ✅" : "تم إضافة الباقة ✅");
      setModalOpen(false);
      setEditingPkg(null);
      loadPackages();
    } catch (err) {
      console.error(err);
      toast.error("حدث خطأ أثناء الحفظ");
    }
  };

  const toggleActive = async (id, currentActive) => {
    try {
      const res = await fetch(`/api/academy/packages/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !currentActive }),
      });
      if (!res.ok) throw new Error("فشل التحديث");
      toast.success(currentActive ? "تم إيقاف الباقة" : "تم تفعيل الباقة");
      loadPackages();
    } catch (err) {
      console.error(err);
      toast.error("حدث خطأ");
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("هل تريد حذف هذه الباقة؟ (سيتم إيقافها فقط)")) return;
    try {
      const res = await fetch(`/api/academy/packages/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("فشل الحذف");
      toast.success("تم الحذف");
      loadPackages();
    } catch (err) {
      console.error(err);
      toast.error("حدث خطأ");
    }
  };

  const activePackages = packages.filter((p) => p.active !== false);
  const inactivePackages = packages.filter((p) => p.active === false);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 size={32} className="text-[#0a2463] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-[#0a2463]">
            📦 الباقات التعليمية
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            إدارة الباقات والاشتراكات
          </p>
        </div>
        <button
          onClick={() => {
            setEditingPkg(null);
            setModalOpen(true);
          }}
          className="flex items-center gap-2 bg-[#0a2463] hover:bg-[#0d2d7a] text-white px-5 py-3 rounded-xl font-bold transition-all shadow-lg"
        >
          <Plus size={18} /> باقة جديدة
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "إجمالي الباقات", value: packages.length, color: "purple" },
          { label: "باقات نشطة", value: activePackages.length, color: "green" },
          {
            label: "باقات موقوفة",
            value: inactivePackages.length,
            color: "gray",
          },
        ].map(({ label, value, color }) => (
          <div
            key={label}
            className={`bg-${color}-50 border border-${color}-200 rounded-2xl p-4 text-center`}
          >
            <p className={`text-3xl font-black text-${color}-600`}>{value}</p>
            <p className="text-xs text-gray-600 mt-1">{label}</p>
          </div>
        ))}
      </div>

      {/* Packages Grid */}
      {packages.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Package size={36} className="text-gray-400" />
          </div>
          <p className="text-gray-500 font-bold">لا توجد باقات</p>
          <button
            onClick={() => {
              setEditingPkg(null);
              setModalOpen(true);
            }}
            className="mt-4 text-sm text-[#0a2463] hover:underline font-bold"
          >
            أضف باقة جديدة
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {packages.map((p) => {
            const isActive = p.active !== false;
            return (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`bg-white rounded-2xl p-6 border-2 transition-all hover:shadow-lg ${isActive ? "border-purple-200" : "border-gray-200 opacity-60"}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${isActive ? "bg-purple-100" : "bg-gray-100"}`}
                    >
                      <Package
                        size={20}
                        className={
                          isActive ? "text-purple-600" : "text-gray-400"
                        }
                      />
                    </div>
                    {!isActive && (
                      <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full font-bold">
                        موقوف
                      </span>
                    )}
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        setEditingPkg(p);
                        setModalOpen(true);
                      }}
                      className="p-2 hover:bg-purple-50 rounded-lg transition-all"
                    >
                      <Edit2 size={16} className="text-purple-600" />
                    </button>
                    <button
                      onClick={() => handleDelete(p.id)}
                      className="p-2 hover:bg-red-50 rounded-lg transition-all"
                    >
                      <Trash2 size={16} className="text-red-600" />
                    </button>
                  </div>
                </div>

                <h3 className="font-black text-gray-800 text-xl mb-1">
                  {p.name}
                </h3>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-sm text-gray-500">
                    {p.sessions_count} حصة
                  </span>
                  {Number(p.discount) > 0 && (
                    <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold">
                      وفر {p.discount} ج
                    </span>
                  )}
                </div>

                {p.description && (
                  <p className="text-xs text-gray-500 mb-4">{p.description}</p>
                )}

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="flex items-center gap-1 text-green-600 font-black text-2xl">
                    <DollarSign size={20} />
                    <span>{Number(p.price).toLocaleString()}</span>
                    <span className="text-sm text-gray-400">ج.م</span>
                  </div>
                  <button
                    onClick={() => toggleActive(p.id, isActive)}
                    className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${isActive ? "bg-orange-100 text-orange-600 hover:bg-orange-200" : "bg-green-100 text-green-600 hover:bg-green-200"}`}
                  >
                    {isActive ? "إيقاف" : "تفعيل"}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <AnimatePresence>
        {modalOpen && (
          <PackageModal
            pkg={editingPkg}
            onClose={() => {
              setModalOpen(false);
              setEditingPkg(null);
            }}
            onSave={handleSave}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
