import React from "react";
import {
  ArrowUpRight,
  ArrowDownRight,
  CreditCard,
  Users,
  CheckCircle2,
  XCircle,
  Download,
  Plus,
  X,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  DollarSign,
  BookOpen,
  TrendingUp,
  Zap,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useStore } from "@/utils/store";
import { toast } from "sonner";

// ── Session Revenue View ─────────────────────────────────────────────────────
function SessionRevenueView({ students, attendance }) {
  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];
  const ungrouped = students.filter((s) => !s.group);
  const allGroups = [
    ...groups,
    ...(ungrouped.length > 0 ? ["بدون مجموعة"] : []),
  ];

  const getStudentSessions = (student) => {
    const pkg = Number(student.sessionPackage) || 8;
    const attended = attendance.filter(
      (a) =>
        a.studentId === student.id &&
        (a.status === "present" || a.status === "late"),
    ).length;
    const pricePerSession = student.price
      ? Math.round(Number(student.price) / pkg)
      : 0;
    const earned = attended * pricePerSession;
    const remaining = Math.max(0, pkg - attended);
    return { pkg, attended, pricePerSession, earned, remaining };
  };

  const getGroupStudents = (g) =>
    g === "بدون مجموعة" ? ungrouped : students.filter((s) => s.group === g);

  const totalEarned = students.reduce((acc, s) => {
    const { earned } = getStudentSessions(s);
    return acc + earned;
  }, 0);

  const totalExpected = students.reduce(
    (acc, s) => acc + Number(s.price || 0),
    0,
  );

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-6 rounded-2xl text-white shadow-lg md:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-white/20 rounded-xl">
              <Zap size={20} />
            </div>
            <p className="text-green-100 text-sm">
              إجمالي إيرادات الحصص المنعقدة
            </p>
          </div>
          <p className="text-4xl font-bold mb-2">
            {totalEarned.toLocaleString()} ج.م
          </p>
          <p className="text-green-200 text-sm">
            من إجمالي {totalExpected.toLocaleString()} ج.م في الباقات (
            {totalExpected > 0
              ? Math.round((totalEarned / totalExpected) * 100)
              : 0}
            % محقق)
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700">
          <p className="text-gray-400 text-sm mb-3">متوسط سعر الحصة / طالب</p>
          <p className="text-3xl font-bold text-gray-800 dark:text-white">
            {students.length > 0
              ? Math.round(
                  students.reduce((acc, s) => {
                    const pkg = Number(s.sessionPackage) || 8;
                    return acc + (s.price ? Number(s.price) / pkg : 0);
                  }, 0) / students.length,
                )
              : 0}{" "}
            <span className="text-lg text-gray-400 font-normal">ج.م</span>
          </p>
          <p className="text-xs text-gray-400 mt-2">
            متوسط من {students.length} طالب
          </p>
        </div>
      </div>

      {/* Per Group */}
      {allGroups.map((groupName) => {
        const gs = getGroupStudents(groupName);
        const groupEarned = gs.reduce(
          (acc, s) => acc + getStudentSessions(s).earned,
          0,
        );
        const groupExpected = gs.reduce(
          (acc, s) => acc + Number(s.price || 0),
          0,
        );
        const pct =
          groupExpected > 0
            ? Math.round((groupEarned / groupExpected) * 100)
            : 0;

        return (
          <div
            key={groupName}
            className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden"
          >
            {/* Group Header */}
            <div className="p-5 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
                  <Users
                    size={20}
                    className="text-green-600 dark:text-green-400"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 dark:text-white">
                    {groupName}
                  </h3>
                  <p className="text-xs text-gray-400">{gs.length} طالب</p>
                </div>
              </div>
              <div className="text-left">
                <p className="font-bold text-green-600 text-lg">
                  {groupEarned.toLocaleString()} ج.م
                </p>
                <p className="text-xs text-gray-400">
                  {pct}% من {groupExpected.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Students Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-900/40 text-xs text-gray-400">
                    <th className="px-5 py-3">الطالب</th>
                    <th className="px-5 py-3 text-center">سعر الباقة</th>
                    <th className="px-5 py-3 text-center">عدد الحصص</th>
                    <th className="px-5 py-3 text-center">سعر الحصة</th>
                    <th className="px-5 py-3 text-center">حصص حضرها</th>
                    <th className="px-5 py-3 text-center">متبقي</th>
                    <th className="px-5 py-3 text-center font-bold text-green-600">
                      إيراد الحصص ✓
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                  {gs.map((student) => {
                    const {
                      pkg,
                      attended,
                      pricePerSession,
                      earned,
                      remaining,
                    } = getStudentSessions(student);
                    const pctAttended = Math.min(
                      100,
                      Math.round((attended / pkg) * 100),
                    );
                    const isFinished = remaining === 0;
                    const isLow = remaining > 0 && remaining <= 2;

                    return (
                      <tr
                        key={student.id}
                        className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-all"
                      >
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                              {student.name?.[0]}
                            </div>
                            <div>
                              <p className="font-bold text-gray-800 dark:text-white text-sm">
                                {student.name}
                              </p>
                              <p className="text-xs text-gray-400 font-mono">
                                {student.code}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span className="font-bold text-blue-600">
                            {Number(student.price || 0).toLocaleString()} ج.م
                          </span>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span className="font-bold text-gray-700 dark:text-gray-300">
                            {pkg}
                          </span>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full text-sm font-bold">
                            {pricePerSession} ج.م
                          </span>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <div>
                            <p className="font-bold text-gray-800 dark:text-white">
                              {attended}
                            </p>
                            <div className="w-16 h-1.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden mx-auto mt-1">
                              <div
                                className={`h-full rounded-full ${isFinished ? "bg-red-400" : isLow ? "bg-orange-400" : "bg-green-500"}`}
                                style={{ width: `${pctAttended}%` }}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span
                            className={`font-bold text-sm ${isFinished ? "text-red-500" : isLow ? "text-orange-500" : "text-gray-600 dark:text-gray-400"}`}
                          >
                            {isFinished ? "منتهية!" : remaining}
                          </span>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span className="text-lg font-bold text-green-600 dark:text-green-400">
                            {earned.toLocaleString()} ج.م
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-green-50/60 dark:bg-green-900/10 border-t border-green-100 dark:border-green-900/20">
                    <td
                      colSpan={6}
                      className="px-5 py-3 text-sm font-bold text-green-700 dark:text-green-400"
                    >
                      إجمالي إيراد مجموعة {groupName}
                    </td>
                    <td className="px-5 py-3 text-center text-lg font-bold text-green-600 dark:text-green-400">
                      {groupEarned.toLocaleString()} ج.م
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function Finances() {
  const {
    students,
    payments,
    attendance,
    addPayment,
    deletePayment,
    fetchData,
  } = useStore();
  const [activeTab, setActiveTab] = React.useState("subscriptions");
  const [collapsedGroups, setCollapsedGroups] = React.useState({});
  const [selectedMonth, setSelectedMonth] = React.useState(
    new Date().toISOString().slice(0, 7),
  );
  const [addingPayment, setAddingPayment] = React.useState(null);
  const [customAmount, setCustomAmount] = React.useState("");

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Get unique groups
  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];
  const ungrouped = students.filter((s) => !s.group);

  // All groups including 'ungrouped'
  const allGroupNames = [
    ...groups,
    ...(ungrouped.length > 0 ? ["بدون مجموعة"] : []),
  ];

  // Check if a student paid in the selected month
  const getStudentPaymentForMonth = (studentId) => {
    return payments.find(
      (p) => p.studentId === studentId && p.date?.startsWith(selectedMonth),
    );
  };

  const handleMarkPaid = async (student) => {
    const existingPayment = getStudentPaymentForMonth(student.id);
    if (existingPayment) {
      toast.info("الطالب دفع بالفعل هذا الشهر");
      return;
    }
    const amount = customAmount || student.price || 0;
    try {
      await addPayment({
        studentId: student.id,
        studentName: student.name,
        amount: Number(amount),
        type: "subscription",
        status: "paid",
        month: selectedMonth,
        group: student.group,
      });
      setAddingPayment(null);
      setCustomAmount("");
      toast.success(`تم تسجيل دفع ${student.name} ✅`);
    } catch {
      toast.error("حدث خطأ");
    }
  };

  const handleRemovePayment = async (student) => {
    const payment = getStudentPaymentForMonth(student.id);
    if (!payment) return;
    if (window.confirm("هل تريد حذف هذه الدفعة؟")) {
      await deletePayment(payment.id);
      toast.info("تم حذف الدفعة");
    }
  };

  const toggleGroup = (group) => {
    setCollapsedGroups((prev) => ({ ...prev, [group]: !prev[group] }));
  };

  // Get students for a group
  const getGroupStudents = (groupName) => {
    if (groupName === "بدون مجموعة") return ungrouped;
    return students.filter((s) => s.group === groupName);
  };

  // Group financial stats
  const getGroupStats = (groupStudents) => {
    const totalExpected = groupStudents.reduce(
      (acc, s) => acc + Number(s.price || 0),
      0,
    );
    const paidStudents = groupStudents.filter((s) =>
      getStudentPaymentForMonth(s.id),
    );
    const totalCollected = paidStudents.reduce((acc, s) => {
      const payment = getStudentPaymentForMonth(s.id);
      return acc + Number(payment?.amount || 0);
    }, 0);
    const pending = groupStudents.filter(
      (s) => !getStudentPaymentForMonth(s.id),
    );
    return {
      totalExpected,
      totalCollected,
      paidCount: paidStudents.length,
      pendingCount: pending.length,
    };
  };

  // Overall stats
  const overallStats = React.useMemo(() => {
    const monthPayments = payments.filter((p) =>
      p.date?.startsWith(selectedMonth),
    );
    const totalRevenue = monthPayments.reduce(
      (acc, p) => acc + Number(p.amount || 0),
      0,
    );
    const paidCount = new Set(monthPayments.map((p) => p.studentId)).size;
    const pendingCount = students.length - paidCount;
    const totalExpected = students.reduce(
      (acc, s) => acc + Number(s.price || 0),
      0,
    );
    return { totalRevenue, paidCount, pendingCount, totalExpected };
  }, [payments, students, selectedMonth]);

  const exportReport = () => {
    const rows = [
      ["الاسم", "المجموعة", "الصف", "السعر", "حالة الدفع", "المبلغ المدفوع"],
      ...students.map((s) => {
        const payment = getStudentPaymentForMonth(s.id);
        return [
          s.name,
          s.group,
          s.grade,
          s.price,
          payment ? "مدفوع" : "غير مدفوع",
          payment?.amount || 0,
        ];
      }),
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `تقرير_مالي_${selectedMonth}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const monthNames = {
    "01": "يناير",
    "02": "فبراير",
    "03": "مارس",
    "04": "أبريل",
    "05": "مايو",
    "06": "يونيو",
    "07": "يوليو",
    "08": "أغسطس",
    "09": "سبتمبر",
    10: "أكتوبر",
    11: "نوفمبر",
    12: "ديسمبر",
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            الإدارة المالية
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            تتبع المدفوعات والاشتراكات وإيرادات الحصص
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-4 py-2.5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <button
            onClick={exportReport}
            className="flex items-center gap-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 px-4 py-2.5 rounded-xl text-gray-600 dark:text-gray-300 hover:bg-gray-50 transition-all text-sm font-medium"
          >
            <Download size={18} />
            تصدير
          </button>
        </div>
      </div>

      {/* Tab Toggle */}
      <div className="flex gap-2 bg-gray-100 dark:bg-gray-800 p-1.5 rounded-2xl w-fit">
        {[
          {
            key: "subscriptions",
            label: "💳 الاشتراكات الشهرية",
            icon: CreditCard,
          },
          { key: "sessions", label: "⚡ إيراد الحصص", icon: TrendingUp },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${
              activeTab === tab.key
                ? "bg-white dark:bg-gray-700 text-gray-800 dark:text-white shadow-md"
                : "text-gray-500 hover:text-gray-700"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "sessions" ? (
        <SessionRevenueView students={students} attendance={attendance} />
      ) : (
        <>
          {/* Global Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-5 rounded-2xl text-white shadow-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-white/20 rounded-xl">
                  <DollarSign size={20} />
                </div>
                <ArrowUpRight size={16} className="opacity-70" />
              </div>
              <p className="text-blue-100 text-xs mb-1">إجمالي المُحصَّل</p>
              <h3 className="text-2xl font-bold">
                {overallStats.totalRevenue.toLocaleString()}{" "}
                <span className="text-sm font-normal">ج.م</span>
              </h3>
            </div>
            <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-xl">
                  <ArrowDownRight size={20} className="text-gray-500" />
                </div>
              </div>
              <p className="text-gray-400 text-xs mb-1">المتوقع هذا الشهر</p>
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white">
                {overallStats.totalExpected.toLocaleString()}{" "}
                <span className="text-sm font-normal text-gray-400">ج.م</span>
              </h3>
            </div>
            <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-xl">
                  <CheckCircle2 size={20} className="text-green-600" />
                </div>
              </div>
              <p className="text-gray-400 text-xs mb-1">دفعوا</p>
              <h3 className="text-2xl font-bold text-green-600">
                {overallStats.paidCount}{" "}
                <span className="text-sm font-normal text-gray-400">طالب</span>
              </h3>
            </div>
            <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-xl">
                  <XCircle size={20} className="text-red-500" />
                </div>
              </div>
              <p className="text-gray-400 text-xs mb-1">لم يدفعوا</p>
              <h3 className="text-2xl font-bold text-red-500">
                {overallStats.pendingCount}{" "}
                <span className="text-sm font-normal text-gray-400">طالب</span>
              </h3>
            </div>
          </div>

          {/* Groups */}
          {allGroupNames.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 p-16 text-center text-gray-500">
              <Users size={40} className="mx-auto mb-3 text-gray-300" />
              <p>لا يوجد مجموعات — أضف طلاباً أولاً</p>
            </div>
          ) : (
            allGroupNames.map((groupName) => {
              const groupStudents = getGroupStudents(groupName);
              const stats = getGroupStats(groupStudents);
              const isCollapsed = collapsedGroups[groupName];
              const collectionRate =
                stats.totalExpected > 0
                  ? Math.round(
                      (stats.totalCollected / stats.totalExpected) * 100,
                    )
                  : 0;

              return (
                <motion.div
                  key={groupName}
                  layout
                  className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden shadow-sm"
                >
                  {/* Group Header */}
                  <button
                    onClick={() => toggleGroup(groupName)}
                    className="w-full p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 text-right border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-xl flex items-center justify-center">
                        <Users size={20} />
                      </div>
                      <div className="text-right">
                        <h3 className="font-bold text-gray-800 dark:text-white">
                          {groupName}
                        </h3>
                        <p className="text-xs text-gray-500">
                          {groupStudents.length} طالب
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {/* Mini Stats */}
                      <div className="flex items-center gap-3">
                        <div className="text-center">
                          <p className="text-xs text-gray-400">مُحصَّل</p>
                          <p className="font-bold text-green-600 text-sm">
                            {stats.totalCollected.toLocaleString()} ج.م
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-gray-400">متبقي</p>
                          <p className="font-bold text-red-500 text-sm">
                            {(
                              stats.totalExpected - stats.totalCollected
                            ).toLocaleString()}{" "}
                            ج.م
                          </p>
                        </div>
                        <div className="text-center min-w-[60px]">
                          <p className="text-xs text-gray-400">نسبة التحصيل</p>
                          <p
                            className={`font-bold text-sm ${collectionRate >= 80 ? "text-green-600" : collectionRate >= 50 ? "text-orange-500" : "text-red-500"}`}
                          >
                            {collectionRate}%
                          </p>
                        </div>
                      </div>
                      {/* Progress */}
                      <div className="hidden md:flex flex-col gap-1 min-w-[80px]">
                        <div className="h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden w-20">
                          <div
                            className={`h-full rounded-full ${collectionRate >= 80 ? "bg-green-500" : collectionRate >= 50 ? "bg-orange-400" : "bg-red-400"}`}
                            style={{ width: `${collectionRate}%` }}
                          />
                        </div>
                        <p className="text-xs text-gray-400">
                          {stats.paidCount}/{groupStudents.length} دفعوا
                        </p>
                      </div>
                      {isCollapsed ? (
                        <ChevronDown size={20} className="text-gray-400" />
                      ) : (
                        <ChevronUp size={20} className="text-gray-400" />
                      )}
                    </div>
                  </button>

                  {/* Students Table */}
                  <AnimatePresence>
                    {!isCollapsed && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        {/* Desktop */}
                        <div className="hidden md:block overflow-x-auto">
                          <table className="w-full text-right">
                            <thead>
                              <tr className="bg-gray-50/80 dark:bg-gray-900/50 text-xs text-gray-400">
                                <th className="px-5 py-3 font-medium">#</th>
                                <th className="px-5 py-3 font-medium">
                                  الطالب
                                </th>
                                <th className="px-5 py-3 font-medium">الكود</th>
                                <th className="px-5 py-3 font-medium">الصف</th>
                                <th className="px-5 py-3 font-medium text-center">
                                  السعر
                                </th>
                                <th className="px-5 py-3 font-medium text-center">
                                  سعر الحصة
                                </th>
                                <th className="px-5 py-3 font-medium text-center">
                                  حالة الدفع
                                </th>
                                <th className="px-5 py-3 font-medium text-center">
                                  الإجراءات
                                </th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                              {groupStudents.map((student, idx) => {
                                const payment = getStudentPaymentForMonth(
                                  student.id,
                                );
                                const isPaid = !!payment;
                                const pkg = Number(student.sessionPackage) || 8;
                                const pricePerSession = student.price
                                  ? Math.round(Number(student.price) / pkg)
                                  : 0;
                                return (
                                  <tr
                                    key={student.id}
                                    className={`hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-all ${isPaid ? "" : "bg-red-50/30 dark:bg-red-900/5"}`}
                                  >
                                    <td className="px-5 py-4 text-gray-400 text-sm">
                                      {idx + 1}
                                    </td>
                                    <td className="px-5 py-4">
                                      <div className="flex items-center gap-3">
                                        <div
                                          className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm ${isPaid ? "bg-green-100 dark:bg-green-900/30 text-green-600" : "bg-red-100 dark:bg-red-900/30 text-red-500"}`}
                                        >
                                          {student.name?.[0]}
                                        </div>
                                        <div>
                                          <p className="font-bold text-gray-800 dark:text-white text-sm">
                                            {student.name}
                                          </p>
                                          <p className="text-xs text-gray-400">
                                            {student.phone}
                                          </p>
                                        </div>
                                      </div>
                                    </td>
                                    <td className="px-5 py-4">
                                      <span className="font-mono text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-lg">
                                        {student.code || "—"}
                                      </span>
                                    </td>
                                    <td className="px-5 py-4 text-sm text-gray-500">
                                      {student.grade}
                                    </td>
                                    <td className="px-5 py-4 text-center">
                                      <span className="font-bold text-blue-600">
                                        {Number(
                                          student.price || 0,
                                        ).toLocaleString()}{" "}
                                        ج.م
                                      </span>
                                    </td>
                                    <td className="px-5 py-4 text-center">
                                      <span className="px-2.5 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-full text-sm font-bold">
                                        {pricePerSession} ج.م
                                      </span>
                                    </td>
                                    <td className="px-5 py-4 text-center">
                                      {isPaid ? (
                                        <div className="flex flex-col items-center gap-0.5">
                                          <span className="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full text-xs font-bold">
                                            مدفوع ✓
                                          </span>
                                          <span className="text-xs text-gray-400">
                                            {Number(
                                              payment.amount,
                                            ).toLocaleString()}{" "}
                                            ج.م
                                          </span>
                                        </div>
                                      ) : (
                                        <span className="px-3 py-1 bg-red-100 dark:bg-red-900/30 text-red-500 rounded-full text-xs font-bold">
                                          غير مدفوع
                                        </span>
                                      )}
                                    </td>
                                    <td className="px-5 py-4">
                                      <div className="flex items-center justify-center gap-2">
                                        {isPaid ? (
                                          <button
                                            onClick={() =>
                                              handleRemovePayment(student)
                                            }
                                            className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                            title="إلغاء الدفعة"
                                          >
                                            <XCircle size={16} />
                                          </button>
                                        ) : (
                                          <button
                                            onClick={() => {
                                              setAddingPayment(student.id);
                                              setCustomAmount(
                                                String(student.price || ""),
                                              );
                                            }}
                                            className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all"
                                          >
                                            <Plus size={14} /> تسجيل دفع
                                          </button>
                                        )}
                                        <a
                                          href={`https://wa.me/2${String(student.phone).replace(/^0/, "")}?text=${encodeURIComponent(`مرحباً ${student.name}، يرجى سداد رسوم شهر ${selectedMonth}. المبلغ المطلوب: ${student.price} ج.م`)}`}
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          className="p-1.5 text-green-500 hover:bg-green-50 rounded-lg transition-all"
                                          title="تذكير واتساب"
                                        >
                                          <MessageCircle size={16} />
                                        </a>
                                      </div>
                                      {/* Inline payment input */}
                                      {addingPayment === student.id && (
                                        <div className="mt-2 flex items-center gap-2">
                                          <input
                                            type="number"
                                            value={customAmount}
                                            onChange={(e) =>
                                              setCustomAmount(e.target.value)
                                            }
                                            placeholder="المبلغ"
                                            className="w-24 px-2 py-1 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                                          />
                                          <button
                                            onClick={() =>
                                              handleMarkPaid(student)
                                            }
                                            className="px-2 py-1 bg-green-500 text-white rounded-lg text-xs font-bold"
                                          >
                                            ✓
                                          </button>
                                          <button
                                            onClick={() => {
                                              setAddingPayment(null);
                                              setCustomAmount("");
                                            }}
                                            className="px-2 py-1 bg-gray-200 text-gray-600 rounded-lg text-xs"
                                          >
                                            ✗
                                          </button>
                                        </div>
                                      )}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                            <tfoot>
                              <tr className="bg-blue-50/50 dark:bg-blue-900/10 border-t border-blue-100 dark:border-blue-900/20">
                                <td
                                  colSpan={4}
                                  className="px-5 py-3 text-xs text-blue-600 font-bold"
                                >
                                  إجمالي المجموعة
                                </td>
                                <td className="px-5 py-3 text-center text-xs font-bold text-blue-600">
                                  {stats.totalExpected.toLocaleString()} ج.م
                                </td>
                                <td className="px-5 py-3" />
                                <td className="px-5 py-3 text-center text-xs font-bold text-green-600">
                                  محصَّل: {stats.totalCollected.toLocaleString()}{" "}
                                  ج.م
                                </td>
                                <td className="px-5 py-3 text-center text-xs font-bold text-red-500">
                                  متبقي:{" "}
                                  {(
                                    stats.totalExpected - stats.totalCollected
                                  ).toLocaleString()}{" "}
                                  ج.م
                                </td>
                              </tr>
                            </tfoot>
                          </table>
                        </div>

                        {/* Mobile Cards */}
                        <div className="md:hidden p-4 space-y-3">
                          {groupStudents.map((student) => {
                            const payment = getStudentPaymentForMonth(
                              student.id,
                            );
                            const isPaid = !!payment;
                            const pkg = Number(student.sessionPackage) || 8;
                            const pricePerSession = student.price
                              ? Math.round(Number(student.price) / pkg)
                              : 0;
                            return (
                              <div
                                key={student.id}
                                className={`p-4 rounded-xl border ${isPaid ? "border-green-200 dark:border-green-900/30 bg-green-50/50 dark:bg-green-900/10" : "border-red-200 dark:border-red-900/30 bg-red-50/50 dark:bg-red-900/10"}`}
                              >
                                <div className="flex items-center justify-between mb-3">
                                  <div className="flex items-center gap-2">
                                    <div
                                      className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm ${isPaid ? "bg-green-100 text-green-600" : "bg-red-100 text-red-500"}`}
                                    >
                                      {student.name?.[0]}
                                    </div>
                                    <div>
                                      <p className="font-bold text-sm text-gray-800 dark:text-white">
                                        {student.name}
                                      </p>
                                      <p className="text-xs text-gray-400 font-mono">
                                        {student.code}
                                      </p>
                                    </div>
                                  </div>
                                  <span
                                    className={`px-2.5 py-1 rounded-full text-xs font-bold ${isPaid ? "bg-green-100 text-green-600" : "bg-red-100 text-red-500"}`}
                                  >
                                    {isPaid ? "مدفوع" : "غير مدفوع"}
                                  </span>
                                </div>
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-sm font-bold text-blue-600">
                                    {Number(
                                      student.price || 0,
                                    ).toLocaleString()}{" "}
                                    ج.م
                                  </span>
                                  <span className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-bold">
                                    الحصة: {pricePerSession} ج.م
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  {isPaid ? (
                                    <button
                                      onClick={() =>
                                        handleRemovePayment(student)
                                      }
                                      className="text-xs text-red-500 font-bold"
                                    >
                                      إلغاء
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => handleMarkPaid(student)}
                                      className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold flex-1 justify-center"
                                    >
                                      <Plus size={12} /> تسجيل دفع
                                    </button>
                                  )}
                                  <a
                                    href={`https://wa.me/2${String(student.phone).replace(/^0/, "")}?text=${encodeURIComponent(`مرحباً ${student.name}، يرجى سداد الرسوم`)}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="p-1.5 text-green-500"
                                  >
                                    <MessageCircle size={16} />
                                  </a>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })
          )}
        </>
      )}
    </div>
  );
}
