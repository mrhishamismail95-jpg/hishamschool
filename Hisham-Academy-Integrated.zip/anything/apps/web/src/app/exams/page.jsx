import React from "react";
import {
  FileText,
  Plus,
  Trophy,
  BarChart3,
  Calendar,
  MoreVertical,
  AlertCircle,
  Clock,
  Upload,
  Share2,
  MessageCircle,
  Link2,
  X,
  Users,
  User,
  CheckCircle2,
  Trash2,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useStore } from "@/utils/store";
import { toast } from "sonner";

const GRADE_LEVELS = {
  ابتدائي: [
    "الأول الابتدائي",
    "الثاني الابتدائي",
    "الثالث الابتدائي",
    "الرابع الابتدائي",
    "الخامس الابتدائي",
    "السادس الابتدائي",
  ],
  إعدادي: ["الأول الإعدادي", "الثاني الإعدادي", "الثالث الإعدادي"],
  ثانوي: ["الأول الثانوي", "الثاني الثانوي", "الثالث الثانوي"],
  "لغات ابتدائي": [
    "الأول الابتدائي لغات",
    "الثاني الابتدائي لغات",
    "الثالث الابتدائي لغات",
    "الرابع الابتدائي لغات",
    "الخامس الابتدائي لغات",
    "السادس الابتدائي لغات",
  ],
  "لغات إعدادي": [
    "الأول الإعدادي لغات",
    "الثاني الإعدادي لغات",
    "الثالث الإعدادي لغات",
  ],
  "لغات ثانوي": [
    "الأول الثانوي لغات",
    "الثاني الثانوي لغات",
    "الثالث الثانوي لغات",
  ],
};

// Share Modal
const ShareModal = ({ exam, onClose, students }) => {
  const [shareType, setShareType] = React.useState("group");
  const [selectedStudentId, setSelectedStudentId] = React.useState("");
  const [copied, setCopied] = React.useState(false);

  const link = exam.pdfUrl || "";
  const message = `📚 امتحان: ${exam.title}\n📖 المادة: ${exam.subject}\n📅 التاريخ: ${new Date(exam.date).toLocaleDateString("ar-EG")}\n\n🔗 رابط الامتحان:\n${link}`;

  const copyLink = () => {
    navigator.clipboard.writeText(link).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast.success("تم نسخ الرابط");
    });
  };

  const sendToWhatsApp = (phone) => {
    const encoded = encodeURIComponent(message);
    window.open(
      `https://wa.me/2${phone.replace(/^0/, "")}?text=${encoded}`,
      "_blank",
    );
  };

  const sendToGroup = () => {
    const groupStudents = students.filter(
      (s) => s.group === exam.group || s.grade === exam.grade,
    );
    if (groupStudents.length === 0) {
      toast.error("لا يوجد طلاب في هذه المجموعة");
      return;
    }
    // Open first student then let user continue manually, or copy message
    navigator.clipboard.writeText(message).then(() => {
      toast.success(`تم نسخ الرسالة — أرسلها لـ ${groupStudents.length} طالب`);
    });
  };

  const sendToIndividual = () => {
    const student = students.find((s) => s.id === Number(selectedStudentId));
    if (!student) return toast.error("اختر طالباً أولاً");
    sendToWhatsApp(student.phone);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative w-full max-w-md bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">
            مشاركة الامتحان
          </h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Exam info */}
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-2xl p-4 mb-5">
          <p className="font-bold text-blue-700 dark:text-blue-400">
            {exam.title}
          </p>
          <p className="text-xs text-blue-500">
            {exam.subject} — {exam.grade}
          </p>
        </div>

        {/* Link */}
        {link ? (
          <div className="mb-5">
            <p className="text-xs text-gray-500 mb-2 font-medium">
              رابط الامتحان:
            </p>
            <div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3">
              <Link2 size={16} className="text-gray-400 flex-shrink-0" />
              <p className="text-xs text-gray-600 dark:text-gray-300 truncate flex-1 font-mono">
                {link}
              </p>
              <button
                onClick={copyLink}
                className={`text-xs font-bold px-3 py-1 rounded-lg transition-all ${copied ? "bg-green-500 text-white" : "bg-blue-100 text-blue-600 hover:bg-blue-200"}`}
              >
                {copied ? "✓ تم" : "نسخ"}
              </button>
            </div>
          </div>
        ) : (
          <div className="mb-5 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-xl text-xs text-orange-600 text-center">
            ارفع ملف PDF أولاً لإنشاء رابط قابل للمشاركة
          </div>
        )}

        {/* Share type */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setShareType("group")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all ${
              shareType === "group"
                ? "bg-blue-600 text-white"
                : "bg-gray-100 dark:bg-gray-700 text-gray-500"
            }`}
          >
            <Users size={16} /> مجموعة
          </button>
          <button
            onClick={() => setShareType("individual")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all ${
              shareType === "individual"
                ? "bg-blue-600 text-white"
                : "bg-gray-100 dark:bg-gray-700 text-gray-500"
            }`}
          >
            <User size={16} /> فردي
          </button>
        </div>

        {shareType === "individual" && (
          <div className="mb-4">
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="">اختر الطالب</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} — {s.group}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2">
          <button
            onClick={shareType === "group" ? sendToGroup : sendToIndividual}
            disabled={!link}
            className="w-full flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 disabled:opacity-50 text-white font-bold py-3 rounded-xl transition-all"
          >
            <MessageCircle size={20} />
            {shareType === "group"
              ? "إرسال للمجموعة عبر واتساب"
              : "إرسال للطالب عبر واتساب"}
          </button>
          <button
            onClick={copyLink}
            disabled={!link}
            className="w-full flex items-center justify-center gap-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 disabled:opacity-50 text-gray-700 dark:text-gray-200 font-bold py-3 rounded-xl transition-all"
          >
            <Link2 size={20} />
            نسخ الرابط
          </button>
        </div>
      </motion.div>
    </div>
  );
};

// Exam Card Component — add scores section
const ExamCard = ({
  exam,
  onShare,
  onUploadPdf,
  onDelete,
  onEditScores,
  students,
}) => {
  const fileInputRef = React.useRef(null);
  const [uploading, setUploading] = React.useState(false);
  const [showScores, setShowScores] = React.useState(false);
  const [scores, setScores] = React.useState(exam.scores || {});

  const targetStudents = students.filter((s) => {
    if (exam.group && s.group !== exam.group) return false;
    if (exam.grade && s.grade !== exam.grade) return false;
    return true;
  });

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.type !== "application/pdf") {
      toast.error("يرجى اختيار ملف PDF فقط");
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      toast.error("حجم الملف كبير جداً — الحد الأقصى 4 ميجا");
      return;
    }

    setUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const res = await fetch("/api/exams/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ base64: reader.result }),
        });
        const data = await res.json();
        if (!res.ok || data.error) throw new Error(data.error || "فشل الرفع");
        await onUploadPdf(exam, data.url);
        toast.success("تم رفع الامتحان بنجاح! ✅");
      } catch (err) {
        console.error(err);
        toast.error("فشل رفع الملف — حاول مجدداً");
      } finally {
        setUploading(false);
        e.target.value = "";
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveScores = async () => {
    await onEditScores(exam, scores);
    setShowScores(false);
    toast.success("تم حفظ الدرجات ✅");
  };

  const savedScores = Object.values(exam.scores || {}).filter(
    (v) => v !== "" && !isNaN(Number(v)),
  );
  const avgScore =
    savedScores.length > 0
      ? Math.round(
          savedScores.reduce((a, b) => a + Number(b), 0) / savedScores.length,
        )
      : null;
  const maxScore = Number(exam.maxScore) || 100;
  const weakStudents = savedScores.filter(
    (s) => Number(s) / maxScore < 0.5,
  ).length;

  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="p-5 bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm space-y-4"
    >
      <div className="flex items-start justify-between">
        <div
          className={`p-2.5 rounded-xl ${exam.pdfUrl ? "bg-green-100 dark:bg-green-900/30" : "bg-blue-100 dark:bg-blue-900/30"}`}
        >
          <FileText
            size={20}
            className={exam.pdfUrl ? "text-green-600" : "text-blue-500"}
          />
        </div>
        <button
          onClick={() => onDelete(exam.id)}
          className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
        >
          <Trash2 size={16} />
        </button>
      </div>

      <div>
        <h4 className="font-bold text-gray-800 dark:text-white mb-1">
          {exam.title}
        </h4>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          {exam.subject} — {exam.grade}
        </p>
        {exam.group && (
          <span className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-600 px-2 py-0.5 rounded-full mt-1 inline-block">
            {exam.group}
          </span>
        )}
      </div>

      <div className="flex items-center gap-3 text-xs text-gray-400">
        <div className="flex items-center gap-1">
          <Calendar size={13} />
          <span>{new Date(exam.date).toLocaleDateString("ar-EG")}</span>
        </div>
        <div className="flex items-center gap-1">
          <CheckCircle2 size={13} />
          <span>من {exam.maxScore} درجة</span>
        </div>
      </div>

      {/* Score Summary */}
      {savedScores.length > 0 && (
        <div className="grid grid-cols-3 gap-2 bg-gray-50 dark:bg-gray-900/40 rounded-xl p-3">
          <div className="text-center">
            <p className="text-xs text-gray-400 mb-0.5">المتوسط</p>
            <p className="font-bold text-sm text-blue-600">
              {avgScore}/{maxScore}
            </p>
          </div>
          <div className="text-center border-x border-gray-200 dark:border-gray-700">
            <p className="text-xs text-gray-400 mb-0.5">النسبة</p>
            <p
              className={`font-bold text-sm ${avgScore / maxScore >= 0.7 ? "text-green-600" : avgScore / maxScore >= 0.5 ? "text-orange-500" : "text-red-500"}`}
            >
              {Math.round((avgScore / maxScore) * 100)}%
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-400 mb-0.5">يحتاج دعم</p>
            <p className="font-bold text-sm text-red-500">{weakStudents}</p>
          </div>
        </div>
      )}

      {/* PDF Status */}
      {exam.pdfUrl ? (
        <div className="flex items-center gap-2 bg-green-50 dark:bg-green-900/20 rounded-xl px-3 py-2">
          <CheckCircle2 size={14} className="text-green-500" />
          <span className="text-xs text-green-600 font-medium flex-1">
            PDF مرفوع
          </span>
          <a
            href={exam.pdfUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-blue-500 hover:underline font-bold"
          >
            فتح
          </a>
        </div>
      ) : (
        <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl px-3 py-2 text-xs text-gray-400 text-center">
          لا يوجد PDF مرفوع
        </div>
      )}

      {/* Scores Entry */}
      {showScores && targetStudents.length > 0 && (
        <div className="bg-gray-50 dark:bg-gray-900/40 rounded-xl p-3 space-y-2">
          <p className="text-xs font-bold text-gray-600 dark:text-gray-400 mb-2">
            إدخال درجات الطلاب (من {maxScore})
          </p>
          <div className="max-h-48 overflow-y-auto space-y-2">
            {targetStudents.map((s) => (
              <div key={s.id} className="flex items-center gap-3">
                <span className="text-xs text-gray-700 dark:text-gray-300 flex-1 truncate">
                  {s.name}
                </span>
                <input
                  type="number"
                  min={0}
                  max={maxScore}
                  value={scores[s.id] ?? ""}
                  onChange={(e) =>
                    setScores((prev) => ({ ...prev, [s.id]: e.target.value }))
                  }
                  className="w-16 px-2 py-1 text-xs border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-center focus:ring-1 focus:ring-blue-500 outline-none"
                  placeholder="—"
                />
              </div>
            ))}
          </div>
          <button
            onClick={handleSaveScores}
            className="w-full mt-2 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700 transition-all"
          >
            حفظ الدرجات ✓
          </button>
        </div>
      )}

      {/* Actions */}
      <div className="pt-2 border-t border-gray-100 dark:border-gray-700 flex items-center gap-2">
        <input
          type="file"
          accept="application/pdf"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 text-blue-600 rounded-xl text-xs font-bold transition-all disabled:opacity-60"
        >
          {uploading ? (
            <div className="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full" />
          ) : (
            <Upload size={14} />
          )}
          {uploading ? "جاري الرفع..." : "رفع PDF"}
        </button>
        <button
          onClick={() => setShowScores((v) => !v)}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 text-purple-600 rounded-xl text-xs font-bold transition-all"
        >
          <Trophy size={14} />
          الدرجات
        </button>
        <button
          onClick={() => onShare(exam)}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-green-50 dark:bg-green-900/20 hover:bg-green-100 text-green-600 rounded-xl text-xs font-bold transition-all"
        >
          <Share2 size={14} />
          مشاركة
        </button>
      </div>
    </motion.div>
  );
};

export default function Exams() {
  const { exams, addExam, updateExam, deleteExam, students, fetchData } =
    useStore();
  const [isModalOpen, setModalOpen] = React.useState(false);
  const [shareExam, setShareExam] = React.useState(null);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAddExam = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    await addExam({
      title: fd.get("title"),
      subject: fd.get("subject"),
      grade: fd.get("grade"),
      group: fd.get("group"),
      maxScore: fd.get("maxScore"),
      date: fd.get("date"),
      pdfUrl: "",
      scores: {},
    });
    setModalOpen(false);
    toast.success("تم إنشاء الامتحان بنجاح 🎉");
  };

  const handleUploadPdf = async (exam, url) => {
    await updateExam({ ...exam, pdfUrl: url });
  };

  const handleEditScores = async (exam, scores) => {
    await updateExam({ ...exam, scores });
  };

  const handleDelete = async (id) => {
    if (window.confirm("هل أنت متأكد من حذف هذا الامتحان؟")) {
      await deleteExam(id);
      toast.info("تم حذف الامتحان");
    }
  };

  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];

  // ── Real stats computed from exam scores ──────────────────────────────────
  const allScoresFlat = exams.flatMap((ex) => {
    const max = Number(ex.maxScore) || 100;
    return Object.values(ex.scores || {})
      .filter((v) => v !== "" && !isNaN(Number(v)))
      .map((v) => ({ score: Number(v), max }));
  });
  const avgPct =
    allScoresFlat.length > 0
      ? Math.round(
          allScoresFlat.reduce(
            (acc, { score, max }) => acc + (score / max) * 100,
            0,
          ) / allScoresFlat.length,
        )
      : null;
  const weakCount = allScoresFlat.filter(
    ({ score, max }) => score / max < 0.5,
  ).length;
  const withPdf = exams.filter((e) => e.pdfUrl).length;
  const withScores = exams.filter(
    (e) => Object.keys(e.scores || {}).length > 0,
  ).length;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            الامتحانات والتقييم
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            أنشئ امتحانات، سجّل درجات الطلاب، وشاركها بسهولة.
          </p>
        </div>
        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl transition-all shadow-lg shadow-blue-200 dark:shadow-none font-bold"
        >
          <Plus size={20} />
          <span>إنشاء امتحان جديد</span>
        </button>
      </div>

      {/* Stats — all real */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {
            label: "إجمالي الامتحانات",
            value: exams.length,
            color: "bg-blue-100 dark:bg-blue-900/30 text-blue-600",
            icon: FileText,
          },
          {
            label: "مرفوع PDF",
            value: `${withPdf} / ${exams.length}`,
            color: "bg-green-100 dark:bg-green-900/30 text-green-600",
            icon: Upload,
          },
          {
            label: "متوسط الدرجات",
            value: avgPct !== null ? `${avgPct}%` : "—",
            color:
              avgPct === null
                ? "bg-gray-100 dark:bg-gray-700 text-gray-400"
                : avgPct >= 70
                  ? "bg-purple-100 dark:bg-purple-900/30 text-purple-600"
                  : "bg-orange-100 dark:bg-orange-900/30 text-orange-500",
            icon: Trophy,
          },
          {
            label: "يحتاجون دعماً",
            value:
              weakCount > 0
                ? weakCount
                : allScoresFlat.length === 0
                  ? "—"
                  : "0 🎉",
            color:
              weakCount > 0
                ? "bg-red-100 dark:bg-red-900/30 text-red-500"
                : "bg-green-100 dark:bg-green-900/30 text-green-600",
            icon: AlertCircle,
          },
        ].map(({ label, value, color, icon: Icon }) => (
          <div
            key={label}
            className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex items-center gap-3"
          >
            <div
              className={`w-11 h-11 ${color} rounded-xl flex items-center justify-center flex-shrink-0`}
            >
              <Icon size={22} />
            </div>
            <div>
              <p className="text-xs text-gray-400">{label}</p>
              <h4 className="text-xl font-bold text-gray-800 dark:text-white">
                {value}
              </h4>
            </div>
          </div>
        ))}
      </div>

      {/* Exam Cards */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm">
        <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">
            قائمة الامتحانات
          </h3>
          <span className="text-sm text-gray-400">{exams.length} امتحان</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 p-6 gap-6">
          {exams.map((exam) => (
            <ExamCard
              key={exam.id}
              exam={exam}
              onShare={setShareExam}
              onUploadPdf={handleUploadPdf}
              onDelete={handleDelete}
              onEditScores={handleEditScores}
              students={students}
            />
          ))}
          {exams.length === 0 && (
            <div className="col-span-full py-20 text-center text-gray-500">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock size={28} className="text-gray-400" />
              </div>
              <p className="font-medium">لا توجد امتحانات مسجلة بعد</p>
              <p className="text-sm text-gray-400 mt-1">
                ابدأ بإنشاء أول امتحان وارفع ملف PDF
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Create Exam Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-800 dark:text-white">
                  إنشاء امتحان جديد
                </h3>
                <button
                  onClick={() => setModalOpen(false)}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
                >
                  <X size={22} className="text-gray-500" />
                </button>
              </div>
              <form onSubmit={handleAddExam} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    عنوان الامتحان
                  </label>
                  <input
                    name="title"
                    required
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="مثال: امتحان شهر أكتوبر"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      المادة
                    </label>
                    <input
                      name="subject"
                      required
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="الرياضيات"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      الصف الدراسي
                    </label>
                    <select
                      name="grade"
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    >
                      {Object.entries(GRADE_LEVELS).map(
                        ([category, grades]) => (
                          <optgroup key={category} label={category}>
                            {grades.map((g) => (
                              <option key={g} value={g}>
                                {g}
                              </option>
                            ))}
                          </optgroup>
                        ),
                      )}
                    </select>
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    المجموعة (اختياري)
                  </label>
                  <select
                    name="group"
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="">الكل</option>
                    {groups.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      الدرجة العظمى
                    </label>
                    <input
                      name="maxScore"
                      type="number"
                      required
                      defaultValue={100}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      تاريخ الامتحان
                    </label>
                    <input
                      name="date"
                      type="date"
                      required
                      defaultValue={new Date().toISOString().split("T")[0]}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-blue-200 dark:shadow-none mt-2"
                >
                  إنشاء الامتحان
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Share Modal */}
      <AnimatePresence>
        {shareExam && (
          <ShareModal
            exam={shareExam}
            onClose={() => setShareExam(null)}
            students={students}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
