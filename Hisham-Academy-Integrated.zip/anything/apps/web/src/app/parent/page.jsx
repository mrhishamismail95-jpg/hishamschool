"use client";
import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Users,
  GraduationCap,
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  ChevronRight,
  Bell,
  LogOut,
  Search,
  BarChart2,
  Star,
  TrendingUp,
  Shield,
  Phone,
} from "lucide-react";
import { useStore } from "@/utils/store";
import { Toaster } from "sonner";

const WAIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

const ADMIN_WA = "201550012054";
const PARENT_SESSION_KEY = "parent_session_v1";

// ── Login ─────────────────────────────────────────────────────────────────────
function ParentLogin({ onLogin }) {
  const [nameOrPhone, setNameOrPhone] = useState("");
  const [studentCode, setStudentCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [portalOpen, setPortalOpen] = useState(true);

  useEffect(() => {
    fetch("/api/academy/settings")
      .then((r) => r.json())
      .then((data) => {
        setPortalOpen(data.settings?.portal_parent !== "false");
      })
      .catch(() => {});
  }, []);

  const handleLogin = async () => {
    setError("");
    if (!nameOrPhone.trim() || !studentCode.trim())
      return setError("جميع الحقول مطلوبة");
    setLoading(true);
    try {
      const res = await fetch("/api/academy/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: "parent",
          name: nameOrPhone,
          code: studentCode.toUpperCase(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "بيانات الدخول غير صحيحة");
      const student = data.user;
      sessionStorage.setItem(
        PARENT_SESSION_KEY,
        JSON.stringify({ studentId: student.id, at: new Date().toISOString() }),
      );
      onLogin(student);
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-[#064e3b] via-[#065f46] to-[#047857] flex items-center justify-center p-4"
      dir="rtl"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-emerald-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-72 h-72 bg-teal-400/10 rounded-full blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-md"
      >
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-2xl">
          {!portalOpen && (
            <div className="mb-5 bg-red-500/20 border border-red-400/30 rounded-2xl p-4 text-center">
              <p className="text-red-200 font-bold text-sm">
                بوابة ولي الأمر مغلقة مؤقتاً
              </p>
            </div>
          )}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl">
              <Users size={38} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-white">بوابة ولي الأمر</h1>
            <p className="text-emerald-200 text-sm mt-1">
              تابع تقدم أبنائك الدراسي
            </p>
          </div>

          <div className="mb-4 bg-emerald-500/10 border border-emerald-400/30 rounded-2xl p-3 text-center">
            <p className="text-emerald-200 text-xs font-bold">
              💡 استخدم اسمك أو رقم هاتفك + كود ابنك (مثال: ST-0001)
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-emerald-200 mb-2">
                اسمك أو رقم هاتفك *
              </label>
              <input
                value={nameOrPhone}
                onChange={(e) => setNameOrPhone(e.target.value)}
                onKeyDown={(e) =>
                  e.key === "Enter" &&
                  document.getElementById("student-code-input")?.focus()
                }
                placeholder="اسم ولي الأمر أو رقم الهاتف"
                className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-emerald-300/60 focus:outline-none focus:border-emerald-400 focus:bg-white/15 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-emerald-200 mb-2">
                كود الطالب (ابنك) *
              </label>
              <input
                id="student-code-input"
                value={studentCode}
                onChange={(e) => setStudentCode(e.target.value.toUpperCase())}
                onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                placeholder="ST-0000"
                className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-emerald-300/60 focus:outline-none focus:border-emerald-400 focus:bg-white/15 transition-all font-mono text-lg tracking-wider"
              />
            </div>
            {error && (
              <div className="bg-red-500/20 border border-red-400/30 rounded-2xl p-4 text-center">
                <p className="text-red-200 text-sm font-bold">⚠️ {error}</p>
                <a
                  href={`https://wa.me/${ADMIN_WA}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-300 text-xs underline mt-1 block"
                >
                  تواصل مع الإدارة
                </a>
              </div>
            )}
            <button
              onClick={handleLogin}
              disabled={loading || !portalOpen}
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-2xl font-black text-base hover:shadow-xl transition-all disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div
                  className="w-6 h-6 border-3 border-white border-t-transparent rounded-full"
                  style={{
                    animation: "spin 0.8s linear infinite",
                    borderWidth: "3px",
                  }}
                />
              ) : (
                "👨‍👩‍👧 دخول بوابة ولي الأمر"
              )}
            </button>
          </div>

          <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-3 gap-2 text-center text-xs">
            <a
              href="/student"
              className="text-emerald-300 hover:text-white underline"
            >
              بوابة الطالب
            </a>
            <a
              href="/teacher"
              className="text-emerald-300 hover:text-white underline"
            >
              بوابة المعلم
            </a>
            <a href="/" className="text-gray-400 hover:text-white underline">
              الرئيسية
            </a>
          </div>
        </div>
      </motion.div>
      <Toaster position="top-center" richColors />
      <style
        jsx
        global
      >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// ── Parent Dashboard ──────────────────────────────────────────────────────────
function ParentDashboard({
  student,
  attendance,
  payments,
  homework,
  exams,
  onLogout,
}) {
  const [activeTab, setActiveTab] = useState("home");

  const myAttendance = attendance.filter((a) => a.studentId === student.id);
  const present = myAttendance.filter((a) => a.status === "present").length;
  const late = myAttendance.filter((a) => a.status === "late").length;
  const absent = myAttendance.filter((a) => a.status === "absent").length;
  const pkg = Number(student.sessionPackage) || 8;
  const used = present + late;
  const remaining = Math.max(0, pkg - used);
  const attendanceRate =
    myAttendance.length > 0
      ? Math.round(((present + late) / myAttendance.length) * 100)
      : 0;

  const thisMonth = new Date().toISOString().slice(0, 7);
  const paidThisMonth = payments.some(
    (p) => p.studentId === student.id && p.date?.startsWith(thisMonth),
  );

  const myHomework = homework.filter(
    (hw) => !hw.group || hw.group === student.group,
  );
  const submittedHW = myHomework.filter((hw) =>
    (hw.submissions || []).some((s) => s.studentId === student.id),
  );
  const pendingHW = myHomework.filter(
    (hw) => !(hw.submissions || []).some((s) => s.studentId === student.id),
  );
  const overdueHW = pendingHW.filter(
    (hw) => hw.dueDate < new Date().toISOString().split("T")[0],
  );

  const myExams = exams.filter(
    (ex) =>
      !ex.grade ||
      ex.grade === student.grade ||
      !ex.group ||
      ex.group === student.group,
  );
  const myScores = myExams
    .map((ex) => {
      const score = ex.scores?.[student.id];
      const max = Number(ex.maxScore) || 100;
      return score !== undefined && score !== ""
        ? {
            title: ex.title,
            subject: ex.subject,
            score: Number(score),
            max,
            pct: Math.round((Number(score) / max) * 100),
          }
        : null;
    })
    .filter(Boolean);
  const avgScore =
    myScores.length > 0
      ? Math.round(myScores.reduce((a, s) => a + s.pct, 0) / myScores.length)
      : null;

  // Recent absences (last 14 days)
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 14);
  const recentAbsences = myAttendance.filter(
    (a) => a.status === "absent" && new Date(a.date) >= cutoff,
  ).length;

  const TABS = [
    { key: "home", label: "الرئيسية", icon: "🏠" },
    { key: "attendance", label: "الحضور", icon: "📅" },
    { key: "homework", label: "الواجبات", icon: "📝" },
    { key: "grades", label: "الدرجات", icon: "📊" },
    { key: "contact", label: "التواصل", icon: "💬" },
  ];

  // Smart alerts for parent
  const alerts = [];
  if (!paidThisMonth)
    alerts.push({
      type: "error",
      msg: "لم يتم سداد اشتراك هذا الشهر",
      icon: "💳",
    });
  if (recentAbsences >= 3)
    alerts.push({
      type: "warn",
      msg: `${recentAbsences} غيابات في آخر أسبوعين`,
      icon: "⚠️",
    });
  if (remaining <= 2)
    alerts.push({
      type: "warn",
      msg: `متبقي ${remaining} حصة فقط — يحتاج تجديد`,
      icon: "⚡",
    });
  if (overdueHW.length > 0)
    alerts.push({
      type: "info",
      msg: `${overdueHW.length} واجب متأخر لم يُسلَّم`,
      icon: "📝",
    });

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-gradient-to-l from-[#064e3b] to-[#065f46] px-4 pt-6 pb-14">
        <div className="max-w-2xl mx-auto flex items-start justify-between">
          <div>
            <p className="text-emerald-300 text-sm mb-1">
              بوابة ولي الأمر 👨‍👧‍👦
            </p>
            <h1 className="text-2xl font-black text-white">{student.name}</h1>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              {student.grade && (
                <span className="text-xs bg-white/20 text-white px-3 py-1 rounded-full">
                  {student.grade}
                </span>
              )}
              {student.group && (
                <span className="text-xs bg-emerald-400/30 text-emerald-200 px-3 py-1 rounded-full">
                  {student.group}
                </span>
              )}
              <span className="text-xs bg-white/10 text-emerald-300 px-3 py-1 rounded-full font-mono">
                {student.code}
              </span>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="text-emerald-300 text-xs hover:text-white underline flex items-center gap-1"
          >
            <LogOut size={14} /> خروج
          </button>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 -mt-8 pb-24">
        {/* Stats card */}
        <div className="bg-white rounded-3xl shadow-xl p-5 mb-5 border border-gray-100">
          <div className="grid grid-cols-4 gap-3">
            {[
              {
                label: "الحضور",
                val: `${attendanceRate}%`,
                sub: `${present + late} جلسة`,
                color: "text-emerald-600",
                icon: "✅",
              },
              {
                label: "الغياب",
                val: absent,
                sub: "إجمالي",
                color: absent >= 5 ? "text-red-500" : "text-gray-600",
                icon: "❌",
              },
              {
                label: "الواجبات",
                val: submittedHW.length,
                sub: `من ${myHomework.length}`,
                color: "text-blue-600",
                icon: "📝",
              },
              {
                label: "المتوسط",
                val: avgScore !== null ? `${avgScore}%` : "—",
                sub: `${myScores.length} امتحان`,
                color: "text-purple-600",
                icon: "🏆",
              },
            ].map(({ label, val, sub, color, icon }) => (
              <div key={label} className="text-center">
                <div className="text-xl mb-1">{icon}</div>
                <p className={`text-xl font-black ${color}`}>{val}</p>
                <p className="text-xs text-gray-500 font-medium">{label}</p>
                <p className="text-[10px] text-gray-400">{sub}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white rounded-2xl p-1 shadow-sm border border-gray-100 mb-5 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex-1 min-w-[56px] py-2.5 rounded-xl font-bold text-[11px] whitespace-nowrap transition-all flex flex-col items-center gap-0.5 ${activeTab === t.key ? "bg-[#065f46] text-white shadow-md" : "text-gray-500 hover:bg-gray-50"}`}
            >
              <span className="text-base">{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4"
          >
            {/* ── Home ─────────────────────────────────────────────────── */}
            {activeTab === "home" && (
              <>
                {/* Smart alerts */}
                {alerts.length > 0 && (
                  <div className="space-y-2">
                    {alerts.map((a, i) => (
                      <div
                        key={i}
                        className={`flex items-start gap-3 p-4 rounded-2xl border-2 ${a.type === "error" ? "bg-red-50 border-red-200" : a.type === "warn" ? "bg-orange-50 border-orange-200" : "bg-blue-50 border-blue-200"}`}
                      >
                        <span className="text-xl flex-shrink-0">{a.icon}</span>
                        <p
                          className={`font-bold text-sm pt-0.5 ${a.type === "error" ? "text-red-700" : a.type === "warn" ? "text-orange-700" : "text-blue-700"}`}
                        >
                          {a.msg}
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Payment status */}
                <div
                  className={`rounded-2xl p-5 border-2 ${paidThisMonth ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"}`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 ${paidThisMonth ? "bg-emerald-100" : "bg-red-100"} rounded-xl flex items-center justify-center`}
                    >
                      {paidThisMonth ? (
                        <CheckCircle2 size={24} className="text-emerald-600" />
                      ) : (
                        <XCircle size={24} className="text-red-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p
                        className={`font-black text-sm ${paidThisMonth ? "text-emerald-700" : "text-red-600"}`}
                      >
                        {paidThisMonth
                          ? "✅ الاشتراك مدفوع هذا الشهر"
                          : "❌ لم يتم سداد اشتراك هذا الشهر"}
                      </p>
                      <p
                        className={`text-xs ${paidThisMonth ? "text-emerald-600" : "text-red-500"}`}
                      >
                        {paidThisMonth
                          ? "شكراً — نتمنى لابنك التوفيق!"
                          : "يرجى التواصل مع الإدارة للسداد"}
                      </p>
                    </div>
                    {!paidThisMonth && (
                      <a
                        href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(`السلام عليكم، أنا ولي أمر الطالب ${student.name} (${student.code}) — أريد سداد رسوم هذا الشهر`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-2 bg-emerald-500 text-white rounded-xl text-xs font-bold flex-shrink-0 flex items-center gap-1"
                      >
                        <WAIcon size={14} /> دفع
                      </a>
                    )}
                  </div>
                </div>

                {/* Session progress */}
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-black text-gray-800">باقة الحصص</h3>
                    <span
                      className={`text-sm font-black ${remaining === 0 ? "text-red-500" : remaining <= 2 ? "text-orange-500" : "text-emerald-600"}`}
                    >
                      {remaining === 0
                        ? "❗ انتهت!"
                        : remaining <= 2
                          ? "⚠️ قاربت!"
                          : "✅ جيد"}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-500">حضر {used} حصة</span>
                    <span className="font-bold text-gray-800">
                      متبقي {remaining} من {pkg}
                    </span>
                  </div>
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden mb-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(used / pkg) * 100}%` }}
                      transition={{ duration: 0.8 }}
                      className={`h-full rounded-full ${remaining === 0 ? "bg-red-500" : remaining <= 2 ? "bg-orange-400" : "bg-emerald-500"}`}
                    />
                  </div>
                  {remaining <= 2 && (
                    <a
                      href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(`السلام عليكم، أنا ولي أمر ${student.name} (${student.code}) — متبقي ${remaining} حصة. أريد تجديد الباقة`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 flex items-center justify-center gap-2 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-sm font-bold transition-all"
                    >
                      <WAIcon size={16} /> تجديد الباقة الآن
                    </a>
                  )}
                </div>

                {/* Academic summary */}
                {avgScore !== null && (
                  <div className="bg-gradient-to-br from-[#064e3b] to-[#065f46] rounded-2xl p-5 text-white">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-black">📊 الأداء الأكاديمي</h3>
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-bold ${avgScore >= 85 ? "bg-green-500/30 text-green-300" : avgScore >= 70 ? "bg-blue-500/30 text-blue-300" : avgScore >= 50 ? "bg-orange-500/30 text-orange-300" : "bg-red-500/30 text-red-300"}`}
                      >
                        {avgScore >= 85
                          ? "ممتاز 🏆"
                          : avgScore >= 70
                            ? "جيد جداً ✅"
                            : avgScore >= 50
                              ? "يحتاج تحسن ⚠️"
                              : "يحتاج دعم ❗"}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-4xl font-black text-emerald-300">
                          {avgScore}%
                        </p>
                        <p className="text-emerald-400 text-xs">
                          متوسط الدرجات
                        </p>
                      </div>
                      <div className="flex-1 space-y-2">
                        {myScores.slice(0, 3).map((s, i) => (
                          <div key={i}>
                            <div className="flex justify-between text-xs mb-0.5">
                              <span className="text-emerald-200 truncate">
                                {s.title}
                              </span>
                              <span className="text-white font-bold">
                                {s.pct}%
                              </span>
                            </div>
                            <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${s.pct >= 70 ? "bg-emerald-400" : s.pct >= 50 ? "bg-orange-400" : "bg-red-400"}`}
                                style={{ width: `${s.pct}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* ── Attendance ────────────────────────────────────────────── */}
            {activeTab === "attendance" && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="p-5 border-b border-gray-100">
                  <h3 className="font-black text-gray-800 mb-3">
                    سجل الحضور الكامل
                  </h3>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      ["text-emerald-600", "bg-emerald-50", "حضر", present],
                      ["text-orange-500", "bg-orange-50", "متأخر", late],
                      ["text-red-500", "bg-red-50", "غائب", absent],
                    ].map(([c, bg, l, v]) => (
                      <div
                        key={l}
                        className={`${bg} rounded-xl p-3 text-center`}
                      >
                        <p className={`text-2xl font-black ${c}`}>{v}</p>
                        <p className="text-xs text-gray-500">{l}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="divide-y divide-gray-50 max-h-80 overflow-y-auto">
                  {[...myAttendance]
                    .sort((a, b) => new Date(b.date) - new Date(a.date))
                    .map((rec, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between px-5 py-3"
                      >
                        <span className="text-sm text-gray-600">
                          {new Date(rec.date).toLocaleDateString("ar-EG", {
                            weekday: "short",
                            day: "numeric",
                            month: "short",
                          })}
                        </span>
                        <span
                          className={`text-xs font-bold px-3 py-1 rounded-full ${rec.status === "present" ? "bg-emerald-100 text-emerald-700" : rec.status === "late" ? "bg-orange-100 text-orange-600" : "bg-red-100 text-red-500"}`}
                        >
                          {rec.status === "present"
                            ? "✅ حاضر"
                            : rec.status === "late"
                              ? "⏰ متأخر"
                              : "❌ غائب"}
                        </span>
                      </div>
                    ))}
                  {myAttendance.length === 0 && (
                    <p className="text-center text-gray-400 py-8">
                      لا يوجد سجل حضور بعد
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* ── Homework ──────────────────────────────────────────────── */}
            {activeTab === "homework" && (
              <div className="space-y-3">
                <div className="flex gap-2 flex-wrap">
                  <span className="px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-xl text-xs font-bold">
                    سلّم: {submittedHW.length}
                  </span>
                  <span className="px-3 py-1.5 bg-orange-100 text-orange-600 rounded-xl text-xs font-bold">
                    لم يسلّم: {pendingHW.length}
                  </span>
                  {overdueHW.length > 0 && (
                    <span className="px-3 py-1.5 bg-red-100 text-red-500 rounded-xl text-xs font-bold">
                      متأخر: {overdueHW.length}
                    </span>
                  )}
                </div>
                {myHomework.length === 0 ? (
                  <div className="bg-white rounded-2xl border py-10 text-center text-gray-400">
                    لا توجد واجبات
                  </div>
                ) : (
                  myHomework.map((hw) => {
                    const submitted = (hw.submissions || []).some(
                      (s) => s.studentId === student.id,
                    );
                    const overdue =
                      hw.dueDate < new Date().toISOString().split("T")[0];
                    return (
                      <div
                        key={hw.id}
                        className={`bg-white rounded-2xl p-5 border-2 ${submitted ? "border-emerald-200" : overdue ? "border-red-200" : "border-gray-100"}`}
                      >
                        <div className="flex items-start justify-between mb-1">
                          <h3 className="font-black text-gray-800">
                            {hw.title}
                          </h3>
                          <span
                            className={`text-xs font-bold px-2.5 py-1 rounded-full ${submitted ? "bg-emerald-100 text-emerald-700" : overdue ? "bg-red-100 text-red-500" : "bg-blue-100 text-blue-600"}`}
                          >
                            {submitted
                              ? "✅ سلّم"
                              : overdue
                                ? "❌ متأخر"
                                : "⏳ معلق"}
                          </span>
                        </div>
                        {hw.subject && (
                          <p className="text-xs text-gray-400 mb-1">
                            {hw.subject}
                          </p>
                        )}
                        <p className="text-xs text-gray-400">
                          الموعد:{" "}
                          {new Date(hw.dueDate).toLocaleDateString("ar-EG")}
                        </p>
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* ── Grades ────────────────────────────────────────────────── */}
            {activeTab === "grades" && (
              <div className="space-y-4">
                {avgScore !== null && (
                  <div className="bg-gradient-to-br from-[#064e3b] to-[#065f46] rounded-2xl p-6 text-center text-white">
                    <p className="text-emerald-300 text-sm mb-1">
                      متوسط درجات ابنك
                    </p>
                    <p className="text-5xl font-black text-emerald-400">
                      {avgScore}%
                    </p>
                    <p className="text-emerald-400 text-xs mt-1">
                      من {myScores.length} امتحان
                    </p>
                  </div>
                )}
                {myScores.length === 0 ? (
                  <div className="bg-white rounded-2xl border py-10 text-center text-gray-400">
                    لا توجد درجات مسجلة
                  </div>
                ) : (
                  myScores.map((s, i) => (
                    <div
                      key={i}
                      className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm"
                    >
                      <div className="flex justify-between mb-2">
                        <div>
                          <h3 className="font-black text-gray-800">
                            {s.title}
                          </h3>
                          <p className="text-xs text-gray-400">{s.subject}</p>
                        </div>
                        <div className="text-left">
                          <p className="text-2xl font-black text-[#064e3b]">
                            {s.score}
                          </p>
                          <p className="text-xs text-gray-400">/{s.max}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${s.pct >= 70 ? "bg-emerald-500" : s.pct >= 50 ? "bg-orange-400" : "bg-red-500"}`}
                            style={{ width: `${s.pct}%` }}
                          />
                        </div>
                        <span
                          className={`text-sm font-black ${s.pct >= 70 ? "text-emerald-600" : s.pct >= 50 ? "text-orange-500" : "text-red-500"}`}
                        >
                          {s.pct}%
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* ── Contact ───────────────────────────────────────────────── */}
            {activeTab === "contact" && (
              <div className="space-y-4">
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
                  <h3 className="font-black text-gray-800 mb-4">
                    التواصل مع الإدارة
                  </h3>
                  <div className="space-y-3">
                    <a
                      href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(`السلام عليكم، أنا ولي أمر الطالب ${student.name} (${student.code}) — لدي استفسار`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-4 p-4 bg-emerald-50 hover:bg-emerald-100 rounded-2xl transition-all border border-emerald-200"
                    >
                      <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0 text-white">
                        <WAIcon size={24} />
                      </div>
                      <div>
                        <p className="font-black text-gray-800">
                          واتساب الإدارة
                        </p>
                        <p className="text-xs text-gray-500">
                          تواصل مباشر مع المدرس أو الإدارة
                        </p>
                        <p className="text-xs text-emerald-600 font-mono mt-0.5">
                          01550012054
                        </p>
                      </div>
                      <ChevronRight
                        size={18}
                        className="text-gray-400 mr-auto"
                      />
                    </a>

                    {student.phone && (
                      <a
                        href={`https://wa.me/2${String(student.phone).replace(/^0/, "")}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-4 p-4 bg-blue-50 hover:bg-blue-100 rounded-2xl transition-all border border-blue-200"
                      >
                        <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0 text-white">
                          <Phone size={22} />
                        </div>
                        <div>
                          <p className="font-black text-gray-800">
                            التواصل مع ابنك
                          </p>
                          <p className="text-xs text-gray-500">
                            رقم هاتف الطالب
                          </p>
                          <p className="text-xs text-blue-600 font-mono mt-0.5">
                            {student.phone}
                          </p>
                        </div>
                      </a>
                    )}
                  </div>
                </div>

                <div className="bg-[#064e3b] rounded-2xl p-5 text-center text-white">
                  <p className="font-black text-lg mb-1">
                    🌟 شارك في تقدم ابنك!
                  </p>
                  <p className="text-emerald-200 text-sm mb-4">
                    تابع الواجبات والامتحانات وتواصل مع المدرس بانتظام
                  </p>
                  <a
                    href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(`السلام عليكم، أنا ولي أمر الطالب ${student.name}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-400 text-[#064e3b] rounded-xl font-black hover:bg-emerald-300 transition-all"
                  >
                    <WAIcon size={18} /> ابعت رسالة الآن
                  </a>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
      <Toaster position="top-center" richColors />
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function ParentPage() {
  const { attendance, payments, homework, exams, fetchData } = useStore();
  const [currentStudent, setCurrentStudent] = useState(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    fetchData();
    try {
      const saved = sessionStorage.getItem(PARENT_SESSION_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        // If full student data stored, use it directly
        if (data.id && data.code) setCurrentStudent(data);
      }
    } catch {}
    setChecking(false);
  }, []);

  const handleLogin = (student) => {
    // Store full student data in session
    sessionStorage.setItem(PARENT_SESSION_KEY, JSON.stringify(student));
    setCurrentStudent(student);
  };

  const handleLogout = () => {
    setCurrentStudent(null);
    sessionStorage.removeItem(PARENT_SESSION_KEY);
  };

  if (checking)
    return (
      <div className="min-h-screen bg-[#064e3b] flex items-center justify-center">
        <div
          className="w-12 h-12 border-4 border-emerald-400 border-t-transparent rounded-full"
          style={{ animation: "spin 0.8s linear infinite" }}
        />
        <style
          jsx
          global
        >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );

  return currentStudent ? (
    <ParentDashboard
      student={currentStudent}
      attendance={attendance}
      payments={payments}
      homework={homework}
      exams={exams}
      onLogout={handleLogout}
    />
  ) : (
    <ParentLogin onLogin={handleLogin} />
  );
}
