"use client";
import React from "react";
import { motion } from "motion/react";
import { Shield, Home, ArrowRight } from "lucide-react";

export default function UnauthorizedPage() {
  return (
    <div
      className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50 flex items-center justify-center p-4"
      dir="rtl"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-2xl p-10 max-w-md w-full text-center border border-red-100"
      >
        <div className="w-24 h-24 bg-red-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
          <Shield size={44} className="text-red-500" />
        </div>
        <h1 className="text-3xl font-black text-gray-800 mb-3">403</h1>
        <h2 className="text-xl font-bold text-gray-700 mb-3">
          ليس لديك صلاحية الوصول
        </h2>
        <p className="text-gray-500 text-sm mb-8 leading-relaxed">
          هذه الصفحة تتطلب صلاحيات خاصة للوصول إليها.
          <br />
          تأكد من تسجيل دخولك بالحساب الصحيح.
        </p>
        <div className="space-y-3">
          <a
            href="/"
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-gradient-to-r from-[#0a2463] to-[#1a3a8a] text-white rounded-2xl font-bold hover:shadow-xl transition-all"
          >
            <Home size={18} /> الصفحة الرئيسية
          </a>
          <button
            onClick={() => window.history.back()}
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all"
          >
            <ArrowRight size={18} /> العودة للخلف
          </button>
        </div>
      </motion.div>
    </div>
  );
}
