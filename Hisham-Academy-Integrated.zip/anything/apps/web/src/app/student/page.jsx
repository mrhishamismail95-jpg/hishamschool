"use client";
import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  GraduationCap,
  CalendarCheck,
  FileText,
  CheckCircle2,
  XCircle,
  Clock,
  BarChart2,
  AlignLeft,
  ChevronRight,
  LogOut,
  Video,
  Phone,
  Lock,
} from "lucide-react";
import { useStore } from "@/utils/store";
import { Toaster } from "sonner";

const WAIcon = ({ size = 18, className = "" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);
const TGIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
  </svg>
);

const ADMIN_WA = "201550012054";

// ── Login: Name + Code (both required) ────────────────────────────────────────
function StudentLogin({ onLogin, portalOpen }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [isAdminBypass, setIsAdminBypass] = useState(false);

  useEffect(() => {
    try {
      if (sessionStorage.getItem("admin_session_v1")) setIsAdminBypass(true);
    } catch {}
  }, []);

  const handleLogin = async () => {
    setError("");
    if (!name.trim() || !code.trim())
      return setError("الاسم والكود مطلوبان معاً");
    setLoading(true);
    try {
      const res = await fetch("/api/academy/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: "student",
          name: name.trim(),
          code: code.trim().toUpperCase(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "بيانات الدخول غير صحيحة");
      sessionStorage.setItem("student_session_v1", JSON.stringify(data.user));
      onLogin(data.user);
    } catch (err) {
      setError(
        err.message ||
          "الاسم أو الكود غير صحيح — تأكد من الكود المرسل لك من المدرس",
      );
    }
    setLoading(false);
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-[#0a2463] via-[#0d2d7a] to-[#0a1a4f] flex items-center justify-center p-4"
      dir="rtl"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 right-1/3 w-80 h-80 bg-blue-400/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-72 h-72 bg-[#f7b731]/5 rounded-full blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-sm"
      >
        {/* Admin bypass banner */}
        {isAdminBypass && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 bg-[#f7b731] rounded-2xl p-3 flex items-center justify-between"
          >
            <p className="text-[#0a2463] font-bold text-sm">
              🛡️ أنت مدير — دخول مباشر؟
            </p>
            <button
              onClick={() => {
                const adminSession = JSON.parse(
                  sessionStorage.getItem("admin_session_v1") || "{}",
                );
                const bypassStudent = {
                  id: "admin_bypass",
                  name: adminSession.name || "المدير",
                  code: "ADMIN",
                  grade: "مدير",
                  group: "كل المجموعات",
                  isAdminView: true,
                };
                sessionStorage.setItem(
                  "student_session_v1",
                  JSON.stringify(bypassStudent),
                );
                onLogin(bypassStudent);
              }}
              className="px-3 py-1.5 bg-[#0a2463] text-white rounded-xl text-xs font-black hover:bg-[#0d2d7a] transition-all"
            >
              دخول فوري
            </button>
          </motion.div>
        )}

        <div
          className={`bg-white/8 backdrop-blur-xl border rounded-3xl p-8 shadow-2xl ${!portalOpen ? "border-red-500/30" : "border-white/15"}`}
        >
          {/* Lock message if portal closed */}
          {!portalOpen && (
            <div className="mb-6 bg-red-500/20 border border-red-500/30 rounded-2xl p-4 text-center">
              <Lock size={24} className="text-red-400 mx-auto mb-2" />
              <p className="text-red-300 font-bold text-sm">
                بوابة الطالب مغلقة مؤقتاً
              </p>
              <p className="text-red-400 text-xs mt-1">
                سيُعاد فتحها قريباً — راسلنا على واتساب
              </p>
            </div>
          )}

          <div className="text-center mb-7">
            <div className="w-20 h-20 bg-gradient-to-br from-[#f7b731] to-[#f0a500] rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl">
              <GraduationCap size={40} className="text-[#0a2463]" />
            </div>
            <h1 className="text-2xl font-black text-white">بوابة الطالب</h1>
            <p className="text-blue-300 text-sm mt-1">
              ادخل اسمك وكودك للمتابعة
            </p>
          </div>

          {/* Code hint */}
          <div className="mb-5 bg-[#f7b731]/10 border border-[#f7b731]/30 rounded-2xl p-3 text-center">
            <p className="text-[#f7b731] text-xs font-bold">
              💡 الكود موجود في بطاقة الطالب
            </p>
            <p className="text-blue-300 text-[11px] mt-0.5">
              مثال: ST-0001 · ST-0002 · ST-0003
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-blue-200 mb-2">
                الاسم الكامل *
              </label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) =>
                  e.key === "Enter" &&
                  document.getElementById("code-input")?.focus()
                }
                placeholder="اسمك كما هو مسجل"
                className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-blue-300/50 focus:outline-none focus:border-[#f7b731] focus:bg-white/15 transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-blue-200 mb-2">
                كود الطالب *
              </label>
              <input
                id="code-input"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                placeholder="ST-0000"
                className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-blue-300/50 focus:outline-none focus:border-[#f7b731] focus:bg-white/15 transition-all font-mono text-lg tracking-wider"
              />
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-red-500/20 border border-red-500/30 rounded-2xl p-3 text-center"
              >
                <p className="text-red-300 text-sm font-bold">⚠️ {error}</p>
                <a
                  href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent("السلام عليكم، لا أعرف كودي كطالب — اسمي: " + name)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#f7b731] text-xs underline mt-1 block"
                >
                  استفسر عن كودك من المدرس
                </a>
              </motion.div>
            )}

            <button
              onClick={handleLogin}
              disabled={loading || !portalOpen}
              className="w-full py-4 bg-gradient-to-r from-[#f7b731] to-[#f0a500] text-[#0a2463] rounded-2xl font-black text-base hover:shadow-xl transition-all disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div
                  className="w-6 h-6 border-3 border-[#0a2463] border-t-transparent rounded-full"
                  style={{
                    animation: "spin 0.8s linear infinite",
                    borderWidth: "3px",
                  }}
                />
              ) : (
                "🎓 دخول بوابتي"
              )}
            </button>
          </div>

          <div className="mt-5 pt-4 border-t border-white/10 grid grid-cols-3 gap-2 text-center">
            <a
              href="/parent"
              className="text-emerald-400 hover:text-white underline text-xs"
            >
              ولي الأمر
            </a>
            <a
              href="/teacher"
              className="text-purple-400 hover:text-white underline text-xs"
            >
              المعلم
            </a>
            <a
              href="/"
              className="text-gray-400 hover:text-white underline text-xs"
            >
              الرئيسية
            </a>
          </div>
        </div>
      </motion.div>
      <style
        jsx
        global
      >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <Toaster position="top-center" richColors />
    </div>
  );
}

// ── Student Dashboard ─────────────────────────────────────────────────────────
function StudentDashboard({
  student,
  onLogout,
  attendance,
  payments,
  homework,
  exams,
}) {
  const [activeTab, setActiveTab] = useState("home");

  const myAttendance = attendance.filter((a) => a.studentId === student.id);
  const present = myAttendance.filter((a) => a.status === "present").length;
  const late = myAttendance.filter((a) => a.status === "late").length;
  const absent = myAttendance.filter((a) => a.status === "absent").length;
  const pkg = Number(student.sessionPackage) || 8;
  const used = present + late;
  const remaining = Math.max(0, pkg - used);
  const attRate =
    myAttendance.length > 0
      ? Math.round(((present + late) / myAttendance.length) * 100)
      : 0;
  const thisMonth = new Date().toISOString().slice(0, 7);
  const paidThisMonth = payments.some(
    (p) => p.studentId === student.id && p.date?.startsWith(thisMonth),
  );

  const myHomework = homework.filter(
    (hw) => !hw.group || hw.group === student.group,
  );
  const submittedHW = myHomework.filter((hw) =>
    (hw.submissions || []).some((s) => s.studentId === student.id),
  );
  const pendingHW = myHomework.filter(
    (hw) => !(hw.submissions || []).some((s) => s.studentId === student.id),
  );
  const overdueHW = pendingHW.filter(
    (hw) => hw.dueDate < new Date().toISOString().split("T")[0],
  );

  const myExams = exams.filter(
    (ex) =>
      !ex.grade ||
      ex.grade === student.grade ||
      !ex.group ||
      ex.group === student.group,
  );
  const myScores = myExams
    .map((ex) => {
      const score = ex.scores?.[student.id];
      const max = Number(ex.maxScore) || 100;
      return score !== undefined && score !== ""
        ? {
            title: ex.title,
            subject: ex.subject,
            score: Number(score),
            max,
            pct: Math.round((Number(score) / max) * 100),
            date: ex.date,
          }
        : null;
    })
    .filter(Boolean);
  const avgScore =
    myScores.length > 0
      ? Math.round(myScores.reduce((a, s) => a + s.pct, 0) / myScores.length)
      : null;

  const schedules = useMemo(() => {
    try {
      const all = JSON.parse(localStorage.getItem("schedule") || "[]");
      return all.filter(
        (s) => !s.name || s.name === student.group || !student.group,
      );
    } catch {
      return [];
    }
  }, [student.group]);

  // Lesson links sent by teacher
  const lessonLinks = useMemo(() => {
    try {
      const msgs = JSON.parse(
        localStorage.getItem("teacher_messages_v1") || "[]",
      );
      return msgs.filter(
        (m) =>
          (!m.group || m.group === student.group || m.group === "all") &&
          m.type === "lesson_link",
      );
    } catch {
      return [];
    }
  }, [student.group]);

  const TABS = [
    { key: "home", label: "الرئيسية", icon: "🏠" },
    { key: "attendance", label: "حضوري", icon: "📅" },
    { key: "homework", label: "الواجبات", icon: "📝" },
    { key: "exams", label: "درجاتي", icon: "📊" },
    { key: "schedule", label: "الجدول", icon: "📆" },
    { key: "bookings", label: "احجز حصة", icon: "🎟️" },
    { key: "contact", label: "التواصل", icon: "💬" },
  ];

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-gradient-to-l from-[#0a2463] to-[#0d2d7a] px-4 pt-6 pb-16">
        <div className="max-w-2xl mx-auto flex items-start justify-between">
          <div>
            <p className="text-blue-300 text-sm mb-1">أهلاً بك 👋</p>
            <h1 className="text-2xl font-black text-white">{student.name}</h1>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              {student.grade && (
                <span className="text-xs bg-white/20 text-white px-3 py-1 rounded-full">
                  {student.grade}
                </span>
              )}
              {student.group && (
                <span className="text-xs bg-[#f7b731]/20 text-[#f7b731] px-3 py-1 rounded-full">
                  {student.group}
                </span>
              )}
              {student.code && (
                <span className="text-xs bg-white/10 text-blue-300 px-3 py-1 rounded-full font-mono font-bold">
                  {student.code}
                </span>
              )}
            </div>
          </div>
          <button
            onClick={onLogout}
            className="text-blue-300 text-xs hover:text-white underline flex items-center gap-1"
          >
            <LogOut size={14} /> خروج
          </button>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 -mt-10 pb-24">
        {/* Stats Card */}
        <div className="bg-white rounded-3xl shadow-xl p-5 mb-5 border border-gray-100">
          <div className="grid grid-cols-4 gap-3">
            {[
              {
                l: "متبقي",
                v: remaining,
                s: `من ${pkg}`,
                c:
                  remaining === 0
                    ? "text-red-500"
                    : remaining <= 2
                      ? "text-orange-500"
                      : "text-green-600",
                i: "⚡",
              },
              {
                l: "الحضور",
                v: `${attRate}%`,
                s: `${used} حضور`,
                c: "text-blue-600",
                i: "✅",
              },
              {
                l: "الواجبات",
                v: submittedHW.length,
                s: `من ${myHomework.length}`,
                c: "text-purple-600",
                i: "📝",
              },
              {
                l: "المتوسط",
                v: avgScore !== null ? `${avgScore}%` : "—",
                s: `${myScores.length} امتحان`,
                c: "text-teal-600",
                i: "🏆",
              },
            ].map(({ l, v, s, c, i }) => (
              <div key={l} className="text-center">
                <div className="text-xl mb-1">{i}</div>
                <p className={`text-xl font-black ${c}`}>{v}</p>
                <p className="text-xs text-gray-500">{l}</p>
                <p className="text-[10px] text-gray-400">{s}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Lesson Links from Teacher */}
        {lessonLinks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 bg-gradient-to-r from-purple-600 to-purple-800 rounded-2xl p-4"
          >
            <p className="text-purple-200 text-xs mb-3 font-bold">
              📡 روابط الحصص المباشرة
            </p>
            <div className="space-y-2">
              {lessonLinks.slice(0, 3).map((m, i) => (
                <a
                  key={i}
                  href={m.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-all"
                >
                  <Video size={18} className="flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm truncate">
                      {m.title || "رابط الحصة"}
                    </p>
                    {m.group && m.group !== "all" && (
                      <p className="text-purple-300 text-xs">{m.group}</p>
                    )}
                  </div>
                  <ChevronRight
                    size={16}
                    className="flex-shrink-0 text-purple-300"
                  />
                </a>
              ))}
            </div>
          </motion.div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 bg-white rounded-2xl p-1 shadow-sm border border-gray-100 mb-5 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => t.key === "bookings" ? (window.location.href = "/bookings") : setActiveTab(t.key)}
              className={`flex-1 min-w-[50px] py-2.5 rounded-xl font-bold text-[11px] whitespace-nowrap transition-all flex flex-col items-center gap-0.5 ${activeTab === t.key ? "bg-[#0a2463] text-white shadow-md" : "text-gray-500 hover:bg-gray-50"}`}
            >
              <span>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4"
          >
            {/* ── Home ── */}
            {activeTab === "home" && (
              <>
                {/* Payment */}
                <div
                  className={`rounded-2xl p-5 border-2 ${paidThisMonth ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 ${paidThisMonth ? "bg-green-100" : "bg-red-100"} rounded-xl flex items-center justify-center flex-shrink-0`}
                    >
                      {paidThisMonth ? (
                        <CheckCircle2 size={24} className="text-green-600" />
                      ) : (
                        <XCircle size={24} className="text-red-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p
                        className={`font-black text-sm ${paidThisMonth ? "text-green-700" : "text-red-600"}`}
                      >
                        {paidThisMonth
                          ? "✅ الاشتراك مدفوع هذا الشهر"
                          : "❌ لم يتم سداد الاشتراك"}
                      </p>
                      <p
                        className={`text-xs ${paidThisMonth ? "text-green-600" : "text-red-500"}`}
                      >
                        {paidThisMonth
                          ? "شكراً — مجهودك يستحق!"
                          : "تواصل مع الإدارة للسداد"}
                      </p>
                    </div>
                    {!paidThisMonth && (
                      <a
                        href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(`السلام عليكم، أنا ${student.name} (${student.code}) وأريد سداد رسوم هذا الشهر`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-shrink-0 px-3 py-2 bg-green-500 text-white rounded-xl text-xs font-bold flex items-center gap-1"
                      >
                        <WAIcon size={14} /> سداد
                      </a>
                    )}
                  </div>
                </div>

                {/* Session Progress */}
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-black text-gray-800">باقة الحصص</h3>
                    <span
                      className={`text-sm font-black ${remaining === 0 ? "text-red-500" : remaining <= 2 ? "text-orange-500" : "text-green-600"}`}
                    >
                      {remaining === 0
                        ? "❗ انتهت!"
                        : remaining <= 2
                          ? "⚠️ قاربت!"
                          : "✅ جيد"}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-500">حضرت {used} حصة</span>
                    <span className="font-bold text-gray-800">
                      متبقي {remaining} من {pkg}
                    </span>
                  </div>
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden mb-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{
                        width: `${Math.min((used / pkg) * 100, 100)}%`,
                      }}
                      transition={{ duration: 0.8 }}
                      className={`h-full rounded-full ${remaining === 0 ? "bg-red-500" : remaining <= 2 ? "bg-orange-400" : "bg-green-500"}`}
                    />
                  </div>
                  {remaining <= 2 && (
                    <a
                      href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(`السلام عليكم، أنا ${student.name} (${student.code}) — متبقي ${remaining} حصة. أريد تجديد الباقة`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 py-2.5 bg-green-500 text-white rounded-xl text-sm font-bold transition-all"
                    >
                      <WAIcon size={16} /> تواصل لتجديد الباقة
                    </a>
                  )}
                </div>

                {/* Overdue HW alert */}
                {overdueHW.length > 0 && (
                  <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4">
                    <h3 className="font-black text-orange-700 mb-2">
                      ⚠️ واجبات متأخرة ({overdueHW.length})
                    </h3>
                    {overdueHW.map((hw) => (
                      <div key={hw.id} className="text-sm text-orange-600">
                        • {hw.title}
                      </div>
                    ))}
                    <button
                      onClick={() => setActiveTab("homework")}
                      className="mt-2 text-xs text-orange-700 font-bold underline"
                    >
                      عرض الكل
                    </button>
                  </div>
                )}

                {/* Schedule quick view */}
                {schedules.length > 0 && (
                  <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-black text-gray-800">📅 جدولي</h3>
                      <button
                        onClick={() => setActiveTab("schedule")}
                        className="text-xs text-[#0a2463] font-bold"
                      >
                        الكل
                      </button>
                    </div>
                    <div className="space-y-2">
                      {schedules.slice(0, 3).map((s) => (
                        <div
                          key={s.id}
                          className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl"
                        >
                          <Clock
                            size={15}
                            className="text-blue-600 flex-shrink-0"
                          />
                          <div>
                            <p className="font-bold text-gray-800 text-sm">
                              {s.name}
                            </p>
                            <p className="text-xs text-blue-600">
                              {s.day} · {s.time}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Academic summary */}
                {avgScore !== null && (
                  <div className="bg-gradient-to-br from-[#0a2463] to-[#1a3a8a] rounded-2xl p-5 text-white">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-black">📊 مستواك الأكاديمي</h3>
                      <span
                        className={`text-xs px-3 py-1 rounded-full font-bold ${avgScore >= 85 ? "bg-green-500/30 text-green-300" : avgScore >= 70 ? "bg-blue-500/30 text-blue-300" : avgScore >= 50 ? "bg-orange-500/30 text-orange-300" : "bg-red-500/30 text-red-300"}`}
                      >
                        {avgScore >= 85
                          ? "ممتاز 🏆"
                          : avgScore >= 70
                            ? "جيد جداً ✅"
                            : avgScore >= 50
                              ? "يحتاج تحسن ⚠️"
                              : "يحتاج دعم ❗"}
                      </span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center flex-shrink-0">
                        <p className="text-4xl font-black text-[#f7b731]">
                          {avgScore}%
                        </p>
                        <p className="text-blue-300 text-xs">متوسط درجاتك</p>
                      </div>
                      <div className="flex-1 space-y-2">
                        {myScores.slice(0, 3).map((s, i) => (
                          <div key={i}>
                            <div className="flex justify-between text-xs mb-0.5">
                              <span className="text-blue-200 truncate">
                                {s.title}
                              </span>
                              <span className="text-white font-bold">
                                {s.pct}%
                              </span>
                            </div>
                            <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${s.pct >= 70 ? "bg-green-400" : s.pct >= 50 ? "bg-orange-400" : "bg-red-400"}`}
                                style={{ width: `${s.pct}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* ── Attendance ── */}
            {activeTab === "attendance" && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="p-5 border-b border-gray-100">
                  <h3 className="font-black text-gray-800 mb-3">سجل حضوري</h3>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      ["text-green-600", "bg-green-50", "حضر", present],
                      ["text-orange-500", "bg-orange-50", "متأخر", late],
                      ["text-red-500", "bg-red-50", "غائب", absent],
                    ].map(([c, bg, l, v]) => (
                      <div
                        key={l}
                        className={`${bg} rounded-xl p-3 text-center`}
                      >
                        <p className={`text-2xl font-black ${c}`}>{v}</p>
                        <p className="text-xs text-gray-500">{l}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="divide-y divide-gray-50 max-h-96 overflow-y-auto">
                  {[...myAttendance]
                    .sort((a, b) => new Date(b.date) - new Date(a.date))
                    .map((rec, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between px-5 py-3"
                      >
                        <span className="text-sm text-gray-600">
                          {new Date(rec.date).toLocaleDateString("ar-EG", {
                            weekday: "short",
                            day: "numeric",
                            month: "short",
                          })}
                        </span>
                        <span
                          className={`text-xs font-bold px-3 py-1 rounded-full ${rec.status === "present" ? "bg-green-100 text-green-700" : rec.status === "late" ? "bg-orange-100 text-orange-600" : "bg-red-100 text-red-500"}`}
                        >
                          {rec.status === "present"
                            ? "✅ حاضر"
                            : rec.status === "late"
                              ? "⏰ متأخر"
                              : "❌ غائب"}
                        </span>
                      </div>
                    ))}
                  {myAttendance.length === 0 && (
                    <p className="text-center text-gray-400 py-8">
                      لا يوجد سجل حضور بعد
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* ── Homework ── */}
            {activeTab === "homework" && (
              <div className="space-y-3">
                <div className="flex gap-2 flex-wrap">
                  <span className="px-3 py-1.5 bg-green-100 text-green-700 rounded-xl text-xs font-bold">
                    سلّمت: {submittedHW.length}
                  </span>
                  <span className="px-3 py-1.5 bg-orange-100 text-orange-600 rounded-xl text-xs font-bold">
                    معلق: {pendingHW.length}
                  </span>
                  {overdueHW.length > 0 && (
                    <span className="px-3 py-1.5 bg-red-100 text-red-500 rounded-xl text-xs font-bold">
                      متأخر: {overdueHW.length}
                    </span>
                  )}
                </div>
                {myHomework.length === 0 ? (
                  <div className="bg-white rounded-2xl border py-10 text-center text-gray-400">
                    لا توجد واجبات
                  </div>
                ) : (
                  myHomework.map((hw) => {
                    const submitted = (hw.submissions || []).some(
                      (s) => s.studentId === student.id,
                    );
                    const overdue =
                      hw.dueDate < new Date().toISOString().split("T")[0];
                    return (
                      <div
                        key={hw.id}
                        className={`bg-white rounded-2xl p-5 border-2 ${submitted ? "border-green-200" : overdue ? "border-red-200" : "border-gray-100"}`}
                      >
                        <div className="flex items-start justify-between mb-1">
                          <div>
                            <h3 className="font-black text-gray-800">
                              {hw.title}
                            </h3>
                            {hw.subject && (
                              <p className="text-xs text-gray-400">
                                {hw.subject}
                              </p>
                            )}
                          </div>
                          <span
                            className={`text-xs font-bold px-2.5 py-1 rounded-full flex-shrink-0 ${submitted ? "bg-green-100 text-green-700" : overdue ? "bg-red-100 text-red-500" : "bg-blue-100 text-blue-600"}`}
                          >
                            {submitted
                              ? "✅ سلّمت"
                              : overdue
                                ? "❌ متأخر"
                                : "⏳ معلق"}
                          </span>
                        </div>
                        <p className="text-xs text-gray-400">
                          الموعد:{" "}
                          {new Date(hw.dueDate).toLocaleDateString("ar-EG")}
                        </p>
                        {hw.description && (
                          <p className="text-xs text-gray-500 mt-1">
                            {hw.description}
                          </p>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* ── Exams ── */}
            {activeTab === "exams" && (
              <div className="space-y-4">
                {avgScore !== null && (
                  <div className="bg-gradient-to-br from-[#0a2463] to-[#1a3a8a] rounded-2xl p-6 text-center text-white">
                    <p className="text-blue-200 text-sm mb-1">متوسط درجاتك</p>
                    <p className="text-5xl font-black text-[#f7b731]">
                      {avgScore}%
                    </p>
                    <div className="flex justify-center gap-2 mt-3">
                      <span
                        className={`text-xs px-3 py-1 rounded-full font-bold ${avgScore >= 85 ? "bg-green-500/30 text-green-300" : avgScore >= 70 ? "bg-blue-500/30 text-blue-300" : avgScore >= 50 ? "bg-orange-500/30 text-orange-300" : "bg-red-500/30 text-red-300"}`}
                      >
                        {avgScore >= 85
                          ? "🏆 ممتاز"
                          : avgScore >= 70
                            ? "✅ جيد جداً"
                            : avgScore >= 50
                              ? "⚠️ يحتاج تحسن"
                              : "❗ يحتاج دعم"}
                      </span>
                    </div>
                  </div>
                )}
                {myScores.length === 0 ? (
                  <div className="bg-white rounded-2xl border border-gray-100 py-10 text-center">
                    <BarChart2
                      size={36}
                      className="mx-auto text-gray-300 mb-3"
                    />
                    <p className="text-gray-400">لا توجد درجات مسجلة بعد</p>
                  </div>
                ) : (
                  myScores.map((s, i) => (
                    <div
                      key={i}
                      className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm"
                    >
                      <div className="flex justify-between mb-3">
                        <div>
                          <h3 className="font-black text-gray-800">
                            {s.title}
                          </h3>
                          <p className="text-xs text-gray-400">{s.subject}</p>
                        </div>
                        <div className="text-left">
                          <p className="text-2xl font-black text-[#0a2463]">
                            {s.score}
                          </p>
                          <p className="text-xs text-gray-400">/{s.max}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${s.pct >= 70 ? "bg-green-500" : s.pct >= 50 ? "bg-orange-400" : "bg-red-500"}`}
                            style={{ width: `${s.pct}%` }}
                          />
                        </div>
                        <span
                          className={`text-sm font-black flex-shrink-0 ${s.pct >= 70 ? "text-green-600" : s.pct >= 50 ? "text-orange-500" : "text-red-500"}`}
                        >
                          {s.pct}%
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* ── Schedule ── */}
            {activeTab === "schedule" && (
              <div className="space-y-4">
                <h3 className="font-black text-gray-800 text-lg">
                  جدولي الأسبوعي 📆
                </h3>
                {schedules.length === 0 ? (
                  <div className="bg-white rounded-2xl border py-10 text-center">
                    <div className="text-4xl mb-3">📆</div>
                    <p className="text-gray-500 font-medium">
                      لا يوجد جدول بعد
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      سيُضاف من المدرس قريباً
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {[
                      "السبت",
                      "الأحد",
                      "الاثنين",
                      "الثلاثاء",
                      "الأربعاء",
                      "الخميس",
                      "الجمعة",
                    ].map((day) => {
                      const dayS = schedules.filter((s) => s.day === day);
                      if (!dayS.length) return null;
                      return (
                        <div
                          key={day}
                          className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
                        >
                          <div className="px-5 py-3 bg-[#0a2463]">
                            <span className="text-white font-black text-sm">
                              {day}
                            </span>
                          </div>
                          {dayS
                            .sort((a, b) =>
                              (a.time || "").localeCompare(b.time || ""),
                            )
                            .map((s) => (
                              <div
                                key={s.id}
                                className="flex items-center gap-3 px-5 py-3 border-b border-gray-50 last:border-0"
                              >
                                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                  <Clock size={15} className="text-blue-600" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-bold text-gray-800 text-sm">
                                    {s.name}
                                  </p>
                                  <p className="text-xs text-[#0a2463] font-medium">
                                    {s.time}
                                  </p>
                                </div>
                                {s.location && (
                                  <span className="text-xs text-gray-400">
                                    {s.location}
                                  </span>
                                )}
                              </div>
                            ))}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* ── Contact ── */}
            {activeTab === "contact" && (
              <div className="space-y-4">
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-3">
                  <h3 className="font-black text-gray-800 mb-1">
                    📞 تواصل مع المدرس والإدارة
                  </h3>
                  <a
                    href={`https://wa.me/${ADMIN_WA}?text=${encodeURIComponent(`السلام عليكم، أنا ${student.name} (${student.code}) — لدي استفسار`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 bg-green-50 hover:bg-green-100 rounded-2xl border border-green-200 transition-all"
                  >
                    <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center flex-shrink-0 text-white">
                      <WAIcon size={24} />
                    </div>
                    <div>
                      <p className="font-black text-gray-800">واتساب الإدارة</p>
                      <p className="text-xs text-gray-500">
                        تواصل مباشر مع المدرس أو الإدارة
                      </p>
                      <p className="text-xs text-green-600 font-mono">
                        0{ADMIN_WA.substring(1)}
                      </p>
                    </div>
                    <ChevronRight size={18} className="text-gray-400 mr-auto" />
                  </a>
                  <a
                    href={`https://t.me/+${ADMIN_WA}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 bg-blue-50 hover:bg-blue-100 rounded-2xl border border-blue-200 transition-all"
                  >
                    <div className="w-12 h-12 bg-[#229ED9] rounded-xl flex items-center justify-center flex-shrink-0 text-white">
                      <TGIcon size={22} />
                    </div>
                    <div>
                      <p className="font-black text-gray-800">تيليجرام</p>
                      <p className="text-xs text-gray-500">
                        القناة الرسمية والإعلانات والمواد
                      </p>
                    </div>
                    <ChevronRight size={18} className="text-gray-400 mr-auto" />
                  </a>
                </div>

                <div className="bg-[#0a2463] rounded-2xl p-5 text-center text-white">
                  <p className="font-black text-lg mb-1">كودك الخاص 🎓</p>
                  <p className="text-4xl font-black text-[#f7b731] font-mono mt-2 mb-1">
                    {student.code}
                  </p>
                  <p className="text-blue-300 text-xs">
                    احتفظ بهذا الكود — هو هويتك في المنصة
                  </p>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
      <Toaster position="top-center" richColors />
      <style
        jsx
        global
      >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function StudentPage() {
  const { students, attendance, payments, homework, exams, fetchData } =
    useStore();
  const [currentStudent, setCurrentStudent] = useState(null);
  const [checking, setChecking] = useState(true);
  const [portalOpen, setPortalOpen] = useState(true);

  useEffect(() => {
    fetchData();
    // Load portal status from DB settings
    fetch("/api/academy/settings")
      .then((r) => r.json())
      .then((data) => {
        setPortalOpen(data.settings?.portal_student !== "false");
      })
      .catch(() => {
        // Fallback to localStorage
        try {
          const settings = JSON.parse(
            localStorage.getItem("academy_portal_settings_v1") || "{}",
          );
          setPortalOpen(settings?.portals?.student !== false);
        } catch {}
      });
    try {
      const saved = sessionStorage.getItem("student_session_v1");
      if (saved) {
        const s = JSON.parse(saved);
        if (s.isAdminView || s.code) setCurrentStudent(s);
        else sessionStorage.removeItem("student_session_v1");
      }
    } catch {}
    setChecking(false);
  }, []);

  // Refresh student data from store after load
  useEffect(() => {
    if (!currentStudent || currentStudent.isAdminView || students.length === 0)
      return;
    const fresh = students.find((s) => s.id === currentStudent.id);
    if (fresh) setCurrentStudent(fresh);
  }, [students]);

  const handleLogin = (student) => setCurrentStudent(student);
  const handleLogout = () => {
    fetch("/api/academy/auth", { method: "DELETE" }).catch(() => {});
    setCurrentStudent(null);
    sessionStorage.removeItem("student_session_v1");
  };

  if (checking)
    return (
      <div className="min-h-screen bg-[#0a2463] flex items-center justify-center">
        <div
          className="w-12 h-12 border-4 border-[#f7b731] border-t-transparent rounded-full"
          style={{ animation: "spin 0.8s linear infinite" }}
        />
        <style
          jsx
          global
        >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );

  return currentStudent ? (
    <StudentDashboard
      student={currentStudent}
      onLogout={handleLogout}
      attendance={attendance}
      payments={payments}
      homework={homework}
      exams={exams}
    />
  ) : (
    <StudentLogin onLogin={handleLogin} portalOpen={portalOpen} />
  );
}
