"use client";
import { useEffect } from "react";

export default function AdminPortalRedirect() {
  useEffect(() => {
    window.location.replace("/admin");
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="text-center">
        <div
          className="w-10 h-10 border-4 border-blue-400 border-t-transparent rounded-full mx-auto mb-3"
          style={{ animation: "spin 0.9s linear infinite" }}
        />
        <p className="text-gray-400 text-sm">جاري التوجيه...</p>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
