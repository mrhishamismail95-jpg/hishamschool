"use client";
import React, { useState, useEffect } from "react";
import {
  Save,
  Building2,
  Users,
  UserPlus,
  Database,
  Download,
  Shield,
  Globe,
  Phone,
  MessageSquare,
  CheckCircle2,
  Loader2,
  Lock,
  Unlock,
  CreditCard,
  Wallet as WalletIcon,
} from "lucide-react";
import { toast } from "sonner";
import { motion } from "motion/react";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("academy");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);

  // Academy Info
  const [academyName, setAcademyName] = useState("");
  const [adminPhone, setAdminPhone] = useState("");
  const [whatsappGroup, setWhatsappGroup] = useState("");
  const [telegramChannel, setTelegramChannel] = useState("");
  const [vodafoneCash, setVodafoneCash] = useState("");
  const [instaPay, setInstaPay] = useState("");

  // Portal Control - separate for each role
  const [portalStudent, setPortalStudent] = useState(true);
  const [portalTeacher, setPortalTeacher] = useState(true);
  const [portalParent, setPortalParent] = useState(true);

  // Registration - separate for each role
  const [regStudent, setRegStudent] = useState(true);
  const [regTeacher, setRegTeacher] = useState(true);
  const [regParent, setRegParent] = useState(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/academy/settings");
      if (!res.ok) throw new Error("فشل تحميل الإعدادات");
      const data = await res.json();
      const s = data.settings || {};
      setAcademyName(s.academy_name || "");
      setAdminPhone(s.admin_phone || "");
      setWhatsappGroup(s.whatsapp_group || "");
      setTelegramChannel(s.telegram_channel || "");
      setVodafoneCash(s.vodafone_cash || "");
      setInstaPay(s.insta_pay || "");
      setPortalStudent(s.portal_student !== "false");
      setPortalTeacher(s.portal_teacher !== "false");
      setPortalParent(s.portal_parent !== "false");
      setRegStudent(s.reg_student !== "false");
      setRegTeacher(s.reg_teacher !== "false");
      setRegParent(s.reg_parent !== "false");
    } catch (err) {
      console.error(err);
      toast.error("فشل تحميل الإعدادات");
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const settings = {
        academy_name: academyName,
        admin_phone: adminPhone,
        whatsapp_group: whatsappGroup,
        telegram_channel: telegramChannel,
        vodafone_cash: vodafoneCash,
        insta_pay: instaPay,
        portal_student: portalStudent ? "true" : "false",
        portal_teacher: portalTeacher ? "true" : "false",
        portal_parent: portalParent ? "true" : "false",
        reg_student: regStudent ? "true" : "false",
        reg_teacher: regTeacher ? "true" : "false",
        reg_parent: regParent ? "true" : "false",
      };
      const res = await fetch("/api/academy/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings }),
      });
      if (!res.ok) throw new Error("فشل حفظ الإعدادات");
      toast.success("تم حفظ الإعدادات بنجاح ✅");
    } catch (err) {
      console.error(err);
      toast.error("حدث خطأ أثناء الحفظ");
    } finally {
      setSaving(false);
    }
  };

  const exportBackup = async () => {
    setExporting(true);
    try {
      const [
        studentsRes,
        attendanceRes,
        paymentsRes,
        examsRes,
        hwRes,
        groupsRes,
        pkgRes,
      ] = await Promise.all([
        fetch("/api/academy/students"),
        fetch("/api/academy/attendance"),
        fetch("/api/academy/payments"),
        fetch("/api/academy/exams"),
        fetch("/api/academy/homework"),
        fetch("/api/academy/groups"),
        fetch("/api/academy/packages"),
      ]);
      const students = (await studentsRes.json()).students || [];
      const attendance = (await attendanceRes.json()).attendance || [];
      const payments = (await paymentsRes.json()).payments || [];
      const exams = (await examsRes.json()).exams || [];
      const homework = (await hwRes.json()).homework || [];
      const groups = (await groupsRes.json()).groups || [];
      const packages = (await pkgRes.json()).packages || [];

      const backup = {
        version: "3.0",
        exportDate: new Date().toISOString(),
        students,
        attendance,
        payments,
        exams,
        homework,
        groups,
        packages,
      };
      const blob = new Blob([JSON.stringify(backup, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `backup_${new Date().toISOString().split("T")[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("تم تصدير النسخة الاحتياطية ✅");
    } catch (err) {
      console.error(err);
      toast.error("فشل التصدير");
    } finally {
      setExporting(false);
    }
  };

  const tabs = [
    { key: "academy", label: "معلومات الأكاديمية", icon: Building2 },
    { key: "portals", label: "التحكم بالبوابات", icon: Users },
    { key: "registration", label: "التسجيل", icon: UserPlus },
    { key: "payment", label: "طرق الدفع", icon: CreditCard },
    { key: "backup", label: "النسخ الاحتياطي", icon: Database },
  ];

  const inp =
    "w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-[#0a2463] focus:outline-none text-sm";
  const lbl = "block text-xs font-bold text-gray-600 mb-1.5";

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2
          size={32}
          className="text-[#0a2463]"
          style={{ animation: "spin 0.8s linear infinite" }}
        />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-black text-[#0a2463]">⚙️ إعدادات النظام</h2>
        <p className="text-gray-500 text-sm mt-1">
          إدارة الأكاديمية والبوابات والنسخ الاحتياطي
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {tabs.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-sm transition-all whitespace-nowrap ${activeTab === key ? "bg-[#0a2463] text-white shadow-lg" : "bg-white text-gray-600 border border-gray-200 hover:border-[#0a2463]"}`}
          >
            <Icon size={18} /> {label}
          </button>
        ))}
      </div>

      {/* Academy Info Tab */}
      {activeTab === "academy" && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Building2 size={24} className="text-blue-600" />
            </div>
            <div>
              <h3 className="font-black text-gray-800">معلومات الأكاديمية</h3>
              <p className="text-xs text-gray-500">الاسم والتواصل الرئيسي</p>
            </div>
          </div>
          <div>
            <label className={lbl}>اسم الأكاديمية</label>
            <input
              className={inp}
              placeholder="أكاديمية حسام التعليمية"
              value={academyName}
              onChange={(e) => setAcademyName(e.target.value)}
            />
          </div>
          <div>
            <label className={lbl}>رقم الواتساب الإداري</label>
            <div className="relative">
              <Phone
                size={18}
                className="absolute right-3 top-3.5 text-gray-400"
              />
              <input
                className={`${inp} pr-10`}
                placeholder="201550012054"
                value={adminPhone}
                onChange={(e) => setAdminPhone(e.target.value)}
              />
            </div>
          </div>
          <div>
            <label className={lbl}>رابط مجموعة الواتساب</label>
            <div className="relative">
              <MessageSquare
                size={18}
                className="absolute right-3 top-3.5 text-gray-400"
              />
              <input
                className={`${inp} pr-10`}
                placeholder="https://chat.whatsapp.com/..."
                value={whatsappGroup}
                onChange={(e) => setWhatsappGroup(e.target.value)}
              />
            </div>
          </div>
          <div>
            <label className={lbl}>رابط قناة تيليجرام</label>
            <div className="relative">
              <Globe
                size={18}
                className="absolute right-3 top-3.5 text-gray-400"
              />
              <input
                className={`${inp} pr-10`}
                placeholder="https://t.me/..."
                value={telegramChannel}
                onChange={(e) => setTelegramChannel(e.target.value)}
              />
            </div>
          </div>
          <button
            onClick={saveSettings}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 bg-[#0a2463] hover:bg-[#0d2d7a] disabled:opacity-60 text-white py-3.5 rounded-xl font-bold transition-all"
          >
            {saving ? (
              <Loader2
                size={18}
                style={{ animation: "spin 0.8s linear infinite" }}
              />
            ) : (
              <Save size={18} />
            )}
            {saving ? "جاري الحفظ..." : "حفظ التغييرات"}
          </button>
        </motion.div>
      )}

      {/* Portals Control Tab */}
      {activeTab === "portals" && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Shield size={24} className="text-purple-600" />
            </div>
            <div>
              <h3 className="font-black text-gray-800">التحكم بالبوابات</h3>
              <p className="text-xs text-gray-500">
                إيقاف أو تفعيل وصول المستخدمين لكل دور
              </p>
            </div>
          </div>
          {[
            {
              label: "بوابة الطالب",
              state: portalStudent,
              setState: setPortalStudent,
              color: "blue",
            },
            {
              label: "بوابة المعلم",
              state: portalTeacher,
              setState: setPortalTeacher,
              color: "purple",
            },
            {
              label: "بوابة ولي الأمر",
              state: portalParent,
              setState: setPortalParent,
              color: "emerald",
            },
          ].map(({ label, state, setState, color }) => (
            <div
              key={label}
              className={`flex items-center justify-between p-4 rounded-xl border-2 ${state ? `border-${color}-200 bg-${color}-50` : "border-gray-200 bg-gray-50"}`}
            >
              <div className="flex items-center gap-3">
                {state ? (
                  <Unlock size={20} className={`text-${color}-600`} />
                ) : (
                  <Lock size={20} className="text-gray-400" />
                )}
                <div>
                  <p className="font-bold text-gray-800">{label}</p>
                  <p className="text-xs text-gray-500">
                    {state
                      ? "مفعّلة — يمكن للمستخدمين الدخول"
                      : "موقوفة — لا يمكن الدخول"}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setState(!state)}
                className={`px-5 py-2 rounded-lg font-bold text-sm transition-all ${state ? `bg-${color}-600 text-white` : "bg-gray-300 text-gray-600"}`}
              >
                {state ? "إيقاف" : "تفعيل"}
              </button>
            </div>
          ))}
          <button
            onClick={saveSettings}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 bg-[#0a2463] text-white py-3.5 rounded-xl font-bold"
          >
            {saving ? (
              <Loader2
                size={18}
                style={{ animation: "spin 0.8s linear infinite" }}
              />
            ) : (
              <Save size={18} />
            )}
            حفظ
          </button>
        </motion.div>
      )}

      {/* Registration Tab */}
      {activeTab === "registration" && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <UserPlus size={24} className="text-green-600" />
            </div>
            <div>
              <h3 className="font-black text-gray-800">إعدادات التسجيل</h3>
              <p className="text-xs text-gray-500">
                فتح أو إغلاق التسجيل لكل دور بشكل منفصل
              </p>
            </div>
          </div>
          {[
            {
              label: "تسجيل الطلاب",
              state: regStudent,
              setState: setRegStudent,
              desc: "السماح للطلاب الجدد بالتسجيل",
            },
            {
              label: "تسجيل المعلمين",
              state: regTeacher,
              setState: setRegTeacher,
              desc: "السماح للمعلمين الجدد بالتسجيل",
            },
            {
              label: "تسجيل أولياء الأمور",
              state: regParent,
              setState: setRegParent,
              desc: "السماح لأولياء الأمور بالتسجيل",
            },
          ].map(({ label, state, setState, desc }) => (
            <div
              key={label}
              className={`p-4 rounded-2xl border-2 ${state ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  {state ? (
                    <CheckCircle2 size={20} className="text-green-600" />
                  ) : (
                    <Lock size={20} className="text-red-600" />
                  )}
                  <div>
                    <p className="font-black text-gray-800">{label}</p>
                    <p className="text-sm text-gray-600 mt-0.5">{desc}</p>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setState(!state)}
                className={`w-full py-2.5 rounded-xl font-bold transition-all ${state ? "bg-red-500 hover:bg-red-600 text-white" : "bg-green-500 hover:bg-green-600 text-white"}`}
              >
                {state ? "إغلاق التسجيل" : "فتح التسجيل"}
              </button>
            </div>
          ))}
          <button
            onClick={saveSettings}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 bg-[#0a2463] text-white py-3.5 rounded-xl font-bold mt-4"
          >
            {saving ? (
              <Loader2
                size={18}
                style={{ animation: "spin 0.8s linear infinite" }}
              />
            ) : (
              <Save size={18} />
            )}
            حفظ
          </button>
        </motion.div>
      )}

      {/* Payment Methods Tab */}
      {activeTab === "payment" && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
              <WalletIcon size={24} className="text-orange-600" />
            </div>
            <div>
              <h3 className="font-black text-gray-800">طرق الدفع</h3>
              <p className="text-xs text-gray-500">
                أرقام فودافون كاش وإنستاباي
              </p>
            </div>
          </div>
          <div>
            <label className={lbl}>رقم فودافون كاش</label>
            <div className="relative">
              <Phone
                size={18}
                className="absolute right-3 top-3.5 text-gray-400"
              />
              <input
                className={`${inp} pr-10`}
                placeholder="01xxxxxxxxx"
                value={vodafoneCash}
                onChange={(e) => setVodafoneCash(e.target.value)}
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">
              سيظهر للطلاب عند التسجيل لإتمام الدفع
            </p>
          </div>
          <div>
            <label className={lbl}>رقم إنستاباي</label>
            <div className="relative">
              <CreditCard
                size={18}
                className="absolute right-3 top-3.5 text-gray-400"
              />
              <input
                className={`${inp} pr-10`}
                placeholder="01xxxxxxxxx"
                value={instaPay}
                onChange={(e) => setInstaPay(e.target.value)}
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">
              رقم بديل للدفع الإلكتروني
            </p>
          </div>
          <button
            onClick={saveSettings}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 bg-[#0a2463] hover:bg-[#0d2d7a] disabled:opacity-60 text-white py-3.5 rounded-xl font-bold transition-all"
          >
            {saving ? (
              <Loader2
                size={18}
                style={{ animation: "spin 0.8s linear infinite" }}
              />
            ) : (
              <Save size={18} />
            )}
            {saving ? "جاري الحفظ..." : "حفظ"}
          </button>
        </motion.div>
      )}

      {/* Backup Tab */}
      {activeTab === "backup" && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-100"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Database size={24} className="text-blue-600" />
            </div>
            <div>
              <h3 className="font-black text-gray-800">النسخ الاحتياطي</h3>
              <p className="text-xs text-gray-500">
                تصدير بيانات الأكاديمية بالكامل
              </p>
            </div>
          </div>
          <div className="p-5 bg-blue-50 rounded-xl border border-blue-200 mb-4">
            <p className="text-sm text-gray-700 mb-2">
              <strong>يشمل:</strong> الطلاب، الحضور، المدفوعات، الامتحانات،
              الواجبات، المجموعات، الباقات
            </p>
            <p className="text-xs text-gray-500">
              الملف سيكون بصيغة JSON يمكن استيراده لاحقاً
            </p>
          </div>
          <button
            onClick={exportBackup}
            disabled={exporting}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white py-3.5 rounded-xl font-bold"
          >
            {exporting ? (
              <Loader2
                size={18}
                style={{ animation: "spin 0.8s linear infinite" }}
              />
            ) : (
              <Download size={18} />
            )}
            {exporting ? "جاري التصدير..." : "تصدير نسخة احتياطية"}
          </button>
        </motion.div>
      )}

      <style jsx global>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
