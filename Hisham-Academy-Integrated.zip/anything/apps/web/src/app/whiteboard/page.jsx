"use client";
import React, { useRef, useState, useEffect, useCallback } from "react";
import {
  Pencil,
  Eraser,
  Minus,
  Square,
  Circle,
  Type,
  Download,
  Trash2,
  Undo2,
  Redo2,
  ChevronDown,
  ChevronUp,
  Palette,
  Calculator,
  ZoomIn,
  ZoomOut,
  RotateCcw,
} from "lucide-react";

// ── Math Symbols ──────────────────────────────────────────────────────────────
const MATH_SYMBOLS = [
  ["α", "β", "γ", "δ", "θ", "π", "σ", "φ", "ω", "λ", "μ", "ε"],
  ["∑", "∫", "∂", "∞", "√", "∛", "∜", "∝", "±", "×", "÷", "="],
  ["≠", "≤", "≥", "≈", "∈", "∉", "⊂", "⊃", "∪", "∩", "∀", "∃"],
  ["→", "←", "↔", "⇒", "⇔", "⊥", "∥", "∠", "△", "□", "⊙", "⊕"],
  ["¹", "²", "³", "⁴", "⁵", "⁻¹", "½", "⅓", "¼", "⅔", "¾", "%"],
  ["sin", "cos", "tan", "log", "ln", "lim", "→0", "dx", "dy", "∫₀", "∫ₐ", "Δ"],
];

const COLORS = [
  "#000000",
  "#1a1a2e",
  "#16213e",
  "#e63946",
  "#f77f00",
  "#fcbf49",
  "#2dc653",
  "#0077b6",
  "#7209b7",
  "#9e2a2b",
  "#ffffff",
  "#6c757d",
];

const TOOLS = [
  { id: "pen", label: "قلم", icon: Pencil },
  { id: "eraser", label: "ممحاة", icon: Eraser },
  { id: "line", label: "خط", icon: Minus },
  { id: "rect", label: "مستطيل", icon: Square },
  { id: "circle", label: "دائرة", icon: Circle },
  { id: "text", label: "نص", icon: Type },
];

export default function WhiteboardPage() {
  const canvasRef = useRef(null);
  const overlayRef = useRef(null);
  const [tool, setTool] = useState("pen");
  const [color, setColor] = useState("#000000");
  const [bgColor, setBgColor] = useState("#ffffff");
  const [size, setSize] = useState(3);
  const [drawing, setDrawing] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [history, setHistory] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [showSymbols, setShowSymbols] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [textPos, setTextPos] = useState(null);
  const [fontSize, setFontSize] = useState(20);

  // ── Initialize canvas ──────────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    saveHistory();
  }, []);

  const saveHistory = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setHistory((prev) => [...prev.slice(-30), canvas.toDataURL()]);
    setRedoStack([]);
  };

  const undo = () => {
    if (history.length < 2) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const newHistory = [...history];
    const current = newHistory.pop();
    setRedoStack((prev) => [current, ...prev]);
    setHistory(newHistory);
    const img = new Image();
    img.src = newHistory[newHistory.length - 1];
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    };
  };

  const redo = () => {
    if (redoStack.length === 0) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const [next, ...rest] = redoStack;
    setRedoStack(rest);
    setHistory((prev) => [...prev, next]);
    const img = new Image();
    img.src = next;
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    };
  };

  const clear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    saveHistory();
  };

  const download = () => {
    const canvas = canvasRef.current;
    const a = document.createElement("a");
    a.href = canvas.toDataURL("image/png");
    a.download = `whiteboard-${new Date().toISOString().split("T")[0]}.png`;
    a.click();
  };

  // ── Get canvas coordinates ─────────────────────────────────────────────────
  const getPos = useCallback((e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    if (e.touches) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }, []);

  // ── Draw ───────────────────────────────────────────────────────────────────
  const startDraw = useCallback(
    (e) => {
      e.preventDefault();
      const pos = getPos(e);

      if (tool === "text") {
        setTextPos(pos);
        return;
      }

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      ctx.strokeStyle = color;
      ctx.lineWidth = size;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      if (tool === "pen") {
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
      } else if (tool === "eraser") {
        ctx.strokeStyle = bgColor;
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
      }

      setStartPos(pos);
      setDrawing(true);
    },
    [tool, color, size, bgColor, getPos],
  );

  const draw = useCallback(
    (e) => {
      if (!drawing) return;
      e.preventDefault();
      const pos = getPos(e);
      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");

      if (tool === "pen" || tool === "eraser") {
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
      } else {
        // For shapes: use overlay for preview
        const overlay = overlayRef.current;
        const octx = overlay.getContext("2d");
        octx.clearRect(0, 0, overlay.width, overlay.height);
        octx.strokeStyle = color;
        octx.lineWidth = size;
        octx.lineCap = "round";

        if (tool === "line") {
          octx.beginPath();
          octx.moveTo(startPos.x, startPos.y);
          octx.lineTo(pos.x, pos.y);
          octx.stroke();
        } else if (tool === "rect") {
          octx.strokeRect(
            startPos.x,
            startPos.y,
            pos.x - startPos.x,
            pos.y - startPos.y,
          );
        } else if (tool === "circle") {
          const rx = Math.abs(pos.x - startPos.x) / 2;
          const ry = Math.abs(pos.y - startPos.y) / 2;
          const cx = startPos.x + (pos.x - startPos.x) / 2;
          const cy = startPos.y + (pos.y - startPos.y) / 2;
          octx.beginPath();
          octx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
          octx.stroke();
        }
      }
    },
    [drawing, tool, color, size, startPos, getPos],
  );

  const endDraw = useCallback(
    (e) => {
      if (!drawing) return;
      e.preventDefault();
      const pos = getPos(e);
      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");

      if (tool === "line") {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = size;
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
      } else if (tool === "rect") {
        ctx.strokeStyle = color;
        ctx.lineWidth = size;
        ctx.strokeRect(
          startPos.x,
          startPos.y,
          pos.x - startPos.x,
          pos.y - startPos.y,
        );
      } else if (tool === "circle") {
        const rx = Math.abs(pos.x - startPos.x) / 2;
        const ry = Math.abs(pos.y - startPos.y) / 2;
        const cx = startPos.x + (pos.x - startPos.x) / 2;
        const cy = startPos.y + (pos.y - startPos.y) / 2;
        ctx.strokeStyle = color;
        ctx.lineWidth = size;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Clear overlay
      const overlay = overlayRef.current;
      if (overlay) {
        const octx = overlay.getContext("2d");
        octx.clearRect(0, 0, overlay.width, overlay.height);
      }

      setDrawing(false);
      saveHistory();
    },
    [drawing, tool, color, size, startPos, getPos],
  );

  // ── Add Symbol ─────────────────────────────────────────────────────────────
  const addSymbol = (sym) => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const x = canvas.width / 2 + (Math.random() - 0.5) * 80;
    const y = canvas.height / 2 + (Math.random() - 0.5) * 80;
    ctx.font = `bold ${fontSize + 8}px serif`;
    ctx.fillStyle = color;
    ctx.fillText(sym, x, y);
    saveHistory();
  };

  // ── Add Text ───────────────────────────────────────────────────────────────
  const submitText = () => {
    if (!textInput.trim() || !textPos) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.font = `bold ${fontSize}px Cairo, sans-serif`;
    ctx.fillStyle = color;
    ctx.fillText(textInput, textPos.x, textPos.y);
    setTextInput("");
    setTextPos(null);
    saveHistory();
  };

  // ── Cursor style ───────────────────────────────────────────────────────────
  const cursorStyle =
    tool === "eraser" ? "cell" : tool === "text" ? "text" : "crosshair";

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col bg-gray-50 dark:bg-gray-900 -m-4 lg:-m-8">
      {/* ── Toolbar ──────────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3 flex items-center gap-3 flex-wrap shadow-sm z-10">
        {/* Title */}
        <div className="flex items-center gap-2 ml-2">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center">
            <Calculator size={16} className="text-white" />
          </div>
          <span className="font-black text-gray-800 dark:text-white text-sm hidden sm:block">
            سبورة الرياضيات
          </span>
        </div>

        <div className="w-px h-8 bg-gray-200 dark:bg-gray-700" />

        {/* Tools */}
        <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-xl">
          {TOOLS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTool(id)}
              title={label}
              className={`p-2 rounded-lg transition-all ${tool === id ? "bg-white dark:bg-gray-600 shadow-md text-blue-600" : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"}`}
            >
              <Icon size={18} />
            </button>
          ))}
        </div>

        <div className="w-px h-8 bg-gray-200 dark:bg-gray-700" />

        {/* Colors */}
        <div className="flex gap-1.5 flex-wrap">
          {COLORS.map((c) => (
            <button
              key={c}
              onClick={() => setColor(c)}
              style={{ backgroundColor: c }}
              className={`w-6 h-6 rounded-full border-2 transition-all hover:scale-110 ${color === c ? "border-blue-500 scale-125" : "border-transparent"}`}
            />
          ))}
          <label
            title="لون مخصص"
            className="w-6 h-6 rounded-full border-2 border-gray-300 overflow-hidden cursor-pointer hover:scale-110 transition-all"
          >
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="opacity-0 w-0 h-0"
            />
            <div
              className="w-full h-full"
              style={{
                background:
                  "conic-gradient(red, yellow, lime, cyan, blue, magenta, red)",
              }}
            />
          </label>
        </div>

        <div className="w-px h-8 bg-gray-200 dark:bg-gray-700" />

        {/* Size */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500 hidden sm:block">الحجم:</span>
          <input
            type="range"
            min={1}
            max={30}
            value={size}
            onChange={(e) => setSize(+e.target.value)}
            className="w-20 accent-blue-600"
          />
          <span className="text-xs font-bold text-gray-700 dark:text-gray-300 w-5">
            {size}
          </span>
        </div>

        {tool === "text" && (
          <>
            <div className="w-px h-8 bg-gray-200 dark:bg-gray-700" />
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500">خط:</span>
              <input
                type="range"
                min={10}
                max={60}
                value={fontSize}
                onChange={(e) => setFontSize(+e.target.value)}
                className="w-16 accent-blue-600"
              />
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300 w-5">
                {fontSize}
              </span>
            </div>
          </>
        )}

        <div className="w-px h-8 bg-gray-200 dark:bg-gray-700" />

        {/* Background */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500 hidden sm:block">خلفية:</span>
          <div className="flex gap-1">
            {["#ffffff", "#fef9c3", "#dcfce7", "#dbeafe", "#111827"].map(
              (bg) => (
                <button
                  key={bg}
                  onClick={() => {
                    setBgColor(bg);
                    const c = canvasRef.current;
                    const ctx = c.getContext("2d");
                    ctx.fillStyle = bg;
                    ctx.fillRect(0, 0, c.width, c.height);
                    saveHistory();
                  }}
                  style={{
                    backgroundColor: bg,
                    border:
                      bgColor === bg
                        ? "2px solid #3b82f6"
                        : "2px solid #d1d5db",
                  }}
                  className="w-6 h-6 rounded-lg hover:scale-110 transition-all"
                />
              ),
            )}
          </div>
        </div>

        <div className="flex-1" />

        {/* Math Symbols Toggle */}
        <button
          onClick={() => setShowSymbols((v) => !v)}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-xs transition-all ${showSymbols ? "bg-purple-600 text-white" : "bg-purple-50 dark:bg-purple-900/30 text-purple-600 border border-purple-200"}`}
        >
          <span>∑</span> رموز رياضية{" "}
          {showSymbols ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </button>

        {/* Actions */}
        <div className="flex gap-1">
          <button
            onClick={undo}
            title="تراجع"
            disabled={history.length < 2}
            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-all disabled:opacity-30"
          >
            <Undo2 size={18} />
          </button>
          <button
            onClick={redo}
            title="إعادة"
            disabled={redoStack.length === 0}
            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-all disabled:opacity-30"
          >
            <Redo2 size={18} />
          </button>
          <button
            onClick={clear}
            title="مسح الكل"
            className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
          >
            <Trash2 size={18} />
          </button>
          <button
            onClick={download}
            title="تحميل"
            className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-all"
          >
            <Download size={18} />
          </button>
        </div>
      </div>

      {/* ── Math Symbols Panel ─────────────────────────────────────────────── */}
      {showSymbols && (
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3 shadow-sm z-10">
          <div className="flex flex-wrap gap-2">
            {MATH_SYMBOLS.map((row, ri) =>
              row.map((sym, si) => (
                <button
                  key={`${ri}-${si}`}
                  onClick={() => addSymbol(sym)}
                  className="w-9 h-9 bg-gray-50 dark:bg-gray-700 hover:bg-purple-100 dark:hover:bg-purple-900/40 border border-gray-200 dark:border-gray-600 rounded-lg text-sm font-bold text-gray-800 dark:text-gray-200 hover:text-purple-700 dark:hover:text-purple-300 transition-all hover:scale-110"
                  title={sym}
                >
                  {sym}
                </button>
              )),
            )}
          </div>
        </div>
      )}

      {/* ── Canvas Area ───────────────────────────────────────────────────────── */}
      <div className="flex-1 relative overflow-hidden">
        {/* Main Canvas */}
        <canvas
          ref={canvasRef}
          style={{
            cursor: cursorStyle,
            touchAction: "none",
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
          }}
          onMouseDown={startDraw}
          onMouseMove={draw}
          onMouseUp={endDraw}
          onMouseLeave={endDraw}
          onTouchStart={startDraw}
          onTouchMove={draw}
          onTouchEnd={endDraw}
        />
        {/* Overlay (for shape preview) */}
        <canvas
          ref={overlayRef}
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            pointerEvents: "none",
          }}
        />

        {/* Text input overlay */}
        {textPos && (
          <div
            style={{
              position: "absolute",
              left: textPos.x,
              top: textPos.y - 30,
            }}
            className="z-20"
          >
            <input
              autoFocus
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submitText();
                if (e.key === "Escape") {
                  setTextPos(null);
                  setTextInput("");
                }
              }}
              placeholder="اكتب هنا..."
              style={{
                fontSize,
                color,
                fontFamily: "Cairo, sans-serif",
                fontWeight: "bold",
              }}
              className="border-b-2 border-blue-500 outline-none bg-transparent min-w-[120px]"
            />
            <div className="flex gap-1 mt-1">
              <button
                onClick={submitText}
                className="px-2 py-0.5 bg-blue-600 text-white text-xs rounded-lg"
              >
                ✓
              </button>
              <button
                onClick={() => {
                  setTextPos(null);
                  setTextInput("");
                }}
                className="px-2 py-0.5 bg-gray-200 text-gray-600 text-xs rounded-lg"
              >
                ✗
              </button>
            </div>
          </div>
        )}

        {/* Hint */}
        {tool === "text" && !textPos && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/60 text-white text-xs px-4 py-2 rounded-full pointer-events-none">
            انقر على السبورة لإضافة نص
          </div>
        )}
      </div>

      {/* ── Status Bar ─────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-2 flex items-center justify-between text-xs text-gray-400">
        <span>
          الأداة:{" "}
          <span className="font-bold text-gray-700 dark:text-gray-300">
            {TOOLS.find((t) => t.id === tool)?.label}
          </span>
        </span>
        <span>
          سبورة الرياضيات التفاعلية — اضغط{" "}
          <kbd className="bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded font-mono">
            Ctrl+Z
          </kbd>{" "}
          للتراجع
        </span>
        <span>
          حجم القلم:{" "}
          <span className="font-bold text-gray-700 dark:text-gray-300">
            {size}px
          </span>
        </span>
      </div>

      <style jsx global>{`
        @media (max-width: 640px) {
          .whiteboard-toolbar { overflow-x: auto; flex-wrap: nowrap; }
        }
      `}</style>
    </div>
  );
}
