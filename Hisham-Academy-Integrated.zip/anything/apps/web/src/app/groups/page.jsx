"use client";
import React, { useState, useEffect } from "react";
import {
  Users,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  Clock,
  MapPin,
  DollarSign,
  UserCheck,
  X,
  Search,
  Filter,
  Loader2,
  BookOpen,
  Save,
} from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";

const GRADE_LEVELS = {
  ابتدائي: [
    "الأول الابتدائي",
    "الثاني الابتدائي",
    "الثالث الابتدائي",
    "الرابع الابتدائي",
    "الخامس الابتدائي",
    "السادس الابتدائي",
  ],
  إعدادي: ["الأول الإعدادي", "الثاني الإعدادي", "الثالث الإعدادي"],
  ثانوي: ["الأول الثانوي", "الثاني الثانوي", "الثالث الثانوي"],
  "لغات إعدادي": [
    "الأول الإعدادي لغات",
    "الثاني الإعدادي لغات",
    "الثالث الإعدادي لغات",
  ],
  "لغات ثانوي": [
    "الأول الثانوي لغات",
    "الثاني الثانوي لغات",
    "الثالث الثانوي لغات",
  ],
};

const DAYS = [
  "السبت",
  "الأحد",
  "الإثنين",
  "الثلاثاء",
  "الأربعاء",
  "الخميس",
  "الجمعة",
];

function GroupModal({ group, onClose, onSave, packages }) {
  const [name, setName] = useState(group?.name || "");
  const [gradeCategory, setGradeCategory] = useState(
    group?.grade_category || "",
  );
  const [grade, setGrade] = useState(group?.grade || "");
  const [subject, setSubject] = useState(group?.subject || "");
  const [dayOfWeek, setDayOfWeek] = useState(group?.day_of_week || "");
  const [startTime, setStartTime] = useState(group?.start_time || "");
  const [endTime, setEndTime] = useState(group?.end_time || "");
  const [maxStudents, setMaxStudents] = useState(group?.max_students || 20);
  const [price, setPrice] = useState(group?.price || "");
  const [packageId, setPackageId] = useState(group?.package_id || "");
  const [location, setLocation] = useState(group?.location || "");
  const [notes, setNotes] = useState(group?.notes || "");
  const [saving, setSaving] = useState(false);

  const inp =
    "w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-[#0a2463] focus:outline-none text-sm";
  const lbl = "block text-xs font-bold text-gray-600 mb-1.5";

  const handleSave = async () => {
    if (!name.trim()) return toast.error("اسم المجموعة مطلوب");
    setSaving(true);
    try {
      await onSave({
        id: group?.id,
        name: name.trim(),
        gradeCategory,
        grade,
        subject,
        dayOfWeek,
        startTime,
        endTime,
        maxStudents: Number(maxStudents),
        price: price ? Number(price) : null,
        packageId: packageId ? Number(packageId) : null,
        location,
        notes,
        active: true,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Users size={24} className="text-blue-600" />
            </div>
            <div>
              <h3 className="text-xl font-black text-gray-800">
                {group ? "تعديل المجموعة" : "مجموعة جديدة"}
              </h3>
              <p className="text-xs text-gray-500">
                أدخل بيانات المجموعة الدراسية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-xl transition-all"
          >
            <X size={20} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className={lbl}>اسم المجموعة *</label>
            <input
              className={inp}
              placeholder="مثال: مجموعة السبت صباحاً"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={lbl}>المرحلة</label>
              <select
                className={inp}
                value={gradeCategory}
                onChange={(e) => {
                  setGradeCategory(e.target.value);
                  setGrade("");
                }}
              >
                <option value="">اختر...</option>
                {Object.keys(GRADE_LEVELS).map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className={lbl}>الصف</label>
              <select
                className={inp}
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                disabled={!gradeCategory}
              >
                <option value="">اختر...</option>
                {(GRADE_LEVELS[gradeCategory] || []).map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className={lbl}>المادة</label>
            <input
              className={inp}
              placeholder="الرياضيات، العلوم، اللغة العربية..."
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className={lbl}>اليوم</label>
              <select
                className={inp}
                value={dayOfWeek}
                onChange={(e) => setDayOfWeek(e.target.value)}
              >
                <option value="">اختر...</option>
                {DAYS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className={lbl}>من الساعة</label>
              <input
                type="time"
                className={inp}
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>
            <div>
              <label className={lbl}>إلى الساعة</label>
              <input
                type="time"
                className={inp}
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={lbl}>الحد الأقصى للطلاب</label>
              <input
                type="number"
                className={inp}
                value={maxStudents}
                onChange={(e) => setMaxStudents(e.target.value)}
                min="1"
              />
            </div>
            <div>
              <label className={lbl}>السعر (ج.م)</label>
              <input
                type="number"
                className={inp}
                placeholder="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className={lbl}>الباقة (اختياري)</label>
            <select
              className={inp}
              value={packageId}
              onChange={(e) => setPackageId(e.target.value)}
            >
              <option value="">بدون باقة</option>
              {packages
                .filter((p) => p.active)
                .map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} — {p.sessions_count} حصة
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className={lbl}>المكان</label>
            <input
              className={inp}
              placeholder="القاعة الأولى، المبنى الرئيسي..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>

          <div>
            <label className={lbl}>ملاحظات</label>
            <textarea
              className={`${inp} h-20 resize-none`}
              placeholder="أي ملاحظات إضافية..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 flex items-center justify-center gap-2 bg-[#0a2463] hover:bg-[#0d2d7a] disabled:opacity-60 text-white py-3.5 rounded-xl font-bold"
            >
              {saving ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <Save size={18} />
              )}
              {saving ? "جاري الحفظ..." : "حفظ"}
            </button>
            <button
              onClick={onClose}
              className="px-6 py-3.5 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition-all"
            >
              إلغاء
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function GroupsPage() {
  const [groups, setGroups] = useState([]);
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState(null);
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [groupsRes, packagesRes] = await Promise.all([
        fetch("/api/academy/groups?active=false"),
        fetch("/api/academy/packages"),
      ]);
      const groupsData = await groupsRes.json();
      const packagesData = await packagesRes.json();
      setGroups(groupsData.groups || []);
      setPackages(packagesData.packages || []);
    } catch (err) {
      console.error(err);
      toast.error("فشل تحميل المجموعات");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (data) => {
    try {
      const url = data.id
        ? `/api/academy/groups/${data.id}`
        : "/api/academy/groups";
      const method = data.id ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("فشل الحفظ");
      toast.success(data.id ? "تم التعديل ✅" : "تم إضافة المجموعة ✅");
      setModalOpen(false);
      setEditingGroup(null);
      loadData();
    } catch (err) {
      console.error(err);
      toast.error("حدث خطأ أثناء الحفظ");
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("هل تريد حذف هذه المجموعة؟")) return;
    try {
      const res = await fetch(`/api/academy/groups/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("فشل الحذف");
      toast.success("تم الحذف");
      loadData();
    } catch (err) {
      console.error(err);
      toast.error("حدث خطأ");
    }
  };

  const filteredGroups = groups.filter((g) => {
    if (search && !g.name?.toLowerCase().includes(search.toLowerCase()))
      return false;
    if (gradeFilter && g.grade !== gradeFilter) return false;
    return true;
  });

  const activeGroups = filteredGroups.filter((g) => g.active);
  const inactiveGroups = filteredGroups.filter((g) => !g.active);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 size={32} className="text-[#0a2463] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-[#0a2463]">
            👥 المجموعات الدراسية
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            إدارة المجموعات والجداول الدراسية
          </p>
        </div>
        <button
          onClick={() => {
            setEditingGroup(null);
            setModalOpen(true);
          }}
          className="flex items-center gap-2 bg-[#0a2463] hover:bg-[#0d2d7a] text-white px-5 py-3 rounded-xl font-bold transition-all shadow-lg"
        >
          <Plus size={18} /> مجموعة جديدة
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "إجمالي المجموعات", value: groups.length, color: "blue" },
          { label: "مجموعات نشطة", value: activeGroups.length, color: "green" },
          {
            label: "مجموعات موقوفة",
            value: inactiveGroups.length,
            color: "gray",
          },
          {
            label: "إجمالي المقاعد",
            value: groups.reduce(
              (acc, g) => acc + Number(g.max_students || 0),
              0,
            ),
            color: "purple",
          },
        ].map(({ label, value, color }) => (
          <div
            key={label}
            className={`bg-${color}-50 border border-${color}-200 rounded-2xl p-4 text-center`}
          >
            <p className={`text-3xl font-black text-${color}-600`}>{value}</p>
            <p className="text-xs text-gray-600 mt-1">{label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1 relative">
          <Search
            size={18}
            className="absolute right-3 top-3.5 text-gray-400"
          />
          <input
            className="w-full pr-10 pl-4 py-3 rounded-xl border-2 border-gray-200 focus:border-[#0a2463] focus:outline-none text-sm"
            placeholder="ابحث عن مجموعة..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select
          className="px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-[#0a2463] focus:outline-none text-sm"
          value={gradeFilter}
          onChange={(e) => setGradeFilter(e.target.value)}
        >
          <option value="">كل الصفوف</option>
          {Object.values(GRADE_LEVELS)
            .flat()
            .map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
        </select>
      </div>

      {/* Groups Grid */}
      {filteredGroups.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users size={36} className="text-gray-400" />
          </div>
          <p className="text-gray-500 font-bold">لا توجد مجموعات</p>
          <button
            onClick={() => {
              setEditingGroup(null);
              setModalOpen(true);
            }}
            className="mt-4 text-sm text-[#0a2463] hover:underline font-bold"
          >
            أضف مجموعة جديدة
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredGroups.map((g) => (
            <motion.div
              key={g.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`bg-white rounded-2xl p-5 border-2 transition-all hover:shadow-lg ${g.active ? "border-blue-200" : "border-gray-200 opacity-60"}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${g.active ? "bg-blue-100" : "bg-gray-100"}`}
                  >
                    <Users
                      size={20}
                      className={g.active ? "text-blue-600" : "text-gray-400"}
                    />
                  </div>
                  {!g.active && (
                    <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full font-bold">
                      موقوف
                    </span>
                  )}
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => {
                      setEditingGroup(g);
                      setModalOpen(true);
                    }}
                    className="p-2 hover:bg-blue-50 rounded-lg transition-all"
                  >
                    <Edit2 size={16} className="text-blue-600" />
                  </button>
                  <button
                    onClick={() => handleDelete(g.id)}
                    className="p-2 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <Trash2 size={16} className="text-red-600" />
                  </button>
                </div>
              </div>
              <h3 className="font-black text-gray-800 mb-2 text-lg">
                {g.name}
              </h3>
              {g.grade && (
                <p className="text-xs text-gray-500 mb-1">📚 {g.grade}</p>
              )}
              {g.subject && (
                <p className="text-xs text-gray-500 mb-1">📖 {g.subject}</p>
              )}
              {g.day_of_week && (
                <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                  <Calendar size={12} /> {g.day_of_week}{" "}
                  {g.start_time ? `— ${g.start_time}` : ""}
                </p>
              )}
              <div className="flex items-center gap-3 mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <UserCheck size={14} />
                  <span>
                    {g.current_students || 0}/{g.max_students}
                  </span>
                </div>
                {g.price && (
                  <div className="flex items-center gap-1 text-xs text-green-600 font-bold">
                    <DollarSign size={14} />
                    <span>{Number(g.price).toLocaleString()} ج</span>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <AnimatePresence>
        {modalOpen && (
          <GroupModal
            group={editingGroup}
            onClose={() => {
              setModalOpen(false);
              setEditingGroup(null);
            }}
            onSave={handleSave}
            packages={packages}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
