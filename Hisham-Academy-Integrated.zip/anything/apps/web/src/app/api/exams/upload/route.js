import { upload } from "@/app/api/utils/upload";

export async function POST(request) {
  try {
    const { base64 } = await request.json();
    if (!base64) {
      return Response.json({ error: "لم يتم إرسال ملف" }, { status: 400 });
    }
    const { url, error } = await upload({ base64 });
    if (error) {
      return Response.json({ error }, { status: 500 });
    }
    return Response.json({ url });
  } catch (err) {
    console.error("PDF upload error:", err);
    return Response.json({ error: "فشل رفع الملف" }, { status: 500 });
  }
}
