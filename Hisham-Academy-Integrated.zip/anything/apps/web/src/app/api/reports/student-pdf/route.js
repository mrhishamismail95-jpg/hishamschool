export async function POST(request) {
  try {
    const { student, attendance, payments, exams } = await request.json();

    if (!student) {
      return Response.json({ error: "بيانات الطالب مطلوبة" }, { status: 400 });
    }

    // Generate HTML report
    const html = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تقرير الطالب - ${student.name}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; }
    body { background: #f9fafb; padding: 40px 20px; }
    .container { max-width: 800px; margin: 0 auto; background: white; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); overflow: hidden; }
    .header { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 40px; text-align: center; }
    .header h1 { font-size: 32px; margin-bottom: 8px; }
    .header p { opacity: 0.9; font-size: 14px; }
    .section { padding: 30px; border-bottom: 1px solid #e5e7eb; }
    .section:last-child { border-bottom: none; }
    .section-title { font-size: 20px; font-weight: bold; color: #1f2937; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #3b82f6; }
    .info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
    .info-item { background: #f9fafb; padding: 16px; border-radius: 12px; }
    .info-label { font-size: 12px; color: #6b7280; margin-bottom: 4px; }
    .info-value { font-size: 16px; font-weight: bold; color: #1f2937; }
    .stat-card { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 20px; text-align: center; }
    .stat-value { font-size: 28px; font-weight: bold; color: #2563eb; }
    .stat-label { font-size: 13px; color: #6b7280; margin-top: 4px; }
    .table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    .table th { background: #f3f4f6; padding: 12px; text-align: right; font-size: 13px; color: #6b7280; border-bottom: 2px solid #e5e7eb; }
    .table td { padding: 12px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }
    .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
    .badge-green { background: #d1fae5; color: #065f46; }
    .badge-orange { background: #fed7aa; color: #92400e; }
    .badge-red { background: #fee2e2; color: #991b1b; }
    .footer { background: #f9fafb; padding: 24px; text-align: center; color: #6b7280; font-size: 13px; }
    .progress-bar { height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; margin-top: 8px; }
    .progress-fill { height: 100%; background: linear-gradient(90deg, #10b981 0%, #059669 100%); transition: width 0.3s; }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      <h1>تقرير الطالب</h1>
      <p>تم إنشاؤه في ${new Date().toLocaleDateString("ar-EG", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
    </div>

    <!-- Student Info -->
    <div class="section">
      <h2 class="section-title">معلومات الطالب</h2>
      <div class="info-grid">
        <div class="info-item">
          <div class="info-label">الاسم الكامل</div>
          <div class="info-value">${student.name || "—"}</div>
        </div>
        <div class="info-item">
          <div class="info-label">الكود</div>
          <div class="info-value">${student.code || "—"}</div>
        </div>
        <div class="info-item">
          <div class="info-label">الصف الدراسي</div>
          <div class="info-value">${student.grade || "—"}</div>
        </div>
        <div class="info-item">
          <div class="info-label">المجموعة</div>
          <div class="info-value">${student.group || "—"}</div>
        </div>
        <div class="info-item">
          <div class="info-label">رقم الهاتف</div>
          <div class="info-value">${student.phone || "—"}</div>
        </div>
        <div class="info-item">
          <div class="info-label">رقم ولي الأمر</div>
          <div class="info-value">${student.parentPhone || "—"}</div>
        </div>
      </div>
    </div>

    <!-- Session Stats -->
    <div class="section">
      <h2 class="section-title">إحصائيات الحصص</h2>
      <div class="info-grid">
        <div class="stat-card">
          <div class="stat-value">${attendance.filter((a) => a.status === "present" || a.status === "late").length}</div>
          <div class="stat-label">حصص مستخدمة</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${Math.max(0, (Number(student.sessionPackage) || 8) - attendance.filter((a) => a.status === "present" || a.status === "late").length)}</div>
          <div class="stat-label">حصص متبقية</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${attendance.filter((a) => a.status === "present").length}</div>
          <div class="stat-label">حضور</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${attendance.filter((a) => a.status === "absent").length}</div>
          <div class="stat-label">غياب</div>
        </div>
      </div>
      <div style="margin-top: 20px;">
        <div style="display: flex; justify-content: space-between; font-size: 13px; color: #6b7280; margin-bottom: 4px;">
          <span>التقدم في الباقة</span>
          <span>${Math.round((attendance.filter((a) => a.status === "present" || a.status === "late").length / (Number(student.sessionPackage) || 8)) * 100)}%</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${Math.min(100, (attendance.filter((a) => a.status === "present" || a.status === "late").length / (Number(student.sessionPackage) || 8)) * 100)}%;"></div>
        </div>
      </div>
    </div>

    <!-- Attendance History -->
    <div class="section">
      <h2 class="section-title">سجل الحضور (آخر 10 حصص)</h2>
      ${
        attendance.length === 0
          ? '<p style="color: #9ca3af; text-align: center; padding: 20px;">لا يوجد سجل حضور</p>'
          : `
      <table class="table">
        <thead>
          <tr>
            <th>التاريخ</th>
            <th>الحالة</th>
          </tr>
        </thead>
        <tbody>
          ${attendance
            .slice(-10)
            .reverse()
            .map(
              (a) => `
            <tr>
              <td>${new Date(a.date).toLocaleDateString("ar-EG")}</td>
              <td>
                <span class="badge ${a.status === "present" ? "badge-green" : a.status === "late" ? "badge-orange" : "badge-red"}">
                  ${a.status === "present" ? "حاضر" : a.status === "late" ? "متأخر" : "غائب"}
                </span>
              </td>
            </tr>
          `,
            )
            .join("")}
        </tbody>
      </table>
      `
      }
    </div>

    <!-- Payment History -->
    <div class="section">
      <h2 class="section-title">سجل المدفوعات</h2>
      ${
        payments.length === 0
          ? '<p style="color: #9ca3af; text-align: center; padding: 20px;">لا يوجد سجل مدفوعات</p>'
          : `
      <table class="table">
        <thead>
          <tr>
            <th>التاريخ</th>
            <th>المبلغ</th>
            <th>الحالة</th>
          </tr>
        </thead>
        <tbody>
          ${payments
            .map(
              (p) => `
            <tr>
              <td>${new Date(p.date).toLocaleDateString("ar-EG")}</td>
              <td>${Number(p.amount).toLocaleString()} ج.م</td>
              <td><span class="badge badge-green">مدفوع</span></td>
            </tr>
          `,
            )
            .join("")}
        </tbody>
      </table>
      `
      }
      <div style="margin-top: 20px; background: #f0fdf4; border: 1px solid #86efac; border-radius: 12px; padding: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="font-weight: bold; color: #166534;">إجمالي المدفوعات:</span>
          <span style="font-size: 24px; font-weight: bold; color: #15803d;">${payments.reduce((acc, p) => acc + Number(p.amount || 0), 0).toLocaleString()} ج.م</span>
        </div>
      </div>
    </div>

    <!-- Exams -->
    ${
      exams.length > 0
        ? `
    <div class="section">
      <h2 class="section-title">نتائج الامتحانات</h2>
      <table class="table">
        <thead>
          <tr>
            <th>الامتحان</th>
            <th>المادة</th>
            <th>التاريخ</th>
          </tr>
        </thead>
        <tbody>
          ${exams
            .map(
              (e) => `
            <tr>
              <td>${e.title}</td>
              <td>${e.subject}</td>
              <td>${new Date(e.date).toLocaleDateString("ar-EG")}</td>
            </tr>
          `,
            )
            .join("")}
        </tbody>
      </table>
    </div>
    `
        : ""
    }

    <!-- Footer -->
    <div class="footer">
      <p>هذا التقرير تم إنشاؤه تلقائياً من نظام إدارة الطلاب</p>
      <p style="margin-top: 8px;">للاستفسارات، يرجى التواصل مع المعلم مباشرة</p>
    </div>
  </div>
</body>
</html>
    `;

    return new Response(html, {
      headers: {
        "Content-Type": "text/html; charset=utf-8",
      },
    });
  } catch (err) {
    console.error("PDF generation error:", err);
    return Response.json({ error: "فشل إنشاء التقرير" }, { status: 500 });
  }
}
