import sql from "@/app/api/utils/sql";

// إعداد راتب معلم
export async function POST(request) {
  try {
    const {
      teacher_id,
      salary_type = "per_student",
      amount_per_student = 0,
      fixed_monthly_salary = 0,
      hourly_rate = 0,
      notes,
    } = await request.json();

    if (!teacher_id) {
      return Response.json({ error: "معرف المعلم مطلوب" }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO teacher_salary_config (
        teacher_id, salary_type, amount_per_student,
        fixed_monthly_salary, hourly_rate, notes
      )
      VALUES (
        ${teacher_id}, ${salary_type}, ${amount_per_student},
        ${fixed_monthly_salary}, ${hourly_rate}, ${notes || null}
      )
      ON CONFLICT (teacher_id) DO UPDATE SET
        salary_type = EXCLUDED.salary_type,
        amount_per_student = EXCLUDED.amount_per_student,
        fixed_monthly_salary = EXCLUDED.fixed_monthly_salary,
        hourly_rate = EXCLUDED.hourly_rate,
        notes = EXCLUDED.notes
      RETURNING *
    `;

    return Response.json({
      success: true,
      config: result[0],
      message: "تم تحديث إعدادات الراتب بنجاح",
    });
  } catch (error) {
    console.error("Salary config error:", error);
    return Response.json(
      { error: "حدث خطأ في تحديث إعدادات الراتب" },
      { status: 500 },
    );
  }
}

// تسجيل دفعة راتب
export async function PUT(request) {
  try {
    const { teacher_id, payment_month, paid_amount, payment_date, notes } =
      await request.json();

    if (!teacher_id || !payment_month || !paid_amount) {
      return Response.json(
        { error: "البيانات المطلوبة غير مكتملة" },
        { status: 400 },
      );
    }

    // جلب عدد الطلاب المعينين
    const studentsCount = await sql`
      SELECT COUNT(*) as count
      FROM teacher_student_assignments
      WHERE teacher_id = ${teacher_id}
    `;

    // جلب إعدادات الراتب
    const salaryConfig = await sql`
      SELECT * FROM teacher_salary_config
      WHERE teacher_id = ${teacher_id}
    `;

    let calculated_amount = 0;
    const total_students = parseInt(studentsCount[0]?.count || 0);

    if (salaryConfig.length > 0) {
      const config = salaryConfig[0];

      if (config.salary_type === "per_student") {
        calculated_amount =
          parseFloat(config.amount_per_student || 0) * total_students;
      } else if (config.salary_type === "fixed") {
        calculated_amount = parseFloat(config.fixed_monthly_salary || 0);
      }
    }

    const result = await sql`
      INSERT INTO teacher_salary_payments (
        teacher_id, payment_month, total_students,
        calculated_amount, paid_amount, payment_date, notes,
        status
      )
      VALUES (
        ${teacher_id}, ${payment_month}, ${total_students},
        ${calculated_amount}, ${paid_amount}, ${payment_date || new Date().toISOString().split("T")[0]},
        ${notes || null},
        ${paid_amount >= calculated_amount ? "paid" : "partial"}
      )
      RETURNING *
    `;

    return Response.json({
      success: true,
      payment: result[0],
      message: "تم تسجيل الدفعة بنجاح",
    });
  } catch (error) {
    console.error("Salary payment error:", error);
    return Response.json({ error: "حدث خطأ في تسجيل الدفعة" }, { status: 500 });
  }
}

// الحصول على تاريخ رواتب معلم
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const teacher_id = searchParams.get("teacher_id");

    if (!teacher_id) {
      return Response.json({ error: "معرف المعلم مطلوب" }, { status: 400 });
    }

    const payments = await sql`
      SELECT * FROM teacher_salary_payments
      WHERE teacher_id = ${teacher_id}
      ORDER BY payment_month DESC, created_at DESC
    `;

    const config = await sql`
      SELECT * FROM teacher_salary_config
      WHERE teacher_id = ${teacher_id}
    `;

    return Response.json({
      payments,
      config: config[0] || null,
    });
  } catch (error) {
    console.error("Get salary history error:", error);
    return Response.json(
      { error: "حدث خطأ في جلب تاريخ الرواتب" },
      { status: 500 },
    );
  }
}
