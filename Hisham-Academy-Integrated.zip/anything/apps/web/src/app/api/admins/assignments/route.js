import sql from "@/app/api/utils/sql";

// تعيين طلاب لمعلم
export async function POST(request) {
  try {
    const {
      teacher_id,
      student_ids = [],
      group_ids = [],
      assigned_by,
    } = await request.json();

    if (!teacher_id) {
      return Response.json({ error: "معرف المعلم مطلوب" }, { status: 400 });
    }

    const results = { students: [], groups: [] };

    // تعيين الطلاب
    for (const student_id of student_ids) {
      try {
        const result = await sql`
          INSERT INTO teacher_student_assignments (teacher_id, student_id, assigned_by)
          VALUES (${teacher_id}, ${student_id}, ${assigned_by || null})
          ON CONFLICT (teacher_id, student_id) DO NOTHING
          RETURNING *
        `;
        if (result.length > 0) {
          results.students.push(result[0]);
        }
      } catch (err) {
        console.error("Student assignment error:", err);
      }
    }

    // تعيين المجموعات
    for (const group_id of group_ids) {
      try {
        const result = await sql`
          INSERT INTO teacher_group_assignments (teacher_id, group_id, assigned_by)
          VALUES (${teacher_id}, ${group_id}, ${assigned_by || null})
          ON CONFLICT (teacher_id, group_id) DO NOTHING
          RETURNING *
        `;
        if (result.length > 0) {
          results.groups.push(result[0]);
        }
      } catch (err) {
        console.error("Group assignment error:", err);
      }
    }

    return Response.json({
      success: true,
      message: "تم تعيين الطلاب والمجموعات بنجاح",
      results,
    });
  } catch (error) {
    console.error("Assignment error:", error);
    return Response.json({ error: "حدث خطأ في التعيين" }, { status: 500 });
  }
}

// الحصول على تعيينات المعلم
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const teacher_id = searchParams.get("teacher_id");

    if (!teacher_id) {
      return Response.json({ error: "معرف المعلم مطلوب" }, { status: 400 });
    }

    // جلب الطلاب المعينين
    const students = await sql`
      SELECT s.*, tsa.assigned_at
      FROM students s
      JOIN teacher_student_assignments tsa ON s.id = tsa.student_id
      WHERE tsa.teacher_id = ${teacher_id}
      ORDER BY s.name
    `;

    // جلب المجموعات المعينة
    const groups = await sql`
      SELECT sg.*, tga.assigned_at
      FROM study_groups sg
      JOIN teacher_group_assignments tga ON sg.id = tga.group_id
      WHERE tga.teacher_id = ${teacher_id}
      ORDER BY sg.name
    `;

    return Response.json({
      students,
      groups,
    });
  } catch (error) {
    console.error("Get assignments error:", error);
    return Response.json(
      { error: "حدث خطأ في جلب التعيينات" },
      { status: 500 },
    );
  }
}

// إلغاء تعيين طالب أو مجموعة
export async function DELETE(request) {
  try {
    const { teacher_id, student_id, group_id } = await request.json();

    if (!teacher_id) {
      return Response.json({ error: "معرف المعلم مطلوب" }, { status: 400 });
    }

    if (student_id) {
      await sql`
        DELETE FROM teacher_student_assignments
        WHERE teacher_id = ${teacher_id} AND student_id = ${student_id}
      `;
    }

    if (group_id) {
      await sql`
        DELETE FROM teacher_group_assignments
        WHERE teacher_id = ${teacher_id} AND group_id = ${group_id}
      `;
    }

    return Response.json({
      success: true,
      message: "تم إلغاء التعيين بنجاح",
    });
  } catch (error) {
    console.error("Delete assignment error:", error);
    return Response.json(
      { error: "حدث خطأ في إلغاء التعيين" },
      { status: 500 },
    );
  }
}
