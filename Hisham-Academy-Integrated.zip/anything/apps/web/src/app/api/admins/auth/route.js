import sql from "@/app/api/utils/sql";
import argon2 from "argon2";

// تسجيل دخول الإداري
export async function POST(request) {
  try {
    const { phone, code } = await request.json();

    if (!phone || !code) {
      return Response.json(
        { error: "رقم الهاتف والكود مطلوبان" },
        { status: 400 },
      );
    }

    // البحث عن الإداري بالكود ورقم الهاتف
    const admins = await sql`
      SELECT * FROM admins 
      WHERE code = ${code} AND phone = ${phone}
      LIMIT 1
    `;

    if (admins.length === 0) {
      return Response.json(
        { error: "بيانات الدخول غير صحيحة" },
        { status: 401 },
      );
    }

    const admin = admins[0];

    // التحقق من أن الحساب نشط
    if (!admin.is_active) {
      return Response.json(
        { error: "الحساب غير نشط. يرجى الاتصال بالمدير" },
        { status: 403 },
      );
    }

    // التحقق من صلاحية الاشتراك
    const today = new Date();
    const endDate = admin.subscription_end
      ? new Date(admin.subscription_end)
      : null;

    if (endDate && endDate < today) {
      return Response.json({ error: "انتهت صلاحية الاشتراك" }, { status: 403 });
    }

    // إرجاع بيانات الإداري (بدون كلمة المرور)
    const { password_hash, ...adminData } = admin;

    return Response.json({
      success: true,
      admin: adminData,
      message: "تم تسجيل الدخول بنجاح",
    });
  } catch (error) {
    console.error("Admin login error:", error);
    return Response.json({ error: "حدث خطأ في تسجيل الدخول" }, { status: 500 });
  }
}

// إعادة تعيين الكود — خطوة 1: التحقق من رقم الهاتف
// إعادة تعيين الكود — خطوة 2: تعيين كود جديد
export async function PUT(request) {
  try {
    const { phone, new_code, step } = await request.json();

    if (!phone) {
      return Response.json({ error: "رقم الهاتف مطلوب" }, { status: 400 });
    }

    // الخطوة الأولى: التحقق فقط من وجود الحساب
    if (step === "verify") {
      const admins = await sql`
        SELECT id, name, phone, role, is_active FROM admins
        WHERE phone = ${phone}
        LIMIT 1
      `;
      if (admins.length === 0) {
        return Response.json(
          { error: "لا يوجد حساب مرتبط بهذا الرقم" },
          { status: 404 },
        );
      }
      const admin = admins[0];
      if (!admin.is_active) {
        return Response.json(
          { error: "الحساب موقوف — تواصل مع المدير" },
          { status: 403 },
        );
      }
      // إرجاع اسم مقتضب للتأكيد (بدون كود)
      return Response.json({
        success: true,
        name: admin.name,
        role: admin.role,
        message: "تم التحقق — أدخل الكود الجديد",
      });
    }

    // الخطوة الثانية: تحديث الكود
    if (step === "reset") {
      if (!new_code || new_code.length < 4) {
        return Response.json(
          { error: "يجب أن يكون الكود الجديد 4 أحرف على الأقل" },
          { status: 400 },
        );
      }

      // التأكد من عدم وجود تعارض مع كود موجود لحساب آخر
      const conflict = await sql`
        SELECT id FROM admins WHERE code = ${new_code} AND phone != ${phone}
        LIMIT 1
      `;
      if (conflict.length > 0) {
        return Response.json(
          { error: "هذا الكود مستخدم بالفعل، اختر كوداً آخر" },
          { status: 409 },
        );
      }

      const updated = await sql`
        UPDATE admins
        SET code = ${new_code}
        WHERE phone = ${phone}
        RETURNING id, name, code, phone, role
      `;

      if (updated.length === 0) {
        return Response.json(
          { error: "لم يتم العثور على الحساب" },
          { status: 404 },
        );
      }

      return Response.json({
        success: true,
        message: "تم تحديث الكود بنجاح — يمكنك تسجيل الدخول الآن",
      });
    }

    return Response.json({ error: "خطوة غير معروفة" }, { status: 400 });
  } catch (error) {
    console.error("Reset code error:", error);
    return Response.json(
      { error: "حدث خطأ أثناء إعادة التعيين" },
      { status: 500 },
    );
  }
}
