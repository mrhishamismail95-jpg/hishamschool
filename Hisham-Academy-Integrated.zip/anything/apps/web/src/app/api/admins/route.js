import sql from "@/app/api/utils/sql";
import argon2 from "argon2";

// الحصول على قائمة الإداريين
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const role = searchParams.get("role");

    let query =
      "SELECT id, code, name, phone, role, subscription_type, subscription_start, subscription_end, is_active, notes, created_at FROM admins";
    const params = [];

    if (role) {
      query += " WHERE role = $1";
      params.push(role);
    }

    query += " ORDER BY created_at DESC";

    const admins = await sql(query, params);

    return Response.json({ admins });
  } catch (error) {
    console.error("Get admins error:", error);
    return Response.json(
      { error: "حدث خطأ في جلب الإداريين" },
      { status: 500 },
    );
  }
}

// إضافة إداري جديد (يقوم بها المدير فقط)
export async function POST(request) {
  try {
    const {
      code,
      name,
      phone,
      role = "admin",
      subscription_type = "monthly",
      subscription_start,
      subscription_end,
      created_by,
      notes,
    } = await request.json();

    if (!code || !name || !phone) {
      return Response.json(
        { error: "الكود والاسم ورقم الهاتف مطلوبان" },
        { status: 400 },
      );
    }

    // التحقق من عدم تكرار الكود
    const existing = await sql`
      SELECT id FROM admins WHERE code = ${code}
    `;

    if (existing.length > 0) {
      return Response.json(
        { error: "هذا الكود مستخدم بالفعل" },
        { status: 400 },
      );
    }

    // إنشاء كلمة مرور افتراضية من الكود
    const password_hash = await argon2.hash(code);

    // إضافة الإداري
    const result = await sql`
      INSERT INTO admins (
        code, name, phone, password_hash, role, 
        subscription_type, subscription_start, subscription_end,
        created_by, notes
      )
      VALUES (
        ${code}, ${name}, ${phone}, ${password_hash}, ${role},
        ${subscription_type}, ${subscription_start || null}, ${subscription_end || null},
        ${created_by || null}, ${notes || null}
      )
      RETURNING id, code, name, phone, role, subscription_type, 
                subscription_start, subscription_end, is_active, created_at
    `;

    return Response.json({
      success: true,
      admin: result[0],
      message: "تم إضافة الإداري بنجاح",
    });
  } catch (error) {
    console.error("Create admin error:", error);
    return Response.json(
      { error: "حدث خطأ في إضافة الإداري" },
      { status: 500 },
    );
  }
}
