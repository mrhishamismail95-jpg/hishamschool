import sql from "@/app/api/utils/sql";

// التقارير المالية الشاملة
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const month = searchParams.get("month"); // format: YYYY-MM
    const student_id = searchParams.get("student_id");
    const teacher_id = searchParams.get("teacher_id");

    const report = {
      students: [],
      teachers: [],
      summary: {
        total_revenue: 0,
        total_expenses: 0,
        net_profit: 0,
      },
    };

    // تقرير طالب محدد
    if (student_id) {
      const studentData = await sql`
        SELECT 
          s.*,
          COALESCE(SUM(p.amount), 0) as total_paid,
          s.price * s.session_package as total_due,
          COUNT(a.id) as total_attendance
        FROM students s
        LEFT JOIN payments p ON s.id = p.student_id
        LEFT JOIN attendance a ON s.id = a.student_id AND a.status = 'present'
        WHERE s.id = ${student_id}
        GROUP BY s.id
      `;

      if (studentData.length > 0) {
        const student = studentData[0];
        student.remaining =
          parseFloat(student.total_due || 0) -
          parseFloat(student.total_paid || 0);
        student.sessions_remaining =
          student.session_package - student.sessions_used;
        report.students.push(student);
      }
    }
    // تقرير جميع الطلاب
    else {
      let studentsQuery = `
        SELECT 
          s.*,
          COALESCE(SUM(p.amount), 0) as total_paid,
          s.price * s.session_package as total_due,
          COUNT(DISTINCT a.id) as total_attendance
        FROM students s
        LEFT JOIN payments p ON s.id = p.student_id
        LEFT JOIN attendance a ON s.id = a.student_id AND a.status = 'present'
      `;
      const params = [];

      if (month) {
        studentsQuery += ` AND DATE_TRUNC('month', p.created_at) = $1`;
        params.push(month + "-01");
      }

      studentsQuery += ` GROUP BY s.id ORDER BY s.name`;

      const students = await sql(studentsQuery, params);

      report.students = students.map((s) => ({
        ...s,
        remaining: parseFloat(s.total_due || 0) - parseFloat(s.total_paid || 0),
        sessions_remaining: s.session_package - s.sessions_used,
      }));

      report.summary.total_revenue = students.reduce(
        (sum, s) => sum + parseFloat(s.total_paid || 0),
        0,
      );
    }

    // تقرير معلم محدد
    if (teacher_id) {
      const teacherData = await sql`
        SELECT 
          t.*,
          tsc.salary_type,
          tsc.amount_per_student,
          tsc.fixed_monthly_salary,
          COUNT(DISTINCT tsa.student_id) as assigned_students,
          COALESCE(SUM(tsp.paid_amount), 0) as total_paid
        FROM teachers t
        LEFT JOIN teacher_salary_config tsc ON t.id = tsc.teacher_id
        LEFT JOIN teacher_student_assignments tsa ON t.id = tsa.teacher_id
        LEFT JOIN teacher_salary_payments tsp ON t.id = tsp.teacher_id
        WHERE t.id = ${teacher_id}
        GROUP BY t.id, tsc.salary_type, tsc.amount_per_student, tsc.fixed_monthly_salary
      `;

      if (teacherData.length > 0) {
        const teacher = teacherData[0];

        // حساب الراتب المستحق
        if (teacher.salary_type === "per_student") {
          teacher.salary_due =
            parseFloat(teacher.amount_per_student || 0) *
            parseInt(teacher.assigned_students || 0);
        } else if (teacher.salary_type === "fixed") {
          teacher.salary_due = parseFloat(teacher.fixed_monthly_salary || 0);
        }

        teacher.salary_remaining =
          parseFloat(teacher.salary_due || 0) -
          parseFloat(teacher.total_paid || 0);

        report.teachers.push(teacher);
      }
    }
    // تقرير جميع المعلمين
    else {
      const teachers = await sql`
        SELECT 
          t.*,
          tsc.salary_type,
          tsc.amount_per_student,
          tsc.fixed_monthly_salary,
          COUNT(DISTINCT tsa.student_id) as assigned_students,
          COALESCE(SUM(tsp.paid_amount), 0) as total_paid
        FROM teachers t
        LEFT JOIN teacher_salary_config tsc ON t.id = tsc.teacher_id
        LEFT JOIN teacher_student_assignments tsa ON t.id = tsa.teacher_id
        LEFT JOIN teacher_salary_payments tsp ON t.id = tsp.teacher_id
        GROUP BY t.id, tsc.salary_type, tsc.amount_per_student, tsc.fixed_monthly_salary
        ORDER BY t.name
      `;

      report.teachers = teachers.map((t) => {
        let salary_due = 0;

        if (t.salary_type === "per_student") {
          salary_due =
            parseFloat(t.amount_per_student || 0) *
            parseInt(t.assigned_students || 0);
        } else if (t.salary_type === "fixed") {
          salary_due = parseFloat(t.fixed_monthly_salary || 0);
        }

        return {
          ...t,
          salary_due,
          salary_remaining: salary_due - parseFloat(t.total_paid || 0),
        };
      });

      report.summary.total_expenses = report.teachers.reduce(
        (sum, t) => sum + parseFloat(t.salary_due || 0),
        0,
      );
    }

    report.summary.net_profit =
      report.summary.total_revenue - report.summary.total_expenses;

    return Response.json(report);
  } catch (error) {
    console.error("Financial reports error:", error);
    return Response.json(
      { error: "حدث خطأ في جلب التقارير المالية" },
      { status: 500 },
    );
  }
}
