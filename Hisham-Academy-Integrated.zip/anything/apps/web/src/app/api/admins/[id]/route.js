import sql from "@/app/api/utils/sql";

// تحديث بيانات الإداري
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const updates = await request.json();

    const setClauses = [];
    const values = [];
    let paramCount = 1;

    // بناء الحقول للتحديث
    const allowedFields = [
      "name",
      "phone",
      "role",
      "subscription_type",
      "subscription_start",
      "subscription_end",
      "is_active",
      "notes",
    ];

    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        setClauses.push(`${field} = $${paramCount}`);
        values.push(updates[field]);
        paramCount++;
      }
    }

    if (setClauses.length === 0) {
      return Response.json(
        { error: "لا توجد بيانات للتحديث" },
        { status: 400 },
      );
    }

    values.push(id);
    const query = `
      UPDATE admins 
      SET ${setClauses.join(", ")}
      WHERE id = $${paramCount}
      RETURNING id, code, name, phone, role, subscription_type,
                subscription_start, subscription_end, is_active, notes
    `;

    const result = await sql(query, values);

    if (result.length === 0) {
      return Response.json({ error: "الإداري غير موجود" }, { status: 404 });
    }

    return Response.json({
      success: true,
      admin: result[0],
      message: "تم تحديث بيانات الإداري بنجاح",
    });
  } catch (error) {
    console.error("Update admin error:", error);
    return Response.json(
      { error: "حدث خطأ في تحديث البيانات" },
      { status: 500 },
    );
  }
}

// حذف إداري
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    await sql`DELETE FROM admins WHERE id = ${id}`;

    return Response.json({
      success: true,
      message: "تم حذف الإداري بنجاح",
    });
  } catch (error) {
    console.error("Delete admin error:", error);
    return Response.json({ error: "حدث خطأ في حذف الإداري" }, { status: 500 });
  }
}
