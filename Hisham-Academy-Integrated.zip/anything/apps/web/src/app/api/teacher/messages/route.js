import sql from "@/app/api/utils/sql";

// إرسال رسالة
export async function POST(request) {
  try {
    const { sender_type, sender_id, receiver_type, receiver_id, message } =
      await request.json();

    if (
      !sender_type ||
      !sender_id ||
      !receiver_type ||
      !receiver_id ||
      !message
    ) {
      return Response.json({ error: "جميع الحقول مطلوبة" }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO messages (sender_type, sender_id, receiver_type, receiver_id, message)
      VALUES (${sender_type}, ${sender_id}, ${receiver_type}, ${receiver_id}, ${message})
      RETURNING *
    `;

    return Response.json({
      success: true,
      message: result[0],
      notification: "تم إرسال الرسالة بنجاح",
    });
  } catch (error) {
    console.error("Send message error:", error);
    return Response.json(
      { error: "حدث خطأ في إرسال الرسالة" },
      { status: 500 },
    );
  }
}

// جلب الرسائل
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const user_type = searchParams.get("user_type"); // teacher, student, parent
    const user_id = searchParams.get("user_id");
    const conversation_with_type = searchParams.get("conversation_with_type");
    const conversation_with_id = searchParams.get("conversation_with_id");

    if (!user_type || !user_id) {
      return Response.json(
        { error: "نوع المستخدم ومعرفه مطلوبان" },
        { status: 400 },
      );
    }

    let messages;

    // جلب محادثة محددة
    if (conversation_with_type && conversation_with_id) {
      messages = await sql`
        SELECT m.*
        FROM messages m
        WHERE (
          (m.sender_type = ${user_type} AND m.sender_id = ${user_id} AND 
           m.receiver_type = ${conversation_with_type} AND m.receiver_id = ${conversation_with_id})
          OR
          (m.receiver_type = ${user_type} AND m.receiver_id = ${user_id} AND 
           m.sender_type = ${conversation_with_type} AND m.sender_id = ${conversation_with_id})
        )
        ORDER BY m.created_at ASC
      `;

      // تحديث حالة القراءة
      await sql`
        UPDATE messages
        SET is_read = true
        WHERE receiver_type = ${user_type} 
          AND receiver_id = ${user_id}
          AND sender_type = ${conversation_with_type}
          AND sender_id = ${conversation_with_id}
          AND is_read = false
      `;
    }
    // جلب جميع المحادثات
    else {
      messages = await sql`
        SELECT m.*
        FROM messages m
        WHERE m.sender_type = ${user_type} AND m.sender_id = ${user_id}
           OR m.receiver_type = ${user_type} AND m.receiver_id = ${user_id}
        ORDER BY m.created_at DESC
      `;
    }

    // إضافة بيانات المرسل والمستقبل
    const enrichedMessages = await Promise.all(
      messages.map(async (msg) => {
        let sender_name = "غير معروف";
        let receiver_name = "غير معروف";

        // جلب اسم المرسل
        if (msg.sender_type === "teacher") {
          const teacher =
            await sql`SELECT name FROM teachers WHERE id = ${msg.sender_id}`;
          sender_name = teacher[0]?.name || "معلم";
        } else if (msg.sender_type === "student") {
          const student =
            await sql`SELECT name FROM students WHERE id = ${msg.sender_id}`;
          sender_name = student[0]?.name || "طالب";
        } else if (msg.sender_type === "parent") {
          const parent =
            await sql`SELECT name FROM parents WHERE id = ${msg.sender_id}`;
          sender_name = parent[0]?.name || "ولي أمر";
        }

        // جلب اسم المستقبل
        if (msg.receiver_type === "teacher") {
          const teacher =
            await sql`SELECT name FROM teachers WHERE id = ${msg.receiver_id}`;
          receiver_name = teacher[0]?.name || "معلم";
        } else if (msg.receiver_type === "student") {
          const student =
            await sql`SELECT name FROM students WHERE id = ${msg.receiver_id}`;
          receiver_name = student[0]?.name || "طالب";
        } else if (msg.receiver_type === "parent") {
          const parent =
            await sql`SELECT name FROM parents WHERE id = ${msg.receiver_id}`;
          receiver_name = parent[0]?.name || "ولي أمر";
        }

        return {
          ...msg,
          sender_name,
          receiver_name,
        };
      }),
    );

    return Response.json({ messages: enrichedMessages });
  } catch (error) {
    console.error("Get messages error:", error);
    return Response.json({ error: "حدث خطأ في جلب الرسائل" }, { status: 500 });
  }
}

// حذف رسالة
export async function DELETE(request) {
  try {
    const { searchParams } = new URL(request.url);
    const message_id = searchParams.get("message_id");

    if (!message_id) {
      return Response.json({ error: "معرف الرسالة مطلوب" }, { status: 400 });
    }

    await sql`DELETE FROM messages WHERE id = ${message_id}`;

    return Response.json({
      success: true,
      message: "تم حذف الرسالة بنجاح",
    });
  } catch (error) {
    console.error("Delete message error:", error);
    return Response.json({ error: "حدث خطأ في حذف الرسالة" }, { status: 500 });
  }
}
