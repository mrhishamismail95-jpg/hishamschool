import sql from "@/app/api/utils/sql";

// تسجيل حضور المعلم
export async function POST(request) {
  try {
    const {
      teacher_id,
      date,
      status = "present",
      clock_in,
      clock_out,
      notes,
    } = await request.json();

    if (!teacher_id || !date) {
      return Response.json(
        { error: "معرف المعلم والتاريخ مطلوبان" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO teacher_attendance (
        teacher_id, date, status, clock_in, clock_out, notes
      )
      VALUES (
        ${teacher_id}, ${date}, ${status},
        ${clock_in || null}, ${clock_out || null}, ${notes || null}
      )
      ON CONFLICT (teacher_id, date) DO UPDATE SET
        status = EXCLUDED.status,
        clock_in = EXCLUDED.clock_in,
        clock_out = EXCLUDED.clock_out,
        notes = EXCLUDED.notes
      RETURNING *
    `;

    return Response.json({
      success: true,
      attendance: result[0],
      message: "تم تسجيل الحضور بنجاح",
    });
  } catch (error) {
    console.error("Teacher attendance error:", error);
    return Response.json({ error: "حدث خطأ في تسجيل الحضور" }, { status: 500 });
  }
}

// جلب حضور المعلمين
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const teacher_id = searchParams.get("teacher_id");
    const start_date = searchParams.get("start_date");
    const end_date = searchParams.get("end_date");

    let query = `
      SELECT ta.*, t.name as teacher_name, t.subject
      FROM teacher_attendance ta
      JOIN teachers t ON ta.teacher_id = t.id
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 1;

    if (teacher_id) {
      query += ` AND ta.teacher_id = $${paramCount}`;
      params.push(teacher_id);
      paramCount++;
    }

    if (start_date) {
      query += ` AND ta.date >= $${paramCount}`;
      params.push(start_date);
      paramCount++;
    }

    if (end_date) {
      query += ` AND ta.date <= $${paramCount}`;
      params.push(end_date);
      paramCount++;
    }

    query += ` ORDER BY ta.date DESC, t.name`;

    const attendance = await sql(query, params);

    return Response.json({ attendance });
  } catch (error) {
    console.error("Get teacher attendance error:", error);
    return Response.json({ error: "حدث خطأ في جلب الحضور" }, { status: 500 });
  }
}
