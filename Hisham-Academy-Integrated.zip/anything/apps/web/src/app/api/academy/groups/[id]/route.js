import sql from "@/app/api/utils/sql";

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const {
      name,
      grade,
      gradeCategory,
      subject,
      dayOfWeek,
      startTime,
      endTime,
      maxStudents,
      price,
      packageId,
      location,
      notes,
      active,
    } = body;

    const setClauses = [];
    const values = [];
    let idx = 1;
    const fields = {
      name,
      grade,
      grade_category: gradeCategory,
      subject,
      day_of_week: dayOfWeek,
      start_time: startTime,
      end_time: endTime,
      max_students: maxStudents,
      price,
      package_id: packageId,
      location,
      notes,
      active,
    };
    for (const [key, val] of Object.entries(fields)) {
      if (val !== undefined) {
        setClauses.push(`${key} = $${idx}`);
        values.push(val);
        idx++;
      }
    }
    if (!setClauses.length)
      return Response.json({ error: "لا توجد حقول للتحديث" }, { status: 400 });
    values.push(id);
    const [group] = await sql(
      `UPDATE study_groups SET ${setClauses.join(",")} WHERE id = $${idx} RETURNING *`,
      values,
    );
    return Response.json({ group });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحديث المجموعة" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    await sql`DELETE FROM study_groups WHERE id = ${params.id}`;
    return Response.json({ ok: true });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل حذف المجموعة" }, { status: 500 });
  }
}
