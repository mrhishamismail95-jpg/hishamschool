import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get("studentId");
    const groupId = searchParams.get("groupId");
    const date = searchParams.get("date");
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");

    let query = `
      SELECT a.*, s.name as student_name, s.code as student_code, s.group_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      WHERE 1=1
    `;
    const params = [];
    let idx = 1;

    if (studentId) {
      query += ` AND a.student_id = $${idx}`;
      params.push(studentId);
      idx++;
    }
    if (groupId) {
      query += ` AND a.group_id = $${idx}`;
      params.push(groupId);
      idx++;
    }
    if (date) {
      query += ` AND a.date = $${idx}`;
      params.push(date);
      idx++;
    }
    if (startDate) {
      query += ` AND a.date >= $${idx}`;
      params.push(startDate);
      idx++;
    }
    if (endDate) {
      query += ` AND a.date <= $${idx}`;
      params.push(endDate);
      idx++;
    }
    query += " ORDER BY a.date DESC, s.name ASC";

    const records = await sql(query, params);
    return Response.json({ attendance: records });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحميل سجل الحضور" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { studentId, groupId, date, status, notes } = body;

    if (!studentId || !date)
      return Response.json(
        { error: "معرف الطالب والتاريخ مطلوبان" },
        { status: 400 },
      );

    // Upsert — update if exists, insert if not
    const [record] = await sql`
      INSERT INTO attendance (student_id, group_id, date, status, notes)
      VALUES (${studentId}, ${groupId || null}, ${date}, ${status || "present"}, ${notes || null})
      ON CONFLICT (student_id, date) DO UPDATE SET status = EXCLUDED.status, notes = EXCLUDED.notes
      RETURNING *
    `;

    return Response.json({ record }, { status: 201 });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تسجيل الحضور" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    // Bulk mark attendance for a group/date
    const { records, date, groupId } = await request.json();
    if (!records || !Array.isArray(records))
      return Response.json({ error: "بيانات التحضير مطلوبة" }, { status: 400 });

    const results = await Promise.all(
      records.map(
        (rec) =>
          sql`
        INSERT INTO attendance (student_id, group_id, date, status, notes)
        VALUES (${rec.studentId}, ${groupId || null}, ${date}, ${rec.status || "present"}, ${rec.notes || null})
        ON CONFLICT (student_id, date) DO UPDATE SET status = EXCLUDED.status
        RETURNING *
      `,
      ),
    );

    return Response.json({ records: results.flat() });
  } catch (err) {
    console.error(err);
    return Response.json(
      { error: "فشل تسجيل الحضور الجماعي" },
      { status: 500 },
    );
  }
}
