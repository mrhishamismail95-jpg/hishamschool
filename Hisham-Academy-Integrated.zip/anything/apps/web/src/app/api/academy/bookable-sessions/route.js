import { releaseExpiredBookingSeats } from "@/utils/bookingMaintenance";
import { getServerSession, unauthorized } from "@/utils/serverSession";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const teacherId = searchParams.get("teacherId");
    const includeClosed = searchParams.get("includeClosed") === "true";
    const actor = getServerSession(request);
    if (!actor || !["teacher", "student"].includes(actor.role)) return unauthorized();
    if (teacherId && (actor.role !== "teacher" || String(actor.id) !== String(teacherId))) return Response.json({ error: "غير مصرح بعرض هذه الحصص" }, { status: 403 });
    if (!teacherId && actor.role !== "student") return Response.json({ error: "هذا العرض مخصص للطالب" }, { status: 403 });
    await releaseExpiredBookingSeats();
    let rows;
    if (teacherId && includeClosed) {
      rows = await sql`SELECT bs.*, GREATEST(0, bs.capacity - bs.reserved_seats) AS available_seats
        FROM bookable_sessions bs WHERE bs.teacher_id = ${teacherId} ORDER BY bs.starts_at ASC`;
    } else if (teacherId) {
      rows = await sql`SELECT bs.*, GREATEST(0, bs.capacity - bs.reserved_seats) AS available_seats
        FROM bookable_sessions bs WHERE bs.teacher_id = ${teacherId} AND bs.status IN ('published','full') ORDER BY bs.starts_at ASC`;
    } else {
      rows = await sql`SELECT bs.*, t.name AS teacher_name, GREATEST(0, bs.capacity - bs.reserved_seats) AS available_seats
        FROM bookable_sessions bs LEFT JOIN teachers t ON t.id = bs.teacher_id
        WHERE bs.status = 'published' AND bs.starts_at > NOW()
        AND bs.reserved_seats < bs.capacity ORDER BY bs.starts_at ASC`;
    }
    return Response.json({ sessions: rows });
  } catch (error) {
    console.error("bookable sessions GET", error);
    return Response.json({ error: "تعذر تحميل الحصص المتاحة. تأكد من تطبيق ترحيل قاعدة البيانات." }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const actor = getServerSession(request);
    if (!actor || actor.role !== "teacher") return unauthorized();
    await releaseExpiredBookingSeats();
    const body = await request.json();
    const { teacherId, sessionType, subject, grade, topic, startsAt, endsAt, pricePerSeat, capacity, deliveryMode = "online", meetingUrl, location } = body;
    if (String(actor.id) !== String(teacherId)) return Response.json({ error: "لا يمكنك نشر حصة لحساب معلم آخر" }, { status: 403 });
    if (!teacherId || !subject?.trim() || !topic?.trim() || !startsAt || !endsAt || pricePerSeat === undefined || !capacity) {
      return Response.json({ error: "أكمل بيانات الحصة المطلوبة" }, { status: 400 });
    }
    if (!["private", "group"].includes(sessionType)) return Response.json({ error: "نوع الحصة غير صحيح" }, { status: 400 });
    const seats = Number(capacity);
    const price = Number(pricePerSeat);
    if (!Number.isInteger(seats) || seats < 1 || (sessionType === "private" && seats !== 1) || (sessionType === "group" && seats < 2) || !Number.isFinite(price) || price < 0) {
      return Response.json({ error: "راجع السعر وعدد المقاعد؛ الحصة الخاصة مقعد واحد" }, { status: 400 });
    }
    if (new Date(endsAt) <= new Date(startsAt) || new Date(startsAt) <= new Date()) return Response.json({ error: "موعد الحصة غير صالح" }, { status: 400 });
    const [conflict] = await sql`SELECT id FROM bookable_sessions WHERE teacher_id = ${teacherId}
      AND status IN ('published','full') AND starts_at < ${endsAt} AND ends_at > ${startsAt} LIMIT 1`;
    if (conflict) return Response.json({ error: "لديك حصة أخرى في هذا الموعد" }, { status: 409 });
    const [created] = await sql`
      INSERT INTO bookable_sessions (teacher_id, session_type, subject, grade, topic, starts_at, ends_at, price_per_seat, capacity, delivery_mode, meeting_url, location)
      VALUES (${teacherId}, ${sessionType}, ${subject.trim()}, ${grade || null}, ${topic.trim()}, ${startsAt}, ${endsAt}, ${price}, ${seats}, ${deliveryMode}, ${meetingUrl || null}, ${location || null}) RETURNING *`;
    return Response.json({ session: created }, { status: 201 });
  } catch (error) {
    console.error("bookable sessions POST", error);
    return Response.json({ error: "تعذر نشر الحصة" }, { status: 500 });
  }
}
