import sql from "@/app/api/utils/sql";

// Generate email from name
function generateEmail(name) {
  const slug = name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ".")
    .replace(/[أإآ]/g, "a")
    .replace(/[ةتطث]/g, "t")
    .replace(/[نمله]/g, (c) => ({ ن: "n", م: "m", ل: "l", ه: "h" })[c] || c)
    .replace(/[^a-z0-9.]/g, "");
  return `${slug || "teacher"}@hishamacademy.online`;
}

function generatePassword() {
  const chars =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#";
  let pw = "";
  for (let i = 0; i < 10; i++)
    pw += chars[Math.floor(Math.random() * chars.length)];
  return pw;
}

export async function GET() {
  try {
    const teachers = await sql`
      SELECT id, name, email, phone, subject, groups_assigned, status, notes, created_at
      FROM teachers ORDER BY created_at DESC
    `;
    return Response.json({ teachers });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحميل المدرسين" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const {
      name,
      phone,
      subject,
      groupsAssigned,
      notes,
      status = "active",
      customEmail,
      customPassword,
    } = await request.json();
    if (!name?.trim())
      return Response.json({ error: "اسم المدرس مطلوب" }, { status: 400 });

    const email = customEmail?.trim() || generateEmail(name);
    const plainPassword = customPassword || generatePassword();

    // Check duplicate email
    const existing = await sql`SELECT id FROM teachers WHERE email = ${email}`;
    if (existing.length > 0)
      return Response.json(
        {
          error: "البريد الإلكتروني مستخدم بالفعل",
          suggestedEmail: `${email.split("@")[0]}2@hishamacademy.online`,
        },
        { status: 409 },
      );

    const [teacher] = await sql`
      INSERT INTO teachers (name, email, phone, subject, groups_assigned, password_hash, status, notes)
      VALUES (${name.trim()}, ${email}, ${phone || null}, ${subject || null}, ${groupsAssigned || null}, crypt(${plainPassword}, gen_salt('bf')), ${status}, ${notes || null})
      RETURNING id, name, email, phone, subject, groups_assigned, status, notes, created_at
    `;

    // Create notification for pending teachers
    if (status === "pending") {
      await sql`INSERT INTO notifications (title, message, notification_type, target_role, related_id, related_type) VALUES (${`طلب تسجيل معلم: ${name}`}, ${`قدّم ${name} طلب انضمام كمعلم لمادة ${subject || "غير محدد"}`}, 'info', 'admin', ${teacher.id}, 'teacher')`;
    }

    return Response.json({ teacher, plainPassword, email }, { status: 201 });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل إضافة المدرس" }, { status: 500 });
  }
}
