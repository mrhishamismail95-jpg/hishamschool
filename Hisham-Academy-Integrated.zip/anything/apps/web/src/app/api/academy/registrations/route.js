import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status") || "";
    const type = searchParams.get("type") || "";

    let query = "SELECT * FROM registration_requests WHERE 1=1";
    const params = [];
    let idx = 1;
    if (status) {
      query += ` AND status = $${idx}`;
      params.push(status);
      idx++;
    }
    if (type) {
      query += ` AND request_type = $${idx}`;
      params.push(type);
      idx++;
    }
    query += " ORDER BY submitted_at DESC";

    const requests = await sql(query, params);
    return Response.json({ requests });
  } catch (err) {
    return Response.json({ error: "فشل تحميل طلبات التسجيل" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      requestType = "student",
      name,
      phone,
      parentName,
      parentPhone,
      parentEmail,
      gradeCategory,
      grade,
      groupId,
      groupName,
      packageId,
      packageName,
      subject,
      preferredGroup,
      notes,
    } = body;

    if (!name?.trim())
      return Response.json({ error: "الاسم مطلوب" }, { status: 400 });

    const code = `REG-${Date.now().toString(36).toUpperCase()}`;
    const [req] = await sql`
      INSERT INTO registration_requests (code, request_type, name, phone, parent_name, parent_phone, parent_email, grade_category, grade, group_id, group_name, package_id, package_name, subject, preferred_group, notes)
      VALUES (${code}, ${requestType}, ${name.trim()}, ${phone || null}, ${parentName || null}, ${parentPhone || null}, ${parentEmail || null}, ${gradeCategory || null}, ${grade || null}, ${groupId || null}, ${groupName || null}, ${packageId || null}, ${packageName || null}, ${subject || null}, ${preferredGroup || null}, ${notes || null})
      RETURNING *
    `;

    // Create notification for admin
    await sql`INSERT INTO notifications (title, message, notification_type, target_role, related_id, related_type) VALUES (${`طلب تسجيل جديد: ${name}`}, ${`قدّم ${name} طلب تسجيل (${requestType === "student" ? "طالب" : requestType === "teacher" ? "معلم" : "ولي أمر"})`}, 'info', 'admin', ${req.id}, 'registration')`;

    return Response.json({ request: req, code }, { status: 201 });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل إرسال طلب التسجيل" }, { status: 500 });
  }
}
