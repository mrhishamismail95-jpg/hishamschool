import sql from "@/app/api/utils/sql";

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const {
      name,
      sessionsCount,
      price,
      discount,
      description,
      features,
      active,
    } = await request.json();
    const setClauses = [];
    const values = [];
    let idx = 1;
    const fields = {
      name,
      sessions_count: sessionsCount,
      price,
      discount,
      description,
      features,
      active,
    };
    for (const [key, val] of Object.entries(fields)) {
      if (val !== undefined) {
        setClauses.push(`${key} = $${idx}`);
        values.push(val);
        idx++;
      }
    }
    if (!setClauses.length)
      return Response.json({ error: "لا حقول للتحديث" }, { status: 400 });
    values.push(id);
    const [pkg] = await sql(
      `UPDATE packages SET ${setClauses.join(",")} WHERE id = $${idx} RETURNING *`,
      values,
    );
    return Response.json({ package: pkg });
  } catch (err) {
    return Response.json({ error: "فشل تحديث الباقة" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    await sql`UPDATE packages SET active = FALSE WHERE id = ${params.id}`;
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حذف الباقة" }, { status: 500 });
  }
}
