import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get("studentId");
    const month = searchParams.get("month");

    let query = `
      SELECT p.*, s.name as student_name, s.code as student_code, s.group_name
      FROM payments p
      JOIN students s ON p.student_id = s.id
      WHERE 1=1
    `;
    const params = [];
    let idx = 1;
    if (studentId) {
      query += ` AND p.student_id = $${idx}`;
      params.push(studentId);
      idx++;
    }
    if (month) {
      query += ` AND p.payment_month = $${idx}`;
      params.push(month);
      idx++;
    }
    query += " ORDER BY p.created_at DESC";

    const payments = await sql(query, params);
    return Response.json({ payments });
  } catch (err) {
    return Response.json({ error: "فشل تحميل المدفوعات" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const {
      studentId,
      amount,
      paymentMethod = "cash",
      paymentMonth,
      packageId,
      notes,
    } = await request.json();
    if (!studentId || !amount)
      return Response.json(
        { error: "معرف الطالب والمبلغ مطلوبان" },
        { status: 400 },
      );

    const month = paymentMonth || new Date().toISOString().slice(0, 7);
    const [payment] = await sql`
      INSERT INTO payments (student_id, amount, payment_method, payment_month, package_id, notes)
      VALUES (${studentId}, ${amount}, ${paymentMethod}, ${month}, ${packageId || null}, ${notes || null})
      RETURNING *
    `;
    return Response.json({ payment }, { status: 201 });
  } catch (err) {
    return Response.json({ error: "فشل تسجيل الدفع" }, { status: 500 });
  }
}

export async function DELETE(request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id)
      return Response.json({ error: "معرف الدفع مطلوب" }, { status: 400 });
    await sql`DELETE FROM payments WHERE id = ${id}`;
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حذف الدفع" }, { status: 500 });
  }
}
