import { sessionCookieHeader, clearSessionCookieHeader } from "@/utils/serverSession";
import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const { role, name, code, email, password } = await request.json();

    // ── Student login: name + code ────────────────────────────────────────────
    if (role === "student") {
      if (!name?.trim() || !code?.trim())
        return Response.json(
          { error: "الاسم والكود مطلوبان" },
          { status: 400 },
        );

      const [student] = await sql`
        SELECT * FROM students
        WHERE LOWER(TRIM(name)) = LOWER(TRIM(${name}))
        AND UPPER(TRIM(code)) = UPPER(TRIM(${code}))
        AND status = 'active'
      `;

      if (!student)
        return Response.json(
          { error: "الاسم أو الكود غير صحيح" },
          { status: 401 },
        );

      // Get parent info
      const [parent] =
        await sql`SELECT * FROM parents WHERE student_id = ${student.id} LIMIT 1`;

      const user = { ...student, parentInfo: parent || null, role: "student" };
      const response = Response.json({ user });
      const cookie = sessionCookieHeader(user);
      if (cookie) response.headers.append("Set-Cookie", cookie);
      return response;
    }

    // ── Parent login: parent phone + student code ─────────────────────────────
    if (role === "parent") {
      if (!name?.trim() || !code?.trim())
        return Response.json(
          { error: "الاسم والكود مطلوبان" },
          { status: 400 },
        );

      // Parent can log in via student's code + parent name/phone
      const [studentData] = await sql`
        SELECT s.*, p.name as parent_name_db, p.phone as parent_phone_db, p.email as parent_email_db, p.access_code
        FROM students s
        LEFT JOIN parents p ON p.student_id = s.id
        WHERE UPPER(TRIM(s.code)) = UPPER(TRIM(${code}))
        AND s.status = 'active'
      `;

      if (!studentData)
        return Response.json({ error: "كود الطالب غير صحيح" }, { status: 401 });

      // Verify parent identity via name or phone
      const nameMatch =
        studentData.parent_name_db?.toLowerCase().trim() ===
        name.toLowerCase().trim();
      const phoneMatch =
        studentData.parent_phone?.trim() === name.trim() ||
        studentData.parent_phone_db?.trim() === name.trim();

      if (!nameMatch && !phoneMatch)
        return Response.json(
          { error: "اسم ولي الأمر أو رقم الهاتف غير صحيح" },
          { status: 401 },
        );

      return Response.json({ user: { ...studentData, role: "parent" } });
    }

    // ── Teacher login: email + password ──────────────────────────────────────
    if (role === "teacher") {
      if (!email?.trim() || !password?.trim())
        return Response.json(
          { error: "البريد وكلمة المرور مطلوبان" },
          { status: 400 },
        );

      const [teacher] = await sql`
        SELECT *, (password_hash = crypt(${password}, password_hash)) AS password_ok
        FROM teachers
        WHERE LOWER(email) = LOWER(TRIM(${email}))
      `;

      if (!teacher)
        return Response.json(
          { error: "البريد الإلكتروني غير موجود" },
          { status: 401 },
        );
      if (!teacher.password_ok)
        return Response.json(
          { error: "كلمة المرور غير صحيحة" },
          { status: 401 },
        );
      if (teacher.status === "pending")
        return Response.json(
          { error: "حسابك في انتظار موافقة المدير" },
          { status: 403 },
        );
      if (teacher.status === "suspended")
        return Response.json(
          { error: "تم تعليق حسابك — تواصل مع الإدارة" },
          { status: 403 },
        );

      const { password_hash, password_ok, ...safeTeacher } = teacher;
      const user = { ...safeTeacher, role: "teacher" };
      const response = Response.json({ user });
      const cookie = sessionCookieHeader(user);
      if (cookie) response.headers.append("Set-Cookie", cookie);
      return response;
    }

    return Response.json({ error: "نوع المستخدم غير معروف" }, { status: 400 });
  } catch (err) {
    console.error("Auth error:", err);
    return Response.json({ error: "خطأ في تسجيل الدخول" }, { status: 500 });
  }
}

export async function DELETE() {
  const response = Response.json({ ok: true });
  response.headers.append("Set-Cookie", clearSessionCookieHeader());
  return response;
}
