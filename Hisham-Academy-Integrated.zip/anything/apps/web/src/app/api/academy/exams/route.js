import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const groupId = searchParams.get("groupId");
    const grade = searchParams.get("grade");

    let query = `
      SELECT e.*, 
        COALESCE(json_agg(json_build_object('student_id', es.student_id, 'score', es.score)) FILTER (WHERE es.id IS NOT NULL), '[]') as scores
      FROM exams e
      LEFT JOIN exam_scores es ON es.exam_id = e.id
      WHERE 1=1
    `;
    const params = [];
    let idx = 1;
    if (groupId) {
      query += ` AND e.group_id = $${idx}`;
      params.push(groupId);
      idx++;
    }
    if (grade) {
      query += ` AND e.grade = $${idx}`;
      params.push(grade);
      idx++;
    }
    query += " GROUP BY e.id ORDER BY e.exam_date DESC NULLS LAST";

    const exams = await sql(query, params);
    return Response.json({ exams });
  } catch (err) {
    return Response.json({ error: "فشل تحميل الامتحانات" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const {
      title,
      subject,
      grade,
      groupId,
      groupName,
      examDate,
      maxScore = 100,
      notes,
    } = await request.json();
    if (!title?.trim())
      return Response.json({ error: "عنوان الامتحان مطلوب" }, { status: 400 });
    const [exam] = await sql`
      INSERT INTO exams (title, subject, grade, group_id, group_name, exam_date, max_score, notes)
      VALUES (${title.trim()}, ${subject || null}, ${grade || null}, ${groupId || null}, ${groupName || null}, ${examDate || null}, ${maxScore}, ${notes || null})
      RETURNING *
    `;
    return Response.json({ exam }, { status: 201 });
  } catch (err) {
    return Response.json({ error: "فشل إضافة الامتحان" }, { status: 500 });
  }
}
