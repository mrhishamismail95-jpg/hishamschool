import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id } = params;
    const [student] = await sql`SELECT * FROM students WHERE id = ${id}`;
    if (!student)
      return Response.json({ error: "الطالب غير موجود" }, { status: 404 });
    const parent =
      await sql`SELECT * FROM parents WHERE student_id = ${id} LIMIT 1`;
    return Response.json({ student, parent: parent[0] || null });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحميل الطالب" }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const {
      name,
      phone,
      grade,
      gradeCategory,
      groupId,
      groupName,
      packageId,
      packageName,
      price,
      sessionPackage,
      parentName,
      parentPhone,
      parentEmail,
      notes,
      status,
    } = body;

    const [current] = await sql`SELECT * FROM students WHERE id = ${id}`;
    if (!current)
      return Response.json({ error: "الطالب غير موجود" }, { status: 404 });

    // Update group counts if group changed
    if (groupId !== undefined && current.group_id !== groupId) {
      if (current.group_id)
        await sql`UPDATE study_groups SET current_students = GREATEST(0, current_students - 1) WHERE id = ${current.group_id}`;
      if (groupId)
        await sql`UPDATE study_groups SET current_students = current_students + 1 WHERE id = ${groupId}`;
    }

    const setClauses = [];
    const values = [];
    let idx = 1;

    const fields = {
      name,
      phone,
      grade,
      grade_category: gradeCategory,
      group_id: groupId,
      group_name: groupName,
      package_id: packageId,
      package_name: packageName,
      price,
      session_package: sessionPackage,
      parent_name: parentName,
      parent_phone: parentPhone,
      parent_email: parentEmail,
      notes,
      status,
    };
    for (const [key, val] of Object.entries(fields)) {
      if (val !== undefined) {
        setClauses.push(`${key} = $${idx}`);
        values.push(val);
        idx++;
      }
    }

    if (setClauses.length === 0)
      return Response.json({ error: "لا توجد حقول للتحديث" }, { status: 400 });

    values.push(id);
    const [student] = await sql(
      `UPDATE students SET ${setClauses.join(", ")} WHERE id = $${idx} RETURNING *`,
      values,
    );

    // Update parent record
    if (parentName || parentPhone || parentEmail) {
      const existingParent =
        await sql`SELECT id FROM parents WHERE student_id = ${id} LIMIT 1`;
      if (existingParent.length > 0) {
        await sql`UPDATE parents SET name = COALESCE(${parentName || null}, name), phone = COALESCE(${parentPhone || null}, phone), email = COALESCE(${parentEmail || null}, email) WHERE student_id = ${id}`;
      }
    }

    return Response.json({ student });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحديث بيانات الطالب" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const { id } = params;
    const [student] = await sql`SELECT * FROM students WHERE id = ${id}`;
    if (!student)
      return Response.json({ error: "الطالب غير موجود" }, { status: 404 });
    if (student.group_id)
      await sql`UPDATE study_groups SET current_students = GREATEST(0, current_students - 1) WHERE id = ${student.group_id}`;
    await sql`DELETE FROM students WHERE id = ${id}`;
    return Response.json({ ok: true });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل حذف الطالب" }, { status: 500 });
  }
}
