import { releaseExpiredBookingSeats } from "@/utils/bookingMaintenance";
import { getServerSession, unauthorized } from "@/utils/serverSession";
import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get("studentId");
    const teacherId = searchParams.get("teacherId");
    const actor = getServerSession(request);
    if (!actor) return unauthorized();
    await releaseExpiredBookingSeats();
    if (studentId && (actor.role !== "student" || String(actor.id) !== String(studentId))) return Response.json({ error: "غير مصرح بعرض حجوزات هذا الطالب" }, { status: 403 });
    if (teacherId && (actor.role !== "teacher" || String(actor.id) !== String(teacherId))) return Response.json({ error: "غير مصرح بعرض حجوزات هذا المعلم" }, { status: 403 });
    if (studentId) {
      const bookings = await sql`SELECT b.*, bs.subject, bs.grade, bs.topic, bs.starts_at, bs.ends_at, bs.session_type,
          bs.delivery_mode, bs.meeting_url, bp.status AS payment_status,
          COALESCE(json_agg(json_build_object('studentId', bst.student_id, 'attendanceStatus', bst.attendance_status)) FILTER (WHERE bst.id IS NOT NULL), '[]') AS participants
        FROM session_bookings b JOIN bookable_sessions bs ON bs.id = b.session_id
        LEFT JOIN booking_students bst ON bst.booking_id = b.id
        LEFT JOIN LATERAL (SELECT status FROM booking_payments WHERE booking_id = b.id ORDER BY created_at DESC LIMIT 1) bp ON TRUE
        WHERE b.booked_by_student_id = ${studentId} OR EXISTS (SELECT 1 FROM booking_students x WHERE x.booking_id = b.id AND x.student_id = ${studentId})
        GROUP BY b.id, bs.id, bp.status ORDER BY bs.starts_at DESC`;
      return Response.json({ bookings });
    }
    if (teacherId) {
      const bookings = await sql`SELECT b.*, bs.subject, bs.grade, bs.topic, bs.starts_at, bs.ends_at, bs.session_type,
          bp.status AS payment_status, bp.proof_url, bp.payment_method,
          COALESCE(json_agg(json_build_object('studentId', bst.student_id, 'studentName', st.name, 'studentCode', st.code, 'attendanceStatus', bst.attendance_status)) FILTER (WHERE bst.id IS NOT NULL), '[]') AS participants
        FROM session_bookings b JOIN bookable_sessions bs ON bs.id = b.session_id
        LEFT JOIN booking_students bst ON bst.booking_id = b.id
        LEFT JOIN students st ON st.id = bst.student_id
        LEFT JOIN LATERAL (SELECT status, proof_url, payment_method FROM booking_payments WHERE booking_id = b.id ORDER BY created_at DESC LIMIT 1) bp ON TRUE
        WHERE bs.teacher_id = ${teacherId}
        GROUP BY b.id, bs.id, bp.status, bp.proof_url, bp.payment_method ORDER BY b.created_at DESC`;
      return Response.json({ bookings });
    }
    return Response.json({ error: "معرف الطالب أو المعلم مطلوب" }, { status: 400 });
  } catch (error) {
    console.error("bookings GET", error);
    return Response.json({ error: "تعذر تحميل الحجوزات" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const actor = getServerSession(request);
    if (!actor || actor.role !== "student") return unauthorized();
    await releaseExpiredBookingSeats();
    const body = await request.json();
    const { sessionId, bookedByStudentId, studentCodes, paymentMethod = "bank_transfer", reference, proofUrl } = body;
    let ids = [];
    if (Array.isArray(studentCodes) && studentCodes.length) {
      const codes = [...new Set(studentCodes.map((code) => String(code).trim().toUpperCase()).filter(Boolean))];
      const found = await sql`SELECT id, UPPER(code) AS code FROM students
        WHERE status = 'active' AND UPPER(code) IN
        (SELECT UPPER(value) FROM jsonb_array_elements_text(${JSON.stringify(codes)}::jsonb))`;
      if (found.length !== codes.length) return Response.json({ error: "تعذر العثور على أحد أكواد الطلاب أو أن حسابه غير نشط" }, { status: 400 });
      ids = found.map((student) => String(student.id));
      if (!ids.includes(String(actor.id))) ids.push(String(actor.id));
    }
    if (!ids.length) ids = [String(bookedByStudentId || "")].filter(Boolean);
    ids = [...new Set(ids)];
    if (String(actor.id) !== String(bookedByStudentId)) return Response.json({ error: "لا يمكنك إنشاء حجز باسم طالب آخر" }, { status: 403 });
    if (!sessionId || !bookedByStudentId || !ids.length) return Response.json({ error: "بيانات الحجز غير مكتملة" }, { status: 400 });
    const jsonIds = JSON.stringify(ids);
    // A single SQL statement reserves capacity and creates the booking, participants and payment together.
    const result = await sql`
      WITH chosen AS (
        SELECT id, price_per_seat, capacity, reserved_seats, session_type, status
        FROM bookable_sessions WHERE id = ${sessionId} AND status = 'published' AND starts_at > NOW()
        FOR UPDATE
      ), valid AS (
        SELECT * FROM chosen WHERE reserved_seats + ${ids.length} <= capacity
          AND (session_type = 'group' OR ${ids.length} = 1)
      ), reserved AS (
        UPDATE bookable_sessions s SET reserved_seats = s.reserved_seats + ${ids.length},
          status = CASE WHEN s.reserved_seats + ${ids.length} >= s.capacity THEN 'full' ELSE s.status END,
          updated_at = NOW()
        FROM valid v WHERE s.id = v.id RETURNING s.id, v.price_per_seat
      ), new_booking AS (
        INSERT INTO session_bookings (session_id, booked_by_student_id, seat_count, total_amount, status, expires_at)
        SELECT id, ${bookedByStudentId}, ${ids.length}, price_per_seat * ${ids.length},
          CASE WHEN ${proofUrl || reference || null} IS NULL THEN 'pending_payment' ELSE 'payment_review' END,
          NOW() + INTERVAL '30 minutes' FROM reserved
        RETURNING *
      ), participants AS (
        INSERT INTO booking_students (booking_id, session_id, student_id, seat_price)
        SELECT b.id, b.session_id, (x.value)::BIGINT, r.price_per_seat
        FROM new_booking b CROSS JOIN reserved r CROSS JOIN jsonb_array_elements_text(${jsonIds}::jsonb) x
        RETURNING id
      ), payment AS (
        INSERT INTO booking_payments (booking_id, amount, payment_method, reference, proof_url, status)
        SELECT id, total_amount, ${paymentMethod}, ${reference || null}, ${proofUrl || null},
          CASE WHEN ${proofUrl || reference || null} IS NULL THEN 'pending' ELSE 'under_review' END
        FROM new_booking RETURNING id, status
      ), history AS (
        INSERT INTO booking_status_history (booking_id, new_status, actor_role, actor_id, note)
        SELECT id, status, 'student', ${bookedByStudentId}, 'إنشاء حجز جديد' FROM new_booking RETURNING id
      )
      SELECT b.*, p.status AS payment_status FROM new_booking b CROSS JOIN payment p`;
    if (!result.length) return Response.json({ error: "لم تعد المقاعد متاحة أو أن الحصة غير منشورة" }, { status: 409 });
    return Response.json({ booking: result[0], message: "تم إنشاء الحجز، وهو في انتظار تأكيد الدفع" }, { status: 201 });
  } catch (error) {
    console.error("bookings POST", error);
    const message = String(error?.message || "");
    if (message.includes("booking_students_session_id_student_id_key")) return Response.json({ error: "أحد الطلاب لديه حجز بالفعل في هذه الحصة" }, { status: 409 });
    return Response.json({ error: "تعذر إنشاء الحجز. تحقق من بيانات الطلاب والمقاعد المتاحة." }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const actor = getServerSession(request);
    if (!actor || actor.role !== "teacher") return unauthorized();
    const body = await request.json();
    const { bookingId, action, teacherId, note, studentId, attendanceStatus } = body;
    if (String(actor.id) !== String(teacherId)) return Response.json({ error: "لا يمكنك تنفيذ العملية باسم معلم آخر" }, { status: 403 });
    if (!bookingId || !action) return Response.json({ error: "بيانات العملية غير مكتملة" }, { status: 400 });
    if (action === "review_payment") {
      if (!teacherId || !["approved", "rejected"].includes(body.decision)) return Response.json({ error: "بيانات اعتماد الدفع غير صحيحة" }, { status: 400 });
      const newStatus = body.decision === "approved" ? "confirmed" : "rejected";
      const reviewed = await sql`
        WITH target AS (
          SELECT b.* FROM session_bookings b JOIN bookable_sessions bs ON bs.id = b.session_id
          WHERE b.id = ${bookingId} AND bs.teacher_id = ${teacherId}
            AND (b.expires_at IS NULL OR b.expires_at > NOW())
          FOR UPDATE OF b
        ), updated_payment AS (
          UPDATE booking_payments p SET status = ${body.decision}, reviewed_by_teacher_id = ${teacherId}, reviewed_at = NOW(), review_note = ${note || null}
          WHERE p.id = (SELECT id FROM booking_payments WHERE booking_id = ${bookingId} ORDER BY created_at DESC LIMIT 1)
          AND EXISTS (SELECT 1 FROM target WHERE status IN ('pending_payment','payment_review')) RETURNING p.*
        ), updated_booking AS (
          UPDATE session_bookings b SET status = ${newStatus}, updated_at = NOW()
          FROM target t WHERE b.id = t.id AND t.status IN ('pending_payment','payment_review')
          RETURNING b.*, t.session_id AS reserved_session_id
        ), released AS (
          UPDATE bookable_sessions bs SET reserved_seats = GREATEST(0, bs.reserved_seats - u.seat_count),
            status = CASE WHEN bs.status = 'full' THEN 'published' ELSE bs.status END, updated_at = NOW()
          FROM updated_booking u WHERE bs.id = u.reserved_session_id AND ${body.decision} = 'rejected' RETURNING bs.id
        ), history AS (
          INSERT INTO booking_status_history (booking_id, old_status, new_status, actor_role, actor_id, note)
          SELECT id, status, ${newStatus}, 'teacher', ${teacherId}, ${note || null} FROM target
          WHERE EXISTS (SELECT 1 FROM updated_booking) RETURNING id
        )
        SELECT u.*, p.status AS payment_status FROM updated_booking u LEFT JOIN updated_payment p ON p.booking_id = u.id`;
      if (!reviewed.length) return Response.json({ error: "الحجز غير موجود أو سبق تحديث حالته" }, { status: 404 });
      return Response.json({ ok: true, booking: reviewed[0], status: newStatus });
    }
    if (action === "attendance") {
      if (!teacherId || !studentId || !["present", "absent", "late"].includes(attendanceStatus)) return Response.json({ error: "بيانات الحضور غير صحيحة" }, { status: 400 });
      const [updated] = await sql`UPDATE booking_students bst SET attendance_status = ${attendanceStatus}
        FROM session_bookings b JOIN bookable_sessions s ON s.id = b.session_id
        WHERE bst.booking_id = b.id AND bst.student_id = ${studentId} AND b.id = ${bookingId} AND b.status = 'confirmed' AND s.teacher_id = ${teacherId}
        RETURNING bst.*`;
      if (!updated) return Response.json({ error: "لم يتم العثور على الطالب في هذا الحجز" }, { status: 404 });
      return Response.json({ participant: updated });
    }
    return Response.json({ error: "العملية غير مدعومة" }, { status: 400 });
  } catch (error) {
    console.error("bookings PATCH", error);
    return Response.json({ error: "تعذر تحديث الحجز" }, { status: 500 });
  }
}
