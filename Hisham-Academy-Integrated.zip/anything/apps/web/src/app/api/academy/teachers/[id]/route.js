import sql from "@/app/api/utils/sql";

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const { name, phone, subject, groupsAssigned, notes, status, newPassword } =
      await request.json();

    const setClauses = [];
    const values = [];
    let idx = 1;
    const fields = {
      name,
      phone,
      subject,
      groups_assigned: groupsAssigned,
      notes,
      status,
    };
    for (const [key, val] of Object.entries(fields)) {
      if (val !== undefined) {
        setClauses.push(`${key} = $${idx}`);
        values.push(val);
        idx++;
      }
    }
    if (newPassword) {
      setClauses.push(`password_hash = crypt($${idx}, gen_salt('bf'))`);
      values.push(newPassword);
      idx++;
    }
    if (!setClauses.length)
      return Response.json({ error: "لا توجد حقول للتحديث" }, { status: 400 });
    values.push(id);
    const [teacher] = await sql(
      `UPDATE teachers SET ${setClauses.join(",")} WHERE id = $${idx} RETURNING id, name, email, phone, subject, groups_assigned, status, notes, created_at`,
      values,
    );

    // If teacher was pending and now active, notify
    if (status === "active") {
      await sql`UPDATE notifications SET is_read = TRUE WHERE related_id = ${id} AND related_type = 'teacher'`;
    }

    return Response.json({ teacher });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحديث بيانات المدرس" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    await sql`DELETE FROM teachers WHERE id = ${params.id}`;
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حذف المدرس" }, { status: 500 });
  }
}
