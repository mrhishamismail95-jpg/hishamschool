import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const today = new Date().toISOString().split("T")[0];
    const thisMonth = new Date().toISOString().slice(0, 7);

    const [
      studentsData,
      todayAttData,
      monthPayData,
      pendingRegsData,
      groupsData,
      notificationsData,
      lowSessionsData,
    ] = await sql.transaction([
      sql`SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status='active') as active FROM students`,
      sql`SELECT status, COUNT(*) as cnt FROM attendance WHERE date = ${today} GROUP BY status`,
      sql`SELECT COALESCE(SUM(amount), 0) as total, COUNT(DISTINCT student_id) as paid_count FROM payments WHERE payment_month = ${thisMonth}`,
      sql`SELECT COUNT(*) as pending FROM registration_requests WHERE status = 'pending'`,
      sql`SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE active=TRUE) as active FROM study_groups`,
      sql`SELECT COUNT(*) as unread FROM notifications WHERE is_read = FALSE`,
      sql`
        SELECT s.id, s.name, s.code, s.group_name, s.session_package,
               COUNT(a.id) FILTER (WHERE a.status IN ('present','late')) as sessions_used
        FROM students s
        LEFT JOIN attendance a ON a.student_id = s.id
        WHERE s.status = 'active'
        GROUP BY s.id
        HAVING (s.session_package - COUNT(a.id) FILTER (WHERE a.status IN ('present','late'))) <= 2
        LIMIT 10
      `,
    ]);

    const todayAttMap = {};
    for (const row of todayAttData) todayAttMap[row.status] = Number(row.cnt);

    return Response.json({
      students: {
        total: Number(studentsData[0].total),
        active: Number(studentsData[0].active),
      },
      today: {
        present: (todayAttMap.present || 0) + (todayAttMap.late || 0),
        absent: todayAttMap.absent || 0,
        late: todayAttMap.late || 0,
      },
      month: {
        revenue: Number(monthPayData[0].total),
        paidCount: Number(monthPayData[0].paid_count),
      },
      pendingRegistrations: Number(pendingRegsData[0].pending),
      groups: {
        total: Number(groupsData[0].total),
        active: Number(groupsData[0].active),
      },
      unreadNotifications: Number(notificationsData[0].unread),
      lowSessionStudents: lowSessionsData,
    });
  } catch (err) {
    console.error("Dashboard error:", err);
    return Response.json(
      { error: "فشل تحميل بيانات لوحة القيادة" },
      { status: 500 },
    );
  }
}
