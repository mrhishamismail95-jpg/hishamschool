import sql from "@/app/api/utils/sql";

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const {
      title,
      subject,
      grade,
      groupId,
      groupName,
      examDate,
      maxScore,
      notes,
    } = await request.json();
    const setClauses = [];
    const values = [];
    let idx = 1;
    const fields = {
      title,
      subject,
      grade,
      group_id: groupId,
      group_name: groupName,
      exam_date: examDate,
      max_score: maxScore,
      notes,
    };
    for (const [key, val] of Object.entries(fields)) {
      if (val !== undefined) {
        setClauses.push(`${key} = $${idx}`);
        values.push(val);
        idx++;
      }
    }
    if (!setClauses.length)
      return Response.json({ error: "لا توجد حقول للتحديث" }, { status: 400 });
    values.push(id);
    const [exam] = await sql(
      `UPDATE exams SET ${setClauses.join(",")} WHERE id = $${idx} RETURNING *`,
      values,
    );
    return Response.json({ exam });
  } catch (err) {
    return Response.json({ error: "فشل تحديث الامتحان" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    await sql`DELETE FROM exams WHERE id = ${params.id}`;
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حذف الامتحان" }, { status: 500 });
  }
}
