import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const packages = await sql`SELECT * FROM packages ORDER BY price ASC`;
    return Response.json({ packages });
  } catch (err) {
    return Response.json({ error: "فشل تحميل الباقات" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const {
      name,
      sessionsCount = 8,
      price = 0,
      discount = 0,
      description,
      features,
    } = await request.json();
    if (!name?.trim())
      return Response.json({ error: "اسم الباقة مطلوب" }, { status: 400 });
    const [pkg] = await sql`
      INSERT INTO packages (name, sessions_count, price, discount, description, features)
      VALUES (${name.trim()}, ${sessionsCount}, ${price}, ${discount}, ${description || null}, ${features || null})
      RETURNING *
    `;
    return Response.json({ package: pkg }, { status: 201 });
  } catch (err) {
    return Response.json({ error: "فشل إنشاء الباقة" }, { status: 500 });
  }
}
