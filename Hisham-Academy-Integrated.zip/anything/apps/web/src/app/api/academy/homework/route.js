import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const groupId = searchParams.get("groupId");
    const grade = searchParams.get("grade");

    let query = `
      SELECT h.*,
        COALESCE(json_agg(json_build_object('student_id', hs.student_id, 'submitted_at', hs.submitted_at)) FILTER (WHERE hs.id IS NOT NULL), '[]') as submissions
      FROM homework h
      LEFT JOIN homework_submissions hs ON hs.homework_id = h.id
      WHERE 1=1
    `;
    const params = [];
    let idx = 1;
    if (groupId) {
      query += ` AND h.group_id = $${idx}`;
      params.push(groupId);
      idx++;
    }
    if (grade) {
      query += ` AND h.grade = $${idx}`;
      params.push(grade);
      idx++;
    }
    query += " GROUP BY h.id ORDER BY h.due_date ASC NULLS LAST";

    const homeworkList = await sql(query, params);
    return Response.json({ homework: homeworkList });
  } catch (err) {
    return Response.json({ error: "فشل تحميل الواجبات" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { title, subject, grade, groupId, groupName, description, dueDate } =
      await request.json();
    if (!title?.trim())
      return Response.json({ error: "عنوان الواجب مطلوب" }, { status: 400 });
    const [hw] = await sql`
      INSERT INTO homework (title, subject, grade, group_id, group_name, description, due_date)
      VALUES (${title.trim()}, ${subject || null}, ${grade || null}, ${groupId || null}, ${groupName || null}, ${description || null}, ${dueDate || null})
      RETURNING *
    `;
    return Response.json({ homework: hw }, { status: 201 });
  } catch (err) {
    return Response.json({ error: "فشل إضافة الواجب" }, { status: 500 });
  }
}
