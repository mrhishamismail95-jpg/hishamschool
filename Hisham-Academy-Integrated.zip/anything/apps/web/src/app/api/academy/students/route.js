import sql from "@/app/api/utils/sql";

function generateCode(maxNum) {
  return `ST-${String(maxNum + 1).padStart(4, "0")}`;
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const group = searchParams.get("group") || "";
    const grade = searchParams.get("grade") || "";
    const status = searchParams.get("status") || "";

    let query = "SELECT * FROM students WHERE 1=1";
    const params = [];
    let idx = 1;

    if (search) {
      query += ` AND (LOWER(name) LIKE LOWER($${idx}) OR code LIKE $${idx + 1} OR phone LIKE $${idx + 2})`;
      const s = `%${search}%`;
      params.push(s, s, s);
      idx += 3;
    }
    if (group) {
      query += ` AND group_name = $${idx}`;
      params.push(group);
      idx++;
    }
    if (grade) {
      query += ` AND grade = $${idx}`;
      params.push(grade);
      idx++;
    }
    if (status) {
      query += ` AND status = $${idx}`;
      params.push(status);
      idx++;
    }
    query += " ORDER BY created_at DESC";

    const students = await sql(query, params);
    return Response.json({ students });
  } catch (err) {
    console.error("GET /api/academy/students", err);
    return Response.json({ error: "فشل تحميل الطلاب" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      name,
      phone,
      grade,
      gradeCategory,
      groupId,
      groupName,
      packageId,
      packageName,
      price,
      sessionPackage,
      parentName,
      parentPhone,
      parentEmail,
      notes,
      status = "active",
    } = body;

    if (!name?.trim())
      return Response.json({ error: "اسم الطالب مطلوب" }, { status: 400 });

    // Generate unique code
    const [{ max_num }] =
      await sql`SELECT COALESCE(MAX(CAST(REPLACE(code, 'ST-', '') AS INTEGER)), 0) AS max_num FROM students WHERE code LIKE 'ST-%'`;
    const code = generateCode(Number(max_num));

    const [student] = await sql`
      INSERT INTO students (code, name, phone, grade, grade_category, group_id, group_name, package_id, package_name, price, session_package, parent_name, parent_phone, parent_email, notes, status)
      VALUES (${code}, ${name.trim()}, ${phone || null}, ${grade || null}, ${gradeCategory || null}, ${groupId || null}, ${groupName || null}, ${packageId || null}, ${packageName || null}, ${price || 0}, ${sessionPackage || 8}, ${parentName || null}, ${parentPhone || null}, ${parentEmail || null}, ${notes || null}, ${status})
      RETURNING *
    `;

    // Update group student count
    if (groupId) {
      await sql`UPDATE study_groups SET current_students = current_students + 1 WHERE id = ${groupId}`;
    }

    // Create parent record if parent info provided
    if (parentName || parentPhone) {
      const accessCode = `P-${student.id}-${Date.now().toString(36).toUpperCase()}`;
      await sql`
        INSERT INTO parents (student_id, name, phone, email, access_code)
        VALUES (${student.id}, ${parentName || name}, ${parentPhone || null}, ${parentEmail || null}, ${accessCode})
      `;
    }

    return Response.json({ student, code }, { status: 201 });
  } catch (err) {
    console.error("POST /api/academy/students", err);
    return Response.json({ error: "فشل إضافة الطالب" }, { status: 500 });
  }
}
