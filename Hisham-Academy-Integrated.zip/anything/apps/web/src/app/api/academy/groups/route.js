import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const activeOnly = searchParams.get("active") !== "false";
    const grade = searchParams.get("grade") || "";

    let query =
      "SELECT sg.*, p.name as package_name_joined FROM study_groups sg LEFT JOIN packages p ON sg.package_id = p.id WHERE 1=1";
    const params = [];
    let idx = 1;

    if (activeOnly) {
      query += ` AND sg.active = TRUE`;
    }
    if (grade) {
      query += ` AND sg.grade = $${idx}`;
      params.push(grade);
      idx++;
    }
    query += " ORDER BY sg.day_of_week, sg.start_time";

    const groups = await sql(query, params);
    return Response.json({ groups });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحميل المجموعات" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      name,
      grade,
      gradeCategory,
      subject,
      dayOfWeek,
      startTime,
      endTime,
      maxStudents = 20,
      price = 0,
      packageId,
      location,
      notes,
    } = body;

    if (!name?.trim())
      return Response.json({ error: "اسم المجموعة مطلوب" }, { status: 400 });

    const [group] = await sql`
      INSERT INTO study_groups (name, grade, grade_category, subject, day_of_week, start_time, end_time, max_students, price, package_id, location, notes)
      VALUES (${name.trim()}, ${grade || null}, ${gradeCategory || null}, ${subject || null}, ${dayOfWeek || null}, ${startTime || null}, ${endTime || null}, ${maxStudents}, ${price}, ${packageId || null}, ${location || null}, ${notes || null})
      RETURNING *
    `;
    return Response.json({ group }, { status: 201 });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل إنشاء المجموعة" }, { status: 500 });
  }
}
