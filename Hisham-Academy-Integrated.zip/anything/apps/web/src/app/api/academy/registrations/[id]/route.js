import sql from "@/app/api/utils/sql";

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const { action } = await request.json(); // 'approve' | 'reject'

    const [reg] =
      await sql`SELECT * FROM registration_requests WHERE id = ${id}`;
    if (!reg)
      return Response.json({ error: "الطلب غير موجود" }, { status: 404 });

    if (action === "approve") {
      let studentCode = null;
      // If student or parent request, create a student record
      if (reg.request_type === "student" || reg.request_type === "parent") {
        const [{ max_num }] =
          await sql`SELECT COALESCE(MAX(CAST(REPLACE(code, 'ST-', '') AS INTEGER)), 0) AS max_num FROM students WHERE code LIKE 'ST-%'`;
        studentCode = `ST-${String(Number(max_num) + 1).padStart(4, "0")}`;

        const [student] = await sql`
          INSERT INTO students (code, name, phone, grade, grade_category, group_id, group_name, package_id, package_name, session_package, parent_name, parent_phone, parent_email, notes)
          VALUES (${studentCode}, ${reg.name}, ${reg.phone || null}, ${reg.grade || null}, ${reg.grade_category || null}, ${reg.group_id || null}, ${reg.group_name || null}, ${reg.package_id || null}, ${reg.package_name || null}, ${reg.package_id ? null : 8}, ${reg.parent_name || null}, ${reg.parent_phone || null}, ${reg.parent_email || null}, ${`مسجَّل من المنصة: ${reg.code}`})
          RETURNING id
        `;

        if (reg.group_id)
          await sql`UPDATE study_groups SET current_students = current_students + 1 WHERE id = ${reg.group_id}`;

        // Create parent record
        if (reg.parent_name || reg.parent_phone) {
          const accessCode = `P-${student.id}-${Date.now().toString(36).toUpperCase()}`;
          await sql`INSERT INTO parents (student_id, name, phone, email, access_code) VALUES (${student.id}, ${reg.parent_name || reg.name}, ${reg.parent_phone || null}, ${reg.parent_email || null}, ${accessCode})`;
        }
      }

      // If teacher request, activate the teacher
      if (reg.request_type === "teacher") {
        await sql`UPDATE teachers SET status = 'active' WHERE name = ${reg.name} AND status = 'pending'`;
      }

      await sql`UPDATE registration_requests SET status = 'approved', reviewed_at = NOW() WHERE id = ${id}`;
      await sql`UPDATE notifications SET is_read = TRUE WHERE related_id = ${id} AND related_type = 'registration'`;
      return Response.json({ ok: true, studentCode });
    } else if (action === "reject") {
      await sql`UPDATE registration_requests SET status = 'rejected', reviewed_at = NOW() WHERE id = ${id}`;
      await sql`UPDATE notifications SET is_read = TRUE WHERE related_id = ${id} AND related_type = 'registration'`;
      return Response.json({ ok: true });
    } else {
      return Response.json({ error: "إجراء غير معروف" }, { status: 400 });
    }
  } catch (err) {
    console.error(err);
    return Response.json({ error: "فشل تحديث الطلب" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    await sql`DELETE FROM registration_requests WHERE id = ${params.id}`;
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حذف الطلب" }, { status: 500 });
  }
}
