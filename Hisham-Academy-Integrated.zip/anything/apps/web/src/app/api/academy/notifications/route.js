import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const unreadOnly = searchParams.get("unread") === "true";

    let query = "SELECT * FROM notifications WHERE 1=1";
    if (unreadOnly) query += " AND is_read = FALSE";
    query += " ORDER BY created_at DESC LIMIT 100";

    const notifications = await sql(query, []);
    return Response.json({ notifications });
  } catch (err) {
    return Response.json({ error: "فشل تحميل الإشعارات" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const { id, allRead } = await request.json();
    if (allRead) {
      await sql`UPDATE notifications SET is_read = TRUE`;
    } else if (id) {
      await sql`UPDATE notifications SET is_read = TRUE WHERE id = ${id}`;
    }
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل تحديث الإشعار" }, { status: 500 });
  }
}

export async function DELETE(request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (id) {
      await sql`DELETE FROM notifications WHERE id = ${id}`;
    } else {
      await sql`DELETE FROM notifications`;
    }
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حذف الإشعار" }, { status: 500 });
  }
}
