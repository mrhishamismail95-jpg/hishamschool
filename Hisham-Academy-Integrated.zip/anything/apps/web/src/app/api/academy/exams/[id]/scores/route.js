import sql from "@/app/api/utils/sql";

export async function PUT(request, { params }) {
  try {
    const { id: examId } = params;
    const { scores } = await request.json(); // { studentId: score, ... }

    if (!scores || typeof scores !== "object") {
      return Response.json({ error: "بيانات الدرجات مطلوبة" }, { status: 400 });
    }

    const results = await Promise.all(
      Object.entries(scores).map(
        ([studentId, score]) =>
          sql`
          INSERT INTO exam_scores (exam_id, student_id, score)
          VALUES (${examId}, ${studentId}, ${score})
          ON CONFLICT (exam_id, student_id) DO UPDATE SET score = EXCLUDED.score
          RETURNING *
        `,
      ),
    );

    return Response.json({ scores: results.flat() });
  } catch (err) {
    console.error(err);
    return Response.json(
      { error: "فشل تحديث درجات الامتحان" },
      { status: 500 },
    );
  }
}
