import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const rows =
      await sql`SELECT setting_key, setting_value FROM academy_settings`;
    const settings = {};
    for (const row of rows) settings[row.setting_key] = row.setting_value;
    return Response.json({ settings });
  } catch (err) {
    return Response.json({ error: "فشل تحميل الإعدادات" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const { settings } = await request.json();
    if (!settings || typeof settings !== "object")
      return Response.json({ error: "البيانات مطلوبة" }, { status: 400 });

    for (const [key, value] of Object.entries(settings)) {
      await sql`
        INSERT INTO academy_settings (setting_key, setting_value, updated_at)
        VALUES (${key}, ${String(value)}, NOW())
        ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()
      `;
    }
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حفظ الإعدادات" }, { status: 500 });
  }
}
