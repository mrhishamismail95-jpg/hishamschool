import sql from "@/app/api/utils/sql";

export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const { title, subject, grade, groupId, groupName, description, dueDate } =
      await request.json();
    const setClauses = [];
    const values = [];
    let idx = 1;
    const fields = {
      title,
      subject,
      grade,
      group_id: groupId,
      group_name: groupName,
      description,
      due_date: dueDate,
    };
    for (const [key, val] of Object.entries(fields)) {
      if (val !== undefined) {
        setClauses.push(`${key} = $${idx}`);
        values.push(val);
        idx++;
      }
    }
    if (!setClauses.length)
      return Response.json({ error: "لا حقول للتحديث" }, { status: 400 });
    values.push(id);
    const [hw] = await sql(
      `UPDATE homework SET ${setClauses.join(",")} WHERE id = $${idx} RETURNING *`,
      values,
    );
    return Response.json({ homework: hw });
  } catch (err) {
    return Response.json({ error: "فشل تحديث الواجب" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    await sql`DELETE FROM homework WHERE id = ${params.id}`;
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: "فشل حذف الواجب" }, { status: 500 });
  }
}
