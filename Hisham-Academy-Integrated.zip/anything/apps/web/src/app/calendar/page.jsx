"use client";
import React, { useState, useEffect } from "react";
import { useStore } from "@/utils/store";
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Users,
  FileText,
  BookOpen,
} from "lucide-react";
import { motion } from "motion/react";

export default function CalendarPage() {
  const { exams, homework, fetchData } = useStore();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [schedule, setSchedule] = useState([]);

  useEffect(() => {
    fetchData();
    // Load schedule from localStorage
    const savedSchedule = localStorage.getItem("schedule");
    if (savedSchedule) {
      setSchedule(JSON.parse(savedSchedule));
    }
  }, []);

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    // Add empty cells for days before month starts
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    // Add days of month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    return days;
  };

  const getEventsForDate = (date) => {
    if (!date) return [];
    const dateStr = date.toISOString().split("T")[0];
    const events = [];

    // Add exams
    exams.forEach((exam) => {
      if (exam.date && exam.date.startsWith(dateStr)) {
        events.push({
          type: "exam",
          title: exam.title,
          subject: exam.subject,
          time: exam.date,
          icon: FileText,
          color: "blue",
        });
      }
    });

    // Add homework due dates
    homework.forEach((hw) => {
      if (hw.dueDate && hw.dueDate === dateStr) {
        events.push({
          type: "homework",
          title: hw.title,
          subject: hw.subject,
          time: hw.dueDate,
          icon: BookOpen,
          color: "purple",
        });
      }
    });

    // Add schedule sessions for this day
    const dayName = [
      "الأحد",
      "الاثنين",
      "الثلاثاء",
      "الأربعاء",
      "الخميس",
      "الجمعة",
      "السبت",
    ][date.getDay()];
    schedule.forEach((session) => {
      if (session.day === dayName) {
        events.push({
          type: "session",
          title: session.name,
          subject: session.subject,
          time: session.time,
          location: session.location,
          icon: Users,
          color: "green",
        });
      }
    });

    return events;
  };

  const hasEvents = (date) => {
    return getEventsForDate(date).length > 0;
  };

  const isToday = (date) => {
    if (!date) return false;
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  const isSameDay = (date1, date2) => {
    if (!date1 || !date2) return false;
    return (
      date1.getDate() === date2.getDate() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getFullYear() === date2.getFullYear()
    );
  };

  const previousMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() - 1),
    );
  };

  const nextMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() + 1),
    );
  };

  const days = getDaysInMonth(currentDate);
  const monthName = currentDate.toLocaleDateString("ar-EG", {
    month: "long",
    year: "numeric",
  });
  const weekDays = [
    "الأحد",
    "الاثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت",
  ];

  const selectedEvents = selectedDate ? getEventsForDate(selectedDate) : [];

  const colorClasses = {
    blue: {
      bg: "bg-blue-100 dark:bg-blue-900/30",
      text: "text-blue-600 dark:text-blue-400",
      border: "border-blue-200 dark:border-blue-800",
    },
    purple: {
      bg: "bg-purple-100 dark:bg-purple-900/30",
      text: "text-purple-600 dark:text-purple-400",
      border: "border-purple-200 dark:border-purple-800",
    },
    green: {
      bg: "bg-green-100 dark:bg-green-900/30",
      text: "text-green-600 dark:text-green-400",
      border: "border-green-200 dark:border-green-800",
    },
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg">
              <CalendarIcon className="text-white" size={24} />
            </div>
            التقويم
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            عرض الحصص والامتحانات والواجبات
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6">
          {/* Month Navigation */}
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={nextMonth}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <ChevronLeft
                size={20}
                className="text-gray-600 dark:text-gray-400"
              />
            </button>
            <h2 className="text-xl font-bold text-gray-800 dark:text-white">
              {monthName}
            </h2>
            <button
              onClick={previousMonth}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <ChevronRight
                size={20}
                className="text-gray-600 dark:text-gray-400"
              />
            </button>
          </div>

          {/* Week Days */}
          <div className="grid grid-cols-7 gap-2 mb-2">
            {weekDays.map((day) => (
              <div
                key={day}
                className="text-center text-sm font-medium text-gray-500 dark:text-gray-400 py-2"
              >
                {day.slice(0, 3)}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2">
            {days.map((date, index) => {
              const events = date ? getEventsForDate(date) : [];
              const today = isToday(date);
              const selected = isSameDay(date, selectedDate);

              return (
                <motion.button
                  key={index}
                  whileHover={date ? { scale: 1.05 } : {}}
                  whileTap={date ? { scale: 0.95 } : {}}
                  onClick={() => date && setSelectedDate(date)}
                  disabled={!date}
                  className={`
                    aspect-square p-2 rounded-xl transition-all relative
                    ${!date ? "invisible" : ""}
                    ${today ? "bg-blue-600 text-white font-bold shadow-lg" : ""}
                    ${selected && !today ? "bg-blue-100 dark:bg-blue-900/30 border-2 border-blue-500" : ""}
                    ${!today && !selected ? "hover:bg-gray-100 dark:hover:bg-gray-700" : ""}
                    ${!today && !selected ? "text-gray-800 dark:text-white" : ""}
                  `}
                >
                  {date && (
                    <>
                      <span className="text-sm">{date.getDate()}</span>
                      {events.length > 0 && (
                        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
                          {events.slice(0, 3).map((event, i) => (
                            <div
                              key={i}
                              className={`w-1 h-1 rounded-full ${
                                event.color === "blue"
                                  ? "bg-blue-500"
                                  : event.color === "purple"
                                    ? "bg-purple-500"
                                    : "bg-green-500"
                              } ${today ? "bg-white" : ""}`}
                            />
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-4 mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                امتحانات
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                واجبات
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                حصص
              </span>
            </div>
          </div>
        </div>

        {/* Events Sidebar */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">
            {selectedDate
              ? selectedDate.toLocaleDateString("ar-EG", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })
              : "اختر يوم"}
          </h3>

          {selectedEvents.length > 0 ? (
            <div className="space-y-3">
              {selectedEvents.map((event, index) => {
                const colors = colorClasses[event.color];
                const Icon = event.icon;

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-4 rounded-xl border ${colors.bg} ${colors.border}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${colors.bg}`}>
                        <Icon size={18} className={colors.text} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className={`font-bold ${colors.text} mb-1`}>
                          {event.title}
                        </h4>
                        {event.subject && (
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                            {event.subject}
                          </p>
                        )}
                        <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                          {event.time && (
                            <span className="flex items-center gap-1">
                              <Clock size={12} />
                              {event.time}
                            </span>
                          )}
                          {event.location && <span>• {event.location}</span>}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <CalendarIcon className="mx-auto text-gray-400 mb-3" size={48} />
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                {selectedDate
                  ? "لا توجد فعاليات في هذا اليوم"
                  : "اختر يوم لعرض الفعاليات"}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
