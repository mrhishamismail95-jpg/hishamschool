"use client";
import React, { useState, useEffect } from "react";
import { useStore } from "@/utils/store";
import {
  BookOpen,
  Plus,
  Calendar,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Trash2,
  Edit,
  Search,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

export default function HomeworkPage() {
  const {
    homework,
    students,
    fetchData,
    addHomework,
    updateHomework,
    deleteHomework,
  } = useStore();
  const [showModal, setShowModal] = useState(false);
  const [editingHomework, setEditingHomework] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterGroup, setFilterGroup] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    group: "",
    grade: "",
    dueDate: "",
    subject: "",
  });

  useEffect(() => {
    fetchData();
  }, []);

  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title || !formData.dueDate) {
      toast.error("من فضلك أدخل العنوان والموعد النهائي");
      return;
    }

    try {
      if (editingHomework) {
        await updateHomework({ ...editingHomework, ...formData });
        toast.success("تم تحديث الواجب بنجاح");
      } else {
        await addHomework({
          ...formData,
          submissions: [],
        });
        toast.success("تم إضافة الواجب بنجاح");
      }
      setShowModal(false);
      setEditingHomework(null);
      setFormData({
        title: "",
        description: "",
        group: "",
        grade: "",
        dueDate: "",
        subject: "",
      });
    } catch (error) {
      toast.error("حدث خطأ أثناء حفظ الواجب");
      console.error(error);
    }
  };

  const handleEdit = (hw) => {
    setEditingHomework(hw);
    setFormData({
      title: hw.title,
      description: hw.description || "",
      group: hw.group || "",
      grade: hw.grade || "",
      dueDate: hw.dueDate,
      subject: hw.subject || "",
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (confirm("هل أنت متأكد من حذف هذا الواجب؟")) {
      try {
        await deleteHomework(id);
        toast.success("تم حذف الواجب");
      } catch (error) {
        toast.error("حدث خطأ أثناء الحذف");
        console.error(error);
      }
    }
  };

  const toggleSubmission = async (homeworkId, studentId) => {
    const hw = homework.find((h) => h.id === homeworkId);
    if (!hw) return;

    const submissions = hw.submissions || [];
    const hasSubmitted = submissions.some((s) => s.studentId === studentId);

    const updatedSubmissions = hasSubmitted
      ? submissions.filter((s) => s.studentId !== studentId)
      : [...submissions, { studentId, submittedAt: new Date().toISOString() }];

    try {
      await updateHomework({ ...hw, submissions: updatedSubmissions });
      toast.success(hasSubmitted ? "تم إلغاء التسليم" : "تم تسجيل التسليم");
    } catch (error) {
      toast.error("حدث خطأ");
      console.error(error);
    }
  };

  const getHomeworkStats = (hw) => {
    const targetStudents = students.filter((s) => {
      if (hw.group && s.group !== hw.group) return false;
      if (hw.grade && s.grade !== hw.grade) return false;
      return true;
    });
    const submitted = (hw.submissions || []).length;
    const total = targetStudents.length;
    return {
      submitted,
      total,
      percentage: total > 0 ? Math.round((submitted / total) * 100) : 0,
    };
  };

  const isOverdue = (dueDate) => {
    return new Date(dueDate) < new Date();
  };

  const filteredHomework = homework.filter((hw) => {
    const matchesSearch =
      hw.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hw.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGroup = filterGroup === "all" || hw.group === filterGroup;
    const stats = getHomeworkStats(hw);
    const matchesStatus =
      filterStatus === "all" ||
      (filterStatus === "completed" &&
        stats.submitted === stats.total &&
        stats.total > 0) ||
      (filterStatus === "pending" && stats.submitted < stats.total) ||
      (filterStatus === "overdue" &&
        isOverdue(hw.dueDate) &&
        stats.submitted < stats.total);
    return matchesSearch && matchesGroup && matchesStatus;
  });

  const sortedHomework = [...filteredHomework].sort(
    (a, b) => new Date(a.dueDate) - new Date(b.dueDate),
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
              <BookOpen className="text-white" size={24} />
            </div>
            الواجبات
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            إدارة ومتابعة واجبات الطلاب
          </p>
        </div>
        <button
          onClick={() => {
            setEditingHomework(null);
            setFormData({
              title: "",
              description: "",
              group: "",
              grade: "",
              dueDate: "",
              subject: "",
            });
            setShowModal(true);
          }}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:shadow-lg transition-all duration-200 font-medium"
        >
          <Plus size={20} />
          إضافة واجب جديد
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                إجمالي الواجبات
              </p>
              <p className="text-3xl font-bold text-gray-800 dark:text-white mt-1">
                {homework.length}
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center">
              <BookOpen
                className="text-purple-600 dark:text-purple-400"
                size={24}
              />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                واجبات نشطة
              </p>
              <p className="text-3xl font-bold text-gray-800 dark:text-white mt-1">
                {homework.filter((hw) => !isOverdue(hw.dueDate)).length}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
              <Clock className="text-blue-600 dark:text-blue-400" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                واجبات متأخرة
              </p>
              <p className="text-3xl font-bold text-gray-800 dark:text-white mt-1">
                {
                  homework.filter((hw) => {
                    const stats = getHomeworkStats(hw);
                    return (
                      isOverdue(hw.dueDate) && stats.submitted < stats.total
                    );
                  }).length
                }
              </p>
            </div>
            <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center">
              <XCircle className="text-red-600 dark:text-red-400" size={24} />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                واجبات مكتملة
              </p>
              <p className="text-3xl font-bold text-gray-800 dark:text-white mt-1">
                {
                  homework.filter((hw) => {
                    const stats = getHomeworkStats(hw);
                    return stats.submitted === stats.total && stats.total > 0;
                  }).length
                }
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
              <CheckCircle2
                className="text-green-600 dark:text-green-400"
                size={24}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-200 dark:border-gray-700">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              size={20}
            />
            <input
              type="text"
              placeholder="بحث في الواجبات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <select
            value={filterGroup}
            onChange={(e) => setFilterGroup(e.target.value)}
            className="px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="all">كل المجموعات</option>
            {groups.map((group) => (
              <option key={group} value={group}>
                {group}
              </option>
            ))}
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="all">كل الحالات</option>
            <option value="pending">قيد الانتظار</option>
            <option value="completed">مكتملة</option>
            <option value="overdue">متأخرة</option>
          </select>
        </div>
      </div>

      {/* Homework List */}
      <div className="space-y-4">
        <AnimatePresence>
          {sortedHomework.map((hw) => {
            const stats = getHomeworkStats(hw);
            const overdue = isOverdue(hw.dueDate);
            const targetStudents = students.filter((s) => {
              if (hw.group && s.group !== hw.group) return false;
              if (hw.grade && s.grade !== hw.grade) return false;
              return true;
            });

            return (
              <motion.div
                key={hw.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold text-gray-800 dark:text-white">
                          {hw.title}
                        </h3>
                        {overdue && stats.submitted < stats.total && (
                          <span className="px-3 py-1 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 text-xs font-medium rounded-full">
                            متأخر
                          </span>
                        )}
                        {stats.submitted === stats.total && stats.total > 0 && (
                          <span className="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 text-xs font-medium rounded-full">
                            مكتمل
                          </span>
                        )}
                      </div>
                      {hw.description && (
                        <p className="text-gray-600 dark:text-gray-400 mb-3">
                          {hw.description}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-3 text-sm">
                        {hw.subject && (
                          <span className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                            <BookOpen size={16} />
                            {hw.subject}
                          </span>
                        )}
                        {hw.group && (
                          <span className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                            <Users size={16} />
                            {hw.group}
                          </span>
                        )}
                        <span className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                          <Calendar size={16} />
                          {new Date(hw.dueDate).toLocaleDateString("ar-EG")}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEdit(hw)}
                        className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-colors"
                      >
                        <Edit size={18} />
                      </button>
                      <button
                        onClick={() => handleDelete(hw.id)}
                        className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        التسليم: {stats.submitted} من {stats.total}
                      </span>
                      <span className="text-sm font-bold text-gray-800 dark:text-white">
                        {stats.percentage}%
                      </span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
                        style={{ width: `${stats.percentage}%` }}
                      />
                    </div>
                  </div>

                  {/* Students List */}
                  {targetStudents.length > 0 && (
                    <details className="group">
                      <summary className="cursor-pointer text-sm font-medium text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 list-none flex items-center gap-2">
                        <span>عرض الطلاب ({targetStudents.length})</span>
                        <span className="group-open:rotate-180 transition-transform">
                          ▼
                        </span>
                      </summary>
                      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                        {targetStudents.map((student) => {
                          const hasSubmitted = (hw.submissions || []).some(
                            (s) => s.studentId === student.id,
                          );
                          return (
                            <div
                              key={student.id}
                              onClick={() =>
                                toggleSubmission(hw.id, student.id)
                              }
                              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                                hasSubmitted
                                  ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800"
                                  : "bg-gray-50 dark:bg-gray-900 border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-700"
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  {hasSubmitted ? (
                                    <CheckCircle2
                                      className="text-green-600 dark:text-green-400"
                                      size={18}
                                    />
                                  ) : (
                                    <XCircle
                                      className="text-gray-400"
                                      size={18}
                                    />
                                  )}
                                  <span className="text-sm font-medium text-gray-800 dark:text-white">
                                    {student.name}
                                  </span>
                                </div>
                                <span className="text-xs text-gray-500 dark:text-gray-400">
                                  {student.code}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </details>
                  )}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {sortedHomework.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="mx-auto text-gray-400 mb-4" size={48} />
            <p className="text-gray-500 dark:text-gray-400">لا توجد واجبات</p>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 w-full max-w-lg border border-gray-200 dark:border-gray-700"
            >
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
                {editingHomework ? "تعديل الواجب" : "إضافة واجب جديد"}
              </h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    عنوان الواجب *
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    الوصف
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      المادة
                    </label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) =>
                        setFormData({ ...formData, subject: e.target.value })
                      }
                      className="w-full px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      المجموعة
                    </label>
                    <select
                      value={formData.group}
                      onChange={(e) =>
                        setFormData({ ...formData, group: e.target.value })
                      }
                      className="w-full px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="">الكل</option>
                      {groups.map((group) => (
                        <option key={group} value={group}>
                          {group}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    الموعد النهائي *
                  </label>
                  <input
                    type="date"
                    value={formData.dueDate}
                    onChange={(e) =>
                      setFormData({ ...formData, dueDate: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    required
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:shadow-lg transition-all duration-200 font-medium"
                  >
                    {editingHomework ? "تحديث" : "إضافة"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-6 py-3 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-xl hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors font-medium"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
