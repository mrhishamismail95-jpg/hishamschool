import React from "react";
import {
  CheckCircle2,
  XCircle,
  Clock,
  Download,
  Users,
  ChevronDown,
  ChevronUp,
  Search,
  Calendar,
  History,
  X,
  BookOpen,
  DollarSign,
  Hash,
  AlertTriangle,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useStore } from "@/utils/store";
import { toast } from "sonner";

// ─── Session History Modal ────────────────────────────────────────────────────
function SessionHistoryModal({ student, attendance, onClose }) {
  const records = attendance
    .filter((a) => a.studentId === student.id)
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  const pkg = Number(student.sessionPackage) || 8;
  const sessionsUsed = records.filter(
    (r) => r.status === "present" || r.status === "late",
  ).length;
  const remaining = Math.max(0, pkg - sessionsUsed);

  const statusMap = {
    present: {
      label: "حاضر",
      cls: "bg-green-100 dark:bg-green-900/30 text-green-600",
    },
    late: {
      label: "متأخر",
      cls: "bg-orange-100 dark:bg-orange-900/30 text-orange-500",
    },
    absent: {
      label: "غائب",
      cls: "bg-red-100 dark:bg-red-900/30 text-red-500",
    },
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 16 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-3xl shadow-2xl overflow-hidden max-h-[88vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-2xl flex items-center justify-center font-bold text-lg">
              {student.name?.[0]}
            </div>
            <div>
              <h3 className="font-bold text-gray-800 dark:text-white text-lg leading-tight">
                {student.name}
              </h3>
              <p className="text-xs text-gray-400 font-mono">
                {student.code} · {student.grade}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-all"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Session Stats */}
        <div className="mx-6 mb-4 grid grid-cols-3 gap-3">
          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-2xl p-3 text-center">
            <p className="text-xl font-bold text-blue-600">{sessionsUsed}</p>
            <p className="text-xs text-blue-400 mt-0.5">حصص مستخدمة</p>
          </div>
          <div
            className={`rounded-2xl p-3 text-center ${remaining === 0 ? "bg-red-50 dark:bg-red-900/20" : remaining <= 2 ? "bg-orange-50 dark:bg-orange-900/20" : "bg-green-50 dark:bg-green-900/20"}`}
          >
            <p
              className={`text-xl font-bold ${remaining === 0 ? "text-red-500" : remaining <= 2 ? "text-orange-500" : "text-green-600"}`}
            >
              {remaining}
            </p>
            <p
              className={`text-xs mt-0.5 ${remaining === 0 ? "text-red-400" : remaining <= 2 ? "text-orange-400" : "text-green-400"}`}
            >
              حصص متبقية
            </p>
          </div>
          <div className="bg-gray-50 dark:bg-gray-900/50 rounded-2xl p-3 text-center">
            <p className="text-xl font-bold text-gray-700 dark:text-gray-300">
              {pkg}
            </p>
            <p className="text-xs text-gray-400 mt-0.5">الباقة الكاملة</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mx-6 mb-5">
          <div className="h-2.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{
                width: `${Math.min(100, (sessionsUsed / pkg) * 100)}%`,
              }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className={`h-full rounded-full ${remaining === 0 ? "bg-red-400" : remaining <= 2 ? "bg-orange-400" : "bg-green-500"}`}
            />
          </div>
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>0</span>
            <span>{pkg} حصة</span>
          </div>
        </div>

        {/* Session Log */}
        <div className="px-6 pb-1 flex items-center justify-between">
          <h4 className="text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
            <History size={15} />
            سجل الحصص ({records.length})
          </h4>
        </div>

        <div className="overflow-y-auto px-6 pb-6 mt-3 space-y-2 flex-1">
          {records.length === 0 ? (
            <div className="py-12 text-center text-gray-400">
              <Calendar size={32} className="mx-auto mb-2 opacity-40" />
              <p className="text-sm">لا يوجد سجل حصص بعد</p>
            </div>
          ) : (
            records.map((rec, idx) => {
              const dateObj = new Date(rec.date);
              const isCountable =
                rec.status === "present" || rec.status === "late";
              // Session number (counting from oldest)
              const sessionNum = isCountable
                ? records
                    .filter(
                      (r) => r.status === "present" || r.status === "late",
                    )
                    .sort((a, b) => new Date(a.date) - new Date(b.date))
                    .findIndex((r) => r.id === rec.id) + 1
                : null;

              return (
                <motion.div
                  key={rec.id || idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.03 }}
                  className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-xl"
                >
                  {/* Session number badge */}
                  <div className="w-8 h-8 rounded-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center text-xs font-bold text-gray-500 flex-shrink-0">
                    {isCountable ? sessionNum : "—"}
                  </div>

                  {/* Date */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-gray-800 dark:text-white">
                      {dateObj.toLocaleDateString("ar-EG", {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                    <p className="text-xs text-gray-400">
                      {dateObj.toLocaleDateString("ar-EG")}
                    </p>
                  </div>

                  {/* Status badge */}
                  <span
                    className={`px-2.5 py-1 rounded-full text-xs font-bold flex-shrink-0 ${statusMap[rec.status]?.cls}`}
                  >
                    {statusMap[rec.status]?.label}
                  </span>
                </motion.div>
              );
            })
          )}
        </div>

        {/* Warning if ending soon */}
        {remaining > 0 && remaining <= 2 && (
          <div className="mx-6 mb-5 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-xl flex items-center gap-2 text-orange-600">
            <AlertTriangle size={16} />
            <p className="text-xs font-medium">
              تنبيه: متبقي {remaining} {remaining === 1 ? "حصة" : "حصتين"} فقط —
              يحتاج تجديد قريباً
            </p>
          </div>
        )}
        {remaining === 0 && (
          <div className="mx-6 mb-5 p-3 bg-red-50 dark:bg-red-900/20 rounded-xl flex items-center gap-2 text-red-600">
            <XCircle size={16} />
            <p className="text-xs font-bold">انتهت الحصص — يجب التجديد</p>
          </div>
        )}
      </motion.div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function Attendance() {
  const { students, attendance, markAttendance, fetchData } = useStore();
  const [selectedGroup, setSelectedGroup] = React.useState("الكل");
  const [search, setSearch] = React.useState("");
  const [date, setDate] = React.useState(
    new Date().toISOString().split("T")[0],
  );
  const [collapsedGroups, setCollapsedGroups] = React.useState({});
  const [historyStudent, setHistoryStudent] = React.useState(null);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const allGroups = [
    "الكل",
    ...new Set(students.map((s) => s.group).filter(Boolean)),
  ];

  const filteredStudents = students.filter((s) => {
    const matchGroup = selectedGroup === "الكل" || s.group === selectedGroup;
    const matchSearch =
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.code?.toLowerCase().includes(search.toLowerCase());
    return matchGroup && matchSearch;
  });

  const groupedStudents = React.useMemo(() => {
    const groups = {};
    filteredStudents.forEach((student) => {
      const group = student.group || "بدون مجموعة";
      if (!groups[group]) groups[group] = [];
      groups[group].push(student);
    });
    return groups;
  }, [filteredStudents]);

  // All attendance records for this student (used for session count)
  const getStudentAttendance = (studentId) =>
    attendance.filter((a) => a.studentId === studentId);

  const getSessionsUsed = (studentId) =>
    getStudentAttendance(studentId).filter(
      (a) => a.status === "present" || a.status === "late",
    ).length;

  // Status for the currently selected date
  const getStatusOnDate = (studentId) => {
    return attendance.find(
      (a) => a.studentId === studentId && a.date.startsWith(date),
    )?.status;
  };

  const handleMark = async (student, status) => {
    try {
      await markAttendance({
        studentId: student.id,
        status,
        date,
        studentName: student.name,
      });
      const labels = { present: "حاضر ✅", late: "متأخر ⏱️", absent: "غائب ❌" };
      toast.success(`${student.name} — ${labels[status]}`);
    } catch {
      toast.error("حدث خطأ في التسجيل");
    }
  };

  const toggleGroup = (group) =>
    setCollapsedGroups((prev) => ({ ...prev, [group]: !prev[group] }));

  // ── Stats for selected date ──
  const todayRecords = attendance.filter((a) => a.date.startsWith(date));
  const presentToday = todayRecords.filter(
    (a) => a.status === "present",
  ).length;
  const lateToday = todayRecords.filter((a) => a.status === "late").length;
  const absentToday = todayRecords.filter((a) => a.status === "absent").length;
  const notMarked = students.length - todayRecords.length;

  const selectedDateLabel = new Date(date + "T12:00:00").toLocaleDateString(
    "ar-EG",
    {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    },
  );

  // ── Export ──
  const exportReport = () => {
    const rows = [
      [
        "الكود",
        "الاسم",
        "المجموعة",
        "الصف",
        "الحصص المستخدمة",
        "الحصص المتبقية",
        "الحالة",
        "التاريخ",
      ],
      ...students.map((s) => {
        const pkg = Number(s.sessionPackage) || 8;
        const used = getSessionsUsed(s.id);
        const remaining = Math.max(0, pkg - used);
        const status = getStatusOnDate(s.id);
        const statusLabel =
          status === "present"
            ? "حاضر"
            : status === "late"
              ? "متأخر"
              : status === "absent"
                ? "غائب"
                : "لم يُسجَّل";
        return [
          s.code,
          s.name,
          s.group,
          s.grade,
          used,
          remaining,
          statusLabel,
          date,
        ];
      }),
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `تقرير_تحضير_${date}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            تحضير الطلاب
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            كل حصة تُسجَّل بتاريخها وتُحتسب من رصيد الطالب تلقائياً
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="px-4 py-2.5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <button
            onClick={exportReport}
            className="flex items-center gap-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 px-4 py-2.5 rounded-xl text-gray-600 dark:text-gray-300 hover:bg-gray-50 transition-all text-sm font-medium"
          >
            <Download size={17} /> تصدير
          </button>
        </div>
      </div>

      {/* ── Date Banner ── */}
      <div className="bg-gradient-to-l from-blue-600 to-blue-700 text-white rounded-2xl px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Calendar size={22} className="opacity-80" />
          <div>
            <p className="font-bold text-lg leading-tight">
              {selectedDateLabel}
            </p>
            <p className="text-blue-200 text-xs mt-0.5">حصة بتاريخ {date}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="text-center">
            <p className="text-2xl font-bold">{presentToday + lateToday}</p>
            <p className="text-blue-200 text-xs">حضروا</p>
          </div>
          <div className="w-px h-8 bg-blue-500" />
          <div className="text-center">
            <p className="text-2xl font-bold">{absentToday}</p>
            <p className="text-blue-200 text-xs">غابوا</p>
          </div>
          <div className="w-px h-8 bg-blue-500" />
          <div className="text-center">
            <p className="text-2xl font-bold">{notMarked}</p>
            <p className="text-blue-200 text-xs">لم يُسجَّلوا</p>
          </div>
        </div>
      </div>

      {/* ── Quick Stats ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            label: "إجمالي الطلاب",
            value: students.length,
            cls: "bg-blue-50 dark:bg-blue-900/20 text-blue-600",
            icon: Users,
          },
          {
            label: "حاضرون ✅",
            value: presentToday,
            cls: "bg-green-50 dark:bg-green-900/20 text-green-600",
            icon: CheckCircle2,
          },
          {
            label: "متأخرون ⏱️",
            value: lateToday,
            cls: "bg-orange-50 dark:bg-orange-900/20 text-orange-500",
            icon: Clock,
          },
          {
            label: "غائبون ❌",
            value: absentToday,
            cls: "bg-red-50 dark:bg-red-900/20 text-red-500",
            icon: XCircle,
          },
        ].map(({ label, value, cls, icon: Icon }) => (
          <div
            key={label}
            className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl p-4 flex items-center gap-3"
          >
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${cls}`}
            >
              <Icon size={19} />
            </div>
            <div>
              <p className="text-xs text-gray-400">{label}</p>
              <p className="text-xl font-bold text-gray-800 dark:text-white">
                {value}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Filters ── */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
            size={17}
          />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم أو الكود..."
            className="w-full pr-10 pl-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 flex-wrap">
          {allGroups.map((g) => (
            <button
              key={g}
              onClick={() => setSelectedGroup(g)}
              className={`px-4 py-2 rounded-xl whitespace-nowrap text-xs font-bold transition-all ${
                selectedGroup === g
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 dark:bg-gray-700 text-gray-500 hover:bg-gray-200"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      {/* ── Grouped Tables ── */}
      {Object.keys(groupedStudents).length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 p-20 text-center">
          <Users size={40} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">لا يوجد طلاب</p>
        </div>
      ) : (
        Object.entries(groupedStudents).map(([groupName, groupStudents]) => {
          const isCollapsed = collapsedGroups[groupName];
          const presentCount = groupStudents.filter((s) => {
            const st = getStatusOnDate(s.id);
            return st === "present" || st === "late";
          }).length;
          const notMarkedCount = groupStudents.filter(
            (s) => !getStatusOnDate(s.id),
          ).length;

          return (
            <motion.div
              key={groupName}
              layout
              className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden shadow-sm"
            >
              {/* Group Header */}
              <button
                onClick={() => toggleGroup(groupName)}
                className="w-full p-5 flex items-center justify-between text-right hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-all border-b border-gray-100 dark:border-gray-700"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-xl flex items-center justify-center">
                    <Users size={20} />
                  </div>
                  <div className="text-right">
                    <h3 className="font-bold text-gray-800 dark:text-white">
                      {groupName}
                    </h3>
                    <p className="text-xs text-gray-500">
                      {groupStudents.length} طالب ·{" "}
                      <span className="text-green-600 font-medium">
                        {presentCount} حضروا
                      </span>
                      {notMarkedCount > 0 && (
                        <span className="text-orange-500 font-medium">
                          {" "}
                          · {notMarkedCount} لم يُسجَّلوا
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex gap-1">
                    <span className="bg-green-100 dark:bg-green-900/30 text-green-600 text-xs font-bold px-2 py-1 rounded-lg">
                      {presentCount}✓
                    </span>
                    <span className="bg-gray-100 dark:bg-gray-700 text-gray-500 text-xs font-bold px-2 py-1 rounded-lg">
                      {groupStudents.length}
                    </span>
                  </div>
                  {isCollapsed ? (
                    <ChevronDown size={18} className="text-gray-400" />
                  ) : (
                    <ChevronUp size={18} className="text-gray-400" />
                  )}
                </div>
              </button>

              <AnimatePresence>
                {!isCollapsed && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.22 }}
                    className="overflow-hidden"
                  >
                    {/* ── Desktop Table ── */}
                    <div className="hidden md:block overflow-x-auto">
                      <table className="w-full text-right">
                        <thead>
                          <tr className="bg-gray-50/80 dark:bg-gray-900/40 text-xs text-gray-400 border-b border-gray-100 dark:border-gray-700">
                            <th className="px-5 py-3 font-medium">#</th>
                            <th className="px-5 py-3 font-medium">الطالب</th>
                            <th className="px-5 py-3 font-medium">الكود</th>
                            <th className="px-5 py-3 font-medium">الصف</th>
                            <th className="px-5 py-3 font-medium">سجل الحصص</th>
                            <th className="px-5 py-3 font-medium text-center">
                              سعر الحصة
                            </th>
                            <th className="px-5 py-3 font-medium text-center">
                              تحضير هذه الحصة
                            </th>
                            <th className="px-5 py-3 font-medium text-center">
                              الحالة
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                          {groupStudents.map((student, idx) => {
                            const pkg = Number(student.sessionPackage) || 8;
                            const used = getSessionsUsed(student.id);
                            const remaining = Math.max(0, pkg - used);
                            const pricePerSession = student.price
                              ? Math.round(Number(student.price) / pkg)
                              : 0;
                            const status = getStatusOnDate(student.id);
                            const isFinished = remaining === 0;
                            const isLow = remaining > 0 && remaining <= 2;
                            const allRecords = getStudentAttendance(student.id);

                            return (
                              <tr
                                key={student.id}
                                className={`hover:bg-blue-50/30 dark:hover:bg-gray-700/20 transition-all ${isFinished ? "opacity-60" : ""}`}
                              >
                                <td className="px-5 py-4 text-gray-400 text-sm">
                                  {idx + 1}
                                </td>

                                {/* Student */}
                                <td className="px-5 py-4">
                                  <div className="flex items-center gap-3">
                                    <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                                      {student.name?.[0]}
                                    </div>
                                    <div>
                                      <p className="font-bold text-gray-800 dark:text-white text-sm">
                                        {student.name}
                                      </p>
                                      <p className="text-xs text-gray-400">
                                        {student.phone}
                                      </p>
                                    </div>
                                  </div>
                                </td>

                                {/* Code */}
                                <td className="px-5 py-4">
                                  <span className="font-mono text-xs bg-gray-100 dark:bg-gray-700 text-gray-500 px-2 py-1 rounded-lg">
                                    {student.code || "—"}
                                  </span>
                                </td>

                                {/* Grade */}
                                <td className="px-5 py-4 text-sm text-gray-500 dark:text-gray-400">
                                  {student.grade}
                                </td>

                                {/* Session log column */}
                                <td className="px-5 py-4">
                                  <div className="space-y-2">
                                    {/* Progress */}
                                    <div className="flex items-center gap-2">
                                      <div className="h-2 w-24 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                                        <div
                                          className={`h-full rounded-full transition-all ${isFinished ? "bg-red-400" : isLow ? "bg-orange-400" : "bg-green-500"}`}
                                          style={{
                                            width: `${Math.min(100, (used / pkg) * 100)}%`,
                                          }}
                                        />
                                      </div>
                                      <span
                                        className={`text-xs font-bold ${isFinished ? "text-red-500" : isLow ? "text-orange-500" : "text-green-600"}`}
                                      >
                                        {isFinished
                                          ? "انتهت!"
                                          : `${remaining} متبقية`}
                                      </span>
                                    </div>
                                    {/* Counters row */}
                                    <div className="flex items-center gap-2 text-xs text-gray-400">
                                      <span>
                                        {used}/{pkg} حصة
                                      </span>
                                      {allRecords.length > 0 && (
                                        <span className="text-gray-300">·</span>
                                      )}
                                      {/* Mini date dots */}
                                      <div className="flex gap-0.5">
                                        {allRecords.slice(-8).map((r, i) => (
                                          <div
                                            key={i}
                                            title={r.date?.split("T")[0]}
                                            className={`w-2 h-2 rounded-full ${
                                              r.status === "present"
                                                ? "bg-green-400"
                                                : r.status === "late"
                                                  ? "bg-orange-400"
                                                  : "bg-red-300"
                                            }`}
                                          />
                                        ))}
                                        {allRecords.length > 8 && (
                                          <span className="text-gray-300 text-xs">
                                            +{allRecords.length - 8}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    {/* History button */}
                                    <button
                                      onClick={() => setHistoryStudent(student)}
                                      className="flex items-center gap-1 text-xs text-blue-500 hover:text-blue-700 font-medium hover:underline"
                                    >
                                      <History size={12} />
                                      عرض السجل الكامل
                                    </button>
                                  </div>
                                </td>

                                {/* Price per session */}
                                <td className="px-5 py-4 text-center">
                                  <p className="font-bold text-blue-600 text-sm">
                                    {pricePerSession} ج.م
                                  </p>
                                  <p className="text-xs text-gray-400">
                                    من{" "}
                                    {Number(
                                      student.price || 0,
                                    ).toLocaleString()}
                                  </p>
                                </td>

                                {/* Mark attendance */}
                                <td className="px-5 py-4">
                                  <div className="flex items-center justify-center gap-1.5">
                                    <button
                                      onClick={() =>
                                        handleMark(student, "present")
                                      }
                                      title="حاضر"
                                      className={`p-2 rounded-xl transition-all ${status === "present" ? "bg-green-500 text-white shadow-md shadow-green-200" : "bg-green-50 dark:bg-green-900/20 text-green-600 hover:bg-green-100"}`}
                                    >
                                      <CheckCircle2 size={18} />
                                    </button>
                                    <button
                                      onClick={() =>
                                        handleMark(student, "late")
                                      }
                                      title="متأخر"
                                      className={`p-2 rounded-xl transition-all ${status === "late" ? "bg-orange-500 text-white shadow-md shadow-orange-200" : "bg-orange-50 dark:bg-orange-900/20 text-orange-500 hover:bg-orange-100"}`}
                                    >
                                      <Clock size={18} />
                                    </button>
                                    <button
                                      onClick={() =>
                                        handleMark(student, "absent")
                                      }
                                      title="غائب"
                                      className={`p-2 rounded-xl transition-all ${status === "absent" ? "bg-red-500 text-white shadow-md shadow-red-200" : "bg-red-50 dark:bg-red-900/20 text-red-500 hover:bg-red-100"}`}
                                    >
                                      <XCircle size={18} />
                                    </button>
                                  </div>
                                </td>

                                {/* Status badge */}
                                <td className="px-5 py-4 text-center">
                                  {status ? (
                                    <span
                                      className={`px-3 py-1.5 rounded-full text-xs font-bold ${
                                        status === "present"
                                          ? "bg-green-100 dark:bg-green-900/30 text-green-600"
                                          : status === "late"
                                            ? "bg-orange-100 dark:bg-orange-900/30 text-orange-500"
                                            : "bg-red-100 dark:bg-red-900/30 text-red-500"
                                      }`}
                                    >
                                      {status === "present"
                                        ? "✅ حاضر"
                                        : status === "late"
                                          ? "⏱ متأخر"
                                          : "❌ غائب"}
                                    </span>
                                  ) : (
                                    <span className="text-gray-300 text-xs">
                                      لم يُسجَّل
                                    </span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                        <tfoot>
                          <tr className="bg-blue-50/50 dark:bg-blue-900/10 border-t border-blue-100 dark:border-blue-800/30 text-xs">
                            <td
                              colSpan={4}
                              className="px-5 py-3 font-bold text-blue-600"
                            >
                              إجمالي المجموعة
                            </td>
                            <td className="px-5 py-3 text-blue-600 font-medium">
                              متوسط:{" "}
                              {Math.round(
                                groupStudents.reduce(
                                  (a, s) => a + getSessionsUsed(s.id),
                                  0,
                                ) / (groupStudents.length || 1),
                              )}{" "}
                              حصة/طالب
                            </td>
                            <td className="px-5 py-3 text-center text-blue-600 font-bold">
                              {groupStudents.reduce(
                                (a, s) =>
                                  a +
                                  (s.price
                                    ? Math.round(
                                        Number(s.price) /
                                          (Number(s.sessionPackage) || 8),
                                      )
                                    : 0),
                                0,
                              )}{" "}
                              ج.م
                            </td>
                            <td
                              colSpan={2}
                              className="px-5 py-3 text-center text-green-600 font-bold"
                            >
                              {presentCount} / {groupStudents.length} حضروا
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>

                    {/* ── Mobile Cards ── */}
                    <div className="md:hidden p-4 space-y-3">
                      {groupStudents.map((student) => {
                        const pkg = Number(student.sessionPackage) || 8;
                        const used = getSessionsUsed(student.id);
                        const remaining = Math.max(0, pkg - used);
                        const pricePerSession = student.price
                          ? Math.round(Number(student.price) / pkg)
                          : 0;
                        const status = getStatusOnDate(student.id);
                        const isFinished = remaining === 0;
                        const isLow = remaining > 0 && remaining <= 2;

                        const borderCls =
                          status === "present"
                            ? "border-green-200 bg-green-50/50 dark:bg-green-900/10 dark:border-green-800/40"
                            : status === "late"
                              ? "border-orange-200 bg-orange-50/50 dark:bg-orange-900/10 dark:border-orange-800/40"
                              : status === "absent"
                                ? "border-red-200 bg-red-50/50 dark:bg-red-900/10 dark:border-red-800/40"
                                : "border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800";

                        return (
                          <div
                            key={student.id}
                            className={`p-4 rounded-2xl border ${borderCls}`}
                          >
                            {/* Top row */}
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-2.5">
                                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-xl flex items-center justify-center font-bold">
                                  {student.name?.[0]}
                                </div>
                                <div>
                                  <p className="font-bold text-gray-800 dark:text-white text-sm leading-tight">
                                    {student.name}
                                  </p>
                                  <p className="text-xs text-gray-400 font-mono">
                                    {student.code}
                                  </p>
                                </div>
                              </div>
                              {status ? (
                                <span
                                  className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                                    status === "present"
                                      ? "bg-green-100 text-green-600"
                                      : status === "late"
                                        ? "bg-orange-100 text-orange-500"
                                        : "bg-red-100 text-red-500"
                                  }`}
                                >
                                  {status === "present"
                                    ? "✅ حاضر"
                                    : status === "late"
                                      ? "⏱ متأخر"
                                      : "❌ غائب"}
                                </span>
                              ) : (
                                <span className="text-xs text-gray-300">
                                  لم يُسجَّل
                                </span>
                              )}
                            </div>

                            {/* Info */}
                            <div className="flex items-center gap-3 mb-3 text-xs text-gray-500">
                              <span className="flex items-center gap-1">
                                <BookOpen size={11} />
                                {student.grade}
                              </span>
                              <span className="flex items-center gap-1">
                                <DollarSign size={11} />
                                {pricePerSession} ج.م/حصة
                              </span>
                            </div>

                            {/* Session progress */}
                            <div className="mb-1">
                              <div className="flex justify-between text-xs mb-1">
                                <span
                                  className={`font-bold ${isFinished ? "text-red-500" : isLow ? "text-orange-500" : "text-green-600"}`}
                                >
                                  {isFinished
                                    ? "انتهت الحصص!"
                                    : `متبقي ${remaining} حصة`}
                                </span>
                                <span className="text-gray-400">
                                  {used}/{pkg}
                                </span>
                              </div>
                              <div className="h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                                <div
                                  className={`h-full rounded-full ${isFinished ? "bg-red-400" : isLow ? "bg-orange-400" : "bg-green-500"}`}
                                  style={{
                                    width: `${Math.min(100, (used / pkg) * 100)}%`,
                                  }}
                                />
                              </div>
                            </div>

                            {/* History link */}
                            <button
                              onClick={() => setHistoryStudent(student)}
                              className="flex items-center gap-1 text-xs text-blue-500 font-medium mb-3"
                            >
                              <History size={12} /> عرض سجل الحصص بالتواريخ
                            </button>

                            {/* Action buttons */}
                            <div className="grid grid-cols-3 gap-2">
                              {[
                                {
                                  s: "present",
                                  label: "حاضر",
                                  activeCls: "bg-green-500 text-white",
                                  inactiveCls: "bg-green-100 text-green-600",
                                  Icon: CheckCircle2,
                                },
                                {
                                  s: "late",
                                  label: "متأخر",
                                  activeCls: "bg-orange-500 text-white",
                                  inactiveCls: "bg-orange-100 text-orange-500",
                                  Icon: Clock,
                                },
                                {
                                  s: "absent",
                                  label: "غائب",
                                  activeCls: "bg-red-500 text-white",
                                  inactiveCls: "bg-red-100 text-red-500",
                                  Icon: XCircle,
                                },
                              ].map(
                                ({
                                  s,
                                  label,
                                  activeCls,
                                  inactiveCls,
                                  Icon,
                                }) => (
                                  <button
                                    key={s}
                                    onClick={() => handleMark(student, s)}
                                    className={`py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${status === s ? activeCls : inactiveCls}`}
                                  >
                                    <Icon size={14} /> {label}
                                  </button>
                                ),
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })
      )}

      {/* ── Session History Modal ── */}
      <AnimatePresence>
        {historyStudent && (
          <SessionHistoryModal
            student={historyStudent}
            attendance={attendance}
            onClose={() => setHistoryStudent(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
