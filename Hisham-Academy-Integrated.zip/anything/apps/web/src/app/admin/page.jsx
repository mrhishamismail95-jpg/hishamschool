"use client";
import { useState, useEffect } from "react";
import { LoginScreen } from "@/components/admin/LoginScreen";
import { AdminDashboard } from "@/components/admin/AdminDashboard";

const SESSION_KEY = "hisham_admin_v2";

function getSession() {
  if (typeof window === "undefined") return null;
  try {
    return JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
  } catch {
    return null;
  }
}

export default function AdminPage() {
  const [admin, setAdmin] = useState(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    setAdmin(getSession());
    setChecking(false);
  }, []);

  const handleLogin = (adminData) => {
    localStorage.setItem(SESSION_KEY, JSON.stringify(adminData));
    setAdmin(adminData);
  };

  const handleLogout = () => {
    localStorage.removeItem(SESSION_KEY);
    setAdmin(null);
  };

  if (checking) {
    return (
      <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
        <div className="text-center">
          <div
            className="w-12 h-12 border-4 border-amber-400 border-t-transparent rounded-full mx-auto mb-3"
            style={{ animation: "spin .9s linear infinite" }}
          />
          <p className="text-gray-400 text-sm">جاري التحقق...</p>
        </div>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    );
  }

  return admin ? (
    <AdminDashboard admin={admin} onLogout={handleLogout} />
  ) : (
    <LoginScreen onLogin={handleLogin} />
  );
}
