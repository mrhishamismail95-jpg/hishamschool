"use client";
import { useEffect } from "react";

export default function AdminsManagementRedirect() {
  useEffect(() => {
    window.location.replace("/admin");
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div
          className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-3"
          style={{ animation: "spin 0.9s linear infinite" }}
        />
        <p className="text-gray-400 text-sm">جاري التوجيه للوحة الإدارة...</p>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
