"use client";
import React, { useState, useEffect } from "react";
import {
  getTeacherSession,
  setTeacherSession,
  clearTeacherSession,
  findTeacher,
} from "@/utils/teacherAuth";
import { TeacherDashboard } from "@/components/teacher/TeacherDashboard";
import { motion, AnimatePresence } from "motion/react";
import {
  BookOpen,
  Lock,
  Video,
  Send,
  Link2,
  Bell,
  Users,
  CalendarCheck,
  AlignLeft,
  FileText,
  ChevronRight,
  LogOut,
} from "lucide-react";
import { Toaster, toast } from "sonner";
import { useStore } from "@/utils/store";

const WAIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

// ── Teacher Login ─────────────────────────────────────────────────────────────
function TeacherLoginScreen({ onLogin, portalOpen }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(false);
  const [isAdminBypass, setIsAdminBypass] = useState(false);

  useEffect(() => {
    try {
      if (sessionStorage.getItem("admin_session_v1")) setIsAdminBypass(true);
    } catch {}
  }, []);

  const handle = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    // findTeacher is now async — calls /api/academy/auth
    const result = await findTeacher(email.trim(), password);
    if (result && !result.error) {
      setTeacherSession({
        id: result.id,
        email: result.email,
        name: result.name || "المعلم",
        subject: result.subject || "",
        phone: result.phone || "",
        groups: result.groups_assigned || result.groups || "",
        at: new Date().toISOString(),
      });
      onLogin();
    } else {
      setError(result?.error || "البريد أو كلمة المرور غير صحيحة");
    }
    setLoading(false);
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4"
      dir="rtl"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-md"
      >
        {/* Admin bypass */}
        {isAdminBypass && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 bg-[#f7b731] rounded-2xl p-3 flex items-center justify-between"
          >
            <p className="text-[#0a2463] font-bold text-sm">
              🛡️ أنت مدير — دخول مباشر؟
            </p>
            <button
              onClick={() => {
                const adminSession = JSON.parse(
                  sessionStorage.getItem("admin_session_v1") || "{}",
                );
                setTeacherSession({
                  email: "admin@bypass.com",
                  name: adminSession.name || "المدير (عرض المعلم)",
                  subject: "مدير",
                  groups: "all",
                  at: new Date().toISOString(),
                  isAdminBypass: true,
                });
                onLogin();
              }}
              className="px-3 py-1.5 bg-[#0a2463] text-white rounded-xl text-xs font-black hover:bg-[#0d2d7a] transition-all"
            >
              دخول فوري
            </button>
          </motion.div>
        )}

        <div
          className={`bg-white/8 backdrop-blur-xl border rounded-3xl p-8 shadow-2xl ${!portalOpen ? "border-red-500/30" : "border-white/15"}`}
        >
          {!portalOpen && (
            <div className="mb-6 bg-red-500/20 border border-red-500/30 rounded-2xl p-4 text-center">
              <Lock size={24} className="text-red-400 mx-auto mb-2" />
              <p className="text-red-300 font-bold text-sm">
                بوابة المعلم مغلقة مؤقتاً
              </p>
            </div>
          )}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl">
              <BookOpen size={36} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-white">بوابة المعلم</h1>
            <p className="text-purple-300 text-sm mt-1">
              ادخل بالبيانات التي أرسلها إليك المدير
            </p>
          </div>
          <form onSubmit={handle} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-purple-200 mb-2">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="teacher@school.com"
                className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-purple-200 mb-2">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type={show ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
                >
                  {show ? "🙈" : "👁️"}
                </button>
              </div>
            </div>
            {error && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-xl px-4 py-2.5 text-red-300 text-sm">
                {error}
              </div>
            )}
            <button
              type="submit"
              disabled={loading || !portalOpen}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-2xl font-black text-base hover:shadow-xl transition-all disabled:opacity-70 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div
                  className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                  style={{ animation: "spin 0.8s linear infinite" }}
                />
              ) : (
                <>
                  <BookOpen size={20} />
                  دخول بوابة المعلم
                </>
              )}
            </button>
          </form>
          <div className="mt-5 p-4 bg-white/5 rounded-2xl border border-white/10 text-center">
            <p className="text-xs text-gray-400">
              📨 بيانات الدخول تُرسَل من المدير عبر واتساب
              <br />
              <span className="text-purple-300 text-[11px]">
                المعلم الافتراضي: teacher@hishamacademy.online
              </span>
            </p>
          </div>
          <div className="flex justify-center gap-4 mt-4 text-xs">
            <a
              href="/student"
              className="text-blue-400 hover:text-blue-300 underline"
            >
              بوابة الطالب
            </a>
            <a href="/" className="text-gray-400 hover:text-white underline">
              الرئيسية
            </a>
          </div>
        </div>
      </motion.div>
      <Toaster position="top-center" richColors />
      <style
        jsx
        global
      >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// ── Lesson Link Sender ────────────────────────────────────────────────────────
function LessonLinkSender({ teacherSession, students }) {
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [group, setGroup] = useState("all");
  const [sending, setSending] = useState(false);
  const [recentLinks, setRecentLinks] = useState([]);

  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];

  useEffect(() => {
    try {
      const msgs = JSON.parse(
        localStorage.getItem("teacher_messages_v1") || "[]",
      );
      setRecentLinks(msgs.filter((m) => m.type === "lesson_link").slice(0, 5));
    } catch {}
  }, []);

  const sendLink = async () => {
    if (!url.trim()) return;
    setSending(true);
    await new Promise((r) => setTimeout(r, 400));
    const msg = {
      id: Date.now(),
      type: "lesson_link",
      title: title || "رابط الحصة",
      url,
      group,
      sentBy: teacherSession?.name,
      sentAt: new Date().toISOString(),
    };
    try {
      const msgs = JSON.parse(
        localStorage.getItem("teacher_messages_v1") || "[]",
      );
      msgs.unshift(msg);
      localStorage.setItem(
        "teacher_messages_v1",
        JSON.stringify(msgs.slice(0, 50)),
      );
      setRecentLinks(msgs.filter((m) => m.type === "lesson_link").slice(0, 5));
    } catch {}
    toast.success("✅ تم إرسال رابط الحصة!");
    setTitle("");
    setUrl("");
    setSending(false);
  };

  const deleteLink = (id) => {
    try {
      const msgs = JSON.parse(
        localStorage.getItem("teacher_messages_v1") || "[]",
      );
      const updated = msgs.filter((m) => m.id !== id);
      localStorage.setItem("teacher_messages_v1", JSON.stringify(updated));
      setRecentLinks(
        updated.filter((m) => m.type === "lesson_link").slice(0, 5),
      );
    } catch {}
  };

  return (
    <div className="bg-white rounded-2xl p-5 border border-purple-100 shadow-sm">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
          <Video size={20} className="text-purple-600" />
        </div>
        <div>
          <h3 className="font-black text-gray-800">إرسال رابط الحصة</h3>
          <p className="text-xs text-gray-500">أرسل رابط زووم أو ميت للطلاب</p>
        </div>
      </div>
      <div className="space-y-3 mb-4">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="عنوان الحصة (اختياري)"
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm focus:border-purple-400 focus:outline-none"
        />
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://zoom.us/j/... أو أي رابط"
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm focus:border-purple-400 focus:outline-none font-mono"
        />
        <div className="flex gap-2">
          <select
            value={group}
            onChange={(e) => setGroup(e.target.value)}
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-xl text-sm focus:border-purple-400 focus:outline-none"
          >
            <option value="all">كل الطلاب</option>
            {groups.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
          <button
            onClick={sendLink}
            disabled={sending || !url.trim()}
            className="px-5 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-black text-sm transition-all disabled:opacity-60 flex items-center gap-2 flex-shrink-0"
          >
            <Send size={16} /> إرسال
          </button>
        </div>
      </div>
      {recentLinks.length > 0 && (
        <div>
          <p className="text-xs font-bold text-gray-500 mb-2 uppercase tracking-wide">
            آخر الروابط المرسلة
          </p>
          <div className="space-y-2">
            {recentLinks.map((link) => (
              <div
                key={link.id}
                className="flex items-center gap-3 p-3 bg-purple-50 rounded-xl border border-purple-100"
              >
                <Link2 size={15} className="text-purple-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-gray-800 text-xs truncate">
                    {link.title}
                  </p>
                  <p className="text-purple-500 text-[10px] truncate">
                    {link.url}
                  </p>
                  {link.group !== "all" && (
                    <p className="text-gray-400 text-[10px]">{link.group}</p>
                  )}
                </div>
                <button
                  onClick={() => deleteLink(link.id)}
                  className="text-gray-400 hover:text-red-500 text-xs flex-shrink-0"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Teacher Quick Dashboard ───────────────────────────────────────────────────
function TeacherQuickDash({ teacherSession, onLogout }) {
  const { students, attendance, homework, exams, payments, fetchData } =
    useStore();
  const [activeTab, setActiveTab] = useState("home");

  useEffect(() => {
    fetchData();
  }, []);

  const myGroups = teacherSession?.groups
    ? teacherSession.groups
        .split(",")
        .map((g) => g.trim())
        .filter(Boolean)
    : [];
  const myStudents =
    myGroups.length > 0
      ? students.filter((s) => myGroups.includes(s.group))
      : students;
  const todayStr = new Date().toISOString().split("T")[0];
  const todayAtt = attendance.filter(
    (a) =>
      a.date?.startsWith(todayStr) &&
      myStudents.some((s) => s.id === a.studentId),
  );
  const presentToday = todayAtt.filter(
    (a) => a.status === "present" || a.status === "late",
  ).length;
  const absentToday = todayAtt.filter((a) => a.status === "absent").length;
  const pendingHW = homework.filter((hw) => {
    const inMyGroups =
      !hw.group || myGroups.includes(hw.group) || myGroups.length === 0;
    return inMyGroups && (hw.submissions || []).length < myStudents.length;
  });

  const TABS = [
    { key: "home", label: "الرئيسية", icon: "🏠" },
    { key: "students", label: "طلابي", icon: "👨‍🎓" },
    { key: "lesson", label: "رابط الحصة", icon: "📡" },
    { key: "attendance", label: "التحضير", icon: "📅" },
    { key: "pages", label: "الصفحات", icon: "📚" },
  ];

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-gradient-to-l from-purple-900 to-blue-900 px-4 pt-6 pb-16">
        <div className="max-w-2xl mx-auto flex items-start justify-between">
          <div>
            <p className="text-purple-300 text-sm mb-1">بوابة المعلم 📚</p>
            <h1 className="text-2xl font-black text-white">
              {teacherSession?.name || "المعلم"}
            </h1>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              {teacherSession?.subject && (
                <span className="text-xs bg-white/20 text-white px-3 py-1 rounded-full">
                  {teacherSession.subject}
                </span>
              )}
              {myGroups.length > 0 &&
                myGroups.slice(0, 2).map((g) => (
                  <span
                    key={g}
                    className="text-xs bg-purple-400/20 text-purple-200 px-3 py-1 rounded-full"
                  >
                    {g}
                  </span>
                ))}
              {teacherSession?.isAdminBypass && (
                <span className="text-xs bg-[#f7b731]/30 text-[#f7b731] px-3 py-1 rounded-full font-bold">
                  🛡️ عرض المدير
                </span>
              )}
            </div>
          </div>
          <button
            onClick={onLogout}
            className="text-purple-300 text-xs hover:text-white underline flex items-center gap-1"
          >
            <LogOut size={14} />
            خروج
          </button>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 -mt-10 pb-24">
        {/* Stats */}
        <div className="bg-white rounded-3xl shadow-xl p-5 mb-5 border border-gray-100">
          <div className="grid grid-cols-3 gap-4">
            {[
              {
                i: "👨‍🎓",
                v: myStudents.length,
                l: "طلابي",
                c: "text-blue-600",
              },
              {
                i: "✅",
                v: presentToday,
                l: "حضروا اليوم",
                c: "text-green-600",
              },
              { i: "❌", v: absentToday, l: "غابوا اليوم", c: "text-red-500" },
            ].map(({ i, v, l, c }) => (
              <div key={l} className="text-center">
                <div className="text-2xl mb-1">{i}</div>
                <p className={`text-2xl font-black ${c}`}>{v}</p>
                <p className="text-xs text-gray-500">{l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white rounded-2xl p-1 shadow-sm border border-gray-100 mb-5 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex-1 min-w-[56px] py-2.5 rounded-xl font-bold text-[11px] whitespace-nowrap transition-all flex flex-col items-center gap-0.5 ${activeTab === t.key ? "bg-purple-700 text-white shadow-md" : "text-gray-500 hover:bg-gray-50"}`}
            >
              <span>{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-4"
          >
            {activeTab === "home" && (
              <>
                {/* Alerts */}
                {absentToday > 0 && (
                  <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-4 flex items-start gap-3">
                    <span className="text-2xl">⚠️</span>
                    <div>
                      <p className="font-black text-red-700">
                        {absentToday} طالب غائب اليوم
                      </p>
                      <button
                        onClick={() => setActiveTab("attendance")}
                        className="text-red-500 text-xs underline"
                      >
                        راجع التحضير
                      </button>
                    </div>
                  </div>
                )}
                {pendingHW.length > 0 && (
                  <div className="bg-orange-50 border-2 border-orange-200 rounded-2xl p-4 flex items-start gap-3">
                    <span className="text-2xl">📝</span>
                    <div>
                      <p className="font-black text-orange-700">
                        {pendingHW.length} واجب لم يكتمل التسليم
                      </p>
                      <a
                        href="/homework"
                        className="text-orange-500 text-xs underline"
                      >
                        عرض الواجبات
                      </a>
                    </div>
                  </div>
                )}
                <LessonLinkSender
                  teacherSession={teacherSession}
                  students={myStudents}
                />
                {/* Quick actions */}
                <div className="grid grid-cols-2 gap-3">
                  {[
                    {
                      href: "/attendance",
                      label: "تحضير اليوم",
                      icon: "📅",
                      color: "bg-green-500 text-white",
                    },
                    {
                      href: "/homework",
                      label: "الواجبات",
                      icon: "📝",
                      color: "bg-blue-600 text-white",
                    },
                    {
                      href: "/exams",
                      label: "الامتحانات",
                      icon: "📊",
                      color: "bg-purple-600 text-white",
                    },
                    {
                      href: "/students",
                      label: "قائمة الطلاب",
                      icon: "👨‍🎓",
                      color: "bg-[#0a2463] text-white",
                    },
                  ].map(({ href, label, icon, color }) => (
                    <a
                      key={href}
                      href={href}
                      className={`flex items-center gap-3 p-4 ${color} rounded-2xl font-bold text-sm hover:opacity-90 transition-all`}
                    >
                      <span className="text-xl">{icon}</span>
                      {label}
                    </a>
                  ))}
                </div>
              </>
            )}

            {activeTab === "students" && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="p-4 border-b border-gray-100">
                  <h3 className="font-black text-gray-800">
                    طلابي ({myStudents.length} طالب)
                  </h3>
                  {myGroups.length > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      المجموعات: {myGroups.join(" · ")}
                    </p>
                  )}
                </div>
                <div className="divide-y divide-gray-50 max-h-96 overflow-y-auto">
                  {myStudents.map((s) => {
                    const pkg = Number(s.sessionPackage) || 8;
                    const used = attendance.filter(
                      (a) =>
                        a.studentId === s.id &&
                        (a.status === "present" || a.status === "late"),
                    ).length;
                    const rem = Math.max(0, pkg - used);
                    return (
                      <div
                        key={s.id}
                        className="flex items-center gap-3 px-4 py-3"
                      >
                        <div className="w-9 h-9 bg-purple-100 rounded-xl flex items-center justify-center text-purple-700 font-black flex-shrink-0">
                          {s.name?.[0]}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-gray-800 text-sm truncate">
                            {s.name}
                          </p>
                          <p className="text-xs text-gray-400">
                            {s.grade} · {s.code}
                          </p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p
                            className={`text-sm font-black ${rem === 0 ? "text-red-500" : rem <= 2 ? "text-orange-500" : "text-gray-500"}`}
                          >
                            {rem} حصة
                          </p>
                          <p className="text-[10px] text-gray-400">متبقية</p>
                        </div>
                      </div>
                    );
                  })}
                  {myStudents.length === 0 && (
                    <p className="text-center text-gray-400 py-8">
                      لا يوجد طلاب في مجموعاتك
                    </p>
                  )}
                </div>
              </div>
            )}

            {activeTab === "lesson" && (
              <LessonLinkSender
                teacherSession={teacherSession}
                students={myStudents}
              />
            )}

            {activeTab === "attendance" && (
              <div className="space-y-3">
                <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
                  <h3 className="font-black text-gray-800 mb-3">
                    تحضير اليوم —{" "}
                    {new Date().toLocaleDateString("ar-EG", {
                      weekday: "long",
                      day: "numeric",
                      month: "long",
                    })}
                  </h3>
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-green-50 rounded-xl p-3 text-center border border-green-200">
                      <p className="text-2xl font-black text-green-600">
                        {presentToday}
                      </p>
                      <p className="text-xs text-green-700">حضروا</p>
                    </div>
                    <div className="bg-red-50 rounded-xl p-3 text-center border border-red-200">
                      <p className="text-2xl font-black text-red-500">
                        {absentToday}
                      </p>
                      <p className="text-xs text-red-600">غابوا</p>
                    </div>
                  </div>
                  <a
                    href="/attendance"
                    className="w-full flex items-center justify-center gap-2 py-3 bg-[#0a2463] text-white rounded-xl font-bold hover:bg-[#0d2d7a] transition-all"
                  >
                    <CalendarCheck size={18} /> فتح صفحة التحضير الكاملة
                  </a>
                </div>
              </div>
            )}

            {activeTab === "pages" && (
              <div className="space-y-3">
                <p className="font-bold text-gray-600 text-sm">
                  الصفحات المتاحة لك
                </p>
                {[
                  {
                    href: "/attendance",
                    label: "تحضير الطلاب",
                    desc: "سجّل الحضور يومياً",
                    icon: "📅",
                    color: "bg-green-500",
                  },
                  {
                    href: "/homework",
                    label: "الواجبات",
                    desc: "إضافة وإدارة الواجبات",
                    icon: "📝",
                    color: "bg-blue-600",
                  },
                  {
                    href: "/exams",
                    label: "الامتحانات",
                    desc: "إدارة الاختبارات والدرجات",
                    icon: "📊",
                    color: "bg-purple-600",
                  },
                  {
                    href: "/students",
                    label: "قائمة الطلاب",
                    desc: "عرض بيانات الطلاب",
                    icon: "👨‍🎓",
                    color: "bg-[#0a2463]",
                  },
                  {
                    href: "/schedule",
                    label: "الجدول الدراسي",
                    desc: "جدول المجموعات",
                    icon: "📆",
                    color: "bg-teal-600",
                  },
                  {
                    href: "/notifications",
                    label: "الإشعارات",
                    desc: "تنبيهات ومتابعة",
                    icon: "🔔",
                    color: "bg-orange-500",
                  },
                ].map(({ href, label, desc, icon, color }) => (
                  <a
                    key={href}
                    href={href}
                    className="flex items-center gap-4 p-4 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all"
                  >
                    <div
                      className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center flex-shrink-0`}
                    >
                      <span className="text-xl">{icon}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-black text-gray-800">{label}</p>
                      <p className="text-xs text-gray-500">{desc}</p>
                    </div>
                    <ChevronRight size={18} className="text-gray-400" />
                  </a>
                ))}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
      <Toaster position="top-center" richColors />
      <style
        jsx
        global
      >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function TeacherPage() {
  const { students } = useStore();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [teacherSession, setSession] = useState(null);
  const [checking, setChecking] = useState(true);
  const [portalOpen, setPortalOpen] = useState(true);
  const [useNewDash, setUseNewDash] = useState(false);

  useEffect(() => {
    // Fetch portal status from DB settings
    fetch("/api/academy/settings")
      .then((r) => r.json())
      .then((data) => {
        setPortalOpen(data.settings?.portal_teacher !== "false");
      })
      .catch(() => {});
    const session = getTeacherSession();
    if (session) {
      setIsLoggedIn(true);
      setSession(session);
      setUseNewDash(true);
    }
    setChecking(false);
  }, []);

  const handleLogin = () => {
    const session = getTeacherSession();
    setSession(session);
    setIsLoggedIn(true);
    setUseNewDash(true);
  };

  const handleLogout = () => {
    clearTeacherSession();
    setIsLoggedIn(false);
    setSession(null);
    setUseNewDash(false);
  };

  if (checking)
    return (
      <div className="min-h-screen bg-purple-900 flex items-center justify-center">
        <div
          className="w-10 h-10 border-4 border-purple-300 border-t-transparent rounded-full"
          style={{ animation: "spin 0.8s linear infinite" }}
        />
        <style
          jsx
          global
        >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );

  if (isLoggedIn) {
    // Use quick teacher dash (new) or full dashboard (existing)
    if (useNewDash)
      return (
        <TeacherQuickDash
          teacherSession={teacherSession}
          onLogout={handleLogout}
        />
      );
    return <TeacherDashboard onLogout={handleLogout} />;
  }
  return <TeacherLoginScreen onLogin={handleLogin} portalOpen={portalOpen} />;
}
