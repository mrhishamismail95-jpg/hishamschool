import React from "react";
import {
  Calendar,
  Clock,
  Users,
  Plus,
  Edit2,
  Trash2,
  X,
  BookOpen,
  MapPin,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useStore } from "@/utils/store";
import { toast } from "sonner";

const DAYS = [
  "السبت",
  "الأحد",
  "الاثنين",
  "الثلاثاء",
  "الأربعاء",
  "الخميس",
  "الجمعة",
];

const GRADE_LEVELS = {
  ابتدائي: [
    "الأول الابتدائي",
    "الثاني الابتدائي",
    "الثالث الابتدائي",
    "الرابع الابتدائي",
    "الخامس الابتدائي",
    "السادس الابتدائي",
  ],
  إعدادي: ["الأول الإعدادي", "الثاني الإعدادي", "الثالث الإعدادي"],
  ثانوي: ["الأول الثانوي", "الثاني الثانوي", "الثالث الثانوي"],
  "لغات ابتدائي": [
    "الأول الابتدائي لغات",
    "الثاني الابتدائي لغات",
    "الثالث الابتدائي لغات",
    "الرابع الابتدائي لغات",
    "الخامس الابتدائي لغات",
    "السادس الابتدائي لغات",
  ],
  "لغات إعدادي": [
    "الأول الإعدادي لغات",
    "الثاني الإعدادي لغات",
    "الثالث الإعدادي لغات",
  ],
  "لغات ثانوي": [
    "الأول الثانوي لغات",
    "الثاني الثانوي لغات",
    "الثالث الثانوي لغات",
  ],
};

const EMPTY_FORM = {
  name: "",
  day: "",
  time: "",
  grade: "",
  subject: "",
  location: "",
  notes: "",
};

// Modal Component
function ScheduleModal({ isOpen, onClose, schedule = null, onSave }) {
  const [formData, setFormData] = React.useState(EMPTY_FORM);
  const [selectedCategory, setSelectedCategory] = React.useState("");

  React.useEffect(() => {
    if (schedule) {
      setFormData({ ...EMPTY_FORM, ...schedule });
      for (const [cat, grades] of Object.entries(GRADE_LEVELS)) {
        if (grades.includes(schedule.grade)) {
          setSelectedCategory(cat);
          break;
        }
      }
    } else {
      setFormData(EMPTY_FORM);
      setSelectedCategory("");
    }
  }, [schedule, isOpen]);

  const set = (key, value) =>
    setFormData((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  const currentGrades = selectedCategory ? GRADE_LEVELS[selectedCategory] : [];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative w-full max-w-xl bg-white dark:bg-gray-800 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
          >
            <div className="flex items-center justify-between p-7 pb-5 border-b border-gray-100 dark:border-gray-700">
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white">
                {schedule ? "تعديل الحصة" : "إضافة حصة جديدة"}
              </h3>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-all"
              >
                <X size={22} className="text-gray-500" />
              </button>
            </div>

            <form
              onSubmit={handleSubmit}
              className="overflow-y-auto px-7 pb-7 space-y-5"
            >
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  اسم المجموعة *
                </label>
                <input
                  required
                  value={formData.name}
                  onChange={(e) => set("name", e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="مثال: مجموعة السبت الصباحية"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    اليوم *
                  </label>
                  <select
                    required
                    value={formData.day}
                    onChange={(e) => set("day", e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="">اختر اليوم</option>
                    {DAYS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    الوقت *
                  </label>
                  <input
                    required
                    type="time"
                    value={formData.time}
                    onChange={(e) => set("time", e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  المرحلة الدراسية *
                </label>
                <div className="flex flex-wrap gap-2">
                  {Object.keys(GRADE_LEVELS).map((cat) => (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => {
                        setSelectedCategory(cat);
                        set("grade", "");
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedCategory === cat ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-gray-700 text-gray-500 hover:bg-gray-200"}`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {selectedCategory && (
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    الصف الدراسي *
                  </label>
                  <select
                    required
                    value={formData.grade}
                    onChange={(e) => set("grade", e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="">اختر الصف</option>
                    {currentGrades.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  المادة
                </label>
                <input
                  value={formData.subject}
                  onChange={(e) => set("subject", e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="مثال: الرياضيات"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  المكان
                </label>
                <input
                  value={formData.location}
                  onChange={(e) => set("location", e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="مثال: قاعة A — الدور الثاني"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  ملاحظات
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => set("notes", e.target.value)}
                  rows={2}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                  placeholder="أي ملاحظات إضافية..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-blue-200 dark:shadow-none"
              >
                {schedule ? "حفظ التغييرات" : "إضافة الحصة"}
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

// Main Page
export default function Schedule() {
  const { students } = useStore();
  const [schedules, setSchedules] = React.useState([]);
  const [isModalOpen, setModalOpen] = React.useState(false);
  const [editingSchedule, setEditingSchedule] = React.useState(null);
  const [selectedDay, setSelectedDay] = React.useState("الكل");

  // Load from localStorage
  React.useEffect(() => {
    const saved = localStorage.getItem("schedule");
    if (saved) {
      try {
        setSchedules(JSON.parse(saved));
      } catch {}
    }
  }, []);

  // Save to localStorage
  React.useEffect(() => {
    localStorage.setItem("schedule", JSON.stringify(schedules));
  }, [schedules]);

  const handleSave = (data) => {
    if (editingSchedule) {
      setSchedules((prev) =>
        prev.map((s) =>
          s.id === editingSchedule.id ? { ...data, id: s.id } : s,
        ),
      );
      toast.success("تم تحديث الحصة ✅");
    } else {
      setSchedules((prev) => [...prev, { ...data, id: Date.now() }]);
      toast.success("تم إضافة الحصة بنجاح 🎉");
    }
    setEditingSchedule(null);
  };

  const handleEdit = (schedule) => {
    setEditingSchedule(schedule);
    setModalOpen(true);
  };

  const handleAdd = () => {
    setEditingSchedule(null);
    setModalOpen(true);
  };

  const handleDelete = (id) => {
    if (window.confirm("هل أنت متأكد من حذف هذه الحصة؟")) {
      setSchedules((prev) => prev.filter((s) => s.id !== id));
      toast.info("تم حذف الحصة");
    }
  };

  const allDays = ["الكل", ...DAYS];
  const filteredSchedules =
    selectedDay === "الكل"
      ? schedules
      : schedules.filter((s) => s.day === selectedDay);

  // Group by day
  const groupedByDay = React.useMemo(() => {
    const groups = {};
    filteredSchedules.forEach((s) => {
      if (!groups[s.day]) groups[s.day] = [];
      groups[s.day].push(s);
    });
    // Sort each day's schedules by time
    Object.keys(groups).forEach((day) => {
      groups[day].sort((a, b) => a.time.localeCompare(b.time));
    });
    return groups;
  }, [filteredSchedules]);

  // Sort days
  const sortedDays = Object.keys(groupedByDay).sort(
    (a, b) => DAYS.indexOf(a) - DAYS.indexOf(b),
  );

  // Count students per schedule
  const getStudentCount = (scheduleName) => {
    return students.filter((s) => s.group === scheduleName).length;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            جدول المجموعات
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            نظّم أوقات الحصص والمجموعات الأسبوعية
          </p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl transition-all shadow-lg shadow-blue-200 dark:shadow-none font-bold"
        >
          <Plus size={20} />
          إضافة حصة جديدة
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          {
            label: "إجمالي الحصص",
            value: schedules.length,
            color: "text-blue-600",
            bg: "bg-blue-50 dark:bg-blue-900/20",
          },
          {
            label: "أيام التدريس",
            value: new Set(schedules.map((s) => s.day)).size,
            color: "text-green-600",
            bg: "bg-green-50 dark:bg-green-900/20",
          },
          {
            label: "المجموعات النشطة",
            value: schedules.length,
            color: "text-purple-600",
            bg: "bg-purple-50 dark:bg-purple-900/20",
          },
        ].map(({ label, value, color, bg }) => (
          <div key={label} className={`${bg} rounded-2xl p-4 text-center`}>
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Day Filter */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex gap-2 overflow-x-auto">
        {allDays.map((d) => (
          <button
            key={d}
            onClick={() => setSelectedDay(d)}
            className={`px-4 py-2 rounded-xl whitespace-nowrap text-sm font-bold transition-all ${
              selectedDay === d
                ? "bg-blue-600 text-white"
                : "bg-gray-100 dark:bg-gray-700 text-gray-500 hover:bg-gray-200"
            }`}
          >
            {d}
          </button>
        ))}
      </div>

      {/* Schedule Cards */}
      {schedules.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 p-20 text-center">
          <Calendar size={40} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 font-medium mb-2">لا يوجد جدول حصص بعد</p>
          <p className="text-sm text-gray-400 mb-6">
            ابدأ بإضافة أول حصة في الجدول
          </p>
          <button
            onClick={handleAdd}
            className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-bold"
          >
            <Plus size={18} /> إضافة حصة جديدة
          </button>
        </div>
      ) : filteredSchedules.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 p-16 text-center">
          <Calendar size={36} className="text-gray-300 mx-auto mb-2" />
          <p className="text-gray-500">لا توجد حصص في هذا اليوم</p>
        </div>
      ) : (
        sortedDays.map((day) => (
          <div
            key={day}
            className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden shadow-sm"
          >
            <div className="p-5 bg-gradient-to-l from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-900/10 border-b border-blue-200 dark:border-blue-900/30">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center">
                    <Calendar size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 dark:text-white text-lg">
                      {day}
                    </h3>
                    <p className="text-xs text-blue-600">
                      {groupedByDay[day].length} حصة
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {groupedByDay[day].map((schedule) => {
                const studentCount = getStudentCount(schedule.name);
                return (
                  <motion.div
                    key={schedule.id}
                    layout
                    className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border border-gray-100 dark:border-gray-700 hover:shadow-md transition-all group"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-800 dark:text-white mb-1 leading-tight">
                          {schedule.name}
                        </h4>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <Clock size={12} />
                          <span className="font-mono">{schedule.time}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleEdit(schedule)}
                          className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                        >
                          <Edit2 size={15} />
                        </button>
                        <button
                          onClick={() => handleDelete(schedule.id)}
                          className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      {schedule.grade && (
                        <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
                          <BookOpen size={12} className="text-gray-400" />
                          <span>{schedule.grade}</span>
                        </div>
                      )}
                      {schedule.subject && (
                        <div className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-600 px-2 py-1 rounded-lg inline-block">
                          {schedule.subject}
                        </div>
                      )}
                      {schedule.location && (
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <MapPin size={12} className="text-gray-400" />
                          <span>{schedule.location}</span>
                        </div>
                      )}
                      <div className="pt-2 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs text-gray-500">
                          <Users size={13} className="text-gray-400" />
                          <span className="font-bold text-gray-700 dark:text-gray-300">
                            {studentCount}
                          </span>
                          <span>طالب</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        ))
      )}

      <ScheduleModal
        isOpen={isModalOpen}
        onClose={() => setModalOpen(false)}
        schedule={editingSchedule}
        onSave={handleSave}
      />
    </div>
  );
}
