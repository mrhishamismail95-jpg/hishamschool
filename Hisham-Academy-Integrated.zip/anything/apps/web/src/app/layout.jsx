"use client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import React, { useState, useEffect, useMemo } from "react";
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  Wallet,
  FileText,
  Settings,
  Bell,
  Menu,
  X,
  Calendar,
  BookOpen,
  AlignLeft,
  UserPlus,
  Shield,
  Archive,
  PenTool,
  GraduationCap,
  BarChart2,
  ClipboardList,
  ChevronDown,
  ChevronLeft,
  LogOut,
  Home,
  TrendingUp,
  Star,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Toaster } from "sonner";
import { useStore } from "@/utils/store";
import {
  getCurrentRole,
  getCurrentSession,
  canAccess,
  ROLES,
} from "@/utils/rbac";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

// ── Icon Map ──────────────────────────────────────────────────────────────────
const ICONS = {
  LayoutDashboard,
  Users,
  CalendarCheck,
  Wallet,
  FileText,
  Settings,
  Bell,
  Calendar,
  BookOpen,
  AlignLeft,
  UserPlus,
  Shield,
  Archive,
  PenTool,
  GraduationCap,
  BarChart2,
  ClipboardList,
  Home,
  TrendingUp,
  Star,
};

// ── Smart notification counter ────────────────────────────────────────────────
function useNotifCount() {
  const { students, attendance, payments, homework, fetchData } = useStore();
  const [dismissed, setDismissed] = useState([]);
  useEffect(() => {
    fetchData();
    try {
      setDismissed(
        JSON.parse(localStorage.getItem("dismissed_notifs") || "[]"),
      );
    } catch {}
  }, []);

  return useMemo(() => {
    const today = new Date();
    const thisMonth = today.toISOString().slice(0, 7);
    const todayStr = today.toISOString().split("T")[0];
    let count = 0;
    students.forEach((s) => {
      const pkg = Number(s.sessionPackage) || 8;
      const attended = attendance.filter(
        (a) =>
          a.studentId === s.id &&
          (a.status === "present" || a.status === "late"),
      ).length;
      const rem = Math.max(0, pkg - attended);
      if (rem === 0 && !dismissed.includes(`finished-${s.id}`)) count++;
      else if (rem <= 2 && rem > 0 && !dismissed.includes(`low-${s.id}`))
        count++;
      const hasPaid = payments.some(
        (p) => p.studentId === s.id && p.date?.startsWith(thisMonth),
      );
      if (
        !hasPaid &&
        s.price &&
        !dismissed.includes(`unpaid-${s.id}-${thisMonth}`)
      )
        count++;
      const cutoff = new Date(today);
      cutoff.setDate(cutoff.getDate() - 14);
      const absences = attendance.filter(
        (a) =>
          a.studentId === s.id &&
          a.status === "absent" &&
          new Date(a.date) >= cutoff,
      ).length;
      if (absences >= 3 && !dismissed.includes(`absences-${s.id}`)) count++;
    });
    (homework || []).forEach((hw) => {
      if (hw.dueDate < todayStr) {
        const targets = students.filter(
          (s) => !hw.group || s.group === hw.group,
        );
        const notSub = targets.filter(
          (s) => !(hw.submissions || []).some((sub) => sub.studentId === s.id),
        ).length;
        if (notSub > 0 && !dismissed.includes(`hw-${hw.id}`)) count++;
      }
    });
    return count;
  }, [students, attendance, payments, homework, dismissed]);
}

// ── Collapsible Nav Group ─────────────────────────────────────────────────────
function NavGroup({ group, currentPath, notifCount, defaultOpen }) {
  const [open, setOpen] = useState(defaultOpen || false);
  const Icon = ICONS[group.icon];
  const isActive = group.children?.some((c) => c.href === currentPath);

  useEffect(() => {
    if (isActive) setOpen(true);
  }, [isActive]);

  if (group.single) {
    const GroupIcon = ICONS[group.icon];
    const active = currentPath === group.href;
    return (
      <a
        href={group.href}
        className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${active ? "bg-gradient-to-r from-[#1a3a8a] to-[#0a2463] text-white shadow-lg" : "text-gray-600 hover:bg-blue-50 hover:text-[#0a2463]"}`}
      >
        <div className="relative flex-shrink-0">
          {GroupIcon && <GroupIcon size={19} />}
          {group.href === "/notifications" && notifCount > 0 && (
            <span className="absolute -top-1.5 -left-1.5 min-w-[15px] h-[15px] bg-red-500 rounded-full flex items-center justify-center text-[8px] font-bold text-white px-0.5">
              {notifCount > 9 ? "9+" : notifCount}
            </span>
          )}
        </div>
        <span className="font-semibold text-sm flex-1">{group.label}</span>
        {active && <div className="w-1.5 h-1.5 bg-white/60 rounded-full" />}
      </a>
    );
  }

  return (
    <div>
      <button
        onClick={() => setOpen((v) => !v)}
        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${isActive ? "bg-blue-50 text-[#0a2463]" : "text-gray-600 hover:bg-gray-50 hover:text-gray-800"}`}
      >
        <div className="flex-shrink-0 w-5 flex justify-center">
          {Icon && <Icon size={19} />}
        </div>
        <span className="font-semibold text-sm flex-1 text-right">
          {group.label}
        </span>
        <div
          className={`transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        >
          <ChevronDown size={15} className="text-gray-400" />
        </div>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            style={{ overflow: "hidden" }}
          >
            <div className="mt-1 mr-4 space-y-0.5 border-r-2 border-blue-100 pr-3">
              {group.children.map((child) => {
                const ChildIcon = ICONS[child.icon];
                const active = currentPath === child.href;
                return (
                  <a
                    key={child.href}
                    href={child.href}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${active ? "bg-[#0a2463] text-white font-bold shadow-md" : "text-gray-500 hover:bg-blue-50 hover:text-[#0a2463] font-medium"}`}
                  >
                    {ChildIcon && (
                      <ChildIcon size={15} className="flex-shrink-0" />
                    )}
                    <span>{child.label}</span>
                  </a>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Unauthorized Banner ───────────────────────────────────────────────────────
function UnauthorizedBanner({ role }) {
  const roleLabels = {
    admin: "المدير",
    teacher: "المعلم",
    student: "الطالب",
    parent: "ولي الأمر",
    guest: "زائر",
  };
  const portals = {
    teacher: "/teacher",
    student: "/student",
    parent: "/parent",
    guest: "/admin",
  };
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-xl p-8 max-w-md w-full text-center border border-red-100"
      >
        <div className="w-20 h-20 bg-red-100 rounded-3xl flex items-center justify-center mx-auto mb-5">
          <Shield size={36} className="text-red-500" />
        </div>
        <h2 className="text-2xl font-black text-gray-800 mb-2">
          ليس لديك صلاحية
        </h2>
        <p className="text-gray-500 text-sm mb-6">
          هذه الصفحة مخصصة للمدير فقط.
          <br />
          لا يمكنك الوصول إليها بصفتك{" "}
          <span className="font-bold text-[#0a2463]">
            {roleLabels[role] || "زائر"}
          </span>
          .
        </p>
        <div className="flex flex-col gap-3">
          {portals[role] && (
            <a
              href={portals[role]}
              className="w-full py-3 bg-gradient-to-r from-[#0a2463] to-[#1a3a8a] text-white rounded-2xl font-bold hover:shadow-lg transition-all"
            >
              الذهاب إلى بوابتي
            </a>
          )}
          <button
            onClick={() => window.history.back()}
            className="w-full py-3 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all"
          >
            العودة للخلف
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ── Admin Sidebar Content ─────────────────────────────────────────────────────
function AdminSidebar({ currentPath, notifCount, session }) {
  const ADMIN_GROUPS = [
    {
      key: "dashboard",
      label: "لوحة القيادة",
      icon: "LayoutDashboard",
      href: "/dashboard",
      single: true,
    },
    {
      key: "students",
      label: "الطلاب",
      icon: "Users",
      collapsible: true,
      children: [
        { label: "قائمة الطلاب", href: "/students", icon: "Users" },
        { label: "المجموعات", href: "/groups", icon: "Users" },
        { label: "الحضور والغياب", href: "/attendance", icon: "CalendarCheck" },
        { label: "تسجيل جديد", href: "/", icon: "UserPlus" },
      ],
    },
    {
      key: "teachers",
      label: "المدرسون",
      icon: "BookOpen",
      collapsible: true,
      children: [
        { label: "إدارة المدرسين", href: "/admin", icon: "Shield" },
        { label: "الجداول الدراسية", href: "/schedule", icon: "ClipboardList" },
        { label: "بوابة المعلم", href: "/teacher", icon: "BookOpen" },
      ],
    },
    {
      key: "academic",
      label: "أكاديمي",
      icon: "GraduationCap",
      collapsible: true,
      children: [
        { label: "الواجبات", href: "/homework", icon: "AlignLeft" },
        { label: "الامتحانات", href: "/exams", icon: "FileText" },
        { label: "التقويم", href: "/calendar", icon: "Calendar" },
        { label: "الأرشيف", href: "/archive", icon: "Archive" },
      ],
    },
    {
      key: "finance",
      label: "المالية",
      icon: "Wallet",
      collapsible: true,
      children: [
        { label: "المدفوعات", href: "/finances", icon: "Wallet" },
        { label: "الباقات", href: "/packages", icon: "Star" },
      ],
    },
    {
      key: "settings",
      label: "الإعدادات",
      icon: "Settings",
      collapsible: true,
      children: [
        { label: "الإشعارات", href: "/notifications", icon: "Bell" },
        { label: "إعدادات النظام", href: "/settings", icon: "Settings" },
      ],
    },
  ];

  return (
    <div className="h-full flex flex-col px-3 py-5 overflow-y-auto">
      {/* Logo */}
      <div className="flex items-center gap-3 px-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-[#0a2463] to-[#1a3a8a] rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
          <span className="text-xl font-black text-white">أ</span>
        </div>
        <div className="min-w-0">
          <p className="font-black text-[#0a2463] text-sm leading-tight">
            لوحة الإدارة
          </p>
          <p className="text-[10px] text-gray-400">نظام إدارة الأكاديمية</p>
        </div>
      </div>

      {/* Admin profile badge */}
      <div className="mx-2 mb-5 bg-gradient-to-r from-[#0a2463] to-[#1a3a8a] rounded-2xl p-3 flex items-center gap-3">
        <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center text-white font-black text-base flex-shrink-0">
          {session?.name?.[0] || "م"}
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-white font-bold text-xs truncate">
            {session?.name || "المدير"}
          </p>
          <div className="flex items-center gap-1 mt-0.5">
            <div className="w-1.5 h-1.5 bg-green-400 rounded-full" />
            <span className="text-[10px] text-blue-200">مدير النظام</span>
          </div>
        </div>
        <Shield size={14} className="text-white/60 flex-shrink-0" />
      </div>

      {/* Navigation groups */}
      <nav className="flex-1 space-y-1">
        {ADMIN_GROUPS.map((group) => (
          <NavGroup
            key={group.key}
            group={group}
            currentPath={currentPath}
            notifCount={notifCount}
            defaultOpen={group.children?.some((c) => c.href === currentPath)}
          />
        ))}
      </nav>

      {/* Portals quick links */}
      <div className="mt-4 pt-4 border-t border-gray-100 space-y-1">
        <p className="px-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">
          البوابات
        </p>
        {[
          {
            href: "/teacher",
            label: "بوابة المعلم",
            color: "text-purple-600 bg-purple-50 hover:bg-purple-100",
            icon: BookOpen,
          },
          {
            href: "/student",
            label: "بوابة الطالب",
            color: "text-blue-600 bg-blue-50 hover:bg-blue-100",
            icon: GraduationCap,
          },
          {
            href: "/parent",
            label: "بوابة ولي الأمر",
            color: "text-emerald-600 bg-emerald-50 hover:bg-emerald-100",
            icon: Users,
          },
        ].map(({ href, label, color, icon: Icon }) => (
          <a
            key={href}
            href={href}
            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${color}`}
          >
            <Icon size={15} /> {label}
          </a>
        ))}
      </div>
    </div>
  );
}

// ── AppShell ──────────────────────────────────────────────────────────────────
function AppShell({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPath, setCurrentPath] = useState("");
  const [role, setRole] = useState(ROLES.GUEST);
  const [session, setSession] = useState(null);
  const [mounted, setMounted] = useState(false);
  const notifCount = useNotifCount();

  useEffect(() => {
    setCurrentPath(window.location.pathname);
    const r = getCurrentRole();
    const s = getCurrentSession();
    setRole(r);
    setSession(s);
    setMounted(true);
  }, []);

  // ── Standalone routes (no sidebar) ────────────────────────────────────────
  const standaloneRoutes = [
    "/", // public landing page — no sidebar
    "/register",
    "/admin",
    "/teacher",
    "/student",
    "/parent",
    "/unauthorized",
  ];
  if (!mounted)
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div
          className="w-8 h-8 border-4 border-[#0a2463] border-t-transparent rounded-full"
          style={{ animation: "spin 0.8s linear infinite" }}
        />
      </div>
    );
  if (standaloneRoutes.includes(currentPath)) return <>{children}</>;

  // ── Access control ────────────────────────────────────────────────────────
  const authorized = canAccess(currentPath, role);

  // If no role detected on main routes, treat as admin (backward compat for direct access)
  const effectiveRole =
    role === ROLES.GUEST && !standaloneRoutes.includes(currentPath)
      ? ROLES.ADMIN
      : role;
  const isAuthorized = canAccess(currentPath, effectiveRole);

  return (
    <div className="min-h-screen flex bg-gray-50" dir="rtl">
      {/* Mobile overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 right-0 z-50 w-64 bg-white border-l border-gray-100 shadow-xl transform transition-transform duration-300 lg:translate-x-0 lg:static lg:inset-auto lg:shadow-none ${sidebarOpen ? "translate-x-0" : "translate-x-full"}`}
      >
        <AdminSidebar
          currentPath={currentPath}
          notifCount={notifCount}
          session={session}
        />
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-4 lg:px-6 bg-white border-b border-gray-100 sticky top-0 z-30 shadow-sm">
          {/* Left: hamburger + page title */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-xl transition-all"
            >
              <Menu size={22} />
            </button>
            <div className="hidden lg:block">
              {/* Breadcrumb */}
              <nav className="flex items-center gap-1.5 text-xs text-gray-400">
                <span>الرئيسية</span>
                {currentPath !== "/" && (
                  <>
                    <ChevronLeft size={12} />
                    <span className="text-[#0a2463] font-bold capitalize">
                      {currentPath.replace("/", "")}
                    </span>
                  </>
                )}
              </nav>
            </div>
          </div>

          {/* Right: notifications + profile */}
          <div className="flex items-center gap-2">
            {/* Notif bell */}
            <a
              href="/notifications"
              className="relative p-2.5 text-gray-500 hover:bg-gray-100 rounded-xl transition-all"
            >
              <Bell size={20} />
              {notifCount > 0 && (
                <motion.span
                  key={notifCount}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-red-500 rounded-full border-2 border-white flex items-center justify-center text-[9px] font-bold text-white px-0.5"
                >
                  {notifCount > 9 ? "9+" : notifCount}
                </motion.span>
              )}
            </a>

            {/* Portals quick switch */}
            <div className="hidden md:flex items-center gap-1 bg-gray-100 rounded-xl p-1">
              <a
                href="/teacher"
                className="px-2.5 py-1.5 bg-white rounded-lg text-purple-700 text-xs font-bold hover:shadow-sm transition-all flex items-center gap-1"
              >
                <BookOpen size={12} /> معلم
              </a>
              <a
                href="/student"
                className="px-2.5 py-1.5 text-gray-500 hover:bg-white rounded-lg text-xs font-medium transition-all flex items-center gap-1"
              >
                <GraduationCap size={12} /> طالب
              </a>
              <a
                href="/parent"
                className="px-2.5 py-1.5 text-gray-500 hover:bg-white rounded-lg text-xs font-medium transition-all flex items-center gap-1"
              >
                <Users size={12} /> ولي أمر
              </a>
            </div>

            {/* Profile */}
            <div className="flex items-center gap-2.5 pr-2 border-r border-gray-200">
              <div className="hidden sm:block text-right">
                <p className="text-xs font-bold text-gray-800">
                  {session?.name || "المدير"}
                </p>
                <p className="text-[10px] text-gray-400">مدير النظام</p>
              </div>
              <div className="w-8 h-8 bg-gradient-to-br from-[#0a2463] to-[#1a3a8a] rounded-full flex items-center justify-center text-white font-black text-sm flex-shrink-0">
                {session?.name?.[0] || "م"}
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {isAuthorized ? (
            children
          ) : (
            <UnauthorizedBanner role={effectiveRole} />
          )}
        </main>
      </div>

      <style jsx global>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

export default function RootLayout({ children }) {
  return (
    <QueryClientProvider client={queryClient}>
      <html lang="ar" dir="rtl">
        <head>
          <title>أكاديمي — نظام إدارة الأكاديميات</title>
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link
            rel="preconnect"
            href="https://fonts.gstatic.com"
            crossOrigin="true"
          />
          <link
            href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap"
            rel="stylesheet"
          />
          <style>{`* { font-family: 'Cairo', sans-serif; } body { margin: 0; padding: 0; overflow-x: hidden; }`}</style>
        </head>
        <body>
          <AppShell>{children}</AppShell>
          <Toaster position="top-center" richColors />
        </body>
      </html>
    </QueryClientProvider>
  );
}
