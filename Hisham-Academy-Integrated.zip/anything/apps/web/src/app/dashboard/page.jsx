"use client";
// Admin-only dashboard — moved from "/" to "/dashboard"
import React from "react";
import {
  Users,
  CalendarCheck,
  Wallet,
  UserPlus,
  Zap,
  AlertTriangle,
  ChevronRight,
  XCircle,
} from "lucide-react";
import { motion } from "motion/react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { useStore } from "@/utils/store";

const StatCard = ({ title, value, icon: Icon, sub, gradient, delay, href }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    whileHover={{ y: -4, transition: { duration: 0.2 } }}
    className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg transition-all cursor-pointer"
    onClick={() => href && (window.location.href = href)}
  >
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3 rounded-xl bg-gradient-to-br ${gradient} shadow-md`}>
        <Icon size={22} className="text-white" />
      </div>
      {href && <ChevronRight size={16} className="text-gray-300" />}
    </div>
    <p className="text-gray-500 text-sm mb-1">{title}</p>
    <h3 className="text-3xl font-black text-gray-800">{value}</h3>
    {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
  </motion.div>
);

export default function DashboardPage() {
  const { students, attendance, payments, homework, fetchData } = useStore();
  React.useEffect(() => {
    fetchData();
  }, []);

  const todayStr = new Date().toISOString().split("T")[0];
  const thisMonth = todayStr.slice(0, 7);

  const todayAtt = attendance.filter((a) => a.date?.startsWith(todayStr));
  const presentToday = todayAtt.filter(
    (a) => a.status === "present" || a.status === "late",
  ).length;
  const absentToday = todayAtt.filter((a) => a.status === "absent").length;
  const notMarked = students.length - todayAtt.length;

  const monthPayments = payments.filter((p) => p.date?.startsWith(thisMonth));
  const totalMonthRevenue = monthPayments.reduce(
    (acc, p) => acc + Number(p.amount || 0),
    0,
  );
  const paidCount = new Set(monthPayments.map((p) => p.studentId)).size;
  const unpaidCount = students.length - paidCount;

  const sessionRevenue = students.reduce((acc, s) => {
    const pkg = Number(s.sessionPackage) || 8;
    const attended = attendance.filter(
      (a) =>
        a.studentId === s.id && (a.status === "present" || a.status === "late"),
    ).length;
    const pricePerSession = s.price ? Math.round(Number(s.price) / pkg) : 0;
    return acc + attended * pricePerSession;
  }, 0);

  const monthlyData = React.useMemo(() => {
    const data = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const key = d.toISOString().slice(0, 7);
      const label = d.toLocaleDateString("ar-EG", { month: "short" });
      const revenue = payments
        .filter((p) => p.date?.startsWith(key))
        .reduce((acc, p) => acc + Number(p.amount || 0), 0);
      data.push({ name: label, revenue });
    }
    return data;
  }, [payments]);

  const presentAll = attendance.filter((a) => a.status === "present").length;
  const lateAll = attendance.filter((a) => a.status === "late").length;
  const absentAll = attendance.filter((a) => a.status === "absent").length;
  const pieData = [
    { name: "حاضر", value: presentAll, color: "#10B981" },
    { name: "متأخر", value: lateAll, color: "#F59E0B" },
    { name: "غائب", value: absentAll, color: "#EF4444" },
  ].filter((d) => d.value > 0);

  const groups = [...new Set(students.map((s) => s.group).filter(Boolean))];
  const lowSessions = students.filter((s) => {
    const pkg = Number(s.sessionPackage) || 8;
    const used = attendance.filter(
      (a) =>
        a.studentId === s.id && (a.status === "present" || a.status === "late"),
    ).length;
    return Math.max(0, pkg - used) <= 2;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
      >
        <div>
          <h2 className="text-2xl font-black text-[#0a2463]">
            لوحة القيادة 🏠
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            {new Date().toLocaleDateString("ar-EG", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {lowSessions.length > 0 && (
            <a
              href="/notifications"
              className="flex items-center gap-2 bg-orange-500 text-white px-4 py-2.5 rounded-xl font-bold text-sm hover:bg-orange-600 transition-all"
            >
              <AlertTriangle size={16} /> {lowSessions.length} تنبيه
            </a>
          )}
          <a
            href="/students"
            className="flex items-center gap-2 bg-[#0a2463] text-white px-4 py-2.5 rounded-xl font-bold text-sm hover:bg-[#0d2d7a] transition-all"
          >
            <UserPlus size={16} /> إضافة طالب
          </a>
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="إجمالي الطلاب"
          value={students.length}
          icon={Users}
          sub={`${groups.length} مجموعة`}
          gradient="from-blue-500 to-cyan-500"
          delay={0}
          href="/students"
        />
        <StatCard
          title="حضور اليوم"
          value={presentToday}
          icon={CalendarCheck}
          sub={
            absentToday > 0
              ? `${absentToday} غائب · ${notMarked} لم يُسجَّل`
              : "لا غياب 🎉"
          }
          gradient="from-green-500 to-emerald-500"
          delay={0.1}
          href="/attendance"
        />
        <StatCard
          title="إيرادات الشهر"
          value={`${totalMonthRevenue.toLocaleString()} ج`}
          icon={Wallet}
          sub={`${paidCount} دفعوا · ${unpaidCount} لم يدفعوا`}
          gradient="from-purple-500 to-pink-500"
          delay={0.2}
          href="/finances"
        />
        <StatCard
          title="إيراد الحصص"
          value={`${sessionRevenue.toLocaleString()} ج`}
          icon={Zap}
          sub="إجمالي مكتسَب"
          gradient="from-orange-500 to-red-500"
          delay={0.3}
          href="/finances"
        />
      </div>

      {/* Today Banner */}
      {students.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="bg-gradient-to-l from-[#0a2463] to-[#1a3a8a] text-white rounded-2xl px-6 py-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        >
          <div>
            <p className="text-blue-200 text-sm mb-1">
              تحضير اليوم — {todayStr}
            </p>
            <h3 className="text-xl font-black">
              {todayAtt.length === 0
                ? "لم يتم تسجيل الحضور بعد"
                : `سُجِّل ${todayAtt.length} من ${students.length} طالب`}
            </h3>
          </div>
          <div className="flex items-center gap-6">
            {[
              { l: "حضروا", v: presentToday, c: "text-green-300" },
              { l: "غابوا", v: absentToday, c: "text-red-300" },
              { l: "لم يُسجَّل", v: notMarked, c: "text-yellow-300" },
            ].map(({ l, v, c }) => (
              <div key={l} className="text-center">
                <p className={`text-2xl font-black ${c}`}>{v}</p>
                <p className="text-blue-200 text-xs">{l}</p>
              </div>
            ))}
            <a
              href="/attendance"
              className="hidden md:flex items-center gap-1.5 bg-white/20 hover:bg-white/30 px-4 py-2 rounded-xl text-sm font-bold transition-all"
            >
              <CalendarCheck size={16} /> تحضير الآن
            </a>
          </div>
        </motion.div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"
        >
          <h3 className="text-lg font-black text-gray-800 mb-5 flex items-center gap-2">
            <Wallet size={20} className="text-purple-500" /> الإيرادات الشهرية
          </h3>
          <div className="h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8B5CF6" />
                    <stop offset="100%" stopColor="#EC4899" stopOpacity={0.7} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#F3F4F6"
                />
                <XAxis
                  dataKey="name"
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `${v.toLocaleString()}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1F2937",
                    border: "none",
                    borderRadius: "12px",
                    color: "#fff",
                    direction: "rtl",
                  }}
                  formatter={(v) => [
                    `${Number(v).toLocaleString()} ج.م`,
                    "الإيراد",
                  ]}
                />
                <Bar
                  dataKey="revenue"
                  fill="url(#revGrad)"
                  radius={[8, 8, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"
        >
          <h3 className="text-lg font-black text-gray-800 mb-5">
            توزيع الحضور
          </h3>
          {pieData.length > 0 ? (
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1F2937",
                      border: "none",
                      borderRadius: "12px",
                      color: "#fff",
                      direction: "rtl",
                    }}
                  />
                  <Legend
                    iconType="circle"
                    formatter={(v) => (
                      <span style={{ color: "#6B7280", fontSize: "12px" }}>
                        {v}
                      </span>
                    )}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-[200px] flex items-center justify-center">
              <p className="text-gray-400 text-sm">لا يوجد بيانات حضور بعد</p>
            </div>
          )}
        </motion.div>
      </div>

      {/* Groups + Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"
        >
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-lg font-black text-gray-800">ملخص المجموعات</h3>
            <a
              href="/students"
              className="text-sm text-[#0a2463] hover:underline font-bold"
            >
              عرض الكل
            </a>
          </div>
          {groups.length === 0 ? (
            <div className="py-8 text-center text-gray-400">
              <Users size={32} className="mx-auto mb-2 opacity-30" />
              <p className="text-sm">لا يوجد مجموعات بعد</p>
            </div>
          ) : (
            <div className="space-y-3">
              {groups.map((group) => {
                const gs = students.filter((s) => s.group === group);
                const paid = gs.filter((s) =>
                  payments.some(
                    (p) =>
                      p.studentId === s.id && p.date?.startsWith(thisMonth),
                  ),
                );
                const pct =
                  gs.length > 0
                    ? Math.round((paid.length / gs.length) * 100)
                    : 0;
                return (
                  <div
                    key={group}
                    className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl"
                  >
                    <div className="w-9 h-9 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Users size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-800 text-sm truncate">
                        {group}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${pct >= 80 ? "bg-green-500" : pct >= 50 ? "bg-orange-400" : "bg-red-400"}`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-400">
                          {paid.length}/{gs.length}
                        </span>
                      </div>
                    </div>
                    <span
                      className={`text-sm font-black ${pct >= 80 ? "text-green-600" : pct >= 50 ? "text-orange-500" : "text-red-500"}`}
                    >
                      {pct}%
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"
        >
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-lg font-black text-gray-800">⚠️ تنبيهات مهمة</h3>
            <a
              href="/notifications"
              className="text-sm text-[#0a2463] hover:underline font-bold"
            >
              كل الإشعارات
            </a>
          </div>
          {lowSessions.length === 0 && unpaidCount === 0 ? (
            <div className="py-8 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <CalendarCheck size={22} className="text-green-600" />
              </div>
              <p className="text-sm text-gray-500">كل شيء على ما يرام 🎉</p>
            </div>
          ) : (
            <div className="space-y-3">
              {lowSessions.slice(0, 4).map((s) => {
                const pkg = Number(s.sessionPackage) || 8;
                const used = attendance.filter(
                  (a) =>
                    a.studentId === s.id &&
                    (a.status === "present" || a.status === "late"),
                ).length;
                const rem = Math.max(0, pkg - used);
                return (
                  <div
                    key={s.id}
                    className={`flex items-center gap-3 p-3 rounded-xl border ${rem === 0 ? "bg-red-50 border-red-100" : "bg-orange-50 border-orange-100"}`}
                  >
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0 ${rem === 0 ? "bg-red-500" : "bg-orange-400"}`}
                    >
                      {s.name?.[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-gray-800 truncate">
                        {s.name}
                      </p>
                      <p
                        className={`text-xs ${rem === 0 ? "text-red-500" : "text-orange-500"}`}
                      >
                        {rem === 0 ? "انتهت الحصص!" : `متبقي ${rem} حصة`}
                      </p>
                    </div>
                  </div>
                );
              })}
              {unpaidCount > 0 && (
                <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-xl border border-purple-100">
                  <div className="w-9 h-9 bg-purple-100 rounded-xl flex items-center justify-center">
                    <Wallet size={18} className="text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-sm text-gray-800">
                      {unpaidCount} طالب لم يدفعوا
                    </p>
                    <p className="text-xs text-purple-500">هذا الشهر</p>
                  </div>
                  <a
                    href="/finances"
                    className="text-xs text-purple-600 font-bold hover:underline"
                  >
                    متابعة
                  </a>
                </div>
              )}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
