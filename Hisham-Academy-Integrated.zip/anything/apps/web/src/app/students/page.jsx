import React from "react";
import {
  Search,
  Plus,
  Filter,
  MessageCircle,
  GraduationCap,
  Users as UsersIcon,
  X,
  Hash,
  DollarSign,
  BookOpen,
  Phone,
  Edit2,
  Trash2,
  FileText,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useStore } from "@/utils/store";
import { toast } from "sonner";

const GRADE_LEVELS = {
  ابتدائي: [
    "الأول الابتدائي",
    "الثاني الابتدائي",
    "الثالث الابتدائي",
    "الرابع الابتدائي",
    "الخامس الابتدائي",
    "السادس الابتدائي",
  ],
  إعدادي: ["الأول الإعدادي", "الثاني الإعدادي", "الثالث الإعدادي"],
  ثانوي: ["الأول الثانوي", "الثاني الثانوي", "الثالث الثانوي"],
  "لغات ابتدائي": [
    "الأول الابتدائي لغات",
    "الثاني الابتدائي لغات",
    "الثالث الابتدائي لغات",
    "الرابع الابتدائي لغات",
    "الخامس الابتدائي لغات",
    "السادس الابتدائي لغات",
  ],
  "لغات إعدادي": [
    "الأول الإعدادي لغات",
    "الثاني الإعدادي لغات",
    "الثالث الإعدادي لغات",
  ],
  "لغات ثانوي": [
    "الأول الثانوي لغات",
    "الثاني الثانوي لغات",
    "الثالث الثانوي لغات",
  ],
};

const SESSION_PACKAGES = [8, 12];

const EMPTY_FORM = {
  name: "",
  phone: "",
  parentPhone: "",
  grade: "",
  group: "",
  price: "",
  sessionPackage: "8",
  notes: "",
};

const StudentModal = ({ isOpen, onClose, student = null }) => {
  const addStudent = useStore((state) => state.addStudent);
  const updateStudent = useStore((state) => state.updateStudent);
  const [formData, setFormData] = React.useState(EMPTY_FORM);
  const [selectedCategory, setSelectedCategory] = React.useState("");

  React.useEffect(() => {
    if (student) {
      setFormData({ ...EMPTY_FORM, ...student });
      // Try to find category
      for (const [cat, grades] of Object.entries(GRADE_LEVELS)) {
        if (grades.includes(student.grade)) {
          setSelectedCategory(cat);
          break;
        }
      }
    } else {
      setFormData(EMPTY_FORM);
      setSelectedCategory("");
    }
  }, [student, isOpen]);

  const set = (key, value) =>
    setFormData((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (student) {
        await updateStudent({ ...formData, id: student.id });
        toast.success("تم تحديث بيانات الطالب ✅");
      } else {
        await addStudent(formData);
        toast.success("تم إضافة الطالب بنجاح 🎉");
      }
      onClose();
    } catch {
      toast.error("حدث خطأ ما");
    }
  };

  const currentGrades = selectedCategory ? GRADE_LEVELS[selectedCategory] : [];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative w-full max-w-xl bg-white dark:bg-gray-800 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-7 pb-5">
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white">
                {student ? "تعديل بيانات الطالب" : "إضافة طالب جديد"}
              </h3>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-all"
              >
                <X size={22} className="text-gray-500" />
              </button>
            </div>

            {/* Auto-generated code badge */}
            {!student && (
              <div className="mx-7 mb-4 px-4 py-2.5 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center gap-2">
                <Hash size={16} className="text-blue-500" />
                <p className="text-sm text-blue-600">
                  سيتم إنشاء كود مميز تلقائياً للطالب عند الحفظ
                </p>
              </div>
            )}
            {student?.code && (
              <div className="mx-7 mb-4 px-4 py-2.5 bg-gray-50 dark:bg-gray-900/50 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Hash size={16} className="text-gray-400" />
                  <span className="text-sm text-gray-500">كود الطالب:</span>
                </div>
                <span className="font-mono font-bold text-gray-800 dark:text-white text-sm bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-lg">
                  {student.code}
                </span>
              </div>
            )}

            {/* Form */}
            <form
              onSubmit={handleSubmit}
              className="overflow-y-auto px-7 pb-7 space-y-5"
            >
              {/* Name + Phone */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    اسم الطالب *
                  </label>
                  <input
                    required
                    value={formData.name}
                    onChange={(e) => set("name", e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                    placeholder="مثال: محمد أحمد"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    رقم هاتف الطالب *
                  </label>
                  <input
                    required
                    value={formData.phone}
                    onChange={(e) => set("phone", e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                    placeholder="01xxxxxxxxx"
                  />
                </div>
              </div>

              {/* Parent Phone */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  رقم ولي الأمر
                </label>
                <input
                  value={formData.parentPhone}
                  onChange={(e) => set("parentPhone", e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                  placeholder="01xxxxxxxxx"
                />
              </div>

              {/* Grade Category + Grade */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  المرحلة الدراسية *
                </label>
                <div className="flex flex-wrap gap-2">
                  {Object.keys(GRADE_LEVELS).map((cat) => (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => {
                        setSelectedCategory(cat);
                        set("grade", "");
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedCategory === cat ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-gray-700 text-gray-500 hover:bg-gray-200"}`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {selectedCategory && (
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    الصف الدراسي *
                  </label>
                  <select
                    required
                    value={formData.grade}
                    onChange={(e) => set("grade", e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                  >
                    <option value="">اختر الصف</option>
                    {currentGrades.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Group */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  المجموعة / الكروب
                </label>
                <input
                  value={formData.group}
                  onChange={(e) => set("group", e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                  placeholder="مثال: السبت 4 عصراً — مجموعة أ"
                />
              </div>

              {/* Price + Session Package */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    سعر الباقة (ج.م)
                  </label>
                  <div className="relative">
                    <DollarSign
                      size={16}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                    />
                    <input
                      type="number"
                      min="0"
                      value={formData.price}
                      onChange={(e) => set("price", e.target.value)}
                      className="w-full pr-9 pl-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                      placeholder="800"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    عدد الحصص في الباقة
                  </label>
                  <div className="flex gap-2 h-[52px]">
                    {SESSION_PACKAGES.map((pkg) => (
                      <button
                        type="button"
                        key={pkg}
                        onClick={() => set("sessionPackage", String(pkg))}
                        className={`flex-1 rounded-xl text-sm font-bold transition-all ${String(formData.sessionPackage) === String(pkg) ? "bg-blue-600 text-white shadow-md" : "bg-gray-100 dark:bg-gray-700 text-gray-500 hover:bg-gray-200"}`}
                      >
                        {pkg} حصص
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Price per session display */}
              {formData.price && formData.sessionPackage && (
                <div className="bg-blue-50 dark:bg-blue-900/20 px-4 py-3 rounded-xl flex items-center justify-between">
                  <span className="text-sm text-blue-600">
                    سعر الحصة الواحدة:
                  </span>
                  <span className="font-bold text-blue-700">
                    {Math.round(
                      Number(formData.price) / Number(formData.sessionPackage),
                    )}{" "}
                    ج.م
                  </span>
                </div>
              )}

              {/* Notes */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  ملاحظات
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => set("notes", e.target.value)}
                  rows={2}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all resize-none"
                  placeholder="أي ملاحظات خاصة بالطالب..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-blue-200 dark:shadow-none"
              >
                {student ? "حفظ التغييرات" : "إضافة الطالب الآن"}
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default function Students() {
  const {
    students,
    loading,
    deleteStudent,
    fetchData,
    attendance,
    payments,
    exams,
  } = useStore();
  const [search, setSearch] = React.useState("");
  const [filterGrade, setFilterGrade] = React.useState("الكل");
  const [isModalOpen, setModalOpen] = React.useState(false);
  const [editingStudent, setEditingStudent] = React.useState(null);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const allGrades = [
    "الكل",
    ...new Set(students.map((s) => s.grade).filter(Boolean)),
  ];

  const filteredStudents = students.filter((s) => {
    const matchSearch =
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.phone?.includes(search) ||
      s.code?.toLowerCase().includes(search.toLowerCase());
    const matchGrade = filterGrade === "الكل" || s.grade === filterGrade;
    return matchSearch && matchGrade;
  });

  const handleEdit = (student) => {
    setEditingStudent(student);
    setModalOpen(true);
  };
  const handleAdd = () => {
    setEditingStudent(null);
    setModalOpen(true);
  };
  const handleDelete = async (id) => {
    if (window.confirm("هل أنت متأكد من حذف هذا الطالب؟")) {
      await deleteStudent(id);
      toast.info("تم حذف الطالب");
    }
  };

  const handleGeneratePDF = async (student) => {
    try {
      const studentAttendance = attendance.filter(
        (a) => a.studentId === student.id,
      );
      const studentPayments = payments.filter(
        (p) => p.studentId === student.id,
      );
      const studentExams = exams.filter((e) => e.grade === student.grade);

      const res = await fetch("/api/reports/student-pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          student,
          attendance: studentAttendance,
          payments: studentPayments,
          exams: studentExams,
        }),
      });

      if (!res.ok) throw new Error("فشل إنشاء التقرير");

      const html = await res.text();
      const blob = new Blob([html], { type: "text/html" });
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
      toast.success("تم إنشاء التقرير بنجاح ✅");
    } catch (err) {
      console.error(err);
      toast.error("فشل إنشاء التقرير");
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            إدارة الطلاب
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            {students.length} طالب مسجل في النظام
          </p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl transition-all shadow-lg shadow-blue-200 dark:shadow-none font-bold"
        >
          <Plus size={20} />
          إضافة طالب جديد
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
            size={18}
          />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث باسم الطالب أو الكود أو الهاتف..."
            className="w-full pr-10 pl-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {allGrades.slice(0, 6).map((g) => (
            <button
              key={g}
              onClick={() => setFilterGrade(g)}
              className={`px-3 py-2 rounded-xl whitespace-nowrap text-xs font-bold transition-all ${filterGrade === g ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-gray-700 text-gray-500 hover:bg-gray-200"}`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-3 gap-4">
        {[
          {
            label: "إجمالي الطلاب",
            value: students.length,
            color: "text-blue-600",
            bg: "bg-blue-50 dark:bg-blue-900/20",
          },
          {
            label: "الصفوف المختلفة",
            value: new Set(students.map((s) => s.grade).filter(Boolean)).size,
            color: "text-purple-600",
            bg: "bg-purple-50 dark:bg-purple-900/20",
          },
          {
            label: "المجموعات",
            value: new Set(students.map((s) => s.group).filter(Boolean)).size,
            color: "text-green-600",
            bg: "bg-green-50 dark:bg-green-900/20",
          },
        ].map(({ label, value, color, bg }) => (
          <div key={label} className={`${bg} rounded-2xl p-4 text-center`}>
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Student Cards */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filteredStudents.map((student) => {
            const pricePerSession =
              student.price && student.sessionPackage
                ? Math.round(
                    Number(student.price) / Number(student.sessionPackage),
                  )
                : null;

            return (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                key={student.id}
                className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden hover:shadow-md transition-all group"
              >
                <div className="p-5">
                  {/* Top */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-2xl flex items-center justify-center font-bold text-lg">
                      {student.name?.[0]}
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleEdit(student)}
                        className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(student.id)}
                        className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>

                  {/* Name */}
                  <h3 className="font-bold text-gray-800 dark:text-white mb-0.5">
                    {student.name}
                  </h3>

                  {/* Code badge */}
                  {student.code && (
                    <span className="inline-block font-mono text-xs bg-gray-100 dark:bg-gray-700 text-gray-500 px-2 py-0.5 rounded-md mb-3">
                      {student.code}
                    </span>
                  )}

                  {/* Info */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <GraduationCap size={13} className="text-gray-400" />
                      <span>{student.grade}</span>
                    </div>
                    {student.group && (
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <UsersIcon size={13} className="text-gray-400" />
                        <span className="truncate">{student.group}</span>
                      </div>
                    )}
                    {student.phone && (
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Phone size={13} className="text-gray-400" />
                        <a
                          href={`tel:${student.phone}`}
                          className="hover:text-blue-600 transition-all"
                        >
                          {student.phone}
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Price Info */}
                  {student.price && (
                    <div className="mt-3 p-2.5 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-between">
                      <div className="text-xs">
                        <p className="text-blue-600 font-bold">
                          {Number(student.price).toLocaleString()} ج.م
                        </p>
                        <p className="text-blue-400">
                          {student.sessionPackage} حصص
                        </p>
                      </div>
                      {pricePerSession && (
                        <div className="text-xs text-center">
                          <p className="text-gray-500">الحصة</p>
                          <p className="font-bold text-gray-700 dark:text-gray-300">
                            {pricePerSession} ج.م
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="mt-4 flex items-center gap-2">
                    <a
                      href={`https://wa.me/2${String(student.phone || "").replace(/^0/, "")}?text=${encodeURIComponent(`مرحباً ${student.name}`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl text-xs font-bold transition-all"
                    >
                      <MessageCircle size={15} />
                      واتساب
                    </a>
                    <button
                      onClick={() => handleGeneratePDF(student)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 text-purple-600 rounded-xl text-xs font-bold transition-all"
                      title="تقرير PDF"
                    >
                      <FileText size={15} />
                      تقرير
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {filteredStudents.length === 0 && !loading && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4">
            <UsersIcon size={32} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">
            {students.length === 0
              ? "لا يوجد طلاب بعد"
              : "لا يوجد نتائج مطابقة"}
          </h3>
          <p className="text-gray-500 text-sm max-w-xs">
            {students.length === 0
              ? "ابدأ بإضافة أول طالب في النظام"
              : "جرّب تغيير معايير البحث"}
          </p>
          {students.length === 0 && (
            <button
              onClick={handleAdd}
              className="mt-6 flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-bold"
            >
              <Plus size={18} /> إضافة طالب جديد
            </button>
          )}
        </div>
      )}

      <StudentModal
        isOpen={isModalOpen}
        onClose={() => setModalOpen(false)}
        student={editingStudent}
      />
    </div>
  );
}
