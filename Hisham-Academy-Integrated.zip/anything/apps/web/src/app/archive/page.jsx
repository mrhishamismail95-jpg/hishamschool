"use client";
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Archive,
  FolderOpen,
  Link2,
  Plus,
  Trash2,
  ExternalLink,
  Search,
  FileText,
  Video,
  Image,
  Music,
  Download,
  FolderPlus,
  BookOpen,
  RefreshCw,
  Eye,
  Copy,
  Star,
  Filter,
  ChevronDown,
} from "lucide-react";
import { toast } from "sonner";

// ── Google Drive Folder Embed ─────────────────────────────────────────────────
const STORAGE_KEY = "archive_resources_v1";
const DRIVE_KEY = "archive_drive_folders_v1";

function getResources() {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveResources(res) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(res));
}

function getDriveFolders() {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(DRIVE_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveDriveFolders(f) {
  localStorage.setItem(DRIVE_KEY, JSON.stringify(f));
}

// Convert any Google Drive share link to embed URL
function toEmbedUrl(url) {
  if (!url) return null;
  // Folder: https://drive.google.com/drive/folders/FOLDER_ID
  const folderMatch = url.match(/folders\/([a-zA-Z0-9_-]+)/);
  if (folderMatch) {
    return `https://drive.google.com/embeddedfolderview?id=${folderMatch[1]}#list`;
  }
  // File: https://drive.google.com/file/d/FILE_ID/view
  const fileMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (fileMatch) {
    return `https://drive.google.com/file/d/${fileMatch[1]}/preview`;
  }
  // Direct ID
  if (/^[a-zA-Z0-9_-]{28,}$/.test(url)) {
    return `https://drive.google.com/embeddedfolderview?id=${url}#list`;
  }
  return null;
}

// File type icon
function FileIcon({ type }) {
  const map = {
    video: { Icon: Video, color: "text-red-500 bg-red-50" },
    image: { Icon: Image, color: "text-purple-500 bg-purple-50" },
    audio: { Icon: Music, color: "text-yellow-500 bg-yellow-50" },
    pdf: { Icon: FileText, color: "text-orange-500 bg-orange-50" },
    link: { Icon: Link2, color: "text-blue-500 bg-blue-50" },
  };
  const { Icon, color } = map[type] || {
    Icon: FileText,
    color: "text-gray-500 bg-gray-50",
  };
  return (
    <div
      className={`w-10 h-10 rounded-xl flex items-center justify-center ${color} flex-shrink-0`}
    >
      <Icon size={20} />
    </div>
  );
}

const CATEGORIES = [
  "الكل",
  "رياضيات",
  "لغة عربية",
  "علوم",
  "لغة إنجليزية",
  "فيزياء",
  "كيمياء",
  "أحياء",
  "تاريخ",
  "جغرافيا",
  "أخرى",
];
const FILE_TYPES = ["link", "pdf", "video", "image", "audio"];

// ── Add Resource Modal ────────────────────────────────────────────────────────
function AddResourceModal({ onClose, onAdd }) {
  const [form, setForm] = useState({
    title: "",
    url: "",
    type: "link",
    category: "أخرى",
    description: "",
    starred: false,
  });
  const upd = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const handle = (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.url.trim()) {
      toast.error("العنوان والرابط مطلوبان");
      return;
    }
    onAdd({ ...form, id: Date.now(), addedAt: new Date().toISOString() });
    onClose();
    toast.success("تم إضافة المصدر بنجاح ✅");
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.9 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl"
      >
        <h3 className="text-xl font-bold text-gray-800 mb-5 flex items-center gap-2">
          <Plus size={22} className="text-blue-600" /> إضافة مصدر جديد
        </h3>
        <form onSubmit={handle} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              العنوان *
            </label>
            <input
              value={form.title}
              onChange={(e) => upd("title", e.target.value)}
              placeholder="عنوان المصدر أو الملف"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              الرابط *
            </label>
            <input
              value={form.url}
              onChange={(e) => upd("url", e.target.value)}
              placeholder="https://drive.google.com/..."
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm font-mono"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
                النوع
              </label>
              <select
                value={form.type}
                onChange={(e) => upd("type", e.target.value)}
                className="w-full px-3 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm"
              >
                {FILE_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t === "link"
                      ? "رابط"
                      : t === "pdf"
                        ? "PDF"
                        : t === "video"
                          ? "فيديو"
                          : t === "image"
                            ? "صورة"
                            : "صوت"}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
                التصنيف
              </label>
              <select
                value={form.category}
                onChange={(e) => upd("category", e.target.value)}
                className="w-full px-3 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm"
              >
                {CATEGORIES.filter((c) => c !== "الكل").map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              وصف قصير
            </label>
            <input
              value={form.description}
              onChange={(e) => upd("description", e.target.value)}
              placeholder="وصف اختياري..."
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all"
            >
              إضافة
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200"
            >
              إلغاء
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}

// ── Add Drive Folder Modal ────────────────────────────────────────────────────
function AddDriveModal({ onClose, onAdd }) {
  const [form, setForm] = useState({ name: "", url: "", description: "" });
  const upd = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const handle = (e) => {
    e.preventDefault();
    const embed = toEmbedUrl(form.url);
    if (!form.name.trim() || !embed) {
      toast.error("اسم المجلد ورابط Drive صحيح مطلوبان");
      return;
    }
    onAdd({
      ...form,
      id: Date.now(),
      embed,
      addedAt: new Date().toISOString(),
    });
    onClose();
    toast.success("تم إضافة مجلد Drive ✅");
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.9 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl"
      >
        <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <FolderPlus size={22} className="text-green-600" /> ربط مجلد Google
          Drive
        </h3>
        <p className="text-sm text-gray-500 mb-5">
          اربط مجلد Drive وسيُعرض مباشرة في الأرشيف
        </p>
        <form onSubmit={handle} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              اسم المجلد *
            </label>
            <input
              value={form.name}
              onChange={(e) => upd("name", e.target.value)}
              placeholder="مثال: مواد الثالث الثانوي"
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              رابط المجلد من Google Drive *
            </label>
            <input
              value={form.url}
              onChange={(e) => upd("url", e.target.value)}
              placeholder="https://drive.google.com/drive/folders/..."
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm font-mono"
            />
            <p className="text-xs text-gray-400 mt-1">
              ⚠️ تأكد من ضبط صلاحيات المجلد على "يمكن لأي شخص مشاركة الرابط"
            </p>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              وصف
            </label>
            <input
              value={form.description}
              onChange={(e) => upd("description", e.target.value)}
              placeholder="وصف محتوى المجلد..."
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-sm"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all"
            >
              ربط المجلد
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200"
            >
              إلغاء
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}

// ── Main Archive Page ─────────────────────────────────────────────────────────
export default function ArchivePage() {
  const [resources, setResources] = useState([]);
  const [driveFolders, setDriveFolders] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("الكل");
  const [showAddResource, setShowAddResource] = useState(false);
  const [showAddDrive, setShowAddDrive] = useState(false);
  const [activeTab, setActiveTab] = useState("resources");
  const [previewUrl, setPreviewUrl] = useState(null);
  const [activeDriveFolder, setActiveDriveFolder] = useState(null);

  useEffect(() => {
    setResources(getResources());
    const folders = getDriveFolders();
    setDriveFolders(folders);
    if (folders.length > 0) setActiveDriveFolder(folders[0].id);
  }, []);

  const addResource = (r) => {
    const updated = [r, ...resources];
    setResources(updated);
    saveResources(updated);
  };

  const deleteResource = (id) => {
    const updated = resources.filter((r) => r.id !== id);
    setResources(updated);
    saveResources(updated);
    toast.info("تم حذف المصدر");
  };

  const addDriveFolder = (f) => {
    const updated = [f, ...driveFolders];
    setDriveFolders(updated);
    saveDriveFolders(updated);
    setActiveDriveFolder(f.id);
  };

  const deleteDriveFolder = (id) => {
    const updated = driveFolders.filter((f) => f.id !== id);
    setDriveFolders(updated);
    saveDriveFolders(updated);
    if (activeDriveFolder === id) setActiveDriveFolder(updated[0]?.id || null);
    toast.info("تم حذف المجلد");
  };

  const toggleStar = (id) => {
    const updated = resources.map((r) =>
      r.id === id ? { ...r, starred: !r.starred } : r,
    );
    setResources(updated);
    saveResources(updated);
  };

  const filtered = resources.filter((r) => {
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      r.title.toLowerCase().includes(q) ||
      r.description?.toLowerCase().includes(q) ||
      r.category?.toLowerCase().includes(q);
    const matchCat = category === "الكل" || r.category === category;
    return matchSearch && matchCat;
  });

  const starred = filtered.filter((r) => r.starred);
  const regular = filtered.filter((r) => !r.starred);
  const sortedResources = [...starred, ...regular];

  const activeFolder = driveFolders.find((f) => f.id === activeDriveFolder);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Archive className="text-white" size={24} />
            </div>
            الأرشيف التعليمي
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1 text-sm">
            مكتبة المصادر والمواد التعليمية المرتبطة بـ Google Drive
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setShowAddDrive(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-white dark:bg-gray-800 border-2 border-green-200 dark:border-green-800 text-green-700 dark:text-green-400 rounded-xl font-bold text-sm hover:bg-green-50 transition-all"
          >
            <FolderPlus size={18} /> ربط Drive
          </button>
          <button
            onClick={() => setShowAddResource(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl font-bold text-sm shadow-lg hover:shadow-xl transition-all"
          >
            <Plus size={18} /> إضافة مصدر
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-gray-100 dark:bg-gray-800 p-1.5 rounded-2xl w-fit">
        {[
          { key: "resources", label: `📚 المصادر (${resources.length})` },
          { key: "drive", label: `☁️ Google Drive (${driveFolders.length})` },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === t.key ? "bg-white dark:bg-gray-700 text-gray-800 dark:text-white shadow-md" : "text-gray-500 hover:text-gray-700"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Resources Tab ─────────────────────────────────────────────────── */}
      {activeTab === "resources" && (
        <div className="space-y-5">
          {/* Filters */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4 flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search
                size={18}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="بحث في المصادر..."
                className="w-full pr-10 pl-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {CATEGORIES.map((c) => (
                <button
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${category === c ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200"}`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              {
                label: "إجمالي المصادر",
                val: resources.length,
                color: "text-blue-600",
                bg: "bg-blue-50 dark:bg-blue-900/20",
              },
              {
                label: "مميزة ⭐",
                val: resources.filter((r) => r.starred).length,
                color: "text-yellow-600",
                bg: "bg-yellow-50 dark:bg-yellow-900/20",
              },
              {
                label: "فيديوهات",
                val: resources.filter((r) => r.type === "video").length,
                color: "text-red-600",
                bg: "bg-red-50 dark:bg-red-900/20",
              },
              {
                label: "ملفات PDF",
                val: resources.filter((r) => r.type === "pdf").length,
                color: "text-orange-600",
                bg: "bg-orange-50 dark:bg-orange-900/20",
              },
            ].map((s) => (
              <div key={s.label} className={`${s.bg} rounded-2xl p-4`}>
                <p className={`text-2xl font-bold ${s.color}`}>{s.val}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {s.label}
                </p>
              </div>
            ))}
          </div>

          {/* Resource Cards */}
          {sortedResources.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 py-20 text-center">
              <Archive size={48} className="mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500 font-medium">لا توجد مصادر بعد</p>
              <p className="text-sm text-gray-400 mt-1">
                ابدأ بإضافة أول مصدر تعليمي
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              <AnimatePresence>
                {sortedResources.map((r, i) => (
                  <motion.div
                    key={r.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ delay: i * 0.04 }}
                    className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5 hover:shadow-lg transition-all group"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <FileIcon type={r.type} />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-gray-800 dark:text-white text-sm truncate">
                            {r.title}
                          </h3>
                          {r.description && (
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 truncate">
                              {r.description}
                            </p>
                          )}
                          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                            <span className="text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded-lg font-medium">
                              {r.category}
                            </span>
                            <span className="text-xs text-gray-400">
                              {new Date(r.addedAt).toLocaleDateString("ar-EG")}
                            </span>
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => toggleStar(r.id)}
                        className="p-1.5 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-all flex-shrink-0"
                      >
                        <Star
                          size={16}
                          className={
                            r.starred
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-gray-300"
                          }
                        />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 pt-3 border-t border-gray-100 dark:border-gray-700">
                      <a
                        href={r.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 text-blue-600 rounded-xl text-xs font-bold transition-all"
                      >
                        <ExternalLink size={13} /> فتح
                      </a>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(r.url);
                          toast.success("تم نسخ الرابط");
                        }}
                        className="px-3 py-2 bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 text-gray-500 rounded-xl text-xs font-bold transition-all"
                      >
                        <Copy size={13} />
                      </button>
                      <button
                        onClick={() => deleteResource(r.id)}
                        className="px-3 py-2 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 text-red-500 rounded-xl text-xs font-bold transition-all"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      )}

      {/* ── Google Drive Tab ──────────────────────────────────────────────── */}
      {activeTab === "drive" && (
        <div className="space-y-5">
          {driveFolders.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border-2 border-dashed border-gray-300 dark:border-gray-600 py-24 text-center">
              <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <FolderOpen
                  size={36}
                  className="text-green-600 dark:text-green-400"
                />
              </div>
              <h3 className="text-xl font-bold text-gray-700 dark:text-gray-300 mb-2">
                لم تُربط أي مجلدات بعد
              </h3>
              <p className="text-gray-400 text-sm mb-6">
                ارتبط بمجلد Google Drive وسيُعرض محتواه مباشرة هنا
              </p>
              <button
                onClick={() => setShowAddDrive(true)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg"
              >
                <FolderPlus size={20} /> ربط مجلد Google Drive
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Folder List */}
              <div className="space-y-3">
                <h3 className="font-bold text-gray-700 dark:text-gray-300 text-sm px-1">
                  المجلدات المرتبطة
                </h3>
                {driveFolders.map((f) => (
                  <div
                    key={f.id}
                    onClick={() => setActiveDriveFolder(f.id)}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${activeDriveFolder === f.id ? "border-green-500 bg-green-50 dark:bg-green-900/20" : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-green-300"}`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <FolderOpen
                          size={18}
                          className="text-green-600 flex-shrink-0"
                        />
                        <span className="font-bold text-gray-800 dark:text-white text-sm truncate">
                          {f.name}
                        </span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteDriveFolder(f.id);
                        }}
                        className="p-1 text-gray-300 hover:text-red-500 transition-colors flex-shrink-0"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                    {f.description && (
                      <p className="text-xs text-gray-400 pr-6 truncate">
                        {f.description}
                      </p>
                    )}
                    <p className="text-xs text-gray-300 pr-6 mt-1 font-mono">
                      {new Date(f.addedAt).toLocaleDateString("ar-EG")}
                    </p>
                  </div>
                ))}
                <button
                  onClick={() => setShowAddDrive(true)}
                  className="w-full py-3 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-2xl text-gray-500 hover:border-green-400 hover:text-green-600 transition-all text-sm font-bold flex items-center justify-center gap-2"
                >
                  <FolderPlus size={16} /> إضافة مجلد
                </button>
              </div>

              {/* Drive Embed */}
              <div className="lg:col-span-3">
                {activeFolder ? (
                  <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden shadow-sm">
                    <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
                      <div className="flex items-center gap-3">
                        <FolderOpen size={20} className="text-green-600" />
                        <h3 className="font-bold text-gray-800 dark:text-white">
                          {activeFolder.name}
                        </h3>
                      </div>
                      <a
                        href={activeFolder.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white rounded-xl text-xs font-bold hover:bg-green-700 transition-all"
                      >
                        <ExternalLink size={14} /> فتح في Drive
                      </a>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900">
                      <iframe
                        src={activeFolder.embed}
                        title={activeFolder.name}
                        className="w-full"
                        style={{ height: "560px", border: "none" }}
                        allowFullScreen
                      />
                    </div>
                    <div className="px-5 py-3 bg-amber-50 dark:bg-amber-900/20 border-t border-amber-100 dark:border-amber-900/30">
                      <p className="text-xs text-amber-700 dark:text-amber-400">
                        ⚠️ إذا لم يظهر المجلد: تأكد من ضبط صلاحيات المجلد في
                        Drive على "كل من لديه الرابط يمكنه العرض"
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-gray-50 dark:bg-gray-900 rounded-2xl h-96 flex items-center justify-center">
                    <p className="text-gray-400">اختر مجلداً من القائمة</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modals */}
      <AnimatePresence>
        {showAddResource && (
          <AddResourceModal
            onClose={() => setShowAddResource(false)}
            onAdd={addResource}
          />
        )}
        {showAddDrive && (
          <AddDriveModal
            onClose={() => setShowAddDrive(false)}
            onAdd={addDriveFolder}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
