"use client";
import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  GraduationCap,
  CheckCircle2,
  Send,
  Star,
  Users,
  Award,
  TrendingUp,
  Lock,
  ExternalLink,
  Zap,
  CreditCard,
  Link2,
  Shield,
  Menu,
  X,
} from "lucide-react";
import { getSettings } from "@/utils/portalSettings";

const WAIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);
const TGIcon = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
  </svg>
);

const GRADE_LEVELS = {
  ابتدائي: [
    "الأول الابتدائي",
    "الثاني الابتدائي",
    "الثالث الابتدائي",
    "الرابع الابتدائي",
    "الخامس الابتدائي",
    "السادس الابتدائي",
  ],
  إعدادي: ["الأول الإعدادي", "الثاني الإعدادي", "الثالث الإعدادي"],
  ثانوي: ["الأول الثانوي", "الثاني الثانوي", "الثالث الثانوي"],
  "لغات إعدادي": [
    "الأول الإعدادي لغات",
    "الثاني الإعدادي لغات",
    "الثالث الإعدادي لغات",
  ],
  "لغات ثانوي": [
    "الأول الثانوي لغات",
    "الثاني الثانوي لغات",
    "الثالث الثانوي لغات",
  ],
};

function RegisterForm({ onSuccess, adminPhone }) {
  const [type, setType] = useState("student");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [parentName, setParentName] = useState("");
  const [parentPhone, setParentPhone] = useState("");
  const [parentEmail, setParentEmail] = useState("");
  const [gradeCategory, setGradeCategory] = useState("");
  const [grade, setGrade] = useState("");
  const [subject, setSubject] = useState("");
  const [groupId, setGroupId] = useState("");
  const [packageId, setPackageId] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [groups, setGroups] = useState([]);
  const [packages, setPackages] = useState([]);

  useEffect(() => {
    Promise.all([
      fetch("/api/academy/groups?active=true")
        .then((r) => r.json())
        .catch(() => ({ groups: [] })),
      fetch("/api/academy/packages")
        .then((r) => r.json())
        .catch(() => ({ packages: [] })),
    ]).then(([gRes, pRes]) => {
      setGroups(gRes.groups || []);
      setPackages(pRes.packages || []);
    });
  }, []);

  const inp =
    "w-full px-4 py-3.5 rounded-xl border-2 border-gray-200 bg-white focus:border-[#0a2463] focus:outline-none transition-all text-gray-800 text-sm font-medium";
  const lbl =
    "block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1.5";
  const filteredGroups = grade
    ? groups.filter((g) => !g.grade || g.grade === grade)
    : groups;
  const activePackages = packages.filter((p) => p.active !== false);

  const handle = async (e) => {
    e.preventDefault();
    setError("");
    if (!name.trim() || !phone.trim())
      return setError("الاسم ورقم الهاتف مطلوبان");
    if (type !== "teacher" && !grade)
      return setError("يرجى اختيار الصف الدراسي");
    if (type === "teacher" && !subject.trim())
      return setError("يرجى إدخال المادة");
    setLoading(true);
    try {
      const selectedGroup = groups.find((g) => g.id === Number(groupId));
      const selectedPkg = packages.find((p) => p.id === Number(packageId));
      const res = await fetch("/api/academy/registrations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requestType: type,
          name: name.trim(),
          phone,
          parentName: parentName || null,
          parentPhone: parentPhone || null,
          parentEmail: parentEmail || null,
          gradeCategory,
          grade,
          groupId: groupId ? Number(groupId) : null,
          groupName: selectedGroup?.name || null,
          packageId: packageId ? Number(packageId) : null,
          packageName: selectedPkg?.name || null,
          subject: subject || null,
          notes: notes || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "فشل إرسال الطلب");
      onSuccess(data.code, { type, name, phone, grade });
    } catch (err) {
      setError(err.message || "حدث خطأ — حاول مرة أخرى");
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handle} className="space-y-4">
      {/* Type */}
      <div>
        <p className={lbl}>نوع التسجيل</p>
        <div className="grid grid-cols-3 gap-2">
          {[
            { k: "student", l: "طالب", e: "🎓" },
            { k: "teacher", l: "مدرس", e: "📚" },
            { k: "parent", l: "ولي أمر", e: "👨‍👩‍👧" },
          ].map(({ k, l, e }) => (
            <button
              key={k}
              type="button"
              onClick={() => setType(k)}
              className={`py-3 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition-all ${type === k ? "bg-[#0a2463] text-white shadow-lg" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
            >
              <span className="text-lg">{e}</span>
              {l}
            </button>
          ))}
        </div>
      </div>
      {/* Name */}
      <div>
        <label className={lbl}>
          {type === "teacher"
            ? "اسم المدرس"
            : type === "parent"
              ? "اسم ولي الأمر"
              : "اسم الطالب"}{" "}
          *
        </label>
        <input
          className={inp}
          placeholder="الاسم رباعي كاملاً"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      {/* Phone */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={lbl}>رقم الواتساب *</label>
          <input
            className={inp}
            placeholder="01xxxxxxxxx"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
        {type === "teacher" ? (
          <div>
            <label className={lbl}>المادة *</label>
            <input
              className={inp}
              placeholder="الرياضيات..."
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>
        ) : (
          <div>
            <label className={lbl}>اسم ولي الأمر</label>
            <input
              className={inp}
              placeholder="اسم ولي الأمر"
              value={parentName}
              onChange={(e) => setParentName(e.target.value)}
            />
          </div>
        )}
      </div>
      {/* Parent contact */}
      {type !== "teacher" && (
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={lbl}>هاتف ولي الأمر</label>
            <input
              className={inp}
              placeholder="01xxxxxxxxx"
              type="tel"
              value={parentPhone}
              onChange={(e) => setParentPhone(e.target.value)}
            />
          </div>
          <div>
            <label className={lbl}>بريد ولي الأمر</label>
            <input
              className={inp}
              placeholder="email@..."
              type="email"
              value={parentEmail}
              onChange={(e) => setParentEmail(e.target.value)}
            />
          </div>
        </div>
      )}
      {/* Grade */}
      {type !== "teacher" && (
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={lbl}>المرحلة</label>
            <select
              className={inp}
              value={gradeCategory}
              onChange={(e) => {
                setGradeCategory(e.target.value);
                setGrade("");
                setGroupId("");
              }}
            >
              <option value="">اختر...</option>
              {Object.keys(GRADE_LEVELS).map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className={lbl}>الصف *</label>
            <select
              className={inp}
              value={grade}
              onChange={(e) => {
                setGrade(e.target.value);
                setGroupId("");
              }}
              disabled={!gradeCategory}
            >
              <option value="">اختر...</option>
              {(GRADE_LEVELS[gradeCategory] || []).map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
      {/* Group selection from DB */}
      {type !== "teacher" && filteredGroups.length > 0 && (
        <div>
          <label className={lbl}>المجموعة الدراسية</label>
          <select
            className={inp}
            value={groupId}
            onChange={(e) => setGroupId(e.target.value)}
          >
            <option value="">اختر مجموعة...</option>
            {filteredGroups.map((g) => {
              const available =
                Number(g.max_students) - Number(g.current_students);
              const full = available <= 0;
              return (
                <option key={g.id} value={g.id} disabled={full}>
                  {g.name}
                  {g.day_of_week
                    ? ` — ${g.day_of_week} ${g.start_time || ""}`
                    : ""}
                  {full
                    ? " (ممتلئة)"
                    : available <= 3
                      ? ` (${available} مقعد فقط)`
                      : ""}
                </option>
              );
            })}
          </select>
        </div>
      )}
      {/* Package selection from DB */}
      {type !== "teacher" && activePackages.length > 0 && (
        <div>
          <label className={lbl}>الباقة التعليمية (اختياري)</label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {activePackages.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() =>
                  setPackageId(packageId === String(p.id) ? "" : String(p.id))
                }
                className={`p-3 rounded-xl border-2 text-right transition-all ${packageId === String(p.id) ? "border-[#0a2463] bg-[#0a2463]/5" : "border-gray-200 hover:border-gray-300"}`}
              >
                <p className="font-black text-[#0a2463] text-sm">{p.name}</p>
                <p className="text-xs text-gray-500">{p.sessions_count} حصة</p>
                <p className="font-black text-green-700 text-sm">
                  {Number(p.price).toLocaleString()} ج.م
                </p>
                {Number(p.discount) > 0 && (
                  <p className="text-[10px] text-red-500">
                    وفر {p.discount} ج.م
                  </p>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
      {/* Notes */}
      <div>
        <label className={lbl}>ملاحظات (اختياري)</label>
        <textarea
          className={`${inp} h-16 resize-none`}
          placeholder="أي ملاحظات..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
      {error && (
        <p className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-xl px-4 py-2.5 font-medium">
          ⚠️ {error}
        </p>
      )}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.97 }}
        type="submit"
        disabled={loading}
        className="w-full py-4 bg-gradient-to-r from-[#f7b731] to-[#f0a500] text-[#0a2463] rounded-xl font-black text-base shadow-lg hover:shadow-xl transition-all disabled:opacity-70 flex items-center justify-center gap-2"
      >
        {loading ? (
          <>
            <span
              className="inline-block w-5 h-5 border-2 border-[#0a2463] border-t-transparent rounded-full"
              style={{ animation: "spin 0.8s linear infinite" }}
            />
            جاري الإرسال...
          </>
        ) : (
          <>
            <Send size={18} />
            إرسال طلب التسجيل
          </>
        )}
      </motion.button>
      <p className="text-center text-xs text-gray-400">
        ✅ سيتم التواصل معك خلال 24 ساعة
      </p>
    </form>
  );
}

function PriceTable({ prices }) {
  if (!prices?.length) return null;
  return (
    <section id="prices" className="py-16 bg-white">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-yellow-100 text-yellow-700 px-4 py-2 rounded-full text-sm font-bold mb-3">
            <CreditCard size={15} />
            الأسعار والباقات
          </div>
          <h2 className="text-3xl font-black text-[#0a2463]">
            اختر الباقة المناسبة
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {prices.map((pkg, i) => {
            const isBest = i === prices.length - 1;
            const pkgName = pkg.name || pkg.label;
            const pkgPrice = pkg.price || 0;
            const pkgDiscount = pkg.discount || 0;
            const pkgNote = pkg.description || pkg.note;
            return (
              <motion.div
                key={pkg.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`rounded-3xl p-7 border-2 relative text-center transition-all ${isBest ? "bg-[#0a2463] border-[#0a2463] text-white shadow-2xl scale-105" : "bg-white border-gray-200 text-gray-800 shadow-lg hover:border-[#0a2463]/40"}`}
              >
                {isBest && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#f7b731] text-[#0a2463] px-4 py-1 rounded-full text-xs font-black">
                    ⭐ الأوفر
                  </div>
                )}
                {pkgDiscount > 0 && (
                  <div
                    className={`absolute top-4 left-4 text-xs font-black px-2 py-0.5 rounded-lg ${isBest ? "bg-[#f7b731] text-[#0a2463]" : "bg-red-100 text-red-600"}`}
                  >
                    وفر {pkgDiscount} ج
                  </div>
                )}
                <h3
                  className={`text-xl font-black mb-2 ${isBest ? "text-[#f7b731]" : "text-[#0a2463]"}`}
                >
                  {pkgName}
                </h3>
                {pkg.sessions_count && (
                  <p
                    className={`text-xs mb-2 ${isBest ? "text-blue-200" : "text-gray-500"}`}
                  >
                    {pkg.sessions_count} حصة
                  </p>
                )}
                {pkgNote && (
                  <p
                    className={`text-xs mb-4 ${isBest ? "text-blue-200" : "text-gray-400"}`}
                  >
                    {pkgNote}
                  </p>
                )}
                <div className="mb-5">
                  <span
                    className={`text-5xl font-black ${isBest ? "text-white" : "text-[#0a2463]"}`}
                  >
                    {Number(pkgPrice).toLocaleString()}
                  </span>
                  <span
                    className={`text-sm ${isBest ? "text-blue-200" : "text-gray-400"}`}
                  >
                    {" "}
                    ج.م
                  </span>
                </div>
                <a
                  href={`https://wa.me/201550012054?text=${encodeURIComponent(`أريد الاشتراك في ${pkgName} بسعر ${pkgPrice} جنيه`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-black text-sm transition-all ${isBest ? "bg-[#f7b731] text-[#0a2463] hover:bg-yellow-300" : "bg-[#0a2463] text-white hover:bg-[#0d2d7a]"}`}
                >
                  <WAIcon size={16} />
                  اشترك الآن
                </a>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default function HomePage() {
  const [settings, setSettings] = useState(null);
  const [regOpen, setRegOpen] = useState(true);
  const [packages, setPackages] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [regCode, setRegCode] = useState("");
  const [regForm, setRegForm] = useState({});
  const [menuOpen, setMenuOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const formRef = useRef(null);

  useEffect(() => {
    // Load settings from DB API
    fetch("/api/academy/settings")
      .then((r) => r.json())
      .then((data) => {
        const s = data.settings || {};
        setSettings(s);
        setRegOpen(s.registration_open !== "false");
      })
      .catch(() => {
        // Fallback to localStorage
        try {
          const s = JSON.parse(
            localStorage.getItem("academy_portal_settings_v1") || "{}",
          );
          setSettings(s);
          setRegOpen(s.registrationOpen !== false);
        } catch {}
      });
    // Load packages from DB API for price table
    fetch("/api/academy/packages")
      .then((r) => r.json())
      .then((data) => setPackages(data.packages || []))
      .catch(() => {});
    try {
      if (sessionStorage.getItem("admin_session_v1")) setIsAdmin(true);
    } catch {}
  }, []);

  const scrollToForm = () =>
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  const adminPhone =
    settings?.admin_phone || settings?.adminPhone || "201550012054";
  const waGroupLink =
    settings?.whatsapp_group ||
    settings?.whatsappGroup ||
    "https://chat.whatsapp.com/CPbJ8ZCrXBU1EbkDzqYuYd";
  const tgLink =
    settings?.telegram_channel ||
    settings?.telegramChannel ||
    `https://t.me/+${adminPhone}`;
  const publicLinks = (() => {
    try {
      return JSON.parse(settings?.links_json || "[]").filter((l) => l.public);
    } catch {
      return (settings?.links || []).filter((l) => l.public);
    }
  })();
  const academyName =
    settings?.academy_name || settings?.academyName || "الأكاديمية التعليمية";

  const navLinks = [
    { label: "الرئيسية", href: "#hero" },
    { label: "الأسعار", href: "#prices" },
    { label: "انضم للمجموعة", href: waGroupLink, external: true },
    { label: "تواصل معنا", href: "#contact" },
  ];

  return (
    <div className="min-h-screen font-cairo" dir="rtl">
      {/* Admin shortcut banner */}
      {isAdmin && (
        <div className="bg-[#f7b731] px-4 py-2 flex items-center justify-between gap-4">
          <p className="text-[#0a2463] font-bold text-sm">🛡️ أنت مسجل كمدير</p>
          <a
            href="/dashboard"
            className="flex items-center gap-1.5 px-4 py-1.5 bg-[#0a2463] text-white rounded-lg text-xs font-black hover:bg-[#0d2d7a] transition-all"
          >
            لوحة القيادة ←
          </a>
        </div>
      )}

      {/* NAVBAR */}
      <nav className="bg-[#1a3560] sticky top-0 z-50 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 flex-shrink-0">
            <div className="w-9 h-9 bg-[#f7b731] rounded-xl flex items-center justify-center">
              <GraduationCap size={20} className="text-[#0a2463]" />
            </div>
            <div className="hidden sm:block">
              <p className="text-white font-black text-sm leading-tight">
                {academyName}
              </p>
              <p className="text-[#f7b731] text-[10px] font-bold">
                منصة تعليمية متكاملة
              </p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-5">
            {navLinks.map(({ label, href, external }) => (
              <a
                key={label}
                href={href}
                target={external ? "_blank" : undefined}
                rel={external ? "noopener noreferrer" : undefined}
                className="text-blue-200 hover:text-[#f7b731] text-sm font-bold transition-colors flex items-center gap-1"
              >
                {external && <ExternalLink size={12} />}
                {label}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-1 bg-white/10 rounded-xl p-1">
              {[
                { href: "/student", icon: "🎓", label: "طالب" },
                { href: "/teacher", icon: "📚", label: "معلم" },
                { href: "/parent", icon: "👨‍👩‍👧", label: "ولي أمر" },
                { href: "/admin", icon: "🛡️", label: "إدارة" },
              ].map(({ href, icon, label }) => (
                <a
                  key={href}
                  href={href}
                  className="px-2 py-1.5 text-white hover:bg-white/20 rounded-lg text-xs font-bold transition-all flex items-center gap-1"
                >
                  <span>{icon}</span>
                  <span className="hidden lg:inline">{label}</span>
                </a>
              ))}
            </div>
            {regOpen && (
              <button
                onClick={scrollToForm}
                className="px-3 py-2 bg-[#f7b731] hover:bg-[#f0a500] text-[#0a2463] rounded-xl font-black text-sm transition-all flex-shrink-0"
              >
                سجّل الآن
              </button>
            )}
            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="md:hidden p-2 text-white"
            >
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden bg-[#06173d] border-t border-white/10 overflow-hidden"
            >
              <div className="px-4 py-4 space-y-2">
                {navLinks.map(({ label, href, external }) => (
                  <a
                    key={label}
                    href={href}
                    target={external ? "_blank" : undefined}
                    rel={external ? "noopener noreferrer" : undefined}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 text-blue-200 font-bold py-2.5 border-b border-white/5 text-sm"
                  >
                    {external && <ExternalLink size={13} />}
                    {label}
                  </a>
                ))}
                <div className="grid grid-cols-2 gap-2 pt-2">
                  {[
                    { href: "/student", icon: "🎓", label: "بوابة الطالب" },
                    { href: "/teacher", icon: "📚", label: "بوابة المعلم" },
                    { href: "/parent", icon: "👨‍👩‍👧", label: "ولي الأمر" },
                    { href: "/admin", icon: "🛡️", label: "المدير" },
                  ].map(({ href, icon, label }) => (
                    <a
                      key={href}
                      href={href}
                      className="flex items-center gap-2 py-2.5 px-3 bg-white/10 rounded-xl text-white text-xs font-bold"
                    >
                      <span>{icon}</span>
                      {label}
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* HERO + FORM */}
      <section
        id="hero"
        className="bg-gradient-to-br from-[#1e3d6f] via-[#2a4f8a] to-[#1a3560] min-h-[88vh] flex items-center"
      >
        <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 lg:grid-cols-2 gap-10 items-center w-full">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 bg-[#f7b731]/20 border border-[#f7b731]/30 text-[#f7b731] px-4 py-2 rounded-full text-sm font-bold mb-6">
              <Zap size={14} />
              {regOpen ? "التسجيل مفتوح الآن! 🚀" : "التسجيل مغلق مؤقتاً 🔒"}
            </div>
            <h1 className="text-4xl md:text-5xl font-black text-white leading-tight mb-5">
              ارتقِ بمستواك
              <br />
              <span className="text-[#f7b731]">مع أفضل المدرسين</span>
            </h1>
            <p className="text-blue-200 text-base leading-relaxed mb-7">
              منصة تعليمية متكاملة للطلاب وأولياء الأمور والمدرسين. حصص مباشرة
              مع متابعة يومية عبر واتساب وتيليجرام.
            </p>
            <div className="grid grid-cols-4 gap-3 mb-8">
              {[
                { v: "+٥٠٠", l: "طالب", i: "👨‍🎓" },
                { v: "٩.٨", l: "تقييم / ١٠", i: "⭐" },
                { v: "٩٠٪", l: "نسبة التحسن", i: "📈" },
                { v: "+٩", l: "سنوات خبرة", i: "🏆" },
              ].map(({ v, l, i }) => (
                <div
                  key={l}
                  className="bg-white/10 rounded-2xl p-3 text-center border border-white/10"
                >
                  <div className="text-xl mb-1">{i}</div>
                  <p className="text-xl font-black text-[#f7b731]">{v}</p>
                  <p className="text-blue-300 text-[10px]">{l}</p>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-3">
              <a
                href={waGroupLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-bold transition-all shadow-lg"
              >
                <WAIcon size={18} />
                انضم للمجموعة
              </a>
              <a
                href={`https://wa.me/${adminPhone}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3 bg-[#128C7E] hover:bg-[#0f7a6e] text-white rounded-xl font-bold transition-all"
              >
                <WAIcon size={18} />
                واتساب الإدارة
              </a>
              <a
                href={tgLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3 bg-[#229ED9] hover:bg-[#1a8bc4] text-white rounded-xl font-bold transition-all"
              >
                <TGIcon size={18} />
                تيليجرام
              </a>
            </div>
          </motion.div>
          <motion.div
            ref={formRef}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="bg-white rounded-3xl shadow-2xl shadow-black/40 overflow-hidden"
          >
            <div className="bg-gradient-to-r from-[#0a2463] to-[#1a3a8a] px-6 py-5">
              <h2 className="text-xl font-black text-white">
                📝 سجّل الآن — مجاناً
              </h2>
              <p className="text-blue-200 text-xs mt-1">
                أرسل طلبك وانتظر رد الإدارة خلال 24 ساعة
              </p>
            </div>
            <div className="p-6">
              <AnimatePresence mode="wait">
                {!regOpen ? (
                  <motion.div
                    key="closed"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-8"
                  >
                    <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Lock size={30} className="text-red-500" />
                    </div>
                    <h3 className="text-xl font-black text-gray-700 mb-2">
                      التسجيل مغلق مؤقتاً
                    </h3>
                    <p className="text-gray-500 text-sm mb-5">
                      تابعنا عبر واتساب لمعرفة موعد الفتح
                    </p>
                    <a
                      href={`https://wa.me/${adminPhone}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 py-3 bg-green-500 text-white rounded-xl font-bold"
                    >
                      <WAIcon size={18} />
                      ابقَ على اطلاع
                    </a>
                  </motion.div>
                ) : submitted ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-4"
                  >
                    <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                      <CheckCircle2 size={40} className="text-white" />
                    </div>
                    <h3 className="text-2xl font-black text-[#0a2463] mb-1">
                      تم التسجيل! 🎉
                    </h3>
                    <div className="bg-[#0a2463] rounded-2xl p-5 my-4">
                      <p className="text-blue-200 text-xs mb-1">رقم طلبك</p>
                      <p className="text-3xl font-black text-[#f7b731] font-mono tracking-widest">
                        {regCode}
                      </p>
                    </div>
                    <div className="space-y-2">
                      <a
                        href={`https://wa.me/${adminPhone}?text=${encodeURIComponent(`السلام عليكم، أنا ${regForm.name}، رقم طلب التسجيل: ${regCode}`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full flex items-center justify-center gap-2 py-3 bg-green-500 text-white rounded-xl font-bold"
                      >
                        <WAIcon size={18} />
                        تواصل على واتساب
                      </a>
                      <a
                        href={waGroupLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full flex items-center justify-center gap-2 py-3 bg-[#128C7E] text-white rounded-xl font-bold"
                      >
                        <WAIcon size={16} />
                        انضم لمجموعة الواتساب 📱
                      </a>
                      <button
                        onClick={() => {
                          setSubmitted(false);
                          setRegCode("");
                          setRegForm({});
                        }}
                        className="w-full py-2.5 bg-gray-100 text-gray-600 rounded-xl font-bold text-sm"
                      >
                        تسجيل شخص آخر
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <RegisterForm
                      adminPhone={adminPhone}
                      onSuccess={(code, form) => {
                        setRegCode(code);
                        setRegForm(form);
                        setSubmitted(true);
                        scrollToForm();
                      }}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </section>

      {/* WhatsApp Group Banner */}
      <div className="bg-[#128C7E] py-6">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-right">
            <p className="text-white font-black text-lg">
              📱 انضم لمجموعة الواتساب الرسمية
            </p>
            <p className="text-green-200 text-sm">
              كل الإعلانات والمواد والمستجدات في مكان واحد
            </p>
          </div>
          <a
            href={waGroupLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-8 py-4 bg-white text-[#128C7E] rounded-2xl font-black text-base hover:shadow-xl transition-all flex-shrink-0"
          >
            <WAIcon size={22} /> انضم الآن 🚀
          </a>
        </div>
      </div>

      {/* Price Table from DB */}
      {packages.length > 0 && <PriceTable prices={packages} />}

      {/* Portals */}
      <section id="portals" className="py-16 bg-gray-50">
        <div className="max-w-5xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-black text-[#0a2463]">
              البوابات الخاصة
            </h2>
            <p className="text-gray-500 mt-2">ادخل بوابتك وتابع كل ما يخصك</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              {
                href: "/admin",
                label: "بوابة الإدارة",
                desc: "المدير والإداريون والمعلمون",
                icon: "🛡️",
                color: "from-slate-600 to-slate-800",
              },
              {
                href: "/student",
                label: "بوابة الطالب",
                desc: "حضورك وواجباتك ودرجاتك",
                icon: "🎓",
                color: "from-blue-600 to-blue-800",
              },
              {
                href: "/teacher",
                label: "بوابة المعلم",
                desc: "إدارة الطلاب والحصص والشات",
                icon: "📚",
                color: "from-violet-600 to-violet-800",
              },
              {
                href: "/parent",
                label: "بوابة ولي الأمر",
                desc: "تابع تقدم ابنك",
                icon: "👨‍👩‍👧",
                color: "from-teal-600 to-teal-800",
              },
            ].map(({ href, label, desc, icon, color }) => (
              <motion.a
                key={href}
                href={href}
                whileHover={{ y: -4 }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className={`bg-gradient-to-br ${color} rounded-3xl p-6 text-center text-white hover:shadow-2xl transition-all`}
              >
                <div className="text-4xl mb-3">{icon}</div>
                <h3 className="font-black text-base mb-1">{label}</h3>
                <p className="text-white/70 text-xs">{desc}</p>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 bg-[#0a2463]">
        <div className="max-w-5xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-black text-white">تواصل معنا</h2>
            <p className="text-blue-200 mt-2">نحن هنا لمساعدتك</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <a
              href={`https://wa.me/${adminPhone}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-5 bg-green-500 hover:bg-green-600 rounded-2xl text-white transition-all"
            >
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <WAIcon size={24} />
              </div>
              <div>
                <p className="font-black">واتساب</p>
                <p className="text-green-100 text-xs font-mono">
                  {adminPhone.replace("2", "0")}
                </p>
              </div>
            </a>
            <a
              href={tgLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-5 bg-[#229ED9] hover:bg-[#1a8bc4] rounded-2xl text-white transition-all"
            >
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <TGIcon size={24} />
              </div>
              <div>
                <p className="font-black">تيليجرام</p>
                <p className="text-blue-100 text-xs">القناة الرسمية</p>
              </div>
            </a>
            <a
              href={waGroupLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-5 bg-[#128C7E] hover:bg-[#0f7a6e] rounded-2xl text-white transition-all"
            >
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <WAIcon size={24} />
              </div>
              <div>
                <p className="font-black">مجموعة الواتساب</p>
                <p className="text-green-100 text-xs">المجموعة الرسمية</p>
              </div>
            </a>
          </div>
          {publicLinks.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {publicLinks.map((link) => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-3 bg-white/10 hover:bg-white/20 rounded-xl text-white text-sm font-bold transition-all border border-white/20"
                >
                  <Link2 size={15} />
                  <span className="truncate">{link.label}</span>
                </a>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#06173d] py-8">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-[#f7b731] rounded-lg flex items-center justify-center">
              <GraduationCap size={18} className="text-[#0a2463]" />
            </div>
            <p className="text-white font-black text-sm">{academyName}</p>
          </div>
          <p className="text-blue-400 text-xs">
            © {new Date().getFullYear()} — جميع الحقوق محفوظة
          </p>
          <div className="flex items-center gap-2">
            {[
              {
                href: `https://wa.me/${adminPhone}`,
                bg: "bg-green-500",
                i: <WAIcon size={16} />,
              },
              { href: tgLink, bg: "bg-[#229ED9]", i: <TGIcon size={16} /> },
              {
                href: waGroupLink,
                bg: "bg-[#128C7E]",
                i: <WAIcon size={16} />,
              },
            ].map(({ href, bg, i }, idx) => (
              <a
                key={idx}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className={`w-8 h-8 ${bg} rounded-lg flex items-center justify-center text-white hover:opacity-80 transition-all`}
              >
                {i}
              </a>
            ))}
            <a
              href="/admin"
              className="w-8 h-8 bg-gray-600 rounded-lg flex items-center justify-center text-white hover:opacity-80 transition-all"
            >
              <Shield size={15} />
            </a>
          </div>
        </div>
      </footer>

      {/* Floating WA */}
      <a
        href={`https://wa.me/${adminPhone}?text=${encodeURIComponent("السلام عليكم، أريد الاستفسار عن التسجيل")}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 left-6 z-50 flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-3 rounded-2xl shadow-2xl transition-all font-bold text-sm"
      >
        <WAIcon size={20} /> واتساب
      </a>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap');
        .font-cairo, * { font-family: 'Cairo', sans-serif; }
        html { scroll-behavior: smooth; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
