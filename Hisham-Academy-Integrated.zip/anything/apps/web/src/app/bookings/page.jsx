"use client";
import React, { useEffect, useMemo, useState } from "react";
import { CalendarPlus, Users, UserRound, Clock3, Wallet, CheckCircle2, Upload, RefreshCw, PlusCircle } from "lucide-react";
import { toast, Toaster } from "sonner";
import useUpload from "@/utils/useUpload";

const money = (n) => `${Number(n || 0).toLocaleString("ar-EG")} ج.م`;
const dateLabel = (value) => value ? new Date(value).toLocaleString("ar-EG", { dateStyle: "medium", timeStyle: "short" }) : "—";

export default function BookingsPage() {
  const [actor, setActor] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selected, setSelected] = useState(null);
  const [studentCodesText, setStudentCodesText] = useState("");
  const [proofUrl, setProofUrl] = useState("");
  const [uploadProof, { loading: uploadingProof }] = useUpload();
  const [paymentMethod, setPaymentMethod] = useState("bank_transfer");
  const [form, setForm] = useState({ sessionType: "group", subject: "رياضيات", grade: "", topic: "", startsAt: "", endsAt: "", pricePerSeat: "125", capacity: "5", deliveryMode: "online", meetingUrl: "", location: "" });

  useEffect(() => {
    try {
      const student = JSON.parse(sessionStorage.getItem("student_session_v1") || "null");
      const teacher = JSON.parse(sessionStorage.getItem("teacher_session_v1") || "null");
      setActor(teacher ? { ...teacher, role: "teacher" } : student ? { ...student, role: "student" } : null);
    } catch { setActor(null); }
  }, []);

  const load = async (current = actor) => {
    if (!current) return;
    setLoading(true);
    try {
      const isTeacher = current.role === "teacher";
      const [sessionRes, bookingRes] = await Promise.all([
        fetch(isTeacher ? `/api/academy/bookable-sessions?teacherId=${encodeURIComponent(current.id)}&includeClosed=true` : "/api/academy/bookable-sessions"),
        fetch(isTeacher ? `/api/academy/bookings?teacherId=${encodeURIComponent(current.id)}` : `/api/academy/bookings?studentId=${encodeURIComponent(current.id)}`),
      ]);
      const sessionData = await sessionRes.json();
      const bookingData = await bookingRes.json();
      if (!sessionRes.ok) throw new Error(sessionData.error || "تعذر تحميل الحصص");
      if (!bookingRes.ok) throw new Error(bookingData.error || "تعذر تحميل الحجوزات");
      setSessions(sessionData.sessions || []);
      setBookings(bookingData.bookings || []);
    } catch (error) { toast.error(error.message); }
    finally { setLoading(false); }
  };
  useEffect(() => { if (actor) load(actor); }, [actor]);

  const isTeacher = actor?.role === "teacher";
  const codes = useMemo(() => [...new Set(studentCodesText.split(/[،,\s]+/).map((x) => x.trim().toUpperCase()).filter(Boolean))], [studentCodesText]);

  const publish = async (event) => {
    event.preventDefault();
    if (!actor?.id) return toast.error("تعذر تحديد حساب المعلم");
    setSaving(true);
    try {
      const response = await fetch("/api/academy/bookable-sessions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, teacherId: actor.id, capacity: Number(form.sessionType === "private" ? 1 : form.capacity), pricePerSeat: Number(form.pricePerSeat), startsAt: new Date(form.startsAt).toISOString(), endsAt: new Date(form.endsAt).toISOString() }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر نشر الحصة");
      toast.success("تم نشر الحصة للحجز");
      setForm((old) => ({ ...old, topic: "", startsAt: "", endsAt: "" }));
      await load(actor);
    } catch (error) { toast.error(error.message); }
    finally { setSaving(false); }
  };

  const book = async () => {
    if (!selected || !actor?.id) return;
    const participantCount = codes.length ? new Set([...codes, String(actor.code || actor.id).toUpperCase()]).size : 1;
    if (selected.session_type === "private" && participantCount !== 1) return toast.error("الحصة الخاصة تقبل طالبًا واحدًا فقط");
    if (participantCount > Number(selected.available_seats)) return toast.error("عدد المقاعد أكبر من المتاح");
    setSaving(true);
    try {
      const response = await fetch("/api/academy/bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sessionId: selected.id, bookedByStudentId: actor.id, studentCodes: codes, paymentMethod, proofUrl: proofUrl.trim() || null }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر إنشاء الحجز");
      toast.success("تم إنشاء الحجز. ينتظر تأكيد الدفع من المعلم.");
      setSelected(null); setStudentCodesText(""); setProofUrl("");
      await load(actor);
    } catch (error) { toast.error(error.message); }
    finally { setSaving(false); }
  };

  const markAttendance = async (booking, participant, attendanceStatus) => {
    setSaving(true);
    try {
      const response = await fetch("/api/academy/bookings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ bookingId: booking.id, action: "attendance", teacherId: actor.id, studentId: participant.studentId, attendanceStatus }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تسجيل الحضور");
      toast.success("تم تحديث الحضور");
      await load(actor);
    } catch (error) { toast.error(error.message); }
    finally { setSaving(false); }
  };

  const review = async (booking, decision) => {
    setSaving(true);
    try {
      const response = await fetch("/api/academy/bookings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ bookingId: booking.id, action: "review_payment", decision, teacherId: actor.id, note: decision === "approved" ? "تم تأكيد الدفع" : "يرجى مراجعة إثبات الدفع" }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحديث الدفع");
      toast.success(decision === "approved" ? "تم تأكيد الحجز" : "تم رفض الدفع وتحرير المقاعد");
      await load(actor);
    } catch (error) { toast.error(error.message); }
    finally { setSaving(false); }
  };

  if (!actor) return <main dir="rtl" className="min-h-screen bg-slate-50 p-6"><div className="mx-auto max-w-xl rounded-2xl bg-white p-6 text-center shadow">سجل الدخول من بوابة الطالب أو المعلم أولًا، ثم افتح صفحة الحجز.</div></main>;

  return <main dir="rtl" className="min-h-screen bg-slate-50 p-4 md:p-8"><Toaster richColors position="top-center"/><div className="mx-auto max-w-6xl space-y-6">
    <header className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-sm text-indigo-600 font-bold">Hisham Academy</p><h1 className="text-2xl md:text-3xl font-black text-slate-900">{isTeacher ? "إدارة الحصص والحجوزات" : "احجز حصة"}</h1><p className="mt-1 text-sm text-slate-500">{isTeacher ? "انشر المواعيد وراجع حجوزات الطلاب ومدفوعاتهم" : "اختر حصة خاصة أو جماعية واحجز مقعدك"}</p></div><button onClick={() => load(actor)} className="flex items-center gap-2 rounded-xl border bg-white px-4 py-2 text-sm font-bold"><RefreshCw size={16}/> تحديث</button></header>

    {isTeacher && <form onSubmit={publish} className="rounded-2xl border bg-white p-5 shadow-sm space-y-4"><h2 className="flex items-center gap-2 text-lg font-black"><PlusCircle className="text-indigo-600"/> نشر حصة جديدة</h2><div className="grid gap-3 md:grid-cols-3">
      <label className="text-sm font-bold">نوع الحصة<select className="mt-1 w-full rounded-xl border p-3" value={form.sessionType} onChange={e=>setForm({...form,sessionType:e.target.value,capacity:e.target.value==="private"?"1":form.capacity})}><option value="private">خاصة – طالب واحد</option><option value="group">جماعية – عدة طلاب</option></select></label>
      <label className="text-sm font-bold">المادة<input required className="mt-1 w-full rounded-xl border p-3" value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})}/></label>
      <label className="text-sm font-bold">الصف<input className="mt-1 w-full rounded-xl border p-3" value={form.grade} onChange={e=>setForm({...form,grade:e.target.value})} placeholder="مثال: الثالث الإعدادي"/></label>
      <label className="text-sm font-bold md:col-span-3">موضوع الحصة<input required className="mt-1 w-full rounded-xl border p-3" value={form.topic} onChange={e=>setForm({...form,topic:e.target.value})}/></label>
      <label className="text-sm font-bold">بداية الحصة<input required type="datetime-local" className="mt-1 w-full rounded-xl border p-3" value={form.startsAt} onChange={e=>setForm({...form,startsAt:e.target.value})}/></label>
      <label className="text-sm font-bold">نهاية الحصة<input required type="datetime-local" className="mt-1 w-full rounded-xl border p-3" value={form.endsAt} onChange={e=>setForm({...form,endsAt:e.target.value})}/></label>
      <label className="text-sm font-bold">سعر المقعد (جنيه)<input required min="0" type="number" className="mt-1 w-full rounded-xl border p-3" value={form.pricePerSeat} onChange={e=>setForm({...form,pricePerSeat:e.target.value})}/></label>
      {form.sessionType === "group" && <label className="text-sm font-bold">السعة القصوى<input required min="2" type="number" className="mt-1 w-full rounded-xl border p-3" value={form.capacity} onChange={e=>setForm({...form,capacity:e.target.value})}/></label>}
      <label className="text-sm font-bold">طريقة التقديم<select className="mt-1 w-full rounded-xl border p-3" value={form.deliveryMode} onChange={e=>setForm({...form,deliveryMode:e.target.value})}><option value="online">أونلاين</option><option value="in_person">حضوري</option></select></label>
      {form.deliveryMode === "online" ? <label className="text-sm font-bold">رابط الحصة<input className="mt-1 w-full rounded-xl border p-3" type="url" value={form.meetingUrl} onChange={e=>setForm({...form,meetingUrl:e.target.value})} placeholder="https://..."/></label> : <label className="text-sm font-bold">المكان<input className="mt-1 w-full rounded-xl border p-3" value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></label>}
    </div><button disabled={saving} className="rounded-xl bg-indigo-700 px-6 py-3 font-black text-white disabled:opacity-50">{saving?"جارٍ النشر...":"نشر الحصة للحجز"}</button></form>}

    {!isTeacher && <section className="space-y-3"><h2 className="text-lg font-black">الحصص المتاحة</h2>{loading ? <p className="text-slate-500">جارٍ تحميل الحصص...</p> : sessions.length===0 ? <div className="rounded-2xl border bg-white p-8 text-center text-slate-500">لا توجد حصص متاحة للحجز حاليًا.</div> : <div className="grid gap-4 md:grid-cols-2">{sessions.map(s=><article key={s.id} className="rounded-2xl border bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-2"><div><span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-700">{s.session_type==="private"?"حصة خاصة":"حصة جماعية"}</span><h3 className="mt-3 text-lg font-black">{s.subject} – {s.grade || "كل الصفوف"}</h3><p className="text-sm text-slate-500">{s.topic}</p><p className="mt-1 text-xs text-slate-400">{s.teacher_name ? `المعلم: ${s.teacher_name}` : ""}</p></div><div className="text-left font-black text-emerald-700">{money(s.price_per_seat)}<p className="text-xs font-normal text-slate-400">للمقعد</p></div></div><div className="mt-4 space-y-2 text-sm text-slate-600"><p className="flex items-center gap-2"><Clock3 size={16}/>{dateLabel(s.starts_at)}</p><p className="flex items-center gap-2"><Users size={16}/>{s.available_seats} مقعد متاح</p></div><button disabled={Number(s.available_seats)<1} onClick={()=>setSelected(s)} className="mt-4 w-full rounded-xl bg-indigo-700 py-3 font-black text-white disabled:bg-slate-300">اختيار وحجز</button></article>)}</div>}</section>}

    {selected && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4"><div className="w-full max-w-lg rounded-2xl bg-white p-5 shadow-2xl space-y-4"><div className="flex items-center justify-between"><h2 className="text-xl font-black">تأكيد الحجز</h2><button onClick={()=>setSelected(null)} className="text-slate-500">إغلاق ✕</button></div><p className="text-sm text-slate-600">{selected.subject} • {selected.topic} • {dateLabel(selected.starts_at)}</p><div className="rounded-xl bg-slate-50 p-3 text-sm">{selected.session_type==="private"?"حصة خاصة لطالب واحد":"حصة جماعية"} – {money(selected.price_per_seat)} للمقعد</div><label className="block text-sm font-bold">أكواد الطلاب الآخرين (اختياري)<input value={studentCodesText} onChange={e=>setStudentCodesText(e.target.value)} className="mt-1 w-full rounded-xl border p-3" placeholder={`اتركه فارغًا للحجز لنفسك • الحد ${selected.available_seats}`}/><span className="mt-1 block text-xs font-normal text-slate-500">أدخل أكواد الطلاب الآخرين المسجلين مسبقًا مفصولة بفواصل. سيُضاف حسابك تلقائيًا إلى الحجز.</span></label><label className="block text-sm font-bold">وسيلة الدفع<select value={paymentMethod} onChange={e=>setPaymentMethod(e.target.value)} className="mt-1 w-full rounded-xl border p-3"><option value="bank_transfer">تحويل بنكي / إنستاباي</option><option value="vodafone_cash">فودافون كاش</option><option value="cash">نقدًا للمعلم</option></select></label><label className="block text-sm font-bold">إثبات الدفع (صورة أو PDF)<span className="mt-1 flex items-center gap-2 rounded-xl border p-3 font-normal"><Upload size={18} className="text-indigo-600"/><input type="file" accept="image/*,.pdf" disabled={uploadingProof} onChange={async e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>4*1024*1024){toast.error("الحد الأقصى لحجم الإيصال 4 ميجابايت");e.target.value="";return;}const result=await uploadProof({file});if(result.error){toast.error("فشل رفع الإيصال");return;}setProofUrl(result.url);toast.success("تم رفع إثبات الدفع");}}/></span><span className="mt-1 block text-xs font-normal text-slate-500">{uploadingProof?"جارٍ رفع الإيصال...":proofUrl?"تم إرفاق إثبات الدفع":"يمكنك إتمام الحجز دون إرفاقه ثم الدفع للمعلم بالطريقة المتفق عليها."}</span></label><div className="rounded-xl bg-emerald-50 p-3 font-black text-emerald-800">الإجمالي: {money(Number(selected.price_per_seat)*(new Set([...codes, String(actor.code || actor.id).toUpperCase()]).size))}</div><button disabled={saving} onClick={book} className="w-full rounded-xl bg-emerald-600 py-3 font-black text-white disabled:opacity-50">{saving?"جارٍ إنشاء الحجز...":"تأكيد الحجز وإرسال الدفع"}</button></div></div>}

    <section className="space-y-3"><h2 className="text-lg font-black">{isTeacher?"طلبات الحجز والمدفوعات":"حجوزاتي"}</h2>{loading?<p className="text-slate-500">جارٍ التحميل...</p>:bookings.length===0?<div className="rounded-2xl border bg-white p-7 text-center text-slate-500">لا توجد حجوزات حتى الآن.</div>:<div className="space-y-3">{bookings.map(b=><article key={b.id} className="rounded-2xl border bg-white p-4 shadow-sm"><div className="flex flex-wrap items-center justify-between gap-2"><div><h3 className="font-black">{b.subject} – {b.topic}</h3><p className="text-xs text-slate-500">{dateLabel(b.starts_at)} • {b.session_type==="private"?"خاصة":"جماعية"}</p></div><span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-800">{b.status==="confirmed"?"مؤكد":b.status==="rejected"?"مرفوض":b.status==="cancelled"?"ملغي أو انتهت المهلة":b.status==="payment_review"?"بانتظار مراجعة الدفع":"بانتظار الدفع"}</span></div><div className="mt-3 flex flex-wrap gap-4 text-sm text-slate-600"><span>{b.seat_count} مقعد</span><span className="font-black">{money(b.total_amount)}</span><span>الدفع: {b.payment_status||"غير مسجل"}</span></div>{isTeacher && b.status!=="confirmed" && b.payment_status && <div className="mt-3 flex gap-2"><button disabled={saving} onClick={()=>review(b,"approved")} className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-bold text-white">اعتماد الدفع</button><button disabled={saving} onClick={()=>review(b,"rejected")} className="rounded-lg bg-red-50 px-4 py-2 text-sm font-bold text-red-700">رفض</button></div>}{isTeacher && b.status==="confirmed" && Array.isArray(b.participants) && <div className="mt-4 space-y-2 border-t pt-3"><p className="text-sm font-black">الطلاب والحضور</p>{b.participants.map((participant)=><div key={participant.studentId} className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-slate-50 p-2"><span className="text-sm">{participant.studentName || `طالب ${participant.studentId}`} <span className="text-xs text-slate-500">{participant.studentCode || ""}</span></span><div className="flex gap-1"><button disabled={saving} onClick={()=>markAttendance(b,participant,"present")} className={`rounded-md px-2 py-1 text-xs font-bold ${participant.attendanceStatus==="present"?"bg-emerald-600 text-white":"bg-white text-emerald-700 border"}`}>حاضر</button><button disabled={saving} onClick={()=>markAttendance(b,participant,"absent")} className={`rounded-md px-2 py-1 text-xs font-bold ${participant.attendanceStatus==="absent"?"bg-red-600 text-white":"bg-white text-red-700 border"}`}>غائب</button><button disabled={saving} onClick={()=>markAttendance(b,participant,"late")} className={`rounded-md px-2 py-1 text-xs font-bold ${participant.attendanceStatus==="late"?"bg-amber-500 text-white":"bg-white text-amber-700 border"}`}>متأخر</button></div></div>)}</div>}{!isTeacher && b.status==="confirmed" && b.meeting_url && <a href={b.meeting_url} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-2 rounded-lg bg-indigo-50 px-4 py-2 text-sm font-bold text-indigo-700">الدخول للحصة</a>}</article>)}</div>}</section>
  </div></main>;
}
