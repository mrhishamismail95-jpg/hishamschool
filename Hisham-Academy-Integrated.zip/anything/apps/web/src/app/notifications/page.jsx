"use client";
import React, { useState, useEffect, useMemo } from "react";
import { useStore } from "@/utils/store";
import {
  Bell,
  BellOff,
  CheckCheck,
  AlertTriangle,
  Clock,
  DollarSign,
  XCircle,
  BookOpen,
  X,
  ChevronRight,
  RefreshCw,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

// ── توليد الإشعارات الذكية من البيانات الحالية ─────────────────────────────
function generateSmartNotifications(students, attendance, payments, homework) {
  const notifications = [];
  const today = new Date();
  const todayStr = today.toISOString().split("T")[0];
  const thisMonth = todayStr.slice(0, 7);

  students.forEach((student) => {
    const pkg = Number(student.sessionPackage) || 8;
    const attended = attendance.filter(
      (a) =>
        a.studentId === student.id &&
        (a.status === "present" || a.status === "late"),
    );
    const remaining = Math.max(0, pkg - attended.length);

    // 🔴 انتهت الحصص
    if (remaining === 0) {
      notifications.push({
        id: `finished-${student.id}`,
        type: "sessions_finished",
        priority: "high",
        icon: XCircle,
        color: "red",
        title: "انتهت حصص الطالب!",
        message: `${student.name} — استخدم كل الـ ${pkg} حصص. يجب التجديد للاستمرار.`,
        href: "/students",
        linkLabel: "عرض الطلاب",
      });
    }
    // 🟠 حصص قاربت على الانتهاء
    else if (remaining <= 2) {
      notifications.push({
        id: `low-${student.id}`,
        type: "sessions_low",
        priority: "medium",
        icon: AlertTriangle,
        color: "orange",
        title: "حصص قاربت على الانتهاء",
        message: `${student.name} — متبقي ${remaining} ${remaining === 1 ? "حصة" : "حصتان"} فقط من الـ ${pkg} حصة.`,
        href: "/attendance",
        linkLabel: "سجل الحضور",
      });
    }

    // 🟣 لم يدفع هذا الشهر
    const hasPaid = payments.some(
      (p) => p.studentId === student.id && p.date?.startsWith(thisMonth),
    );
    if (!hasPaid && student.price) {
      notifications.push({
        id: `unpaid-${student.id}-${thisMonth}`,
        type: "unpaid",
        priority: "medium",
        icon: DollarSign,
        color: "purple",
        title: "لم يسدد رسوم الشهر",
        message: `${student.name} — لم يدفع رسوم ${new Date(thisMonth + "-01").toLocaleDateString("ar-EG", { month: "long", year: "numeric" })}. المبلغ: ${Number(student.price).toLocaleString()} ج.م`,
        href: "/finances",
        linkLabel: "الإدارة المالية",
      });
    }

    // 🔴 غياب متكرر (3+ في آخر 14 يوم)
    const cutoff = new Date(today);
    cutoff.setDate(cutoff.getDate() - 14);
    const recentAbsences = attendance.filter(
      (a) =>
        a.studentId === student.id &&
        a.status === "absent" &&
        new Date(a.date) >= cutoff,
    );
    if (recentAbsences.length >= 3) {
      notifications.push({
        id: `absences-${student.id}`,
        type: "absences",
        priority: "high",
        icon: XCircle,
        color: "red",
        title: "غياب متكرر — تواصل مع ولي الأمر",
        message: `${student.name} — غاب ${recentAbsences.length} مرات في آخر 14 يوماً.`,
        href: "/attendance",
        linkLabel: "سجل الحضور",
      });
    }
  });

  // 📝 واجبات متأخرة
  (homework || []).forEach((hw) => {
    if (hw.dueDate < todayStr) {
      const targets = students.filter((s) => !hw.group || s.group === hw.group);
      const notSubmitted = targets.filter(
        (s) => !(hw.submissions || []).some((sub) => sub.studentId === s.id),
      );
      if (notSubmitted.length > 0) {
        notifications.push({
          id: `hw-${hw.id}`,
          type: "homework",
          priority: "low",
          icon: BookOpen,
          color: "blue",
          title: "واجب انتهى موعده ولم يسلَّم",
          message: `"${hw.title}" — ${notSubmitted.length} طالب لم يسلّم حتى الآن. (الموعد: ${new Date(hw.dueDate).toLocaleDateString("ar-EG")})`,
          href: "/homework",
          linkLabel: "الواجبات",
        });
      }
    }
  });

  const order = { high: 0, medium: 1, low: 2 };
  return notifications.sort((a, b) => order[a.priority] - order[b.priority]);
}

// ── الألوان ────────────────────────────────────────────────────────────────
const COLORS = {
  red: {
    bg: "bg-red-50 dark:bg-red-900/20",
    border: "border-red-200 dark:border-red-800/40",
    icon: "bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400",
    badge: "bg-red-100 text-red-600",
    bar: "bg-red-500",
  },
  orange: {
    bg: "bg-orange-50 dark:bg-orange-900/20",
    border: "border-orange-200 dark:border-orange-800/40",
    icon: "bg-orange-100 dark:bg-orange-900/40 text-orange-600 dark:text-orange-400",
    badge: "bg-orange-100 text-orange-600",
    bar: "bg-orange-500",
  },
  purple: {
    bg: "bg-purple-50 dark:bg-purple-900/20",
    border: "border-purple-200 dark:border-purple-800/40",
    icon: "bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400",
    badge: "bg-purple-100 text-purple-600",
    bar: "bg-purple-500",
  },
  blue: {
    bg: "bg-blue-50 dark:bg-blue-900/20",
    border: "border-blue-200 dark:border-blue-800/40",
    icon: "bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400",
    badge: "bg-blue-100 text-blue-600",
    bar: "bg-blue-500",
  },
};

const TYPE_LABELS = {
  sessions_finished: "حصص منتهية",
  sessions_low: "حصص قليلة",
  unpaid: "مدفوعات",
  absences: "غياب",
  homework: "واجبات",
};

export default function NotificationsPage() {
  const { students, attendance, payments, homework, fetchData } = useStore();
  const [filter, setFilter] = useState("all");
  const [dismissed, setDismissed] = useState(() => {
    if (typeof window === "undefined") return [];
    try {
      return JSON.parse(localStorage.getItem("dismissed_notifs") || "[]");
    } catch {
      return [];
    }
  });

  useEffect(() => {
    fetchData();
  }, []);

  const all = useMemo(
    () =>
      generateSmartNotifications(
        students,
        attendance,
        payments,
        homework || [],
      ),
    [students, attendance, payments, homework],
  );

  const visible = all.filter((n) => !dismissed.includes(n.id));

  const filtered = visible.filter((n) => {
    if (filter === "all") return true;
    if (filter === "high") return n.priority === "high";
    if (filter === "medium") return n.priority === "medium";
    return n.type === filter;
  });

  const dismiss = (id) => {
    const next = [...dismissed, id];
    setDismissed(next);
    localStorage.setItem("dismissed_notifs", JSON.stringify(next));
    toast.success("تم رفض الإشعار");
  };

  const dismissAll = () => {
    const next = [...dismissed, ...visible.map((n) => n.id)];
    setDismissed(next);
    localStorage.setItem("dismissed_notifs", JSON.stringify(next));
    toast.success("تم رفض كل الإشعارات");
  };

  const reset = () => {
    setDismissed([]);
    localStorage.removeItem("dismissed_notifs");
    toast.success("تم تحديث الإشعارات");
  };

  const highCount = visible.filter((n) => n.priority === "high").length;
  const medCount = visible.filter((n) => n.priority === "medium").length;

  const tabs = [
    { key: "all", label: `الكل (${visible.length})` },
    { key: "high", label: `🔴 عاجل (${highCount})` },
    { key: "medium", label: `🟠 متوسط (${medCount})` },
    { key: "sessions_finished", label: "حصص منتهية" },
    { key: "sessions_low", label: "حصص قليلة" },
    { key: "unpaid", label: "مدفوعات" },
    { key: "absences", label: "غياب" },
    { key: "homework", label: "واجبات" },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white flex items-center gap-3">
            <div className="relative w-12 h-12 bg-gradient-to-br from-red-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
              <Bell className="text-white" size={24} />
              {visible.length > 0 && (
                <span className="absolute -top-1.5 -left-1.5 min-w-[20px] h-5 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1 border-2 border-white dark:border-gray-900">
                  {visible.length > 9 ? "9+" : visible.length}
                </span>
              )}
            </div>
            الإشعارات الذكية
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1 text-sm">
            تنبيهات تلقائية تُولَّد من بيانات الطلاب الحالية
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={reset}
            className="flex items-center gap-2 px-4 py-2.5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-600 dark:text-gray-300 hover:bg-gray-50 transition-all text-sm"
          >
            <RefreshCw size={15} /> تحديث
          </button>
          {visible.length > 0 && (
            <button
              onClick={dismissAll}
              className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 dark:bg-gray-700 rounded-xl text-gray-600 dark:text-gray-300 hover:bg-gray-200 transition-all text-sm font-medium"
            >
              <CheckCheck size={15} /> رفض الكل
            </button>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {
            label: "إجمالي",
            value: visible.length,
            color: "text-gray-800 dark:text-white",
            bg: "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700",
          },
          {
            label: "عاجلة 🔴",
            value: highCount,
            color: "text-red-600",
            bg: "bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800/30",
          },
          {
            label: "متوسطة 🟠",
            value: medCount,
            color: "text-orange-500",
            bg: "bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-800/30",
          },
          {
            label: "منخفضة 🔵",
            value: visible.filter((n) => n.priority === "low").length,
            color: "text-blue-600",
            bg: "bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/30",
          },
        ].map((s) => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-5`}>
            <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {s.label}
            </p>
          </div>
        ))}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
              filter === tab.key
                ? "bg-blue-600 text-white shadow-md"
                : "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications */}
      {filtered.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-16 text-center"
        >
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
            <BellOff className="text-green-600" size={28} />
          </div>
          <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">
            لا توجد إشعارات
          </h3>
          <p className="text-gray-500 text-sm">
            {visible.length === 0
              ? "كل شيء على ما يرام! 🎉"
              : "لا توجد إشعارات في هذه الفئة."}
          </p>
        </motion.div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {filtered.map((n, idx) => {
              const Icon = n.icon;
              const c = COLORS[n.color];
              return (
                <motion.div
                  key={n.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20, height: 0 }}
                  transition={{ delay: idx * 0.04 }}
                  className={`relative flex items-start gap-4 p-5 rounded-2xl border ${c.bg} ${c.border} group`}
                >
                  {/* Priority bar */}
                  <div
                    className={`absolute right-0 top-0 bottom-0 w-1 rounded-r-2xl ${c.bar}`}
                  />

                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${c.icon}`}
                  >
                    <Icon size={20} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-gray-800 dark:text-white">
                          {n.title}
                        </h3>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full font-medium ${c.badge}`}
                        >
                          {n.priority === "high"
                            ? "عاجل"
                            : n.priority === "medium"
                              ? "متوسط"
                              : "منخفض"}
                        </span>
                        <span className="text-xs text-gray-400 bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded-full">
                          {TYPE_LABELS[n.type]}
                        </span>
                      </div>
                      <button
                        onClick={() => dismiss(n.id)}
                        className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-white dark:hover:bg-gray-700 rounded-lg transition-all opacity-0 group-hover:opacity-100 flex-shrink-0"
                      >
                        <X size={15} />
                      </button>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 leading-relaxed">
                      {n.message}
                    </p>
                    <a
                      href={n.href}
                      className={`inline-flex items-center gap-1.5 text-sm font-bold hover:underline ${c.icon.split(" ").find((cls) => cls.startsWith("text-"))}`}
                    >
                      {n.linkLabel} <ChevronRight size={14} />
                    </a>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Info */}
      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800/30 p-5">
        <div className="flex items-start gap-3">
          <Bell size={18} className="text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-blue-700 dark:text-blue-400 leading-relaxed">
            <strong>كيف تعمل الإشعارات:</strong> تتولد تلقائياً من بيانات الطلاب
            عند كل زيارة — طلاب انتهت أو قاربت حصصهم، لم يدفعوا هذا الشهر، لديهم
            غياب متكرر، أو واجبات انتهى موعدها.
          </p>
        </div>
      </div>
    </div>
  );
}
