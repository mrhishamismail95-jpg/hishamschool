"use client";
import { useEffect } from "react";

// /register now redirects to the main landing page at "/"
export default function RegisterRedirect() {
  useEffect(() => {
    window.location.replace("/");
  }, []);
  return (
    <div className="min-h-screen bg-[#0a2463] flex items-center justify-center">
      <div className="text-center text-white">
        <div
          className="w-10 h-10 border-4 border-[#f7b731] border-t-transparent rounded-full mx-auto mb-4"
          style={{ animation: "spin 0.8s linear infinite" }}
        />
        <p className="font-bold text-sm text-blue-200">جاري التوجيه...</p>
      </div>
      <style
        jsx
        global
      >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
