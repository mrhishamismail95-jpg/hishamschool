import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  Wallet,
  FileText,
  BookOpen,
  ClipboardList,
  Archive,
  PenTool,
  GraduationCap,
  UserCheck,
  ExternalLink,
} from "lucide-react";

export function QuickAccessGrid() {
  const LINKS = [
    {
      label: "الطلاب",
      icon: Users,
      href: "/students",
      color: "from-blue-500 to-cyan-600",
      desc: "إدارة بيانات الطلاب",
    },
    {
      label: "التحضير",
      icon: CalendarCheck,
      href: "/attendance",
      color: "from-green-500 to-emerald-600",
      desc: "تسجيل الحضور اليومي",
    },
    {
      label: "المالية",
      icon: Wallet,
      href: "/finances",
      color: "from-purple-500 to-violet-600",
      desc: "المدفوعات والاشتراكات",
    },
    {
      label: "الامتحانات",
      icon: FileText,
      href: "/exams",
      color: "from-orange-500 to-red-500",
      desc: "إدارة الامتحانات والدرجات",
    },
    {
      label: "الواجبات",
      icon: BookOpen,
      href: "/homework",
      color: "from-pink-500 to-rose-600",
      desc: "تتبع الواجبات والتسليم",
    },
    {
      label: "الجدول",
      icon: ClipboardList,
      href: "/schedule",
      color: "from-teal-500 to-cyan-600",
      desc: "جدول المجموعات الأسبوعي",
    },
    {
      label: "الأرشيف",
      icon: Archive,
      href: "/archive",
      color: "from-emerald-600 to-teal-700",
      desc: "مكتبة المصادر و Drive",
    },
    {
      label: "بوابة المعلم",
      icon: GraduationCap,
      href: "/teacher",
      color: "from-violet-600 to-purple-700",
      desc: "لوحة تحكم المعلم",
    },
    {
      label: "بوابة الطالب",
      icon: Users,
      href: "/student",
      color: "from-sky-500 to-blue-600",
      desc: "بوابة الطالب الشخصية",
    },
    {
      label: "التسجيل العام",
      icon: UserCheck,
      href: "/",
      color: "from-yellow-500 to-orange-500",
      desc: "الصفحة الرئيسية والتسجيل",
    },
    {
      label: "لوحة القيادة",
      icon: LayoutDashboard,
      href: "/dashboard",
      color: "from-gray-600 to-gray-700",
      desc: "الإحصائيات العامة",
    },
  ];

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
        <h3 className="font-bold text-gray-800 text-base flex items-center gap-2">
          <LayoutDashboard size={18} className="text-blue-600" /> الوصول السريع
          لجميع الأقسام
        </h3>
        <a
          href="/dashboard"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-xs text-blue-600 font-bold hover:underline"
        >
          النظام الرئيسي <ExternalLink size={12} />
        </a>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 p-4">
        {LINKS.map(({ label, icon: Icon, href, color, desc }) => (
          <a
            key={href}
            href={href}
            className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 hover:border-gray-200 hover:shadow-md transition-all group bg-gray-50 hover:bg-white"
          >
            <div
              className={`w-10 h-10 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-md group-hover:scale-110 transition-all`}
            >
              <Icon size={18} className="text-white" />
            </div>
            <div className="min-w-0">
              <p className="font-bold text-gray-800 text-sm truncate">
                {label}
              </p>
              <p className="text-[11px] text-gray-400 truncate">{desc}</p>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
