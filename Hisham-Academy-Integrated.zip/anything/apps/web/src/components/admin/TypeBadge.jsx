export function TypeBadge({ type }) {
  const map = {
    student: { label: "طالب", cls: "bg-blue-100 text-blue-700" },
    teacher: { label: "مدرس", cls: "bg-purple-100 text-purple-700" },
    parent: { label: "ولي أمر", cls: "bg-green-100 text-green-700" },
  };
  const { label, cls } = map[type] || {
    label: type,
    cls: "bg-gray-100 text-gray-600",
  };
  return (
    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${cls}`}>
      {label}
    </span>
  );
}
