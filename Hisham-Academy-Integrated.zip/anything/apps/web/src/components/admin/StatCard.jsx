export function StatCard({ label, value, icon: Icon, color, bg }) {
  return (
    <div className={`${bg} rounded-2xl p-5 flex items-center gap-4`}>
      <div
        className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center flex-shrink-0 text-white shadow-md`}
      >
        <Icon size={24} />
      </div>
      <div>
        <p className="text-3xl font-bold text-gray-800">{value}</p>
        <p className="text-xs text-gray-500 mt-0.5">{label}</p>
      </div>
    </div>
  );
}
