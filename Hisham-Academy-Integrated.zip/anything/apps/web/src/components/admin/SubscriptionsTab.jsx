import { useState, useEffect } from "react";
import {
  Users,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  RefreshCw,
  Search,
  Shield,
  ChevronDown,
  TrendingDown,
  Bell,
} from "lucide-react";

/* ── helpers ── */
function daysLeft(dateStr) {
  if (!dateStr) return null;
  const diff = new Date(dateStr) - new Date();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

function ExpiryBadge({ days }) {
  if (days === null) return <span className="text-xs text-gray-400">—</span>;
  if (days < 0)
    return (
      <span className="flex items-center gap-1 text-xs font-bold text-red-500 bg-red-50 px-2 py-0.5 rounded-full">
        <XCircle size={11} />
        منتهي
      </span>
    );
  if (days <= 3)
    return (
      <span className="flex items-center gap-1 text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-full">
        <AlertTriangle size={11} />
        ينتهي خلال {days}د
      </span>
    );
  if (days <= 7)
    return (
      <span className="flex items-center gap-1 text-xs font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">
        <AlertTriangle size={11} />
        {days} أيام
      </span>
    );
  if (days <= 30)
    return (
      <span className="flex items-center gap-1 text-xs font-bold text-yellow-600 bg-yellow-50 px-2 py-0.5 rounded-full">
        <Clock size={11} />
        {days} يوم
      </span>
    );
  return (
    <span className="flex items-center gap-1 text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
      <CheckCircle2 size={11} />
      {days} يوم
    </span>
  );
}

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("ar-EG", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

/* ══════════════════════════════
   Student Subscriptions
══════════════════════════════ */
function StudentSubs() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all"); // all | expired | critical | warning | ok

  useEffect(() => {
    fetch("/api/admins/financial-reports")
      .then((r) => r.json())
      .then((d) => setStudents(d.students || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const enriched = students.map((s) => ({
    ...s,
    remainingSessions: (s.session_package || 8) - (s.sessions_used || 0),
    remaining: Number(s.remaining || 0),
    totalPaid: Number(s.total_paid || 0),
    totalDue: Number(s.total_due || 0),
  }));

  const expiredSubs = enriched.filter((s) => s.remainingSessions <= 0);
  const criticalSubs = enriched.filter(
    (s) => s.remainingSessions > 0 && s.remainingSessions <= 2,
  );
  const warningSubs = enriched.filter(
    (s) => s.remainingSessions > 2 && s.remainingSessions <= 4,
  );
  const unpaid = enriched.filter((s) => s.remaining > 0);

  const filtered = enriched.filter((s) => {
    const q = search.toLowerCase();
    const matchSearch =
      !q || s.name?.toLowerCase().includes(q) || s.grade?.includes(q);
    if (filter === "expired") return matchSearch && s.remainingSessions <= 0;
    if (filter === "critical")
      return matchSearch && s.remainingSessions > 0 && s.remainingSessions <= 2;
    if (filter === "warning")
      return matchSearch && s.remainingSessions > 2 && s.remainingSessions <= 4;
    if (filter === "unpaid") return matchSearch && s.remaining > 0;
    return matchSearch;
  });

  if (loading)
    return (
      <div className="text-center py-12 text-gray-400">جاري التحميل...</div>
    );

  return (
    <div className="space-y-5">
      {/* Alert cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            key: "expired",
            label: "اشتراك منتهي",
            count: expiredSubs.length,
            color: "bg-red-50 border-red-200 text-red-700",
            icon: <XCircle size={16} className="text-red-500" />,
          },
          {
            key: "critical",
            label: "ينتهي قريباً (≤2)",
            count: criticalSubs.length,
            color: "bg-orange-50 border-orange-200 text-orange-700",
            icon: <AlertTriangle size={16} className="text-orange-500" />,
          },
          {
            key: "warning",
            label: "تحذير (3-4 حصص)",
            count: warningSubs.length,
            color: "bg-yellow-50 border-yellow-200 text-yellow-700",
            icon: <Clock size={16} className="text-yellow-600" />,
          },
          {
            key: "unpaid",
            label: "مديونية مالية",
            count: unpaid.length,
            color: "bg-blue-50 border-blue-200 text-blue-700",
            icon: <TrendingDown size={16} className="text-blue-500" />,
          },
        ].map((c) => (
          <button
            key={c.key}
            onClick={() => setFilter(filter === c.key ? "all" : c.key)}
            className={`p-4 rounded-2xl border-2 text-right transition-all ${c.color} ${filter === c.key ? "ring-2 ring-offset-1 ring-current" : "hover:opacity-80"}`}
          >
            <div className="flex items-center justify-between mb-2">
              {c.icon}
              <span className="text-2xl font-black">{c.count}</span>
            </div>
            <p className="text-xs font-semibold">{c.label}</p>
          </button>
        ))}
      </div>

      {/* Search + Filter */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search
            size={15}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400"
          />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم أو الصف..."
            className="w-full pr-10 pl-4 py-2.5 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-400 focus:outline-none text-sm text-right"
            dir="rtl"
          />
        </div>
        {filter !== "all" && (
          <button
            onClick={() => setFilter("all")}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-xl text-xs font-bold"
          >
            <XCircle size={14} /> إلغاء الفلتر
          </button>
        )}
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-black text-gray-900">
            اشتراكات الطلاب ({filtered.length})
          </h3>
          <RefreshCw
            size={16}
            className="text-gray-400 cursor-pointer hover:text-blue-500 transition-colors"
            onClick={() => {
              setLoading(true);
              fetch("/api/admins/financial-reports")
                .then((r) => r.json())
                .then((d) => setStudents(d.students || []))
                .finally(() => setLoading(false));
            }}
          />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right" dir="rtl">
            <thead className="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
              <tr>
                {[
                  "الطالب",
                  "الصف",
                  "المجموعة",
                  "الحصص المتبقية",
                  "المدفوع",
                  "المديونية",
                ].map((h) => (
                  <th key={h} className="px-4 py-3">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.length === 0 ? (
                <tr>
                  <td
                    colSpan={6}
                    className="px-4 py-10 text-center text-gray-400 text-sm"
                  >
                    لا توجد نتائج
                  </td>
                </tr>
              ) : (
                filtered.map((s) => {
                  const pct =
                    s.session_package > 0
                      ? Math.round(
                          (s.remainingSessions / s.session_package) * 100,
                        )
                      : 0;
                  const rowBg =
                    s.remainingSessions <= 0
                      ? "bg-red-50/50"
                      : s.remainingSessions <= 2
                        ? "bg-orange-50/40"
                        : "";
                  return (
                    <tr
                      key={s.id}
                      className={`hover:bg-gray-50 transition-colors ${rowBg}`}
                    >
                      <td className="px-4 py-3">
                        <div className="font-semibold text-sm text-gray-900">
                          {s.name}
                        </div>
                        <div className="text-xs text-gray-400">
                          {s.code || ""}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {s.grade || "—"}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {s.group_name || "—"}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 max-w-20 bg-gray-200 rounded-full h-1.5">
                            <div
                              className={`h-1.5 rounded-full transition-all ${pct > 50 ? "bg-green-500" : pct > 25 ? "bg-yellow-500" : "bg-red-500"}`}
                              style={{ width: `${Math.max(0, pct)}%` }}
                            />
                          </div>
                          <span
                            className={`text-xs font-black ${s.remainingSessions <= 0 ? "text-red-600" : s.remainingSessions <= 2 ? "text-orange-600" : "text-gray-700"}`}
                          >
                            {s.remainingSessions}/{s.session_package || 8}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm font-bold text-green-700">
                        {s.totalPaid.toLocaleString()} ج.م
                      </td>
                      <td className="px-4 py-3">
                        {s.remaining > 0 ? (
                          <span className="text-xs font-black text-red-600">
                            {s.remaining.toLocaleString()} ج.م
                          </span>
                        ) : (
                          <span className="text-xs font-bold text-green-600">
                            ✓ مسدد
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════
   Admin Subscriptions
══════════════════════════════ */
function AdminSubs({ currentAdmin }) {
  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    fetch("/api/admins")
      .then((r) => r.json())
      .then((d) => setAdmins(d.admins || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const enriched = admins.map((a) => ({
    ...a,
    days: daysLeft(a.subscription_end),
  }));

  const expired = enriched.filter((a) => a.days !== null && a.days < 0);
  const critical = enriched.filter(
    (a) => a.days !== null && a.days >= 0 && a.days <= 7,
  );
  const warning = enriched.filter(
    (a) => a.days !== null && a.days > 7 && a.days <= 30,
  );
  const ok = enriched.filter((a) => !a.subscription_end || a.days > 30);

  const filtered = enriched.filter((a) => {
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      a.name?.toLowerCase().includes(q) ||
      a.phone?.includes(q) ||
      a.code?.includes(q);
    if (filter === "expired")
      return matchSearch && a.days !== null && a.days < 0;
    if (filter === "critical")
      return matchSearch && a.days !== null && a.days >= 0 && a.days <= 7;
    if (filter === "warning")
      return matchSearch && a.days !== null && a.days > 7 && a.days <= 30;
    if (filter === "ok")
      return matchSearch && (!a.subscription_end || a.days > 30);
    return matchSearch;
  });

  if (loading)
    return (
      <div className="text-center py-12 text-gray-400">جاري التحميل...</div>
    );

  return (
    <div className="space-y-5">
      {/* Alert cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            key: "expired",
            label: "اشتراك منتهي",
            count: expired.length,
            icon: <XCircle size={16} className="text-red-500" />,
            color: "bg-red-50 border-red-200 text-red-700",
          },
          {
            key: "critical",
            label: "ينتهي خلال 7 أيام",
            count: critical.length,
            icon: <AlertTriangle size={16} className="text-orange-500" />,
            color: "bg-orange-50 border-orange-200 text-orange-700",
          },
          {
            key: "warning",
            label: "ينتهي خلال 30 يوم",
            count: warning.length,
            icon: <Bell size={16} className="text-yellow-600" />,
            color: "bg-yellow-50 border-yellow-200 text-yellow-700",
          },
          {
            key: "ok",
            label: "اشتراك سليم",
            count: ok.length,
            icon: <CheckCircle2 size={16} className="text-green-500" />,
            color: "bg-green-50 border-green-200 text-green-700",
          },
        ].map((c) => (
          <button
            key={c.key}
            onClick={() => setFilter(filter === c.key ? "all" : c.key)}
            className={`p-4 rounded-2xl border-2 text-right transition-all ${c.color} ${filter === c.key ? "ring-2 ring-offset-1 ring-current" : "hover:opacity-80"}`}
          >
            <div className="flex items-center justify-between mb-2">
              {c.icon}
              <span className="text-2xl font-black">{c.count}</span>
            </div>
            <p className="text-xs font-semibold">{c.label}</p>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search
          size={15}
          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400"
        />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث بالاسم أو الهاتف أو الكود..."
          className="w-full pr-10 pl-4 py-2.5 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-400 focus:outline-none text-sm text-right"
          dir="rtl"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h3 className="font-black text-gray-900">
            اشتراكات الإداريين ({filtered.length})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right" dir="rtl">
            <thead className="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
              <tr>
                {[
                  "الإداري",
                  "الهاتف",
                  "الدور",
                  "نوع الاشتراك",
                  "تاريخ البداية",
                  "تاريخ الانتهاء",
                  "المتبقي",
                  "الحالة",
                ].map((h) => (
                  <th key={h} className="px-4 py-3">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.length === 0 ? (
                <tr>
                  <td
                    colSpan={8}
                    className="px-4 py-10 text-center text-gray-400 text-sm"
                  >
                    لا توجد نتائج
                  </td>
                </tr>
              ) : (
                filtered.map((a) => {
                  const rowBg =
                    a.days !== null && a.days < 0
                      ? "bg-red-50/40"
                      : a.days !== null && a.days <= 7
                        ? "bg-orange-50/30"
                        : "";
                  return (
                    <tr
                      key={a.id}
                      className={`hover:bg-gray-50 transition-colors ${rowBg}`}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black flex-shrink-0 ${
                              a.role === "superadmin"
                                ? "bg-purple-100 text-purple-700"
                                : "bg-blue-100 text-blue-700"
                            }`}
                          >
                            {a.name?.[0] || "?"}
                          </div>
                          <div>
                            <div className="font-semibold text-sm text-gray-900">
                              {a.name}
                            </div>
                            <div className="text-xs text-gray-400 font-mono">
                              {a.code}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 font-mono">
                        {a.phone}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                            a.role === "superadmin"
                              ? "bg-purple-100 text-purple-700"
                              : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {a.role === "superadmin" ? "🛡️ مدير" : "👤 إداري"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500">
                        {a.subscription_type === "monthly"
                          ? "شهري"
                          : a.subscription_type === "yearly"
                            ? "سنوي"
                            : "—"}
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-400">
                        {fmtDate(a.subscription_start)}
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500">
                        {fmtDate(a.subscription_end)}
                      </td>
                      <td className="px-4 py-3">
                        <ExpiryBadge days={a.days} />
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                            a.is_active
                              ? "bg-green-100 text-green-700"
                              : "bg-red-100 text-red-600"
                          }`}
                        >
                          {a.is_active ? "نشط" : "موقف"}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════
   Main Export
══════════════════════════════ */
export function SubscriptionsTab({ currentAdmin }) {
  const [sub, setSub] = useState("students"); // students | admins

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-black text-gray-900">
            الاشتراكات والإنذارات
          </h2>
          <p className="text-sm text-gray-500">
            متابعة انتهاء اشتراكات الطلاب والإداريين
          </p>
        </div>
        <div className="flex bg-gray-100 rounded-xl p-1">
          {[
            { key: "students", label: "🎓 الطلاب" },
            { key: "admins", label: "🛡️ الإداريون" },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setSub(t.key)}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                sub === t.key
                  ? "bg-white shadow text-gray-900"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {sub === "students" ? (
        <StudentSubs />
      ) : (
        <AdminSubs currentAdmin={currentAdmin} />
      )}
    </div>
  );
}
