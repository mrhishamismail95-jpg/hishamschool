import { useState, useEffect } from "react";
import { Trash2, Plus, ExternalLink, RefreshCw } from "lucide-react";
import { toast } from "sonner";

// ── helpers ───────────────────────────────────────────────────────────────────
async function fetchSettings() {
  const [settRes, pkgRes] = await Promise.all([
    fetch("/api/academy/settings").then((r) => r.json()),
    fetch("/api/academy/packages").then((r) => r.json()),
  ]);
  return { settings: settRes.settings || {}, packages: pkgRes.packages || [] };
}

async function saveToApi(settingsObj) {
  const res = await fetch("/api/academy/settings", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ settings: settingsObj }),
  });
  if (!res.ok) throw new Error("فشل الحفظ");
}

export function PortalSettingsTab() {
  const [settings, setSettings] = useState({});
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newPkg, setNewPkg] = useState({
    name: "",
    sessions_count: "8",
    price: "",
    discount: "0",
    description: "",
  });
  const [newLink, setNewLink] = useState({ label: "", url: "", public: true });
  const [links, setLinks] = useState([]);

  useEffect(() => {
    setLoading(true);
    fetchSettings()
      .then(({ settings: s, packages: p }) => {
        setSettings(s);
        setPackages(p);
        try {
          setLinks(JSON.parse(s.links_json || "[]"));
        } catch {
          setLinks([]);
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const save = async (updates) => {
    try {
      await saveToApi(updates);
      setSettings((s) => ({ ...s, ...updates }));
      toast.success("تم الحفظ ✅");
    } catch {
      toast.error("فشل الحفظ");
    }
  };

  const reg = settings.registration_open !== "false";
  const portalTeacher = settings.portal_teacher !== "false";
  const portalStudent = settings.portal_student !== "false";
  const portalParent = settings.portal_parent !== "false";

  const toggleReg = () => save({ registration_open: reg ? "false" : "true" });
  const togglePortal = (key) => {
    const cur = settings[key] !== "false";
    save({ [key]: cur ? "false" : "true" });
  };

  const addPackage = async () => {
    if (!newPkg.name || !newPkg.price) return;
    try {
      const res = await fetch("/api/academy/packages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newPkg.name,
          sessionsCount: Number(newPkg.sessions_count) || 8,
          price: Number(newPkg.price),
          discount: Number(newPkg.discount) || 0,
          description: newPkg.description,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setPackages((p) => [...p, data.package]);
      setNewPkg({
        name: "",
        sessions_count: "8",
        price: "",
        discount: "0",
        description: "",
      });
      toast.success("تم إضافة الباقة ✅");
    } catch {
      toast.error("فشل الإضافة");
    }
  };

  const deletePackage = async (id) => {
    try {
      await fetch(`/api/academy/packages/${id}`, { method: "DELETE" });
      setPackages((p) => p.filter((x) => x.id !== id));
      toast.info("تم حذف الباقة");
    } catch {
      toast.error("فشل الحذف");
    }
  };

  const saveLinks = async (updatedLinks) => {
    setLinks(updatedLinks);
    await save({ links_json: JSON.stringify(updatedLinks) });
  };
  const addLink = () => {
    if (!newLink.label || !newLink.url) return;
    const updated = [...links, { id: Date.now(), ...newLink }];
    saveLinks(updated);
    setNewLink({ label: "", url: "", public: true });
  };
  const deleteLink = (id) => saveLinks(links.filter((l) => l.id !== id));

  const inp =
    "w-full px-3 py-2.5 border-2 border-gray-200 rounded-xl text-sm focus:border-blue-400 focus:outline-none transition-all";

  if (loading)
    return (
      <div className="flex items-center justify-center py-20">
        <div
          className="w-10 h-10 border-4 border-blue-400 border-t-transparent rounded-full"
          style={{ animation: "spin 0.8s linear infinite" }}
        />
        <style
          jsx
          global
        >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );

  return (
    <div className="space-y-6" dir="rtl">
      {/* Portal Locks */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="font-black text-gray-800 text-lg mb-5">
          🔐 التحكم في البوابات والتسجيل
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div
            className={`flex items-center justify-between p-4 rounded-2xl border-2 ${reg ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}`}
          >
            <div>
              <p className="font-black text-gray-800">📝 التسجيل الجديد</p>
              <p
                className={`text-xs ${reg ? "text-green-600" : "text-red-500"}`}
              >
                {reg ? "مفتوح للعموم" : "مغلق — لا يمكن التسجيل"}
              </p>
            </div>
            <button
              onClick={toggleReg}
              className={`px-4 py-2 rounded-xl font-black text-sm transition-all ${reg ? "bg-green-500 text-white" : "bg-red-500 text-white"}`}
            >
              {reg ? "🟢 مفتوح" : "🔴 مغلق"}
            </button>
          </div>
          {[
            {
              key: "portal_teacher",
              label: "بوابة المعلم",
              icon: "📚",
              open: portalTeacher,
            },
            {
              key: "portal_student",
              label: "بوابة الطالب",
              icon: "🎓",
              open: portalStudent,
            },
            {
              key: "portal_parent",
              label: "بوابة ولي الأمر",
              icon: "👨‍👩‍👧",
              open: portalParent,
            },
          ].map(({ key, label, icon, open }) => (
            <div
              key={key}
              className={`flex items-center justify-between p-4 rounded-2xl border-2 ${open ? "bg-blue-50 border-blue-200" : "bg-gray-100 border-gray-200"}`}
            >
              <div>
                <p className="font-black text-gray-800">
                  {icon} {label}
                </p>
                <p
                  className={`text-xs ${open ? "text-blue-600" : "text-gray-500"}`}
                >
                  {open ? "مفتوحة للمستخدمين" : "مغلقة مؤقتاً"}
                </p>
              </div>
              <button
                onClick={() => togglePortal(key)}
                className={`px-4 py-2 rounded-xl font-black text-sm transition-all ${open ? "bg-blue-500 text-white" : "bg-gray-400 text-white"}`}
              >
                {open ? "🟢 مفتوح" : "🔴 مغلق"}
              </button>
            </div>
          ))}
        </div>
        <div className="mt-4 bg-yellow-50 border border-yellow-100 rounded-xl p-4">
          <p className="text-xs text-yellow-700 font-bold">
            💡 المدير يدخل أي بوابة بغض النظر عن حالة القفل — القفل مؤثر على
            الطلاب والمعلمين فقط
          </p>
        </div>
      </div>

      {/* Packages */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="font-black text-gray-800 text-lg mb-5">
          💰 الباقات التعليمية (مزامنة مع قاعدة البيانات)
        </h3>
        <div className="space-y-3 mb-5">
          {packages.map((pkg) => (
            <div
              key={pkg.id}
              className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl border border-gray-200"
            >
              <div className="flex-1">
                <p className="font-black text-gray-800">{pkg.name}</p>
                <p className="text-sm text-blue-600">
                  {pkg.price} ج.م · {pkg.sessions_count} حصة
                  {pkg.discount > 0 && (
                    <span className="text-red-500 text-xs mr-2">
                      · وفر {pkg.discount} ج
                    </span>
                  )}
                </p>
                {pkg.description && (
                  <p className="text-xs text-gray-400">{pkg.description}</p>
                )}
              </div>
              <button
                onClick={() => deletePackage(pkg.id)}
                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
          {packages.length === 0 && (
            <p className="text-gray-400 text-sm text-center py-4">
              لا توجد باقات — أضف الأولى أدناه
            </p>
          )}
        </div>
        <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200 space-y-3">
          <p className="font-bold text-gray-700 text-sm">+ إضافة باقة جديدة</p>
          <div className="grid grid-cols-2 gap-3">
            <input
              className={inp}
              placeholder="اسم الباقة *"
              value={newPkg.name}
              onChange={(e) =>
                setNewPkg((p) => ({ ...p, name: e.target.value }))
              }
            />
            <input
              className={inp}
              placeholder="عدد الحصص"
              type="number"
              value={newPkg.sessions_count}
              onChange={(e) =>
                setNewPkg((p) => ({ ...p, sessions_count: e.target.value }))
              }
            />
            <input
              className={inp}
              placeholder="السعر (ج.م) *"
              type="number"
              value={newPkg.price}
              onChange={(e) =>
                setNewPkg((p) => ({ ...p, price: e.target.value }))
              }
            />
            <input
              className={inp}
              placeholder="الخصم (اختياري)"
              type="number"
              value={newPkg.discount}
              onChange={(e) =>
                setNewPkg((p) => ({ ...p, discount: e.target.value }))
              }
            />
          </div>
          <input
            className={inp}
            placeholder="وصف الباقة (اختياري)"
            value={newPkg.description}
            onChange={(e) =>
              setNewPkg((p) => ({ ...p, description: e.target.value }))
            }
          />
          <button
            onClick={addPackage}
            className="w-full py-3 bg-[#0a2463] text-white rounded-xl font-black text-sm hover:bg-[#0d2d7a] transition-all flex items-center justify-center gap-2"
          >
            <Plus size={16} /> إضافة الباقة
          </button>
        </div>
      </div>

      {/* Links */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="font-black text-gray-800 text-lg mb-5">
          🔗 الروابط المهمة
        </h3>
        <div className="space-y-3 mb-5">
          {links.map((link) => (
            <div
              key={link.id}
              className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl border border-gray-200"
            >
              <div className="flex-1 min-w-0">
                <p className="font-black text-gray-800 truncate">
                  {link.label}
                </p>
                <p className="text-xs text-blue-600 truncate font-mono">
                  {link.url}
                </p>
                <span
                  className={`text-[10px] font-bold ${link.public ? "text-green-600" : "text-gray-400"}`}
                >
                  {link.public ? "🌐 ظاهر للعموم" : "🔒 داخلي فقط"}
                </span>
              </div>
              <a
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 text-blue-400 hover:bg-blue-50 rounded-lg"
              >
                <ExternalLink size={15} />
              </a>
              <button
                onClick={() => deleteLink(link.id)}
                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
          {links.length === 0 && (
            <p className="text-gray-400 text-sm text-center py-4">
              لا توجد روابط بعد
            </p>
          )}
        </div>
        <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200 space-y-3">
          <p className="font-bold text-gray-700 text-sm">+ إضافة رابط</p>
          <input
            className={inp}
            placeholder="اسم الرابط *"
            value={newLink.label}
            onChange={(e) =>
              setNewLink((p) => ({ ...p, label: e.target.value }))
            }
          />
          <input
            className={inp}
            placeholder="الرابط https://... *"
            value={newLink.url}
            onChange={(e) => setNewLink((p) => ({ ...p, url: e.target.value }))}
          />
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={newLink.public}
              onChange={(e) =>
                setNewLink((p) => ({ ...p, public: e.target.checked }))
              }
              className="w-4 h-4 accent-blue-600"
            />
            <span className="text-sm text-gray-600">
              ظاهر للعموم في الصفحة الرئيسية
            </span>
          </label>
          <button
            onClick={addLink}
            className="w-full py-3 bg-[#0a2463] text-white rounded-xl font-black text-sm hover:bg-[#0d2d7a] transition-all flex items-center justify-center gap-2"
          >
            <Plus size={16} /> إضافة الرابط
          </button>
        </div>
      </div>

      {/* Academy Info */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="font-black text-gray-800 text-lg mb-5">
          🏫 معلومات الأكاديمية
        </h3>
        <div className="space-y-4">
          {[
            {
              key: "academy_name",
              label: "اسم الأكاديمية",
              placeholder: "Hisham Academy",
            },
            {
              key: "admin_phone",
              label: "رقم الواتساب/تيليجرام (بدون +)",
              placeholder: "201550012054",
            },
            {
              key: "whatsapp_group",
              label: "رابط مجموعة الواتساب",
              placeholder: "https://chat.whatsapp.com/...",
            },
            {
              key: "telegram_channel",
              label: "رابط قناة تيليجرام",
              placeholder: "https://t.me/...",
            },
          ].map(({ key, label, placeholder }) => (
            <div key={key}>
              <label className="block text-xs font-bold text-gray-500 mb-1.5">
                {label}
              </label>
              <input
                className={inp}
                placeholder={placeholder}
                value={settings[key] || ""}
                onChange={(e) =>
                  setSettings((s) => ({ ...s, [key]: e.target.value }))
                }
              />
            </div>
          ))}
          <button
            onClick={() =>
              save({
                academy_name: settings.academy_name,
                admin_phone: settings.admin_phone,
                whatsapp_group: settings.whatsapp_group,
                telegram_channel: settings.telegram_channel,
              })
            }
            className="w-full py-3 bg-green-600 text-white rounded-xl font-black text-sm hover:bg-green-700 transition-all"
          >
            💾 حفظ معلومات الأكاديمية
          </button>
        </div>
      </div>
    </div>
  );
}
