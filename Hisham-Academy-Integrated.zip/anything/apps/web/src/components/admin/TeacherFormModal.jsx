import { useState } from "react";
import { motion } from "motion/react";
import { BookOpen } from "lucide-react";
import { toast } from "sonner";

export function TeacherFormModal({ teacher, onClose, onSave }) {
  const [form, setForm] = useState({
    name: teacher?.name || "",
    phone: teacher?.phone || "",
    subject: teacher?.subject || "",
    email: teacher?.email || "",
    password: teacher?.password || "",
    groups: teacher?.groups || "",
    notes: teacher?.notes || "",
  });
  const [showPass, setShowPass] = useState(false);
  const upd = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const iCls =
    "w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-purple-500 focus:outline-none text-sm transition-all";

  const handle = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      toast.error("الاسم ورقم الهاتف مطلوبان");
      return;
    }
    if (!form.email.trim() || !form.password.trim()) {
      toast.error("البريد وكلمة المرور مطلوبان لتسجيل الدخول");
      return;
    }
    if (form.password.length < 6) {
      toast.error("كلمة المرور 6 أحرف على الأقل");
      return;
    }
    onSave({
      ...form,
      id: teacher?.id || Date.now(),
      addedAt: teacher?.addedAt || new Date().toISOString(),
    });
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.9 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl p-7 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 bg-purple-100 rounded-xl flex items-center justify-center">
            <BookOpen size={22} className="text-purple-600" />
          </div>
          <h3 className="text-xl font-bold text-gray-800">
            {teacher ? "تعديل بيانات المدرس" : "إضافة مدرس جديد"}
          </h3>
        </div>
        <form onSubmit={handle} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
                الاسم الكامل *
              </label>
              <input
                value={form.name}
                onChange={(e) => upd("name", e.target.value)}
                className={iCls}
                placeholder="أ. محمد أحمد"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
                رقم الهاتف / واتساب *
              </label>
              <input
                value={form.phone}
                onChange={(e) => upd("phone", e.target.value)}
                className={iCls}
                placeholder="01xxxxxxxxx"
                type="tel"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              المادة
            </label>
            <input
              value={form.subject}
              onChange={(e) => upd("subject", e.target.value)}
              className={iCls}
              placeholder="الرياضيات، الفيزياء..."
            />
          </div>
          <div className="bg-purple-50 border border-purple-100 rounded-2xl p-4 space-y-3">
            <p className="text-xs font-bold text-purple-700">
              🔐 بيانات دخول بوابة المعلم
            </p>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
                البريد الإلكتروني *
              </label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => upd("email", e.target.value)}
                className={iCls}
                placeholder="teacher@school.com"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
                كلمة المرور *
              </label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => upd("password", e.target.value)}
                  className={iCls}
                  placeholder="6 أحرف على الأقل"
                />
                <button
                  type="button"
                  onClick={() => setShowPass((v) => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"
                >
                  {showPass ? "🙈" : "👁️"}
                </button>
              </div>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              المجموعات / الفصول
            </label>
            <input
              value={form.groups}
              onChange={(e) => upd("groups", e.target.value)}
              className={iCls}
              placeholder="مجموعة السبت، مجموعة الأحد..."
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">
              ملاحظات
            </label>
            <textarea
              value={form.notes}
              onChange={(e) => upd("notes", e.target.value)}
              className={`${iCls} h-16 resize-none`}
              placeholder="أي ملاحظات..."
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 py-3.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold transition-all"
            >
              {teacher ? "حفظ التعديلات" : "إضافة المدرس"}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3.5 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200"
            >
              إلغاء
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
