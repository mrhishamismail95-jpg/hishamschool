import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  Plus,
  Search,
  Phone,
  Mail,
  Users,
  BookOpen,
  Edit2,
  Trash2,
  Shield,
} from "lucide-react";
import { toast } from "sonner";
import { TeacherFormModal } from "./TeacherFormModal";
import { WAIconAdmin } from "./WAIcon";

export function TeachersTab() {
  const [teachers, setTeachers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const loadTeachers = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/academy/teachers");
      const data = await res.json();
      setTeachers(data.teachers || []);
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    loadTeachers();
  }, []);

  const saveTeacher = async (formData) => {
    try {
      let res, data;
      if (editingTeacher) {
        res = await fetch(`/api/academy/teachers/${editingTeacher.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: formData.name,
            phone: formData.phone,
            subject: formData.subject,
            groupsAssigned: formData.groups,
            notes: formData.notes,
            newPassword: formData.password || undefined,
          }),
        });
        data = await res.json();
        if (res.ok) {
          toast.success("تم تحديث بيانات المدرس ✅");
          loadTeachers();
        } else toast.error(data.error || "فشل التحديث");
      } else {
        res = await fetch("/api/academy/teachers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: formData.name,
            phone: formData.phone,
            subject: formData.subject,
            groupsAssigned: formData.groups,
            notes: formData.notes,
            status: "active",
            customEmail: formData.email || undefined,
            customPassword: formData.password || undefined,
          }),
        });
        data = await res.json();
        if (res.ok) {
          toast.success(
            `تم إضافة ${formData.name} 🎉\nكلمة المرور: ${data.plainPassword}`,
            { duration: 8000 },
          );
          loadTeachers();
        } else if (res.status === 409) {
          toast.error(`البريد مستخدم — جرّب: ${data.suggestedEmail}`);
        } else {
          toast.error(data.error || "فشل الإضافة");
        }
      }
    } catch {
      toast.error("خطأ في الاتصال");
    }
    setEditingTeacher(null);
  };

  const deleteTeacher = async (id) => {
    if (!confirm("هل أنت متأكد من حذف هذا المدرس؟")) return;
    try {
      await fetch(`/api/academy/teachers/${id}`, { method: "DELETE" });
      setTeachers((t) => t.filter((x) => x.id !== id));
      toast.info("تم حذف المدرس");
    } catch {
      toast.error("فشل الحذف");
    }
  };

  const approveTeacher = async (id, name) => {
    try {
      await fetch(`/api/academy/teachers/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "active" }),
      });
      loadTeachers();
      toast.success(`✅ تم تفعيل حساب ${name}`);
    } catch {
      toast.error("فشل التفعيل");
    }
  };

  const sendWA = (t) => {
    const msg = `السلام عليكم أستاذ ${t.name}،\n\nبيانات دخول بوابة المعلم:\n🌐 الرابط: ${typeof window !== "undefined" ? window.location.origin : ""}/teacher\n📧 البريد: ${t.email}\n\nتواصل مع الإدارة إذا نسيت كلمة المرور\n\nمع تحيات الإدارة`;
    window.open(
      `https://wa.me/2${String(t.phone || "").replace(/^0/, "")}?text=${encodeURIComponent(msg)}`,
      "_blank",
    );
  };

  const filtered = teachers.filter((t) => {
    const q = search.toLowerCase();
    return (
      !q ||
      t.name?.toLowerCase().includes(q) ||
      t.subject?.toLowerCase().includes(q) ||
      t.phone?.includes(q) ||
      t.email?.includes(q)
    );
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">إدارة المدرسين</h2>
          <p className="text-sm text-gray-500">
            البيانات محفوظة في قاعدة البيانات — متزامنة على جميع الأجهزة
          </p>
        </div>
        <button
          onClick={() => {
            setEditingTeacher(null);
            setShowForm(true);
          }}
          className="flex items-center gap-2 px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold text-sm transition-all shadow-md"
        >
          <Plus size={18} /> إضافة مدرس جديد
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          {
            label: "إجمالي المدرسين",
            val: teachers.length,
            c: "text-purple-600",
            bg: "bg-purple-50 border-purple-100",
          },
          {
            label: "نشطون",
            val: teachers.filter((t) => t.status === "active").length,
            c: "text-green-600",
            bg: "bg-green-50 border-green-100",
          },
          {
            label: "في انتظار الموافقة",
            val: teachers.filter((t) => t.status === "pending").length,
            c: "text-orange-600",
            bg: "bg-orange-50 border-orange-100",
          },
        ].map((s) => (
          <div key={s.label} className={`${s.bg} border rounded-2xl p-4`}>
            <p className={`text-2xl font-black ${s.c}`}>{s.val}</p>
            <p className="text-xs text-gray-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search
          size={18}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
        />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث بالاسم أو المادة أو البريد..."
          className="w-full pr-10 pl-4 py-3 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-purple-400 transition-all shadow-sm"
        />
      </div>

      {/* Cards */}
      {loading ? (
        <div className="text-center py-12">
          <div
            className="w-8 h-8 border-4 border-purple-400 border-t-transparent rounded-full mx-auto"
            style={{ animation: "spin 0.8s linear infinite" }}
          />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 py-16 text-center shadow-sm">
          <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <BookOpen size={28} className="text-purple-400" />
          </div>
          <p className="text-gray-500 font-medium text-lg">
            {teachers.length === 0 ? "لا يوجد مدرسون بعد" : "لا توجد نتائج"}
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-xl font-bold hover:bg-purple-700 transition-all mt-4"
          >
            <Plus size={18} /> إضافة أول مدرس
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence>
            {filtered.map((t) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`bg-white rounded-2xl border-2 shadow-sm p-5 hover:shadow-md transition-all ${t.status === "pending" ? "border-orange-200" : "border-gray-100"}`}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center text-white font-black text-xl flex-shrink-0">
                    {t.name?.[0] || "م"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-black text-gray-800 truncate">
                      {t.name}
                    </h3>
                    {t.subject && (
                      <p className="text-xs text-purple-600 font-medium">
                        {t.subject}
                      </p>
                    )}
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${t.status === "active" ? "bg-green-100 text-green-700" : t.status === "pending" ? "bg-orange-100 text-orange-700" : "bg-red-100 text-red-600"}`}
                    >
                      {t.status === "active"
                        ? "✅ نشط"
                        : t.status === "pending"
                          ? "⏳ انتظار الموافقة"
                          : "🚫 موقوف"}
                    </span>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        setEditingTeacher(t);
                        setShowForm(true);
                      }}
                      className="p-1.5 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => deleteTeacher(t.id)}
                      className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
                <div className="space-y-1.5 mb-4">
                  {t.phone && (
                    <div className="flex items-center gap-2">
                      <Phone size={13} className="text-gray-400" />
                      <span className="font-mono text-xs text-gray-600">
                        {t.phone}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Mail size={13} className="text-gray-400" />
                    <span className="text-xs text-gray-600 truncate">
                      {t.email || "—"}
                    </span>
                  </div>
                  {t.groups_assigned && (
                    <div className="flex items-center gap-2">
                      <Users size={13} className="text-gray-400" />
                      <span className="text-xs text-gray-600 truncate">
                        {t.groups_assigned}
                      </span>
                    </div>
                  )}
                </div>
                <div className="bg-purple-50 border border-purple-100 rounded-xl p-3 mb-3">
                  <p className="text-xs text-purple-700 font-bold mb-1">
                    🔑 بيانات الدخول
                  </p>
                  <p className="text-xs text-purple-600 font-mono truncate">
                    {t.email}
                  </p>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(t.email);
                      toast.success("تم نسخ البريد 📋");
                    }}
                    className="text-[10px] text-purple-500 hover:text-purple-700 underline mt-0.5"
                  >
                    📋 نسخ البريد الإلكتروني
                  </button>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => sendWA(t)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-green-50 text-green-600 rounded-xl text-xs font-bold hover:bg-green-100"
                  >
                    <WAIconAdmin size={14} /> واتساب
                  </button>
                  {t.status === "pending" && (
                    <button
                      onClick={() => approveTeacher(t.id, t.name)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700"
                    >
                      ✅ قبول وتفعيل
                    </button>
                  )}
                  <a
                    href="/teacher"
                    target="_blank"
                    className="flex items-center justify-center gap-1.5 py-2 px-3 bg-purple-50 text-purple-600 rounded-xl text-xs font-bold hover:bg-purple-100"
                  >
                    <BookOpen size={14} />
                  </a>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <Shield size={18} className="text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-blue-800 text-sm mb-1">
              💡 نظام إدارة المدرسين المحسّن
            </p>
            <p className="text-xs text-blue-700 leading-relaxed">
              البريد يُنشأ تلقائياً:{" "}
              <span className="font-mono font-bold bg-blue-100 px-1 rounded">
                اسم@hishamacademy.online
              </span>{" "}
              — البيانات محفوظة في قاعدة البيانات وتعمل على كل الأجهزة. المدرسون
              المسجلون ذاتياً يظهرون بحالة "انتظار الموافقة" حتى تفعّلهم.
            </p>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showForm && (
          <TeacherFormModal
            teacher={editingTeacher}
            onClose={() => {
              setShowForm(false);
              setEditingTeacher(null);
            }}
            onSave={saveTeacher}
          />
        )}
      </AnimatePresence>
      <style
        jsx
        global
      >{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
