import { Clock, CheckCircle2, XCircle } from "lucide-react";

export function StatusBadge({ status }) {
  const map = {
    pending: {
      label: "قيد المراجعة",
      cls: "bg-yellow-100 text-yellow-700",
      Icon: Clock,
    },
    approved: {
      label: "مقبول",
      cls: "bg-green-100 text-green-700",
      Icon: CheckCircle2,
    },
    rejected: { label: "مرفوض", cls: "bg-red-100 text-red-600", Icon: XCircle },
  };
  const { label, cls, Icon } = map[status] || map.pending;
  return (
    <span
      className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${cls}`}
    >
      <Icon size={12} />
      {label}
    </span>
  );
}
