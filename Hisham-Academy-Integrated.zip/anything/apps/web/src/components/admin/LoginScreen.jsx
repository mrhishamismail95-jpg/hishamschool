import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Shield,
  Eye,
  EyeOff,
  Phone,
  Hash,
  AlertTriangle,
  Crown,
  UserCog,
  KeyRound,
  CheckCircle2,
  ArrowRight,
  X,
  RefreshCw,
} from "lucide-react";

/* ══════════════════════════════════════════════════════════════
   Forgot Code Modal — 3 steps: phone → verify → new code → done
══════════════════════════════════════════════════════════════ */
function ForgotCodeModal({ onClose }) {
  const [step, setStep] = useState(1); // 1=phone, 2=new code, 3=done
  const [phone, setPhone] = useState("");
  const [verifiedName, setVerifiedName] = useState("");
  const [newCode, setNewCode] = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const [showCode, setShowCode] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  /* Step 1 — verify phone */
  const handleVerify = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/admins/auth", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: phone.trim(), step: "verify" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setVerifiedName(data.name);
      setStep(2);
    } catch (err) {
      setError(err.message || "تعذر التحقق من الرقم");
    }
    setLoading(false);
  };

  /* Step 2 — set new code */
  const handleReset = async (e) => {
    e.preventDefault();
    setError("");
    if (newCode !== confirmCode) {
      setError("الكودان غير متطابقان");
      return;
    }
    if (newCode.length < 4) {
      setError("يجب أن يكون الكود 4 أحرف على الأقل");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/admins/auth", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: phone.trim(),
          new_code: newCode.trim(),
          step: "reset",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setStep(3);
    } catch (err) {
      setError(err.message || "فشل تحديث الكود");
    }
    setLoading(false);
  };

  const inp =
    "w-full bg-white/8 border border-white/15 rounded-2xl px-4 py-3.5 text-white placeholder-gray-500 focus:outline-none focus:border-amber-400/60 focus:bg-white/10 transition-all text-sm";

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      dir="rtl"
    >
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.85, opacity: 0 }}
        transition={{ type: "spring", duration: 0.45 }}
        className="w-full max-w-md bg-[#0d1f3c] border border-white/10 rounded-3xl p-7 shadow-2xl relative"
      >
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 w-8 h-8 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-all"
        >
          <X size={16} />
        </button>

        {/* Progress dots */}
        <div className="flex items-center justify-center gap-2 mb-6">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`rounded-full transition-all duration-300 ${
                s < step
                  ? "w-6 h-2 bg-amber-400"
                  : s === step
                    ? "w-8 h-2 bg-amber-400"
                    : "w-2 h-2 bg-white/15"
              }`}
            />
          ))}
        </div>

        {/* ── Step 1: Phone ── */}
        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div className="text-center mb-6">
              <div className="w-14 h-14 bg-amber-500/15 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-amber-500/20">
                <KeyRound size={26} className="text-amber-400" />
              </div>
              <h2 className="text-lg font-black text-white">نسيت الكود؟</h2>
              <p className="text-gray-400 text-sm mt-1">
                أدخل رقم هاتفك المسجل في النظام
              </p>
            </div>
            <form onSubmit={handleVerify} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-amber-200 mb-2">
                  رقم الهاتف المسجل
                </label>
                <div className="relative">
                  <Phone
                    size={16}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"
                  />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className={`${inp} pr-10`}
                    dir="ltr"
                  />
                </div>
              </div>
              {error && (
                <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/25 rounded-xl px-3 py-2.5">
                  <AlertTriangle
                    size={14}
                    className="text-red-400 flex-shrink-0"
                  />
                  <p className="text-red-300 text-xs">{error}</p>
                </div>
              )}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-gray-900 rounded-2xl font-black text-sm flex items-center justify-center gap-2 hover:from-amber-300 disabled:opacity-60"
              >
                {loading ? (
                  <>
                    <div
                      className="w-4 h-4 border-2 border-gray-900 border-t-transparent rounded-full"
                      style={{ animation: "spin .8s linear infinite" }}
                    />{" "}
                    جاري التحقق...
                  </>
                ) : (
                  <>
                    <ArrowRight size={16} /> التحقق من الرقم
                  </>
                )}
              </button>
            </form>
          </motion.div>
        )}

        {/* ── Step 2: New Code ── */}
        {step === 2 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div className="text-center mb-6">
              <div className="w-14 h-14 bg-blue-500/15 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-blue-500/20">
                <RefreshCw size={26} className="text-blue-400" />
              </div>
              <h2 className="text-lg font-black text-white">تعيين كود جديد</h2>
              <p className="text-gray-400 text-sm mt-1">
                مرحباً{" "}
                <span className="text-amber-300 font-bold">{verifiedName}</span>{" "}
                — أدخل كوداً جديداً
              </p>
            </div>
            <form onSubmit={handleReset} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-blue-200 mb-2">
                  الكود الجديد
                </label>
                <div className="relative">
                  <Hash
                    size={16}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"
                  />
                  <input
                    type={showCode ? "text" : "password"}
                    required
                    value={newCode}
                    onChange={(e) => setNewCode(e.target.value)}
                    minLength={4}
                    placeholder="كود جديد (4 أحرف على الأقل)"
                    className={`${inp} pr-10 pl-10`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowCode((v) => !v)}
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                  >
                    {showCode ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-blue-200 mb-2">
                  تأكيد الكود
                </label>
                <div className="relative">
                  <Hash
                    size={16}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"
                  />
                  <input
                    type={showCode ? "text" : "password"}
                    required
                    value={confirmCode}
                    onChange={(e) => setConfirmCode(e.target.value)}
                    minLength={4}
                    placeholder="أعد كتابة الكود"
                    className={`${inp} pr-10`}
                  />
                </div>
              </div>

              {/* Strength indicator */}
              {newCode && (
                <div className="space-y-1.5">
                  <div className="flex gap-1">
                    {[4, 6, 8, 10].map((len, i) => (
                      <div
                        key={i}
                        className={`h-1.5 flex-1 rounded-full transition-all ${
                          newCode.length >= len
                            ? i === 0
                              ? "bg-red-400"
                              : i === 1
                                ? "bg-yellow-400"
                                : i === 2
                                  ? "bg-blue-400"
                                  : "bg-green-400"
                            : "bg-white/10"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-xs text-gray-400">
                    {newCode.length < 4
                      ? "ضعيف جداً"
                      : newCode.length < 6
                        ? "ضعيف"
                        : newCode.length < 8
                          ? "متوسط"
                          : "قوي ✓"}
                  </p>
                </div>
              )}

              {error && (
                <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/25 rounded-xl px-3 py-2.5">
                  <AlertTriangle
                    size={14}
                    className="text-red-400 flex-shrink-0"
                  />
                  <p className="text-red-300 text-xs">{error}</p>
                </div>
              )}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setStep(1);
                    setError("");
                  }}
                  className="flex-shrink-0 px-4 py-3.5 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl font-bold text-sm transition-all"
                >
                  رجوع
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3.5 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 hover:from-blue-500 disabled:opacity-60"
                >
                  {loading ? (
                    <>
                      <div
                        className="w-4 h-4 border-2 border-white border-t-transparent rounded-full"
                        style={{ animation: "spin .8s linear infinite" }}
                      />{" "}
                      جاري الحفظ...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 size={16} /> حفظ الكود الجديد
                    </>
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {/* ── Step 3: Success ── */}
        {step === 3 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-4"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.1, duration: 0.5 }}
              className="w-20 h-20 bg-green-500/15 rounded-3xl flex items-center justify-center mx-auto mb-5 border border-green-500/25"
            >
              <CheckCircle2 size={40} className="text-green-400" />
            </motion.div>
            <h2 className="text-xl font-black text-white mb-2">
              تم التحديث! 🎉
            </h2>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">
              تم تعيين الكود الجديد بنجاح
              <br />
              يمكنك الآن تسجيل الدخول بالكود الجديد
            </p>
            <button
              onClick={onClose}
              className="w-full py-3.5 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl font-black text-sm hover:from-green-400 transition-all"
            >
              العودة لتسجيل الدخول ←
            </button>
          </motion.div>
        )}
      </motion.div>

      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   Main Login Screen
══════════════════════════════════════════════════════════════ */
export function LoginScreen({ onLogin }) {
  const [mode, setMode] = useState("superadmin"); // "superadmin" | "admin"
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [showCode, setShowCode] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showForgot, setShowForgot] = useState(false);

  const isSuperMode = mode === "superadmin";

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/admins/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: phone.trim(), code: code.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "بيانات الدخول غير صحيحة");

      const role = data.admin?.role;
      if (isSuperMode && role !== "superadmin") {
        throw new Error("هذه البوابة خاصة بالمدير العام فقط");
      }
      if (!isSuperMode && role === "superadmin") {
        throw new Error("يرجى استخدام بوابة المدير العام لهذا الحساب");
      }
      onLogin(data.admin);
    } catch (err) {
      setError(err.message || "حدث خطأ — حاول مرة أخرى");
    }
    setLoading(false);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden"
      style={{
        background: isSuperMode
          ? "linear-gradient(135deg, #0a0f1e 0%, #0d1f3c 40%, #0a1628 100%)"
          : "linear-gradient(135deg, #0f172a 0%, #1e3a5f 40%, #0f172a 100%)",
      }}
      dir="rtl"
    >
      {/* Animated BG */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {isSuperMode ? (
          <>
            <div
              className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-20"
              style={{
                background: "radial-gradient(circle, #f59e0b, transparent)",
              }}
            />
            <div
              className="absolute -bottom-32 -left-32 w-80 h-80 rounded-full opacity-10"
              style={{
                background: "radial-gradient(circle, #f59e0b, transparent)",
              }}
            />
          </>
        ) : (
          <>
            <div
              className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-20"
              style={{
                background: "radial-gradient(circle, #3b82f6, transparent)",
              }}
            />
            <div
              className="absolute -bottom-32 -left-32 w-80 h-80 rounded-full opacity-10"
              style={{
                background: "radial-gradient(circle, #06b6d4, transparent)",
              }}
            />
          </>
        )}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", duration: 0.7 }}
        className="relative w-full max-w-md"
      >
        {/* ── Mode Tabs ── */}
        <div className="flex bg-white/5 backdrop-blur rounded-2xl p-1.5 mb-5 border border-white/10">
          {[
            {
              key: "superadmin",
              label: "المدير العام",
              icon: <Crown size={14} />,
            },
            { key: "admin", label: "الإداريون", icon: <UserCog size={14} /> },
          ].map((m) => (
            <button
              key={m.key}
              onClick={() => {
                setMode(m.key);
                setError("");
                setPhone("");
                setCode("");
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all ${
                mode === m.key
                  ? m.key === "superadmin"
                    ? "bg-gradient-to-r from-amber-400 to-yellow-400 text-gray-900 shadow-lg shadow-amber-500/20"
                    : "bg-gradient-to-r from-blue-600 to-cyan-500 text-white shadow-lg shadow-blue-500/20"
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              {m.icon} {m.label}
            </button>
          ))}
        </div>

        {/* ── Card ── */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              key={mode}
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", duration: 0.4 }}
              className={`w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-2xl ${
                isSuperMode
                  ? "bg-gradient-to-br from-amber-400 to-yellow-500 shadow-amber-500/30"
                  : "bg-gradient-to-br from-blue-500 to-cyan-500 shadow-blue-500/30"
              }`}
            >
              {isSuperMode ? (
                <Crown size={38} className="text-gray-900" />
              ) : (
                <Shield size={38} className="text-white" />
              )}
            </motion.div>

            <AnimatePresence mode="wait">
              <motion.div
                key={mode}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
              >
                <h1
                  className={`text-xl font-black ${isSuperMode ? "text-amber-300" : "text-white"}`}
                >
                  {isSuperMode ? "بوابة المدير العام" : "بوابة الإداريين"}
                </h1>
                <p className="text-gray-400 text-xs mt-1.5">
                  {isSuperMode
                    ? "🛡️ صلاحيات كاملة — وصول لجميع الأقسام"
                    : "👤 دخول لوحة الإدارة اليومية"}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            {/* Phone */}
            <div>
              <label
                className={`block text-xs font-semibold mb-1.5 ${isSuperMode ? "text-amber-200" : "text-blue-200"}`}
              >
                رقم الهاتف
              </label>
              <div className="relative">
                <Phone
                  size={15}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className={`w-full bg-white/8 border rounded-xl px-4 py-3 pr-10 text-white placeholder-gray-500 focus:outline-none transition-all text-sm text-right ${
                    isSuperMode
                      ? "border-amber-500/25 focus:border-amber-400/60 focus:bg-amber-500/5"
                      : "border-white/15 focus:border-blue-400/60 focus:bg-white/8"
                  }`}
                  dir="ltr"
                />
              </div>
            </div>

            {/* Code */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  className={`text-xs font-semibold ${isSuperMode ? "text-amber-200" : "text-blue-200"}`}
                >
                  {isSuperMode ? "كود المدير" : "كود الاشتراك"}
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgot(true)}
                  className="text-xs text-gray-400 hover:text-amber-300 transition-colors flex items-center gap-1"
                >
                  <KeyRound size={11} /> نسيت الكود؟
                </button>
              </div>
              <div className="relative">
                <Hash
                  size={15}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  type={showCode ? "text" : "password"}
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full bg-white/8 border rounded-xl px-4 py-3 pr-10 pl-10 text-white placeholder-gray-500 focus:outline-none transition-all text-sm ${
                    isSuperMode
                      ? "border-amber-500/25 focus:border-amber-400/60 focus:bg-amber-500/5"
                      : "border-white/15 focus:border-blue-400/60 focus:bg-white/8"
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowCode((v) => !v)}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                >
                  {showCode ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Error */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-start gap-2 bg-red-500/12 border border-red-500/25 rounded-xl px-3.5 py-2.5"
                >
                  <AlertTriangle
                    size={14}
                    className="text-red-400 flex-shrink-0 mt-0.5"
                  />
                  <p className="text-red-300 text-xs leading-relaxed">
                    {error}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3.5 text-sm font-black rounded-xl transition-all disabled:opacity-60 flex items-center justify-center gap-2 shadow-lg ${
                isSuperMode
                  ? "bg-gradient-to-r from-amber-400 to-yellow-500 text-gray-900 hover:from-amber-300 shadow-amber-500/25"
                  : "bg-gradient-to-r from-blue-600 to-cyan-500 text-white hover:from-blue-500 shadow-blue-500/25"
              }`}
            >
              {loading ? (
                <>
                  <div
                    className="w-4 h-4 border-2 border-current border-t-transparent rounded-full"
                    style={{ animation: "spin .8s linear infinite" }}
                  />{" "}
                  جاري التحقق...
                </>
              ) : (
                <>
                  {isSuperMode ? <Crown size={16} /> : <Shield size={16} />}{" "}
                  دخول {isSuperMode ? "المدير العام" : "الإداريين"}
                </>
              )}
            </button>
          </form>

          {/* Footer hint */}
          <div
            className={`mt-5 p-3 rounded-xl border text-center text-xs leading-relaxed ${
              isSuperMode
                ? "bg-amber-500/5 border-amber-500/15 text-amber-400/60"
                : "bg-white/4 border-white/8 text-gray-500"
            }`}
          >
            {isSuperMode
              ? "🔐 حصري للمدير العام — لا يمكن الوصول بحساب إداري عادي"
              : "🔐 رقم الهاتف + الكود الذي منحه لك المدير"}
          </div>

          <p className="text-center mt-4">
            <a
              href="/"
              className="text-xs text-gray-500 hover:text-gray-300 transition-colors"
            >
              ← العودة للصفحة الرئيسية
            </a>
          </p>
        </div>
      </motion.div>

      {/* Forgot Code Modal */}
      <AnimatePresence>
        {showForgot && <ForgotCodeModal onClose={() => setShowForgot(false)} />}
      </AnimatePresence>

      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
