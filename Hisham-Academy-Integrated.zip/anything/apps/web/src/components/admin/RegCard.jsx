import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Phone,
  GraduationCap,
  BookOpen,
  ChevronDown,
  UserCheck,
  UserX,
  Trash2,
} from "lucide-react";
import { TypeBadge } from "./TypeBadge";
import { StatusBadge } from "./StatusBadge";

export function RegCard({ reg, onApprove, onReject, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  const dateStr = new Date(reg.submittedAt).toLocaleDateString("ar-EG", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className={`bg-white rounded-2xl border-2 shadow-sm transition-all ${
        reg.status === "approved"
          ? "border-green-100"
          : reg.status === "rejected"
            ? "border-red-100 opacity-70"
            : "border-gray-100 hover:border-blue-100"
      }`}
    >
      {/* Header */}
      <div className="p-4 flex items-start gap-3">
        <div className="w-11 h-11 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
          {reg.name?.[0] || "؟"}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <h3 className="font-bold text-gray-800 text-base truncate">
              {reg.name || "—"}
            </h3>
            <TypeBadge type={reg.type} />
            <StatusBadge status={reg.status} />
          </div>
          <div className="flex items-center gap-3 text-xs text-gray-400 flex-wrap">
            {reg.phone && (
              <span className="flex items-center gap-1">
                <Phone size={11} />
                {reg.phone}
              </span>
            )}
            {reg.grade && (
              <span className="flex items-center gap-1">
                <GraduationCap size={11} />
                {reg.grade}
              </span>
            )}
            {reg.subject && (
              <span className="flex items-center gap-1">
                <BookOpen size={11} />
                {reg.subject}
              </span>
            )}
          </div>
          <p className="text-[11px] text-gray-300 mt-1 font-mono">
            {reg.code} · {dateStr}
          </p>
        </div>
        <button
          onClick={() => setExpanded((v) => !v)}
          className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-lg transition-all flex-shrink-0"
        >
          <ChevronDown
            size={18}
            className={`transition-transform ${expanded ? "rotate-180" : ""}`}
          />
        </button>
      </div>

      {/* Expanded Details */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-gray-100"
          >
            <div className="p-4 grid grid-cols-2 gap-3">
              {[
                reg.parentPhone && {
                  label: "هاتف ولي الأمر",
                  value: reg.parentPhone,
                },
                reg.preferredGroup && {
                  label: "المجموعة المطلوبة",
                  value: reg.preferredGroup,
                },
                reg.preferredDays?.length > 0 && {
                  label: "الأيام المفضلة",
                  value: reg.preferredDays.join("، "),
                },
                reg.notes && { label: "ملاحظات", value: reg.notes },
              ]
                .filter(Boolean)
                .map(({ label, value }) => (
                  <div key={label} className="col-span-2 md:col-span-1">
                    <p className="text-[11px] text-gray-400 font-bold mb-0.5">
                      {label}
                    </p>
                    <p className="text-sm text-gray-700 font-medium">{value}</p>
                  </div>
                ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Actions */}
      {reg.status === "pending" && (
        <div className="flex items-center gap-2 px-4 pb-4">
          <button
            onClick={() => onApprove(reg)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold text-sm transition-all shadow-md shadow-green-100"
          >
            <UserCheck size={16} />
            قبول وإضافة
          </button>
          <button
            onClick={() => onReject(reg)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl font-bold text-sm transition-all border border-red-200"
          >
            <UserX size={16} />
            رفض
          </button>
          <button
            onClick={() => onDelete(reg.id)}
            className="p-2.5 text-gray-300 hover:text-red-400 hover:bg-red-50 rounded-xl transition-all border border-gray-100"
          >
            <Trash2 size={16} />
          </button>
        </div>
      )}
      {reg.status !== "pending" && (
        <div className="flex items-center justify-end gap-2 px-4 pb-4">
          <button
            onClick={() => onDelete(reg.id)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
          >
            <Trash2 size={14} />
            حذف السجل
          </button>
        </div>
      )}
    </motion.div>
  );
}
