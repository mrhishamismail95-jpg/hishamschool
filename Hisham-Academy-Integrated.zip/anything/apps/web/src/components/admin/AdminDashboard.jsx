import { useState, useEffect, useCallback } from "react";
import { AnimatePresence } from "motion/react";
import {
  Shield,
  LogOut,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Wallet,
  Search,
  Settings,
  Bell,
  RefreshCw,
  Download,
  UserCog,
  TrendingUp,
  AlertTriangle,
  Home,
  BookOpen,
  Calendar,
  CreditCard,
  BarChart2,
  ChevronRight,
  Menu,
  X,
} from "lucide-react";
import { useStore } from "@/utils/store";
import { toast, Toaster } from "sonner";
import { StatCard } from "./StatCard";
import { RegCard } from "./RegCard";
import { QuickAccessGrid } from "./QuickAccessGrid";
import { TeachersTab } from "./TeachersTab";
import { ChangePasswordModal } from "./ChangePasswordModal";
import { PortalSettingsTab } from "./PortalSettingsTab";
import AdminsManagement from "./AdminsManagement";
import { SubscriptionsTab } from "./SubscriptionsTab";

/* ══════════════════════════════════════════════════════════════
   Sidebar config
══════════════════════════════════════════════════════════════ */
const SIDEBAR_ITEMS = [
  { key: "overview", label: "نظرة عامة", icon: Home },
  { key: "registrations", label: "طلبات التسجيل", icon: Users },
  { key: "subscriptions", label: "الاشتراكات والتنبيهات", icon: CreditCard },
  { key: "teachers", label: "المعلمون", icon: UserCog },
  { key: "sections", label: "الأقسام السريعة", icon: BarChart2 },
  { key: "settings", label: "إعدادات المنصة", icon: Settings },
  { key: "admins", label: "إدارة الإداريين", icon: Shield, superOnly: true },
];

/* ══════════════════════════════════════════════════════════════
   Overview helpers
══════════════════════════════════════════════════════════════ */
function daysLeft(d) {
  if (!d) return null;
  return Math.ceil((new Date(d) - new Date()) / 86400000);
}

/* ══════════════════════════════════════════════════════════════
   AdminDashboard
══════════════════════════════════════════════════════════════ */
export function AdminDashboard({ onLogout, admin }) {
  const { students, payments, fetchData } = useStore();
  const [regs, setRegs] = useState([]);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("pending");
  const [filterType, setFilterType] = useState("all");
  const [showChangePass, setShowChangePass] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [financials, setFinancials] = useState(null);
  const [adminsData, setAdminsData] = useState([]);

  const isSuperAdmin = admin?.role === "superadmin";
  const adminName = admin?.name || "المدير";

  /* ── Loaders ── */
  const loadRegs = useCallback(async () => {
    try {
      const res = await fetch("/api/academy/registrations");
      const data = await res.json();
      setRegs(data.requests || []);
    } catch {
      try {
        setRegs(
          JSON.parse(localStorage.getItem("pending_registrations") || "[]"),
        );
      } catch {}
    }
  }, []);

  const loadFinancials = useCallback(async () => {
    try {
      const res = await fetch("/api/admins/financial-reports");
      const data = await res.json();
      setFinancials(data);
    } catch {}
  }, []);

  const loadAdmins = useCallback(async () => {
    try {
      const res = await fetch("/api/admins");
      const data = await res.json();
      setAdminsData(data.admins || []);
    } catch {}
  }, []);

  useEffect(() => {
    loadRegs();
    fetchData();
    loadFinancials();
    if (isSuperAdmin) loadAdmins();
  }, []);

  /* ── Reg actions ── */
  const handleApprove = async (reg) => {
    try {
      const res = await fetch(`/api/academy/registrations/${reg.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "approve" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "فشل القبول");
      await loadRegs();
      await fetchData();
      toast.success(
        `✅ تم قبول ${reg.name}${data.studentCode ? ` — الكود: ${data.studentCode}` : ""}`,
      );
    } catch (err) {
      toast.error(err.message || "حدث خطأ");
    }
  };

  const handleReject = async (reg) => {
    try {
      await fetch(`/api/academy/registrations/${reg.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reject" }),
      });
      await loadRegs();
      toast.info(`تم رفض طلب ${reg.name}`);
    } catch {
      toast.error("فشل الرفض");
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("هل أنت متأكد من حذف هذا الطلب؟")) return;
    try {
      await fetch(`/api/academy/registrations/${id}`, { method: "DELETE" });
      await loadRegs();
      toast.info("تم حذف الطلب");
    } catch {
      toast.error("فشل الحذف");
    }
  };

  const handleExport = () => {
    const rows = [
      [
        "الكود",
        "الاسم",
        "النوع",
        "الهاتف",
        "الصف",
        "المجموعة",
        "الحالة",
        "تاريخ التسجيل",
      ],
      ...regs.map((r) => [
        r.code,
        r.name,
        r.type,
        r.phone,
        r.grade,
        r.preferredGroup,
        r.status,
        new Date(r.submittedAt).toLocaleDateString("ar-EG"),
      ]),
    ];
    const csv = rows
      .map((row) =>
        row.map((c) => `"${String(c || "").replace(/"/g, '""')}"`).join(","),
      )
      .join("\n");
    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `طلبات_التسجيل_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    toast.success("تم تصدير البيانات");
  };

  /* ── Derived values ── */
  const pending = regs.filter((r) => r.status === "pending").length;
  const approved = regs.filter((r) => r.status === "approved").length;
  const rejected = regs.filter((r) => r.status === "rejected").length;
  const thisMonth = new Date().toISOString().slice(0, 7);
  const monthRevenue = payments
    .filter((p) => p.payment_month?.startsWith(thisMonth))
    .reduce((a, p) => a + Number(p.amount || 0), 0);

  const expiredAdmins = adminsData.filter((a) => {
    const d = daysLeft(a.subscription_end);
    return d !== null && d < 0;
  });
  const expiringAdmins = adminsData.filter((a) => {
    const d = daysLeft(a.subscription_end);
    return d !== null && d >= 0 && d <= 7;
  });
  const totalAlerts = expiredAdmins.length + expiringAdmins.length + pending;

  const filtered = regs.filter((r) => {
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      r.name?.toLowerCase().includes(q) ||
      r.phone?.includes(q) ||
      r.code?.toLowerCase().includes(q);
    const matchStatus = filterStatus === "all" || r.status === filterStatus;
    const matchType = filterType === "all" || r.type === filterType;
    return matchSearch && matchStatus && matchType;
  });

  /* ── Sidebar ── */
  const sidebarItems = SIDEBAR_ITEMS.filter(
    (i) => !i.superOnly || isSuperAdmin,
  );

  const SidebarContent = () => (
    <div className="flex flex-col h-full" dir="rtl">
      {/* Logo */}
      <div
        className={`p-5 border-b ${isSuperAdmin ? "border-amber-500/20 bg-gradient-to-l from-amber-500/10 to-transparent" : "border-white/8"}`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
              isSuperAdmin
                ? "bg-gradient-to-br from-amber-400 to-yellow-500"
                : "bg-gradient-to-br from-blue-500 to-cyan-500"
            }`}
          >
            {isSuperAdmin ? (
              <span className="text-lg">👑</span>
            ) : (
              <Shield size={20} className="text-white" />
            )}
          </div>
          <div>
            <p className="font-black text-white text-sm leading-tight">
              لوحة الإدارة
            </p>
            <p
              className={`text-xs mt-0.5 ${isSuperAdmin ? "text-amber-300" : "text-gray-400"}`}
            >
              {isSuperAdmin ? "المدير العام" : "الإداري"}
            </p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.key;
          const badge =
            item.key === "registrations" && pending > 0
              ? pending
              : item.key === "subscriptions" && totalAlerts > 0 && isSuperAdmin
                ? totalAlerts
                : null;
          return (
            <button
              key={item.key}
              onClick={() => {
                setActiveTab(item.key);
                setSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all group ${
                isActive
                  ? isSuperAdmin
                    ? "bg-amber-500/15 text-amber-300 border border-amber-500/20"
                    : "bg-blue-600 text-white shadow-md shadow-blue-500/20"
                  : "text-gray-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Icon
                size={17}
                className={`flex-shrink-0 ${isActive ? "" : "opacity-70 group-hover:opacity-100"}`}
              />
              <span className="flex-1 text-right">{item.label}</span>
              {badge && (
                <span
                  className={`flex-shrink-0 min-w-5 h-5 rounded-full text-xs font-black flex items-center justify-center px-1.5 ${
                    isActive
                      ? "bg-white/20 text-white"
                      : "bg-red-500 text-white"
                  }`}
                >
                  {badge}
                </span>
              )}
              {isActive && (
                <ChevronRight size={14} className="flex-shrink-0 opacity-50" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Admin info */}
      <div className="p-3 border-t border-white/8 space-y-2">
        {admin?.subscription_end &&
          (() => {
            const days = daysLeft(admin.subscription_end);
            if (days !== null && days <= 30)
              return (
                <div
                  className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                    days < 0
                      ? "bg-red-500/15 text-red-300 border border-red-500/20"
                      : days <= 7
                        ? "bg-orange-500/15 text-orange-300 border border-orange-500/20"
                        : "bg-yellow-500/10 text-yellow-300 border border-yellow-500/15"
                  }`}
                >
                  <AlertTriangle size={13} className="flex-shrink-0" />
                  {days < 0
                    ? "اشتراكك منتهي!"
                    : `اشتراكك ينتهي خلال ${days} يوم`}
                </div>
              );
            return null;
          })()}
        <div className="flex items-center gap-2.5 px-2 py-1.5">
          <div
            className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-black flex-shrink-0 ${
              isSuperAdmin
                ? "bg-amber-500/20 text-amber-300"
                : "bg-blue-500/20 text-blue-300"
            }`}
          >
            {adminName?.[0]}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-xs font-bold truncate">{adminName}</p>
            <p className="text-gray-500 text-xs truncate">{admin?.phone}</p>
          </div>
        </div>
        <button
          onClick={() => setShowChangePass(true)}
          className="w-full flex items-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-xl text-xs font-semibold transition-all"
        >
          <Settings size={13} /> تغيير الكود
        </button>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2 px-3 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 rounded-xl text-xs font-bold transition-all"
        >
          <LogOut size={13} /> تسجيل الخروج
        </button>
      </div>
    </div>
  );

  /* ── Tab content renderer ── */
  const renderContent = () => {
    switch (activeTab) {
      /* ─── Overview ─── */
      case "overview":
        return (
          <div className="space-y-6">
            {/* Welcome banner */}
            <div
              className={`rounded-2xl p-6 text-white relative overflow-hidden ${
                isSuperAdmin
                  ? "bg-gradient-to-l from-amber-600/90 to-amber-800/90"
                  : "bg-gradient-to-l from-blue-600 to-blue-700"
              }`}
            >
              <div className="relative z-10">
                <p className="text-sm opacity-80 mb-1">
                  {new Date().toLocaleDateString("ar-EG", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
                <h2 className="text-2xl font-black">
                  مرحباً، {adminName} {isSuperAdmin ? "👑" : "👋"}
                </h2>
                <p className="text-sm opacity-75 mt-1">
                  {isSuperAdmin
                    ? "المدير العام — صلاحيات كاملة"
                    : "إداري — لوحة الإدارة اليومية"}
                </p>
              </div>
              <div className="absolute -left-8 -bottom-8 w-36 h-36 rounded-full bg-white/5" />
              <div className="absolute -left-2 -top-8 w-24 h-24 rounded-full bg-white/5" />
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard
                label="إجمالي الطلاب"
                value={students.length}
                icon={Users}
                color="bg-blue-600"
                bg="bg-white border border-gray-100 shadow-sm"
              />
              <StatCard
                label="طلبات التسجيل"
                value={pending}
                icon={Clock}
                color="bg-yellow-500"
                bg="bg-yellow-50 border border-yellow-100 shadow-sm"
              />
              <StatCard
                label="إيرادات هذا الشهر"
                value={`${monthRevenue.toLocaleString()} ج.م`}
                icon={Wallet}
                color="bg-green-600"
                bg="bg-green-50 border border-green-100 shadow-sm"
              />
              <StatCard
                label="طلبات مقبولة"
                value={approved}
                icon={CheckCircle2}
                color="bg-purple-600"
                bg="bg-purple-50 border border-purple-100 shadow-sm"
              />
            </div>

            {/* Alerts row */}
            {(expiredAdmins.length > 0 ||
              expiringAdmins.length > 0 ||
              pending > 0) && (
              <div className="space-y-2">
                <h3 className="font-black text-gray-800 text-sm">
                  🔔 تنبيهات تحتاج انتباهك
                </h3>
                <div className="space-y-2">
                  {expiredAdmins.length > 0 && (
                    <button
                      onClick={() => setActiveTab("subscriptions")}
                      className="w-full flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-2xl hover:bg-red-100 transition-all text-right"
                    >
                      <div className="w-9 h-9 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0">
                        <XCircle size={18} className="text-red-500" />
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-red-700 text-sm">
                          {expiredAdmins.length} إداريون اشتراكهم منتهٍ
                        </p>
                        <p className="text-xs text-red-400">
                          اضغط لعرض التفاصيل
                        </p>
                      </div>
                      <ChevronRight size={16} className="text-red-400" />
                    </button>
                  )}
                  {expiringAdmins.length > 0 && (
                    <button
                      onClick={() => setActiveTab("subscriptions")}
                      className="w-full flex items-center gap-3 p-4 bg-orange-50 border border-orange-200 rounded-2xl hover:bg-orange-100 transition-all text-right"
                    >
                      <div className="w-9 h-9 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0">
                        <AlertTriangle size={18} className="text-orange-500" />
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-orange-700 text-sm">
                          {expiringAdmins.length} إداريون اشتراكهم ينتهي قريباً
                        </p>
                        <p className="text-xs text-orange-400">
                          خلال 7 أيام أو أقل
                        </p>
                      </div>
                      <ChevronRight size={16} className="text-orange-400" />
                    </button>
                  )}
                  {pending > 0 && (
                    <button
                      onClick={() => setActiveTab("registrations")}
                      className="w-full flex items-center gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-2xl hover:bg-yellow-100 transition-all text-right"
                    >
                      <div className="w-9 h-9 bg-yellow-100 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Clock size={18} className="text-yellow-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-yellow-700 text-sm">
                          {pending} طلب تسجيل ينتظر المراجعة
                        </p>
                        <p className="text-xs text-yellow-500">
                          اضغط لمراجعة الطلبات
                        </p>
                      </div>
                      <ChevronRight size={16} className="text-yellow-400" />
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Financial summary */}
            {financials?.summary && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 className="font-black text-gray-900 mb-4 flex items-center gap-2">
                  <TrendingUp size={18} className="text-green-500" /> الملخص
                  المالي
                </h3>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    {
                      label: "إجمالي الإيرادات",
                      value: Number(
                        financials.summary.total_revenue || 0,
                      ).toLocaleString(),
                      color: "text-green-700",
                    },
                    {
                      label: "إجمالي المصروفات",
                      value: Number(
                        financials.summary.total_expenses || 0,
                      ).toLocaleString(),
                      color: "text-red-600",
                    },
                    {
                      label: "صافي الربح",
                      value: Number(
                        financials.summary.net_profit || 0,
                      ).toLocaleString(),
                      color: "text-blue-700",
                    },
                  ].map((f) => (
                    <div key={f.label} className="text-center">
                      <p className={`text-xl font-black ${f.color}`}>
                        {f.value}
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">{f.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Register link */}
            <div
              className={`rounded-2xl p-5 text-white flex flex-col md:flex-row items-center justify-between gap-4 ${
                isSuperAdmin
                  ? "bg-gradient-to-l from-amber-600 to-amber-700"
                  : "bg-gradient-to-l from-blue-600 to-cyan-600"
              }`}
            >
              <div>
                <h3 className="font-bold mb-0.5">رابط صفحة التسجيل</h3>
                <p className="text-sm opacity-75">
                  شارك هذا الرابط مع الطلاب وأولياء الأمور
                </p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="bg-white/15 rounded-xl px-3 py-2 font-mono text-xs border border-white/20">
                  {typeof window !== "undefined" ? window.location.origin : ""}
                  /register
                </div>
                <button
                  onClick={() => {
                    if (typeof window !== "undefined") {
                      navigator.clipboard.writeText(
                        `${window.location.origin}/register`,
                      );
                      toast.success("تم نسخ الرابط");
                    }
                  }}
                  className="px-4 py-2 bg-white text-gray-800 rounded-xl font-bold text-sm hover:bg-gray-100 transition-all shadow"
                >
                  نسخ الرابط
                </button>
              </div>
            </div>
          </div>
        );

      /* ─── Registrations ─── */
      case "registrations":
        return (
          <div className="space-y-5">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard
                label="إجمالي الطلبات"
                value={regs.length}
                icon={Users}
                color="bg-blue-600"
                bg="bg-white border border-gray-100"
              />
              <StatCard
                label="قيد المراجعة"
                value={pending}
                icon={Clock}
                color="bg-yellow-500"
                bg="bg-yellow-50 border border-yellow-100"
              />
              <StatCard
                label="مقبولة"
                value={approved}
                icon={CheckCircle2}
                color="bg-green-600"
                bg="bg-green-50 border border-green-100"
              />
              <StatCard
                label="مرفوضة"
                value={rejected}
                icon={XCircle}
                color="bg-red-500"
                bg="bg-red-50 border border-red-100"
              />
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <Search
                    size={16}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                  />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="بحث بالاسم أو الكود أو الهاتف..."
                    className="w-full pr-9 pl-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-400 transition-all"
                  />
                </div>
                <div className="flex gap-1.5 flex-wrap">
                  {[
                    { key: "all", label: "الكل" },
                    { key: "pending", label: `⏳ (${pending})` },
                    { key: "approved", label: "✅ مقبول" },
                    { key: "rejected", label: "❌ مرفوض" },
                  ].map(({ key, label }) => (
                    <button
                      key={key}
                      onClick={() => setFilterStatus(key)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${filterStatus === key ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={loadRegs}
                    className="p-2.5 bg-gray-100 hover:bg-gray-200 rounded-xl transition-all"
                    title="تحديث"
                  >
                    <RefreshCw size={16} className="text-gray-600" />
                  </button>
                  <button
                    onClick={handleExport}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 rounded-xl font-bold text-sm text-gray-600"
                  >
                    <Download size={16} /> تصدير
                  </button>
                </div>
              </div>
            </div>

            {filtered.length === 0 ? (
              <div className="bg-white rounded-2xl border border-gray-100 py-14 text-center">
                <Users size={32} className="text-gray-200 mx-auto mb-3" />
                <p className="text-gray-400 font-medium text-sm">
                  لا توجد طلبات
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <AnimatePresence>
                  {filtered.map((reg) => (
                    <RegCard
                      key={reg.id}
                      reg={reg}
                      onApprove={handleApprove}
                      onReject={handleReject}
                      onDelete={handleDelete}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        );

      case "subscriptions":
        return <SubscriptionsTab currentAdmin={admin} />;
      case "teachers":
        return <TeachersTab />;
      case "sections":
        return <QuickAccessGrid />;
      case "settings":
        return <PortalSettingsTab />;

      case "admins":
        if (!isSuperAdmin) return null;
        return (
          <div className="space-y-5">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center gap-3">
              <span className="text-2xl">👑</span>
              <div>
                <p className="font-black text-amber-900 text-sm">
                  إدارة الإداريين — المدير العام فقط
                </p>
                <p className="text-amber-600 text-xs">
                  إضافة وتعديل الإداريين وإدارة اشتراكاتهم
                </p>
              </div>
            </div>
            <AdminsManagement currentAdmin={admin} />
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] flex" dir="rtl">
      {/* ── Desktop Sidebar ── */}
      <aside className="hidden lg:flex flex-col w-64 bg-[#0d1b2e] border-l border-white/8 flex-shrink-0 h-screen sticky top-0">
        <SidebarContent />
      </aside>

      {/* ── Mobile Sidebar drawer ── */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <div
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <aside className="fixed right-0 top-0 h-full w-72 bg-[#0d1b2e] border-l border-white/8 z-50 lg:hidden flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-white/8">
                <span className="text-white font-bold text-sm">القائمة</span>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="p-1.5 bg-white/5 rounded-lg text-gray-400 hover:text-white"
                >
                  <X size={18} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                <SidebarContent />
              </div>
            </aside>
          </>
        )}
      </AnimatePresence>

      {/* ── Main content ── */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="bg-[#0d1b2e] border-b border-white/8 px-4 lg:px-6 h-14 flex items-center justify-between gap-3 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-gray-400"
            >
              <Menu size={18} />
            </button>
            <div>
              <h1 className="font-black text-white text-sm">
                {sidebarItems.find((i) => i.key === activeTab)?.label ||
                  "لوحة الإدارة"}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {totalAlerts > 0 && (
              <button
                onClick={() =>
                  setActiveTab(
                    expiredAdmins.length + expiringAdmins.length > 0
                      ? "subscriptions"
                      : "registrations",
                  )
                }
                className="flex items-center gap-1.5 bg-red-500/15 border border-red-500/25 text-red-300 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-red-500/20 transition-all"
              >
                <Bell size={13} /> {totalAlerts}
              </button>
            )}
            <a
              href="/"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 text-gray-300 rounded-xl text-xs font-semibold transition-all"
            >
              <Home size={14} /> الرئيسية
            </a>
          </div>
        </header>

        {/* Page body */}
        <div className="flex-1 bg-gray-50 p-5 overflow-y-auto">
          {renderContent()}
        </div>
      </main>

      <AnimatePresence>
        {showChangePass && (
          <ChangePasswordModal onClose={() => setShowChangePass(false)} />
        )}
      </AnimatePresence>

      <Toaster position="top-center" richColors />
    </div>
  );
}
