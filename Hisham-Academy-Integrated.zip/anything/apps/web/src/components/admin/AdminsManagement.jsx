import { useState, useEffect } from "react";
import { UserPlus, Edit, Trash2, Search } from "lucide-react";

export default function AdminsManagement({ currentAdmin }) {
  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState(null);
  const [search, setSearch] = useState("");
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    phone: "",
    role: "admin",
    subscription_type: "monthly",
    subscription_start: "",
    subscription_end: "",
    notes: "",
  });

  useEffect(() => {
    loadAdmins();
  }, []);

  const loadAdmins = async () => {
    try {
      const response = await fetch("/api/admins");
      const data = await response.json();
      setAdmins(data.admins || []);
    } catch (err) {
      console.error("Load admins error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const url = editingAdmin
        ? `/api/admins/${editingAdmin.id}`
        : "/api/admins";
      const method = editingAdmin ? "PUT" : "POST";
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await response.json();
      if (!response.ok) {
        alert(data.error || "حدث خطأ");
        return;
      }
      setShowForm(false);
      setEditingAdmin(null);
      setFormData({
        code: "",
        name: "",
        phone: "",
        role: "admin",
        subscription_type: "monthly",
        subscription_start: "",
        subscription_end: "",
        notes: "",
      });
      loadAdmins();
    } catch (err) {
      console.error("Submit admin error:", err);
    }
  };

  const handleEdit = (admin) => {
    setEditingAdmin(admin);
    setFormData({
      code: admin.code,
      name: admin.name,
      phone: admin.phone,
      role: admin.role,
      subscription_type: admin.subscription_type || "monthly",
      subscription_start: admin.subscription_start || "",
      subscription_end: admin.subscription_end || "",
      notes: admin.notes || "",
    });
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (currentAdmin && id === currentAdmin.id) {
      alert("لا يمكنك حذف حسابك الخاص");
      return;
    }
    if (!confirm("هل أنت متأكد من حذف هذا الإداري؟")) return;
    try {
      await fetch(`/api/admins/${id}`, { method: "DELETE" });
      loadAdmins();
    } catch (err) {
      console.error("Delete admin error:", err);
    }
  };

  const handleToggleActive = async (admin) => {
    if (currentAdmin && admin.id === currentAdmin.id) {
      alert("لا يمكنك إيقاف حسابك الخاص");
      return;
    }
    try {
      await fetch(`/api/admins/${admin.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_active: !admin.is_active }),
      });
      loadAdmins();
    } catch (err) {
      console.error("Toggle active error:", err);
    }
  };

  const filtered = admins.filter(
    (a) =>
      !search ||
      a.name?.includes(search) ||
      a.phone?.includes(search) ||
      a.code?.includes(search),
  );

  const inp =
    "w-full px-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none text-right bg-gray-50 text-sm";

  if (loading)
    return (
      <div className="text-center py-8 text-gray-400">جاري التحميل...</div>
    );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-black text-gray-900">إدارة الإداريين</h2>
          <p className="text-sm text-gray-500">{admins.length} إداري مسجل</p>
        </div>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditingAdmin(null);
            setFormData({
              code: "",
              name: "",
              phone: "",
              role: "admin",
              subscription_type: "monthly",
              subscription_start: "",
              subscription_end: "",
              notes: "",
            });
          }}
          className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl hover:bg-blue-700 font-bold text-sm shadow-sm"
        >
          <UserPlus className="w-4 h-4" /> إضافة إداري
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث بالاسم أو الهاتف..."
          className="w-full pr-12 pl-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 focus:border-blue-500 focus:outline-none text-right text-sm"
          dir="rtl"
        />
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6">
          <h3 className="font-black text-blue-900 mb-5">
            {editingAdmin ? "تعديل الإداري" : "إضافة إداري جديد"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1.5">
                  الكود *
                </label>
                <input
                  value={formData.code}
                  onChange={(e) =>
                    setFormData({ ...formData, code: e.target.value })
                  }
                  required
                  disabled={!!editingAdmin}
                  placeholder="ADM001"
                  className={inp}
                  dir="rtl"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1.5">
                  الاسم *
                </label>
                <input
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  required
                  placeholder="الاسم الكامل"
                  className={inp}
                  dir="rtl"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1.5">
                  الهاتف *
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  required
                  placeholder="01XXXXXXXXX"
                  className={inp}
                  dir="rtl"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1.5">
                  الدور
                </label>
                <select
                  value={formData.role}
                  onChange={(e) =>
                    setFormData({ ...formData, role: e.target.value })
                  }
                  className={inp}
                  dir="rtl"
                >
                  <option value="admin">إداري</option>
                  <option value="superadmin">مدير النظام</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1.5">
                  نوع الاشتراك
                </label>
                <select
                  value={formData.subscription_type}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      subscription_type: e.target.value,
                    })
                  }
                  className={inp}
                  dir="rtl"
                >
                  <option value="monthly">شهري</option>
                  <option value="yearly">سنوي</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1.5">
                  تاريخ الانتهاء
                </label>
                <input
                  type="date"
                  value={formData.subscription_end}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      subscription_end: e.target.value,
                    })
                  }
                  className={inp}
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 mb-1.5">
                ملاحظات
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) =>
                  setFormData({ ...formData, notes: e.target.value })
                }
                rows={2}
                className={`${inp} resize-none`}
                dir="rtl"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingAdmin(null);
                }}
                className="px-5 py-2.5 bg-white border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 font-bold text-sm"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 font-bold text-sm shadow-sm"
              >
                {editingAdmin ? "حفظ التعديلات" : "إضافة الإداري"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right" dir="rtl">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {[
                  "الكود",
                  "الاسم",
                  "الهاتف",
                  "الدور",
                  "الاشتراك",
                  "الانتهاء",
                  "الحالة",
                  "إجراءات",
                ].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-3 text-xs font-bold text-gray-500 uppercase"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((admin) => (
                <tr key={admin.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-mono text-sm font-bold text-gray-700">
                    {admin.code}
                  </td>
                  <td className="px-4 py-3 text-sm font-semibold text-gray-900">
                    {admin.name}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500">
                    {admin.phone}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs font-bold ${admin.role === "superadmin" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"}`}
                    >
                      {admin.role === "superadmin" ? "مدير" : "إداري"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">
                    {admin.subscription_type === "monthly" ? "شهري" : "سنوي"}
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-400">
                    {admin.subscription_end
                      ? new Date(admin.subscription_end).toLocaleDateString(
                          "ar-EG",
                        )
                      : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => handleToggleActive(admin)}
                      className={`px-2 py-0.5 rounded-full text-xs font-bold ${admin.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}
                    >
                      {admin.is_active ? "نشط" : "موقف"}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleEdit(admin)}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      {(!currentAdmin || admin.id !== currentAdmin.id) && (
                        <button
                          onClick={() => handleDelete(admin.id)}
                          className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td
                    colSpan={8}
                    className="px-4 py-10 text-center text-gray-400 text-sm"
                  >
                    لا يوجد إداريون مطابقون
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
