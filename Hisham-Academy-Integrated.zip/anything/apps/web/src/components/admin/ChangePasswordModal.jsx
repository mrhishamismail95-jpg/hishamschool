import { useState } from "react";
import { motion } from "motion/react";
import { Key } from "lucide-react";
import { toast } from "sonner";
import { getCredentials, saveCredentials } from "@/utils/adminAuth";

export function ChangePasswordModal({ onClose }) {
  const [form, setForm] = useState({
    email: "",
    oldPass: "",
    newPass: "",
    confirmPass: "",
  });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");

  const handle = (e) => {
    e.preventDefault();
    const creds = getCredentials();
    if (form.email.trim().toLowerCase() !== creds.email.toLowerCase()) {
      setError("البريد الإلكتروني غير صحيح");
      return;
    }
    if (form.oldPass !== creds.password) {
      setError("كلمة المرور الحالية غير صحيحة");
      return;
    }
    if (form.newPass.length < 8) {
      setError("كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل");
      return;
    }
    if (form.newPass !== form.confirmPass) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    saveCredentials({
      email: form.email.trim().toLowerCase(),
      password: form.newPass,
    });
    toast.success("تم تغيير بيانات الدخول بنجاح ✅");
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
            <Key size={20} className="text-blue-600" />
          </div>
          <h3 className="text-xl font-bold text-gray-800">
            تغيير بيانات الدخول
          </h3>
        </div>

        <form onSubmit={handle} className="space-y-4">
          {[
            {
              label: "البريد الإلكتروني الجديد",
              key: "email",
              type: "email",
              placeholder: "admin@school.com",
            },
            {
              label: "كلمة المرور الحالية",
              key: "oldPass",
              type: showPass ? "text" : "password",
              placeholder: "••••••••",
            },
            {
              label: "كلمة المرور الجديدة",
              key: "newPass",
              type: showPass ? "text" : "password",
              placeholder: "8 أحرف على الأقل",
            },
            {
              label: "تأكيد كلمة المرور الجديدة",
              key: "confirmPass",
              type: showPass ? "text" : "password",
              placeholder: "نفس كلمة المرور الجديدة",
            },
          ].map(({ label, key, type, placeholder }) => (
            <div key={key}>
              <label className="block text-sm font-bold text-gray-700 mb-1.5">
                {label}
              </label>
              <input
                type={type}
                required
                value={form[key]}
                onChange={(e) =>
                  setForm((p) => ({ ...p, [key]: e.target.value }))
                }
                placeholder={placeholder}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none text-sm transition-all"
              />
            </div>
          ))}

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="showPass"
              checked={showPass}
              onChange={(e) => setShowPass(e.target.checked)}
            />
            <label
              htmlFor="showPass"
              className="text-sm text-gray-500 cursor-pointer"
            >
              إظهار كلمات المرور
            </label>
          </div>

          {error && (
            <p className="text-sm text-red-500 bg-red-50 rounded-xl px-4 py-2">
              ⚠️ {error}
            </p>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all"
            >
              حفظ التغييرات
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
