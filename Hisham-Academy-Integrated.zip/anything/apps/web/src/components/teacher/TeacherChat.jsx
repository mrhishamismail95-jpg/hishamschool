import { useState, useEffect, useRef } from "react";
import { Send, MessageCircle, X } from "lucide-react";

export default function TeacherChat({ teacher }) {
  const [conversations, setConversations] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadConversations();
  }, [teacher]);

  useEffect(() => {
    if (activeChat) {
      loadMessages();
    }
  }, [activeChat]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadConversations = async () => {
    try {
      // جلب الطلاب المعينين للمعلم
      const response = await fetch(
        `/api/admins/assignments?teacher_id=${teacher.id}`,
      );
      const data = await response.json();

      const convos = [];

      // إضافة الطلاب
      if (data.students) {
        data.students.forEach((student) => {
          convos.push({
            type: "student",
            id: student.id,
            name: student.name,
            phone: student.phone,
          });

          // إضافة ولي الأمر إذا كان موجوداً
          if (student.parent_name) {
            convos.push({
              type: "parent",
              id: `parent-${student.id}`,
              name: student.parent_name,
              phone: student.parent_phone,
              related_student: student.name,
            });
          }
        });
      }

      setConversations(convos);
    } catch (err) {
      console.error("Load conversations error:", err);
    }
  };

  const loadMessages = async () => {
    if (!activeChat) return;

    try {
      const response = await fetch(
        `/api/teacher/messages?user_type=teacher&user_id=${teacher.id}&conversation_with_type=${activeChat.type}&conversation_with_id=${activeChat.id}`,
      );
      const data = await response.json();
      setMessages(data.messages || []);
    } catch (err) {
      console.error("Load messages error:", err);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeChat) return;

    setLoading(true);
    try {
      const response = await fetch("/api/teacher/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sender_type: "teacher",
          sender_id: teacher.id,
          receiver_type: activeChat.type,
          receiver_id: activeChat.id,
          message: newMessage,
        }),
      });

      if (response.ok) {
        setNewMessage("");
        loadMessages();
      }
    } catch (err) {
      console.error("Send message error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="bg-white rounded-xl shadow-md overflow-hidden"
      style={{ height: "600px" }}
    >
      <div className="flex h-full">
        {/* Sidebar - Conversations List */}
        <div className="w-80 border-l border-gray-200 bg-gray-50 overflow-y-auto">
          <div className="p-4 border-b border-gray-200 bg-white">
            <h3 className="text-lg font-bold text-gray-900 text-right">
              المحادثات
            </h3>
          </div>

          <div className="divide-y divide-gray-200">
            {conversations.map((conv) => (
              <button
                key={`${conv.type}-${conv.id}`}
                onClick={() => setActiveChat(conv)}
                className={`w-full p-4 text-right hover:bg-white transition-colors ${
                  activeChat?.id === conv.id
                    ? "bg-white border-r-4 border-blue-600"
                    : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                      conv.type === "student" ? "bg-blue-500" : "bg-green-500"
                    }`}
                  >
                    {conv.name.charAt(0)}
                  </div>
                  <div className="flex-1 text-right">
                    <p className="font-medium text-gray-900">{conv.name}</p>
                    <p className="text-xs text-gray-500">
                      {conv.type === "student"
                        ? "طالب"
                        : `ولي أمر ${conv.related_student}`}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {conversations.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>لا توجد محادثات</p>
            </div>
          )}
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {activeChat ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-gray-200 bg-white">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                        activeChat.type === "student"
                          ? "bg-blue-500"
                          : "bg-green-500"
                      }`}
                    >
                      {activeChat.name.charAt(0)}
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gray-900">
                        {activeChat.name}
                      </p>
                      <p className="text-sm text-gray-500">
                        {activeChat.phone}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveChat(null)}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
                {messages.length === 0 ? (
                  <div className="text-center text-gray-500 mt-8">
                    <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>لا توجد رسائل بعد</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((msg) => {
                      const isSent =
                        msg.sender_type === "teacher" &&
                        msg.sender_id === teacher.id;

                      return (
                        <div
                          key={msg.id}
                          className={`flex ${isSent ? "justify-start" : "justify-end"}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                              isSent
                                ? "bg-blue-600 text-white"
                                : "bg-white border border-gray-200 text-gray-900"
                            }`}
                          >
                            <p className="text-sm">{msg.message}</p>
                            <p
                              className={`text-xs mt-1 ${isSent ? "text-blue-100" : "text-gray-500"}`}
                            >
                              {new Date(msg.created_at).toLocaleTimeString(
                                "ar-EG",
                                {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                },
                              )}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </div>

              {/* Message Input */}
              <form
                onSubmit={handleSendMessage}
                className="p-4 bg-white border-t border-gray-200"
              >
                <div className="flex gap-2">
                  <button
                    type="submit"
                    disabled={loading || !newMessage.trim()}
                    className="bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="اكتب رسالتك..."
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-right focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    dir="rtl"
                  />
                </div>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-50">
              <div className="text-center text-gray-500">
                <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-30" />
                <p className="text-lg">اختر محادثة للبدء</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
