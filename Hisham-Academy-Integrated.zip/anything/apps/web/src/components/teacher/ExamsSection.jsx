"use client";
import React from "react";
import { ChevronRight, FileText } from "lucide-react";

export function ExamsSection({ exams }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black text-gray-800">
          الامتحانات ({exams.length})
        </h2>
        <a
          href="/exams"
          className="flex items-center gap-1.5 px-4 py-2 bg-orange-500 text-white rounded-xl text-sm font-bold hover:bg-orange-600 transition-all"
        >
          إدارة الامتحانات <ChevronRight size={16} />
        </a>
      </div>
      {exams.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 py-12 text-center">
          <FileText size={36} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500">لا توجد امتحانات بعد</p>
        </div>
      ) : (
        exams.map((ex) => {
          const scores = Object.values(ex.scores || {}).filter(
            (v) => v !== "" && !isNaN(Number(v)),
          );
          const avg =
            scores.length > 0
              ? Math.round(
                  scores.reduce((a, b) => a + Number(b), 0) / scores.length,
                )
              : null;
          return (
            <div
              key={ex.id}
              className="bg-white rounded-2xl border border-gray-100 p-5"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-black text-gray-800">{ex.title}</h3>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {ex.subject} • {ex.grade} {ex.group && `• ${ex.group}`}
                  </p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {new Date(ex.date).toLocaleDateString("ar-EG")}
                  </p>
                </div>
                <div className="text-left">
                  {avg !== null ? (
                    <div>
                      <p className="text-2xl font-black text-blue-600">{avg}</p>
                      <p className="text-xs text-gray-400">
                        /{ex.maxScore} متوسط
                      </p>
                    </div>
                  ) : (
                    <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-lg">
                      لا درجات
                    </span>
                  )}
                </div>
              </div>
              {ex.pdfUrl && (
                <a
                  href={ex.pdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-1.5 text-xs text-blue-600 hover:underline font-bold"
                >
                  <FileText size={13} /> فتح PDF
                </a>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}
