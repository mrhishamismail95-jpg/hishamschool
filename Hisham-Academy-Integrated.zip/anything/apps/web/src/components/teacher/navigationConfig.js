export const NAV_ITEMS = [
  { key: "overview", label: "نظرة عامة", icon: "LayoutGrid" },
  { key: "attendance", label: "تحضير اليوم", icon: "CalendarCheck" },
  { key: "bookings", label: "الحصص والحجوزات", icon: "CalendarPlus", href: "/bookings" },
  { key: "students", label: "الطلاب", icon: "Users" },
  { key: "homework", label: "الواجبات", icon: "AlignLeft" },
  { key: "exams", label: "الامتحانات", icon: "FileText" },
  { key: "tools", label: "أدوات التدريس", icon: "Calculator" },
];

export const QUICK_TOOLS = [
  {
    label: "السبورة التفاعلية",
    icon: "Calculator",
    href: "/whiteboard",
    color: "from-purple-500 to-indigo-600",
  },
  {
    label: "الأرشيف",
    icon: "Archive",
    href: "/archive",
    color: "from-emerald-500 to-teal-600",
  },
  {
    label: "التقويم",
    icon: "CalendarCheck",
    href: "/calendar",
    color: "from-blue-500 to-cyan-600",
  },
  {
    label: "إدارة الامتحانات",
    icon: "FileText",
    href: "/exams",
    color: "from-orange-500 to-red-500",
  },
  {
    label: "إدارة الواجبات",
    icon: "AlignLeft",
    href: "/homework",
    color: "from-pink-500 to-rose-600",
  },
  {
    label: "التقارير المالية",
    icon: "BarChart2",
    href: "/finances",
    color: "from-green-500 to-emerald-600",
  },
];
