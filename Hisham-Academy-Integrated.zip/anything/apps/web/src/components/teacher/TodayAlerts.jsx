"use client";
import React from "react";
import { Bell, XCircle, Zap } from "lucide-react";

export function TodayAlerts({ lowSessions, unpaid }) {
  if (lowSessions === 0 && unpaid === 0) return null;

  return (
    <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
      <h3 className="font-black text-amber-800 mb-3 flex items-center gap-2">
        <Bell size={18} /> تنبيهات اليوم
      </h3>
      <div className="space-y-2">
        {lowSessions > 0 && (
          <div className="flex items-center gap-2 text-sm text-amber-700 font-medium">
            <XCircle size={16} className="text-orange-500 flex-shrink-0" />
            {lowSessions} طالب حصصهم قاربت على الانتهاء
          </div>
        )}
        {unpaid > 0 && (
          <div className="flex items-center gap-2 text-sm text-amber-700 font-medium">
            <Zap size={16} className="text-red-500 flex-shrink-0" />
            {unpaid} طالب لم يدفعوا رسوم هذا الشهر
          </div>
        )}
      </div>
    </div>
  );
}
