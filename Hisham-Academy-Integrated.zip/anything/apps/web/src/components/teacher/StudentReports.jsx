import { useState, useEffect } from "react";
import { FileText, Send, Download, MessageSquare } from "lucide-react";

export default function StudentReports({ teacher }) {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sendingReport, setSendingReport] = useState(false);

  useEffect(() => {
    loadStudents();
  }, [teacher]);

  const loadStudents = async () => {
    try {
      const response = await fetch(
        `/api/admins/assignments?teacher_id=${teacher.id}`,
      );
      const data = await response.json();
      setStudents(data.students || []);
    } catch (err) {
      console.error("Load students error:", err);
    }
  };

  const generateReport = async (student) => {
    setSelectedStudent(student);
    setLoading(true);

    try {
      // جلب حضور الطالب
      const attendanceRes = await fetch(
        `/api/academy/attendance?student_id=${student.id}`,
      );
      const attendanceData = await attendanceRes.json();

      // جلب درجات الطالب
      const examsRes = await fetch(
        `/api/academy/exams?student_id=${student.id}`,
      );
      const examsData = await examsRes.json();

      // حساب الإحصائيات
      const totalDays = attendanceData.attendance?.length || 0;
      const presentDays =
        attendanceData.attendance?.filter((a) => a.status === "present")
          .length || 0;
      const absentDays =
        attendanceData.attendance?.filter((a) => a.status === "absent")
          .length || 0;
      const attendanceRate =
        totalDays > 0 ? ((presentDays / totalDays) * 100).toFixed(1) : 0;

      const exams = examsData.exams || [];
      const avgScore =
        exams.length > 0
          ? (
              exams.reduce((sum, e) => sum + parseFloat(e.score || 0), 0) /
              exams.length
            ).toFixed(1)
          : 0;

      setReportData({
        student,
        stats: {
          totalDays,
          presentDays,
          absentDays,
          attendanceRate,
          examsCount: exams.length,
          avgScore,
        },
        attendance: attendanceData.attendance || [],
        exams,
      });
    } catch (err) {
      console.error("Generate report error:", err);
    } finally {
      setLoading(false);
    }
  };

  const sendReportViaWhatsApp = async () => {
    if (!reportData || !reportData.student.parent_phone) {
      alert("رقم هاتف ولي الأمر غير متوفر");
      return;
    }

    setSendingReport(true);

    try {
      const message = `
*تقرير مستوى الطالب*
      
*الطالب:* ${reportData.student.name}
*المعلم:* ${teacher.name}
*التاريخ:* ${new Date().toLocaleDateString("ar-EG")}

*📊 الإحصائيات:*
• نسبة الحضور: ${reportData.stats.attendanceRate}%
• أيام الحضور: ${reportData.stats.presentDays} / ${reportData.stats.totalDays}
• أيام الغياب: ${reportData.stats.absentDays}
• عدد الامتحانات: ${reportData.stats.examsCount}
• متوسط الدرجات: ${reportData.stats.avgScore}

*📈 الأداء العام:*
${reportData.stats.attendanceRate >= 80 ? "✅ حضور ممتاز" : reportData.stats.attendanceRate >= 60 ? "⚠️ حضور متوسط" : "❌ حضور ضعيف"}
${reportData.stats.avgScore >= 80 ? "✅ أداء ممتاز" : reportData.stats.avgScore >= 60 ? "⚠️ أداء متوسط" : "❌ يحتاج تحسين"}

_تم الإرسال من منصة أكاديمية هشام_
      `.trim();

      // تشفير الرسالة للURL
      const encodedMessage = encodeURIComponent(message);
      const phone = reportData.student.parent_phone.replace(/\D/g, "");
      const whatsappUrl = `https://wa.me/${phone}?text=${encodedMessage}`;

      // فتح WhatsApp في نافذة جديدة
      window.open(whatsappUrl, "_blank");
    } catch (err) {
      console.error("Send report error:", err);
    } finally {
      setSendingReport(false);
    }
  };

  const downloadReportPDF = async () => {
    if (!reportData) return;

    try {
      const response = await fetch("/api/reports/student-pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          student: reportData.student,
          teacher,
          stats: reportData.stats,
          attendance: reportData.attendance,
          exams: reportData.exams,
        }),
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `تقرير_${reportData.student.name}_${new Date().toISOString().split("T")[0]}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (err) {
      console.error("Download PDF error:", err);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 text-right">
        تقارير الطلاب
      </h2>

      {/* Students List */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4 text-right">
          اختر طالباً لعرض التقرير
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {students.map((student) => (
            <button
              key={student.id}
              onClick={() => generateReport(student)}
              className="p-4 border border-gray-200 rounded-lg hover:bg-blue-50 hover:border-blue-300 transition-colors text-right"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                  {student.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <p className="font-bold text-gray-900">{student.name}</p>
                  <p className="text-sm text-gray-500">{student.grade}</p>
                </div>
                <FileText className="w-5 h-5 text-gray-400" />
              </div>
            </button>
          ))}
        </div>

        {students.length === 0 && (
          <p className="text-center text-gray-500 py-8">
            لا يوجد طلاب معينون لك
          </p>
        )}
      </div>

      {/* Report Display */}
      {loading && (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <div
            className="inline-block h-12 w-12 border-b-2 border-blue-600 rounded-full"
            style={{
              animation: "spin 1s linear infinite",
            }}
          ></div>
          <p className="mt-4 text-gray-600">جاري إنشاء التقرير...</p>
          <style jsx global>{`
            @keyframes spin {
              from { transform: rotate(0deg); }
              to { transform: rotate(360deg); }
            }
          `}</style>
        </div>
      )}

      {reportData && !loading && (
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {/* Report Header */}
          <div className="bg-gradient-to-l from-blue-600 to-blue-700 p-6 text-white">
            <h3 className="text-2xl font-bold mb-2 text-right">
              تقرير مستوى الطالب
            </h3>
            <div className="flex justify-between items-center">
              <div className="text-right">
                <p className="text-blue-100">
                  الطالب: {reportData.student.name}
                </p>
                <p className="text-blue-100 text-sm">
                  التاريخ: {new Date().toLocaleDateString("ar-EG")}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={downloadReportPDF}
                  className="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 flex items-center gap-2 text-sm"
                >
                  <Download className="w-4 h-4" />
                  تحميل PDF
                </button>
                <button
                  onClick={sendReportViaWhatsApp}
                  disabled={sendingReport}
                  className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center gap-2 text-sm disabled:opacity-50"
                >
                  <MessageSquare className="w-4 h-4" />
                  إرسال لولي الأمر
                </button>
              </div>
            </div>
          </div>

          {/* Report Content */}
          <div className="p-6 space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-blue-50 rounded-lg p-4 text-right">
                <p className="text-sm text-gray-600 mb-1">نسبة الحضور</p>
                <p className="text-2xl font-bold text-blue-600">
                  {reportData.stats.attendanceRate}%
                </p>
              </div>

              <div className="bg-green-50 rounded-lg p-4 text-right">
                <p className="text-sm text-gray-600 mb-1">أيام الحضور</p>
                <p className="text-2xl font-bold text-green-600">
                  {reportData.stats.presentDays}
                </p>
              </div>

              <div className="bg-orange-50 rounded-lg p-4 text-right">
                <p className="text-sm text-gray-600 mb-1">أيام الغياب</p>
                <p className="text-2xl font-bold text-orange-600">
                  {reportData.stats.absentDays}
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-4 text-right">
                <p className="text-sm text-gray-600 mb-1">متوسط الدرجات</p>
                <p className="text-2xl font-bold text-purple-600">
                  {reportData.stats.avgScore}
                </p>
              </div>
            </div>

            {/* Performance Analysis */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h4 className="font-bold text-gray-900 mb-3 text-right">
                تحليل الأداء
              </h4>
              <div className="space-y-2 text-right">
                <div className="flex items-center gap-2">
                  {reportData.stats.attendanceRate >= 80 ? (
                    <span className="text-green-600">✅ حضور ممتاز</span>
                  ) : reportData.stats.attendanceRate >= 60 ? (
                    <span className="text-orange-600">
                      ⚠️ حضور متوسط - يحتاج تحسين
                    </span>
                  ) : (
                    <span className="text-red-600">
                      ❌ حضور ضعيف - يحتاج متابعة
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {reportData.stats.avgScore >= 80 ? (
                    <span className="text-green-600">
                      ✅ أداء أكاديمي ممتاز
                    </span>
                  ) : reportData.stats.avgScore >= 60 ? (
                    <span className="text-orange-600">
                      ⚠️ أداء متوسط - يمكن التحسين
                    </span>
                  ) : (
                    <span className="text-red-600">❌ يحتاج إلى دعم إضافي</span>
                  )}
                </div>
              </div>
            </div>

            {/* Recent Exams */}
            {reportData.exams.length > 0 && (
              <div>
                <h4 className="font-bold text-gray-900 mb-3 text-right">
                  آخر الامتحانات
                </h4>
                <div className="space-y-2">
                  {reportData.exams.slice(0, 5).map((exam, idx) => (
                    <div
                      key={idx}
                      className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
                    >
                      <span className="text-gray-600 text-sm">
                        {new Date(exam.exam_date).toLocaleDateString("ar-EG")}
                      </span>
                      <span className="font-medium text-gray-900">
                        {exam.title}
                      </span>
                      <span
                        className={`font-bold ${
                          exam.score >= 80
                            ? "text-green-600"
                            : exam.score >= 60
                              ? "text-orange-600"
                              : "text-red-600"
                        }`}
                      >
                        {exam.score} / {exam.max_score}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
