"use client";
import React from "react";
import {
  Calculator,
  Archive,
  CalendarCheck,
  FileText,
  AlignLeft,
  BarChart2,
} from "lucide-react";

const iconMap = {
  Calculator,
  Archive,
  CalendarCheck,
  FileText,
  AlignLeft,
  BarChart2,
};

export function QuickToolsGrid({ tools }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <h2 className="font-black text-gray-800 mb-4 flex items-center gap-2">
        <Calculator size={18} className="text-purple-600" /> أدوات التدريس
        السريعة
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {tools.map(({ label, icon: iconName, href, color }) => {
          const Icon = iconMap[iconName];
          return (
            <a
              key={label}
              href={href}
              className="flex items-center gap-3 p-4 bg-gray-50 hover:bg-gray-100 rounded-2xl transition-all group border border-gray-100 hover:border-gray-200"
            >
              <div
                className={`w-10 h-10 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-md group-hover:scale-110 transition-all`}
              >
                <Icon size={20} className="text-white" />
              </div>
              <span className="font-bold text-gray-700 text-sm">{label}</span>
            </a>
          );
        })}
      </div>
    </div>
  );
}
