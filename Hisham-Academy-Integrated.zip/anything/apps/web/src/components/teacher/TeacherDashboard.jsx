"use client";
import React, { useState, useEffect, useMemo } from "react";
import { Toaster } from "sonner";
import { toast } from "sonner";
import { useStore } from "@/utils/store";
import { clearTeacherSession, getTeacherSession } from "@/utils/teacherAuth";
import {
  BookOpen,
  Users,
  CalendarCheck,
  FileText,
  Bell,
  LogOut,
  ChevronRight,
  Clock,
  CheckCircle2,
  XCircle,
  Search,
  LayoutGrid,
  AlignLeft,
  Menu,
  Zap,
  Calendar,
  Calculator,
} from "lucide-react";
import { WAIcon } from "@/components/teacher/WAIcon";
import { motion } from "motion/react";

// ── Helpers ───────────────────────────────────────────────────────────────────
function calcStats(students, attendance, payments, todayDate) {
  const todayAtt = attendance.filter((a) => a.date?.startsWith(todayDate));
  const thisMonth = todayDate.slice(0, 7);
  const paidIds = new Set(
    payments
      .filter((p) => p.date?.startsWith(thisMonth))
      .map((p) => p.studentId),
  );
  const presentToday = todayAtt.filter(
    (a) => a.status === "present" || a.status === "late",
  ).length;
  const lowSessions = students.filter((s) => {
    const pkg = Number(s.sessionPackage) || 8;
    const used = attendance.filter(
      (a) =>
        a.studentId === s.id && (a.status === "present" || a.status === "late"),
    ).length;
    return Math.max(0, pkg - used) <= 2;
  }).length;
  return { todayAtt, thisMonth, presentToday, lowSessions, paidIds };
}

export function TeacherDashboard({ onLogout }) {
  const {
    students,
    attendance,
    payments,
    homework,
    exams,
    fetchData,
    markAttendance,
  } = useStore();
  const [activeSection, setActiveSection] = useState("overview");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchStudent, setSearchStudent] = useState("");
  const [todayDate] = useState(new Date().toISOString().split("T")[0]);

  // Teacher profile from session
  const session = useMemo(() => {
    if (typeof window === "undefined") return {};
    try {
      return JSON.parse(sessionStorage.getItem("teacher_session_v1") || "{}");
    } catch {
      return {};
    }
  }, []);
  const teacherName = session.name || "المعلم";
  const teacherGroups = useMemo(
    () =>
      session.groups
        ? session.groups
            .split(/[,،]/)
            .map((g) => g.trim())
            .filter(Boolean)
        : [],
    [session.groups],
  );

  useEffect(() => {
    fetchData();
  }, []);

  const { todayAtt, thisMonth, presentToday, lowSessions, paidIds } = calcStats(
    students,
    attendance,
    payments,
    todayDate,
  );

  // Filter to teacher's groups only (if specified)
  const myStudents = useMemo(
    () =>
      teacherGroups.length > 0
        ? students.filter((s) => teacherGroups.includes(s.group))
        : students,
    [students, teacherGroups],
  );

  const groups = useMemo(
    () => [...new Set(myStudents.map((s) => s.group).filter(Boolean))],
    [myStudents],
  );

  const filteredStudents = myStudents.filter(
    (s) =>
      !searchStudent ||
      s.name.toLowerCase().includes(searchStudent.toLowerCase()) ||
      s.group?.toLowerCase().includes(searchStudent.toLowerCase()),
  );

  const unrecorded = myStudents.filter(
    (s) => !todayAtt.find((a) => a.studentId === s.id),
  ).length;

  // Schedule for teacher's groups
  const schedules = useMemo(() => {
    try {
      const all = JSON.parse(localStorage.getItem("schedule") || "[]");
      return teacherGroups.length > 0
        ? all.filter((s) => teacherGroups.includes(s.name))
        : all;
    } catch {
      return [];
    }
  }, [teacherGroups]);

  // Smart notifications
  const teacherNotifs = useMemo(() => {
    const notifs = [];
    if (lowSessions > 0)
      notifs.push({
        type: "warn",
        msg: `${lowSessions} طالب حصصهم قاربت على الانتهاء`,
        icon: "⚡",
      });
    if (unrecorded > 0)
      notifs.push({
        type: "info",
        msg: `${unrecorded} طالب لم يُسجَّل حضورهم اليوم`,
        icon: "📅",
      });
    const overdueHW = homework.filter(
      (hw) =>
        hw.dueDate < todayDate &&
        (hw.submissions || []).length <
          myStudents.filter((s) => !hw.group || s.group === hw.group).length,
    );
    if (overdueHW.length > 0)
      notifs.push({
        type: "warn",
        msg: `${overdueHW.length} واجب تجاوز موعده ولم يكتمل التسليم`,
        icon: "📝",
      });
    return notifs;
  }, [lowSessions, unrecorded, homework, myStudents, todayDate]);

  const NAV = [
    { key: "overview", label: "نظرة عامة", icon: LayoutGrid },
    { key: "attendance", label: "تحضير اليوم", icon: CalendarCheck },
    { key: "students", label: `طلابي (${myStudents.length})`, icon: Users },
    { key: "homework", label: "الواجبات", icon: AlignLeft },
    { key: "exams", label: "الامتحانات", icon: FileText },
    { key: "schedule", label: "الجدول", icon: Calendar },
    { key: "whiteboard", label: "السبورة", icon: Calculator },
    {
      key: "notifications",
      label: "الإشعارات",
      icon: Bell,
      badge: teacherNotifs.length,
    },
  ];

  const markQuick = async (student, status) => {
    try {
      await markAttendance({
        studentId: student.id,
        studentName: student.name,
        date: todayDate,
        status,
        group: student.group,
      });
      await fetchData();
      toast.success(
        `${student.name}: ${status === "present" ? "✅ حاضر" : status === "absent" ? "❌ غائب" : "⏰ متأخر"}`,
      );
    } catch {
      toast.error("خطأ في تسجيل الحضور");
    }
  };

  const getStudentStatus = (id) =>
    todayAtt.find((a) => a.studentId === id)?.status || null;

  const handleLogout = () => {
    fetch("/api/academy/auth", { method: "DELETE" }).catch(() => {});
    clearTeacherSession();
    onLogout();
  };

  return (
    <div className="min-h-screen bg-gray-50 flex" dir="rtl">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 right-0 z-50 w-64 bg-gradient-to-b from-purple-900 to-indigo-900 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:inset-auto ${sidebarOpen ? "translate-x-0" : "translate-x-full"}`}
      >
        <div className="h-full flex flex-col px-4 py-6 overflow-y-auto">
          {/* Profile */}
          <div className="flex items-center gap-3 px-2 mb-3">
            <div className="w-11 h-11 bg-white/20 rounded-xl flex items-center justify-center text-white font-black text-lg flex-shrink-0">
              {teacherName?.[0] || "م"}
            </div>
            <div className="min-w-0">
              <p className="text-white font-black text-sm truncate">
                {teacherName}
              </p>
              <p className="text-purple-300 text-xs">
                {session.subject || "المعلم"}
              </p>
            </div>
          </div>
          {teacherGroups.length > 0 && (
            <div className="px-2 mb-3">
              <p className="text-purple-400 text-xs mb-1">مجموعاتي:</p>
              <div className="flex flex-wrap gap-1">
                {teacherGroups.map((g) => (
                  <span
                    key={g}
                    className="text-[10px] bg-white/10 text-purple-200 px-2 py-0.5 rounded-lg"
                  >
                    {g}
                  </span>
                ))}
              </div>
            </div>
          )}
          <div className="h-px bg-white/10 mb-3" />

          <nav className="flex-1 space-y-1">
            <a href="/bookings" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-purple-200 hover:bg-white/10 hover:text-white transition-all text-sm">
              <Calendar size={18} /><span className="flex-1">الحصص والحجوزات</span>
            </a>
            {NAV.map(({ key, label, icon: Icon, badge }) => (
              <button
                key={key}
                onClick={() => {
                  setActiveSection(key);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-right ${activeSection === key ? "bg-white/20 text-white font-bold" : "text-purple-200 hover:bg-white/10 hover:text-white"}`}
              >
                <Icon size={18} />
                <span className="text-sm flex-1">{label}</span>
                {badge > 0 && (
                  <span className="bg-red-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center">
                    {badge}
                  </span>
                )}
              </button>
            ))}
          </nav>

          <div className="pt-4 border-t border-white/10 space-y-1 mt-4">
            <a
              href="/admin"
              className="flex items-center gap-3 px-4 py-2.5 text-purple-300 hover:text-white hover:bg-white/10 rounded-xl transition-all text-sm"
            >
              ← لوحة الإدارة
            </a>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-red-400 hover:bg-red-500/20 rounded-xl transition-all text-sm"
            >
              <LogOut size={16} /> تسجيل خروج
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 lg:px-6 sticky top-0 z-30 shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-xl"
            >
              <Menu size={22} />
            </button>
            <div>
              <h1 className="font-black text-gray-800 text-base">
                {NAV.find((n) => n.key === activeSection)?.label?.replace(
                  / \(\d+\)/,
                  "",
                ) || "بوابة المعلم"}
              </h1>
              <p className="text-xs text-gray-400">
                {new Date().toLocaleDateString("ar-EG", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveSection("whiteboard")}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-purple-100 text-purple-700 rounded-xl text-xs font-bold hover:bg-purple-200 transition-all"
            >
              <Calculator size={15} /> السبورة
            </button>
            {teacherNotifs.length > 0 && (
              <button
                onClick={() => setActiveSection("notifications")}
                className="relative p-2 text-orange-500 hover:bg-orange-50 rounded-xl"
              >
                <Bell size={20} />
                <span className="absolute -top-1 -left-1 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                  {teacherNotifs.length}
                </span>
              </button>
            )}
            <div className="w-9 h-9 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-black text-sm">
              {teacherName?.[0] || "م"}
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6">
          {/* ── Overview ─────────────────────────────────────────────────── */}
          {activeSection === "overview" && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  {
                    label: "طلابي",
                    val: myStudents.length,
                    Icon: Users,
                    color: "from-blue-500 to-cyan-500",
                    sub: `${groups.length} مجموعة`,
                  },
                  {
                    label: "حضور اليوم",
                    val: presentToday,
                    Icon: CalendarCheck,
                    color: "from-green-500 to-emerald-500",
                    sub: `من ${myStudents.length}`,
                  },
                  {
                    label: "لم يُسجَّل",
                    val: unrecorded,
                    Icon: Clock,
                    color: "from-orange-500 to-red-500",
                    sub: "اليوم",
                  },
                  {
                    label: "تنبيهات",
                    val: teacherNotifs.length,
                    Icon: Bell,
                    color: "from-purple-500 to-pink-500",
                    sub: "تحتاج متابعة",
                  },
                ].map(({ label, val, Icon, color, sub }) => (
                  <motion.div
                    key={label}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-all"
                  >
                    <div
                      className={`w-11 h-11 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center mb-3 shadow-md`}
                    >
                      <Icon size={22} className="text-white" />
                    </div>
                    <p className="text-2xl font-black text-gray-800">{val}</p>
                    <p className="text-xs text-gray-500 font-medium">{label}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{sub}</p>
                  </motion.div>
                ))}
              </div>

              {groups.length > 0 && (
                <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                  <h2 className="font-black text-gray-800 mb-4 flex items-center gap-2">
                    <Users size={18} className="text-blue-600" /> مجموعاتي
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {groups.map((g) => {
                      const gs = myStudents.filter((s) => s.group === g);
                      const present = gs.filter((s) =>
                        todayAtt.find(
                          (a) =>
                            a.studentId === s.id &&
                            (a.status === "present" || a.status === "late"),
                        ),
                      ).length;
                      return (
                        <div
                          key={g}
                          className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100"
                        >
                          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Users size={20} className="text-blue-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-bold text-gray-800 text-sm truncate">
                              {g}
                            </p>
                            <div className="flex items-center gap-3 mt-1">
                              <span className="text-xs text-gray-400">
                                {gs.length} طالب
                              </span>
                              <span className="text-xs text-green-600 font-medium">
                                ✓ {present} حضروا
                              </span>
                            </div>
                          </div>
                          <button
                            onClick={() => setActiveSection("attendance")}
                            className="text-xs text-blue-600 font-bold hover:underline"
                          >
                            تحضير <ChevronRight size={12} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {teacherNotifs.length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
                  <h3 className="font-black text-amber-800 mb-3 flex items-center gap-2">
                    <Bell size={18} /> تنبيهات اليوم
                  </h3>
                  {teacherNotifs.map((n, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-2 text-sm text-amber-700 font-medium py-1"
                    >
                      <span>{n.icon}</span>
                      {n.msg}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── Attendance ─────────────────────────────────────────────── */}
          {activeSection === "attendance" && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-gray-800">
                  تحضير —{" "}
                  {new Date(todayDate).toLocaleDateString("ar-EG", {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                  })}
                </h2>
                <a
                  href="/attendance"
                  className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all"
                >
                  التحضير الكامل <ChevronRight size={16} />
                </a>
              </div>
              <div className="relative">
                <Search
                  size={18}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  value={searchStudent}
                  onChange={(e) => setSearchStudent(e.target.value)}
                  placeholder="بحث..."
                  className="w-full pr-10 pl-4 py-3 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-500 transition-all"
                />
              </div>
              <div className="space-y-2">
                {filteredStudents.map((s) => {
                  const status = getStudentStatus(s.id);
                  return (
                    <div
                      key={s.id}
                      className={`flex items-center gap-3 p-4 rounded-2xl border-2 transition-all ${status === "present" ? "bg-green-50 border-green-200" : status === "absent" ? "bg-red-50 border-red-200" : status === "late" ? "bg-orange-50 border-orange-200" : "bg-white border-gray-100"}`}
                    >
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold flex-shrink-0">
                        {s.name?.[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-gray-800 text-sm truncate">
                          {s.name}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                          {s.group && <span>{s.group}</span>}
                          {s.grade && <span>• {s.grade}</span>}
                        </div>
                      </div>
                      <div className="flex gap-1.5">
                        {["present", "late", "absent"].map((st) => (
                          <button
                            key={st}
                            onClick={() => markQuick(s, st)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${status === st ? (st === "present" ? "bg-green-600 text-white" : st === "absent" ? "bg-red-600 text-white" : "bg-orange-500 text-white") : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}
                          >
                            {st === "present"
                              ? "✓"
                              : st === "absent"
                                ? "✗"
                                : "⏰"}
                          </button>
                        ))}
                        {s.phone && (
                          <a
                            href={`https://wa.me/2${String(s.phone).replace(/^0/, "")}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-green-100 text-green-600 rounded-lg hover:bg-green-200"
                          >
                            <WAIcon size={16} />
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── Students ─────────────────────────────────────────────────── */}
          {activeSection === "students" && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-gray-800">
                  طلابي ({myStudents.length})
                </h2>
                <a
                  href="/students"
                  className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all"
                >
                  إدارة شاملة <ChevronRight size={16} />
                </a>
              </div>
              <div className="relative">
                <Search
                  size={18}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  value={searchStudent}
                  onChange={(e) => setSearchStudent(e.target.value)}
                  placeholder="بحث..."
                  className="w-full pr-10 pl-4 py-3 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-500"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredStudents.map((s) => {
                  const pkg = Number(s.sessionPackage) || 8;
                  const used = attendance.filter(
                    (a) =>
                      a.studentId === s.id &&
                      (a.status === "present" || a.status === "late"),
                  ).length;
                  const rem = Math.max(0, pkg - used);
                  const paid = paidIds.has(s.id);
                  return (
                    <div
                      key={s.id}
                      className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5"
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-11 h-11 bg-gradient-to-br from-blue-400 to-indigo-600 rounded-xl flex items-center justify-center text-white font-black">
                          {s.name?.[0]}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-black text-gray-800 truncate">
                            {s.name}
                          </p>
                          <p className="text-xs text-gray-400 font-mono">
                            {s.code}
                          </p>
                        </div>
                        <span
                          className={`text-xs font-bold px-2.5 py-1 rounded-full ${paid ? "bg-green-100 text-green-700" : "bg-red-100 text-red-500"}`}
                        >
                          {paid ? "دفع ✓" : "لم يدفع"}
                        </span>
                      </div>
                      <div className="space-y-2 mb-3">
                        {s.grade && (
                          <p className="text-xs text-gray-500">
                            {s.grade} {s.group && `• ${s.group}`}
                          </p>
                        )}
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500">الحصص المتبقية</span>
                          <span
                            className={`font-black ${rem === 0 ? "text-red-500" : rem <= 2 ? "text-orange-500" : "text-green-600"}`}
                          >
                            {rem} / {pkg}
                          </span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${rem === 0 ? "bg-red-500" : rem <= 2 ? "bg-orange-400" : "bg-green-500"}`}
                            style={{ width: `${(used / pkg) * 100}%` }}
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {s.phone && (
                          <a
                            href={`https://wa.me/2${String(s.phone).replace(/^0/, "")}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-green-50 text-green-600 rounded-xl text-xs font-bold hover:bg-green-100"
                          >
                            <WAIcon size={14} /> طالب
                          </a>
                        )}
                        {s.parentPhone && (
                          <a
                            href={`https://wa.me/2${String(s.parentPhone).replace(/^0/, "")}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100"
                          >
                            <WAIcon size={14} /> ولي أمر
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── Homework ─────────────────────────────────────────────────── */}
          {activeSection === "homework" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-gray-800">
                  الواجبات ({homework.length})
                </h2>
                <a
                  href="/homework"
                  className="flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white rounded-xl text-sm font-bold hover:bg-pink-700 transition-all"
                >
                  إدارة الواجبات <ChevronRight size={16} />
                </a>
              </div>
              {homework.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-100 py-12 text-center">
                  <AlignLeft size={36} className="mx-auto text-gray-300 mb-3" />
                  <p className="text-gray-500">لا توجد واجبات بعد</p>
                </div>
              ) : (
                homework.map((hw) => {
                  const total = myStudents.filter(
                    (s) => !hw.group || s.group === hw.group,
                  ).length;
                  const submitted = (hw.submissions || []).length;
                  const overdue = hw.dueDate < todayDate;
                  return (
                    <div
                      key={hw.id}
                      className={`bg-white rounded-2xl border-2 p-5 ${overdue && submitted < total ? "border-red-200 bg-red-50/30" : "border-gray-100"}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-black text-gray-800">
                            {hw.title}
                          </h3>
                          {hw.subject && (
                            <p className="text-xs text-gray-400 mt-0.5">
                              {hw.subject} {hw.group && `• ${hw.group}`}
                            </p>
                          )}
                        </div>
                        <span
                          className={`text-xs font-bold px-2.5 py-1 rounded-full ${overdue && submitted < total ? "bg-red-100 text-red-600" : submitted === total ? "bg-green-100 text-green-600" : "bg-blue-100 text-blue-600"}`}
                        >
                          {overdue && submitted < total
                            ? "متأخر"
                            : submitted === total
                              ? "مكتمل"
                              : "نشط"}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                        <span>
                          التسليم: {submitted}/{total}
                        </span>
                        <span>
                          الموعد:{" "}
                          {new Date(hw.dueDate).toLocaleDateString("ar-EG")}
                        </span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${submitted === total ? "bg-green-500" : overdue ? "bg-red-400" : "bg-blue-500"}`}
                          style={{
                            width: `${total > 0 ? (submitted / total) * 100 : 0}%`,
                          }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* ── Exams ────────────────────────────────────────────────────── */}
          {activeSection === "exams" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-gray-800">
                  الامتحانات ({exams.length})
                </h2>
                <a
                  href="/exams"
                  className="flex items-center gap-1.5 px-4 py-2 bg-orange-500 text-white rounded-xl text-sm font-bold hover:bg-orange-600 transition-all"
                >
                  رفع الدرجات <ChevronRight size={16} />
                </a>
              </div>
              {exams.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-100 py-12 text-center">
                  <FileText size={36} className="mx-auto text-gray-300 mb-3" />
                  <p className="text-gray-500">لا توجد امتحانات بعد</p>
                </div>
              ) : (
                exams.map((ex) => {
                  const scores = Object.values(ex.scores || {}).filter(
                    (v) => v !== "" && !isNaN(Number(v)),
                  );
                  const avg =
                    scores.length > 0
                      ? Math.round(
                          scores.reduce((a, b) => a + Number(b), 0) /
                            scores.length,
                        )
                      : null;
                  return (
                    <div
                      key={ex.id}
                      className="bg-white rounded-2xl border border-gray-100 p-5"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-black text-gray-800">
                            {ex.title}
                          </h3>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {ex.subject} • {ex.grade}{" "}
                            {ex.group && `• ${ex.group}`}
                          </p>
                          <p className="text-xs text-gray-400">
                            {new Date(ex.date).toLocaleDateString("ar-EG")}
                          </p>
                        </div>
                        {avg !== null ? (
                          <div className="text-left">
                            <p className="text-2xl font-black text-blue-600">
                              {avg}
                            </p>
                            <p className="text-xs text-gray-400">
                              /{ex.maxScore} متوسط
                            </p>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-lg">
                            لا درجات
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* ── Schedule ─────────────────────────────────────────────────── */}
          {activeSection === "schedule" && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-gray-800">
                  الجدول الأسبوعي
                </h2>
                <a
                  href="/schedule"
                  className="flex items-center gap-1.5 px-4 py-2 bg-teal-600 text-white rounded-xl text-sm font-bold hover:bg-teal-700 transition-all"
                >
                  إدارة الجدول <ChevronRight size={16} />
                </a>
              </div>
              {schedules.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-100 py-12 text-center">
                  <Calendar size={36} className="mx-auto text-gray-300 mb-3" />
                  <p className="text-gray-500">لا يوجد جدول بعد</p>
                  <a
                    href="/schedule"
                    className="mt-3 inline-flex items-center gap-2 px-5 py-2.5 bg-teal-600 text-white rounded-xl text-sm font-bold hover:bg-teal-700 transition-all mt-4"
                  >
                    إنشاء جدول
                  </a>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    "السبت",
                    "الأحد",
                    "الاثنين",
                    "الثلاثاء",
                    "الأربعاء",
                    "الخميس",
                    "الجمعة",
                  ].map((day) => {
                    const daySessions = schedules.filter((s) => s.day === day);
                    if (daySessions.length === 0) return null;
                    return (
                      <div
                        key={day}
                        className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
                      >
                        <div className="px-5 py-3 bg-teal-50 border-b border-teal-100">
                          <h3 className="font-black text-teal-800">{day}</h3>
                        </div>
                        <div className="divide-y divide-gray-50">
                          {daySessions
                            .sort((a, b) =>
                              (a.time || "").localeCompare(b.time || ""),
                            )
                            .map((s) => (
                              <div
                                key={s.id}
                                className="px-5 py-3 flex items-center gap-3"
                              >
                                <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                  <Clock size={15} className="text-teal-600" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-bold text-gray-800 text-sm truncate">
                                    {s.name}
                                  </p>
                                  <p className="text-xs text-teal-600">
                                    {s.time}
                                  </p>
                                </div>
                                <span className="text-xs text-gray-400 flex-shrink-0">
                                  {
                                    students.filter((st) => st.group === s.name)
                                      .length
                                  }{" "}
                                  طالب
                                </span>
                              </div>
                            ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ── Whiteboard ─────────────────────────────────────────────── */}
          {activeSection === "whiteboard" && (
            <div className="space-y-5">
              <h2 className="text-xl font-black text-gray-800">
                السبورة التفاعلية
              </h2>
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-5 shadow-xl">
                  <Calculator size={36} className="text-white" />
                </div>
                <h3 className="text-xl font-black text-gray-800 mb-2">
                  سبورة الرياضيات التفاعلية
                </h3>
                <p className="text-gray-500 text-sm mb-6 max-w-md mx-auto">
                  اشرح الدروس وارسم الأشكال الهندسية وأضف الرموز الرياضية بسهولة
                  — يمكنك مشاركة الشاشة مع طلابك
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6 text-right max-w-lg mx-auto">
                  {[
                    "✏️ قلم رسم احترافي",
                    "📐 أشكال هندسية (خط / مستطيل / دائرة)",
                    "🔢 72 رمز رياضي",
                    "↩️ تراجع وإعادة",
                    "🎨 ألوان وخلفيات متعددة",
                    "📥 تحميل كصورة PNG",
                  ].map((f) => (
                    <div
                      key={f}
                      className="bg-purple-50 rounded-xl p-3 text-xs text-purple-700 font-medium"
                    >
                      {f}
                    </div>
                  ))}
                </div>
                <a
                  href="/whiteboard"
                  target="_blank"
                  className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-2xl font-black text-base hover:shadow-xl transition-all"
                >
                  <Calculator size={22} /> فتح السبورة التفاعلية ←
                </a>
              </div>
            </div>
          )}

          {/* ── Notifications ───────────────────────────────────────────── */}
          {activeSection === "notifications" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-gray-800">
                  الإشعارات والتنبيهات
                </h2>
                <a
                  href="/notifications"
                  className="flex items-center gap-1.5 px-4 py-2 bg-gray-800 text-white rounded-xl text-sm font-bold hover:bg-gray-900 transition-all"
                >
                  كل الإشعارات <ChevronRight size={16} />
                </a>
              </div>
              {teacherNotifs.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-100 py-12 text-center">
                  <CheckCircle2
                    size={36}
                    className="mx-auto text-green-400 mb-3"
                  />
                  <p className="text-gray-500 font-medium">
                    🎉 لا توجد تنبيهات — كل شيء على ما يرام!
                  </p>
                </div>
              ) : (
                teacherNotifs.map((n, i) => (
                  <div
                    key={i}
                    className={`flex items-start gap-4 p-5 rounded-2xl border-2 ${n.type === "warn" ? "bg-orange-50 border-orange-200" : "bg-blue-50 border-blue-200"}`}
                  >
                    <div
                      className={`w-10 h-10 ${n.type === "warn" ? "bg-orange-100" : "bg-blue-100"} rounded-xl flex items-center justify-center text-xl flex-shrink-0`}
                    >
                      {n.icon}
                    </div>
                    <p
                      className={`font-bold text-sm pt-2 ${n.type === "warn" ? "text-orange-800" : "text-blue-800"}`}
                    >
                      {n.msg}
                    </p>
                  </div>
                ))
              )}

              {/* Low sessions alert list */}
              {myStudents.filter((s) => {
                const pkg = Number(s.sessionPackage) || 8;
                const used = attendance.filter(
                  (a) =>
                    a.studentId === s.id &&
                    (a.status === "present" || a.status === "late"),
                ).length;
                return Math.max(0, pkg - used) <= 2;
              }).length > 0 && (
                <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                  <h3 className="font-black text-gray-800 mb-3 flex items-center gap-2">
                    <Zap size={18} className="text-orange-500" /> طلاب حصصهم
                    قاربت على الانتهاء
                  </h3>
                  <div className="space-y-2">
                    {myStudents
                      .filter((s) => {
                        const pkg = Number(s.sessionPackage) || 8;
                        const used = attendance.filter(
                          (a) =>
                            a.studentId === s.id &&
                            (a.status === "present" || a.status === "late"),
                        ).length;
                        return Math.max(0, pkg - used) <= 2;
                      })
                      .map((s) => {
                        const pkg = Number(s.sessionPackage) || 8;
                        const used = attendance.filter(
                          (a) =>
                            a.studentId === s.id &&
                            (a.status === "present" || a.status === "late"),
                        ).length;
                        const rem = Math.max(0, pkg - used);
                        return (
                          <div
                            key={s.id}
                            className="flex items-center gap-3 p-3 bg-orange-50 rounded-xl"
                          >
                            <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center text-orange-600 font-black flex-shrink-0">
                              {s.name?.[0]}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-bold text-gray-800 text-sm truncate">
                                {s.name}
                              </p>
                              <p className="text-xs text-orange-600">
                                متبقي {rem} حصة من {pkg}
                              </p>
                            </div>
                            {s.phone && (
                              <a
                                href={`https://wa.me/2${String(s.phone).replace(/^0/, "")}?text=${encodeURIComponent(`السلام عليكم ${s.name}، باقة حصصك اقتربت من الانتهاء. يرجى التجديد`)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1.5 bg-green-100 text-green-600 rounded-lg hover:bg-green-200"
                              >
                                <WAIcon size={15} />
                              </a>
                            )}
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>
      <Toaster position="top-center" richColors />
    </div>
  );
}
