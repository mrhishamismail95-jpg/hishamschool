"use client";
import React from "react";
import { ChevronRight } from "lucide-react";
import {
  Calculator,
  Archive,
  CalendarCheck,
  FileText,
  AlignLeft,
  BarChart2,
} from "lucide-react";

const iconMap = {
  Calculator,
  Archive,
  CalendarCheck,
  FileText,
  AlignLeft,
  BarChart2,
};

export function ToolsSection({ tools }) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-black text-gray-800">أدوات التدريس</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {tools.map(({ label, icon: iconName, href, color }) => {
          const Icon = iconMap[iconName];
          return (
            <a
              key={label}
              href={href}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex items-center gap-5 hover:shadow-lg transition-all group"
            >
              <div
                className={`w-16 h-16 bg-gradient-to-br ${color} rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg group-hover:scale-110 transition-all`}
              >
                <Icon size={28} className="text-white" />
              </div>
              <div>
                <h3 className="font-black text-gray-800 text-base">{label}</h3>
                <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                  فتح الأداة <ChevronRight size={12} />
                </p>
              </div>
            </a>
          );
        })}
      </div>
    </div>
  );
}
