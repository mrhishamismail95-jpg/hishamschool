"use client";
import React, { useState } from "react";
import { motion } from "motion/react";
import { BookOpen } from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "sonner";
import { findTeacher, setTeacherSession } from "@/utils/teacherAuth";

export function TeacherLogin({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 600));
    const teacher = findTeacher(email.trim(), password);
    if (teacher) {
      setTeacherSession({
        email: teacher.email,
        name: teacher.name || "المعلم",
        subject: teacher.subject || "",
        phone: teacher.phone || "",
        groups: teacher.groups || "",
        at: new Date().toISOString(),
      });
      onLogin();
    } else {
      setError(
        "البريد أو كلمة المرور غير صحيحة — تأكد أن المدير أضاف بياناتك من لوحة الإدارة",
      );
    }
    setLoading(false);
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4"
      dir="rtl"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-md"
      >
        <div className="bg-white/8 backdrop-blur-xl border border-white/15 rounded-3xl p-8 shadow-2xl">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl">
              <BookOpen size={36} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-white">بوابة المعلم</h1>
            <p className="text-purple-300 text-sm mt-1">
              ادخل بالبيانات التي أرسلها إليك المدير
            </p>
          </div>
          <form onSubmit={handle} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-purple-200 mb-2">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="teacher@school.com"
                className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-purple-200 mb-2">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type={show ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/10 border border-white/20 rounded-2xl px-4 py-3.5 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
                >
                  {show ? "🙈" : "👁️"}
                </button>
              </div>
            </div>
            {error && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-xl px-4 py-2.5 text-red-300 text-sm">
                {error}
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-2xl font-black text-base hover:shadow-xl transition-all disabled:opacity-70 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full teacher-spin" />
              ) : (
                <>
                  <BookOpen size={20} /> دخول بوابة المعلم
                </>
              )}
            </button>
          </form>
          <div className="mt-5 p-4 bg-white/5 rounded-2xl border border-white/10 text-center">
            <p className="text-xs text-gray-400">
              📨 بيانات الدخول تُرسَل من المدير عبر واتساب
              <br />
              <span className="text-purple-300 text-[11px]">
                للتجربة: teacher@school.com / Teacher@2024
              </span>
            </p>
          </div>
          <div className="flex justify-center gap-4 mt-4 text-xs">
            <a
              href="/admin"
              className="text-purple-400 hover:text-purple-300 underline"
            >
              ← لوحة الإدارة
            </a>
            <a
              href="/student"
              className="text-blue-400 hover:text-blue-300 underline"
            >
              بوابة الطالب
            </a>
          </div>
        </div>
      </motion.div>
      <Toaster position="top-center" richColors />
      <style jsx global>{`
        @keyframes teacherspin { to { transform: rotate(360deg); } }
        .teacher-spin { animation: teacherspin 0.8s linear infinite; }
      `}</style>
    </div>
  );
}
