"use client";
import React from "react";
import { Search, ChevronRight } from "lucide-react";
import { WAIcon } from "./WAIcon";
import { getStudentSessionInfo } from "@/utils/teacherHelpers";

export function StudentsSection({
  students,
  searchStudent,
  onSearchChange,
  filteredStudents,
  attendance,
  payments,
  thisMonth,
}) {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black text-gray-800">
          طلابي ({students.length})
        </h2>
        <a
          href="/students"
          className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all"
        >
          إدارة شاملة <ChevronRight size={16} />
        </a>
      </div>
      <div className="relative">
        <Search
          size={18}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
        />
        <input
          value={searchStudent}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="بحث..."
          className="w-full pr-10 pl-4 py-3 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-500"
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredStudents.map((s) => {
          const { pkg, used, remaining } = getStudentSessionInfo(s, attendance);
          const paid = payments.some(
            (p) => p.studentId === s.id && p.date?.startsWith(thisMonth),
          );
          return (
            <div
              key={s.id}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-11 h-11 bg-gradient-to-br from-blue-400 to-indigo-600 rounded-xl flex items-center justify-center text-white font-black">
                  {s.name?.[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-black text-gray-800 truncate">{s.name}</p>
                  <p className="text-xs text-gray-400 font-mono">{s.code}</p>
                </div>
                <span
                  className={`text-xs font-bold px-2.5 py-1 rounded-full ${paid ? "bg-green-100 text-green-700" : "bg-red-100 text-red-500"}`}
                >
                  {paid ? "دفع ✓" : "لم يدفع"}
                </span>
              </div>
              <div className="space-y-2 mb-3">
                {s.grade && (
                  <p className="text-xs text-gray-500">
                    {s.grade} {s.group && `• ${s.group}`}
                  </p>
                )}
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">الحصص المتبقية</span>
                  <span
                    className={`font-black ${remaining === 0 ? "text-red-500" : remaining <= 2 ? "text-orange-500" : "text-green-600"}`}
                  >
                    {remaining} / {pkg}
                  </span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${remaining === 0 ? "bg-red-500" : remaining <= 2 ? "bg-orange-400" : "bg-green-500"}`}
                    style={{ width: `${(used / pkg) * 100}%` }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                {s.phone && (
                  <a
                    href={`https://wa.me/2${String(s.phone).replace(/^0/, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-green-50 text-green-600 rounded-xl text-xs font-bold hover:bg-green-100 transition-all"
                  >
                    <WAIcon size={14} /> واتساب
                  </a>
                )}
                {s.parentPhone && (
                  <a
                    href={`https://wa.me/2${String(s.parentPhone).replace(/^0/, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-all"
                  >
                    <WAIcon size={14} /> ولي الأمر
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
