"use client";
import React from "react";
import { ChevronRight, AlignLeft } from "lucide-react";

export function HomeworkSection({ homework, students, todayDate }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black text-gray-800">
          الواجبات ({homework.length})
        </h2>
        <a
          href="/homework"
          className="flex items-center gap-1.5 px-4 py-2 bg-pink-600 text-white rounded-xl text-sm font-bold hover:bg-pink-700 transition-all"
        >
          إدارة الواجبات <ChevronRight size={16} />
        </a>
      </div>
      {homework.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 py-12 text-center">
          <AlignLeft size={36} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500">لا توجد واجبات بعد</p>
        </div>
      ) : (
        homework.map((hw) => {
          const total = students.filter(
            (s) => !hw.group || s.group === hw.group,
          ).length;
          const submitted = (hw.submissions || []).length;
          const overdue = hw.dueDate < todayDate;
          return (
            <div
              key={hw.id}
              className={`bg-white rounded-2xl border-2 p-5 ${overdue && submitted < total ? "border-red-200 bg-red-50/30" : "border-gray-100"}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-black text-gray-800">{hw.title}</h3>
                  {hw.subject && (
                    <p className="text-xs text-gray-400 mt-0.5">
                      {hw.subject} {hw.group && `• ${hw.group}`}
                    </p>
                  )}
                </div>
                <div className="text-left">
                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full ${overdue && submitted < total ? "bg-red-100 text-red-600" : submitted === total ? "bg-green-100 text-green-600" : "bg-blue-100 text-blue-600"}`}
                  >
                    {overdue && submitted < total
                      ? "متأخر"
                      : submitted === total
                        ? "مكتمل"
                        : "نشط"}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                <span>
                  التسليم: {submitted}/{total}
                </span>
                <span>
                  الموعد: {new Date(hw.dueDate).toLocaleDateString("ar-EG")}
                </span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${submitted === total ? "bg-green-500" : overdue ? "bg-red-400" : "bg-blue-500"}`}
                  style={{
                    width: `${total > 0 ? (submitted / total) * 100 : 0}%`,
                  }}
                />
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}
