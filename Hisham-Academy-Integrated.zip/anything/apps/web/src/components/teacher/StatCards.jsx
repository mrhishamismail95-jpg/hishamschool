"use client";
import React from "react";
import { motion } from "motion/react";
import { Users, CalendarCheck, Zap, Clock } from "lucide-react";

const iconMap = {
  Users,
  CalendarCheck,
  Zap,
  Clock,
};

export function StatCards({ stats }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map(({ label, val, icon: iconName, color, sub }) => {
        const Icon = iconMap[iconName];
        return (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-all"
          >
            <div
              className={`w-11 h-11 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center mb-3 shadow-md`}
            >
              <Icon size={22} className="text-white" />
            </div>
            <p className="text-2xl font-black text-gray-800">{val}</p>
            <p className="text-xs text-gray-500 font-medium">{label}</p>
            <p className="text-xs text-gray-400 mt-0.5">{sub}</p>
          </motion.div>
        );
      })}
    </div>
  );
}
