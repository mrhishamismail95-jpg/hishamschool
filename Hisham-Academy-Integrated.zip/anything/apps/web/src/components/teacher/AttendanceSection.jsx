"use client";
import React from "react";
import { Search, ChevronRight } from "lucide-react";
import { WAIcon } from "./WAIcon";

export function AttendanceSection({
  todayDate,
  searchStudent,
  onSearchChange,
  filteredStudents,
  getStudentStatus,
  onMarkAttendance,
  todayAttendance,
  students,
}) {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black text-gray-800">
          تحضير اليوم —{" "}
          {new Date(todayDate).toLocaleDateString("ar-EG", {
            weekday: "long",
            day: "numeric",
            month: "long",
          })}
        </h2>
        <a
          href="/attendance"
          className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all"
        >
          التحضير الكامل <ChevronRight size={16} />
        </a>
      </div>

      <div className="relative">
        <Search
          size={18}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
        />
        <input
          value={searchStudent}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="بحث بالاسم أو المجموعة..."
          className="w-full pr-10 pl-4 py-3 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-500 transition-all"
        />
      </div>

      <div className="space-y-2">
        {filteredStudents.map((s) => {
          const status = getStudentStatus(s.id);
          return (
            <div
              key={s.id}
              className={`flex items-center gap-3 p-4 rounded-2xl border-2 transition-all ${status === "present" ? "bg-green-50 border-green-200" : status === "absent" ? "bg-red-50 border-red-200" : status === "late" ? "bg-orange-50 border-orange-200" : "bg-white border-gray-100"}`}
            >
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold flex-shrink-0">
                {s.name?.[0]}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-gray-800 text-sm truncate">
                  {s.name}
                </p>
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  {s.group && <span>{s.group}</span>}
                  {s.grade && <span>• {s.grade}</span>}
                </div>
              </div>
              <div className="flex gap-1.5">
                {["present", "late", "absent"].map((st) => (
                  <button
                    key={st}
                    onClick={() => onMarkAttendance(s, st)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${status === st ? (st === "present" ? "bg-green-600 text-white" : st === "absent" ? "bg-red-600 text-white" : "bg-orange-500 text-white") : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}
                  >
                    {st === "present" ? "✓" : st === "absent" ? "✗" : "⏰"}
                  </button>
                ))}
                {s.phone && (
                  <a
                    href={`https://wa.me/2${String(s.phone).replace(/^0/, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition-all"
                  >
                    <WAIcon size={16} />
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex gap-4 bg-gray-50 rounded-2xl p-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-500 rounded-full" />
          <span className="text-gray-600">
            حضور ({todayAttendance.filter((a) => a.status === "present").length}
            )
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-orange-500 rounded-full" />
          <span className="text-gray-600">
            متأخر ({todayAttendance.filter((a) => a.status === "late").length})
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full" />
          <span className="text-gray-600">
            غائب ({todayAttendance.filter((a) => a.status === "absent").length})
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-gray-300 rounded-full" />
          <span className="text-gray-600">
            لم يُسجَّل ({students.length - todayAttendance.length})
          </span>
        </div>
      </div>
    </div>
  );
}
