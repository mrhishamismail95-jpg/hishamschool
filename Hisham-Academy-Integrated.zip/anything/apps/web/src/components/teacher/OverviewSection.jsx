"use client";
import React from "react";
import { StatCards } from "./StatCards";
import { QuickToolsGrid } from "./QuickToolsGrid";
import { TodayAlerts } from "./TodayAlerts";
import { GroupsOverview } from "./GroupsOverview";

export function OverviewSection({
  students,
  groups,
  presentToday,
  unpaid,
  lowSessions,
  payments,
  todayAttendance,
  thisMonth,
  quickTools,
  onNavigateToAttendance,
}) {
  const stats = [
    {
      label: "طلابي",
      val: students.length,
      icon: "Users",
      color: "from-blue-500 to-cyan-500",
      sub: `${groups.length} مجموعة`,
    },
    {
      label: "حضور اليوم",
      val: presentToday,
      icon: "CalendarCheck",
      color: "from-green-500 to-emerald-500",
      sub: `من ${students.length} طالب`,
    },
    {
      label: "لم يدفعوا",
      val: unpaid,
      icon: "Zap",
      color: "from-orange-500 to-red-500",
      sub: "هذا الشهر",
    },
    {
      label: "حصص منتهية قريباً",
      val: lowSessions,
      icon: "Clock",
      color: "from-purple-500 to-pink-500",
      sub: "يحتاجون تجديد",
    },
  ];

  return (
    <div className="space-y-6">
      <StatCards stats={stats} />
      <QuickToolsGrid tools={quickTools} />
      <TodayAlerts lowSessions={lowSessions} unpaid={unpaid} />
      <GroupsOverview
        groups={groups}
        students={students}
        payments={payments}
        todayAttendance={todayAttendance}
        thisMonth={thisMonth}
        onNavigateToAttendance={onNavigateToAttendance}
      />
    </div>
  );
}
