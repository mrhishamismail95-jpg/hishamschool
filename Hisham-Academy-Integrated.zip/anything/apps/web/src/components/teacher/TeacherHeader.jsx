"use client";
import React from "react";
import { Menu, Calculator, Archive } from "lucide-react";

export function TeacherHeader({ activeSection, navItems, onMenuClick }) {
  const currentSection = navItems.find((n) => n.key === activeSection);

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 lg:px-6 sticky top-0 z-30 shadow-sm">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-xl"
        >
          <Menu size={22} />
        </button>
        <div>
          <h1 className="font-black text-gray-800 text-base">
            {currentSection?.label || "بوابة المعلم"}
          </h1>
          <p className="text-xs text-gray-400">
            {new Date().toLocaleDateString("ar-EG", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <a
          href="/whiteboard"
          className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-purple-100 text-purple-700 rounded-xl text-xs font-bold hover:bg-purple-200 transition-all"
        >
          <Calculator size={15} /> السبورة
        </a>
        <a
          href="/archive"
          className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-emerald-100 text-emerald-700 rounded-xl text-xs font-bold hover:bg-emerald-200 transition-all"
        >
          <Archive size={15} /> الأرشيف
        </a>
        <div className="w-9 h-9 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-black text-sm">
          م
        </div>
      </div>
    </header>
  );
}
