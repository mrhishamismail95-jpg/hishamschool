"use client";
import React from "react";
import { BookOpen, Home, LogOut } from "lucide-react";
import {
  LayoutGrid,
  CalendarCheck,
  Users,
  AlignLeft,
  FileText,
  Calculator,
} from "lucide-react";

const iconMap = {
  LayoutGrid,
  CalendarCheck,
  Users,
  AlignLeft,
  FileText,
  Calculator,
};

export function TeacherSidebar({
  activeSection,
  onSectionChange,
  onLogout,
  navItems,
}) {
  return (
    <div className="h-full flex flex-col px-4 py-6">
      <div className="flex items-center gap-3 px-2 mb-8">
        <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
          <BookOpen size={22} className="text-white" />
        </div>
        <div>
          <p className="text-white font-black text-base">بوابة المعلم</p>
          <p className="text-purple-300 text-xs">نظام متكامل للتدريس</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1">
        {navItems.map(({ key, label, icon: iconName }) => {
          const Icon = iconMap[iconName];
          return (
            <button
              key={key}
              onClick={() => onSectionChange(key)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-right ${activeSection === key ? "bg-white/20 text-white font-bold" : "text-purple-200 hover:bg-white/10 hover:text-white"}`}
            >
              <Icon size={20} />
              <span className="text-sm">{label}</span>
            </button>
          );
        })}
      </nav>

      <div className="pt-4 border-t border-white/10 space-y-2">
        <a
          href="/"
          className="flex items-center gap-3 px-4 py-2.5 text-purple-200 hover:text-white hover:bg-white/10 rounded-xl transition-all text-sm"
        >
          <Home size={18} /> لوحة الإدارة
        </a>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 text-red-400 hover:bg-red-500/20 rounded-xl transition-all text-sm"
        >
          <LogOut size={18} /> تسجيل خروج
        </button>
      </div>
    </div>
  );
}
