import { useState, useEffect } from "react";
import {
  FolderOpen,
  Link as LinkIcon,
  ExternalLink,
  Save,
  Edit2,
} from "lucide-react";

export default function ArchiveManager({ teacher }) {
  const [driveLink, setDriveLink] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [tempLink, setTempLink] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setDriveLink(teacher.google_drive_link || "");
    setTempLink(teacher.google_drive_link || "");
  }, [teacher]);

  const handleSave = async () => {
    setSaving(true);

    try {
      const response = await fetch(`/api/academy/teachers/${teacher.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ google_drive_link: tempLink }),
      });

      if (response.ok) {
        setDriveLink(tempLink);
        setEditMode(false);
        alert("تم حفظ رابط الأرشيف بنجاح");
      }
    } catch (err) {
      console.error("Save archive link error:", err);
      alert("حدث خطأ في حفظ الرابط");
    } finally {
      setSaving(false);
    }
  };

  const openArchive = () => {
    if (driveLink) {
      window.open(driveLink, "_blank");
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900 text-right">
          الأرشيف الخاص
        </h2>
        <FolderOpen className="w-8 h-8 text-blue-600" />
      </div>

      <div className="space-y-6">
        {/* Info Box */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-right">
          <p className="text-sm text-blue-800">
            <strong>ملاحظة:</strong> يمكنك ربط حسابك في Google Drive لتخزين
            الملفات والمستندات الخاصة بك. احفظ هنا رابط مجلد Google Drive الخاص
            بك للوصول السريع إليه.
          </p>
        </div>

        {/* Current Link or Editor */}
        {editMode ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                رابط Google Drive
              </label>
              <div className="relative">
                <LinkIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="url"
                  value={tempLink}
                  onChange={(e) => setTempLink(e.target.value)}
                  placeholder="https://drive.google.com/drive/folders/..."
                  className="w-full pr-12 pl-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                  dir="rtl"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setEditMode(false);
                  setTempLink(driveLink);
                }}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
              >
                إلغاء
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {saving ? (
                  "جاري الحفظ..."
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    حفظ
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {driveLink ? (
              <>
                <div className="bg-gray-50 rounded-lg p-4 text-right">
                  <p className="text-sm text-gray-600 mb-1">الرابط المحفوظ:</p>
                  <p className="text-blue-600 font-mono text-sm break-all">
                    {driveLink}
                  </p>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setEditMode(true)}
                    className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center justify-center gap-2"
                  >
                    <Edit2 className="w-4 h-4" />
                    تعديل الرابط
                  </button>
                  <button
                    onClick={openArchive}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    فتح الأرشيف
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <FolderOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600 mb-4">
                  لم يتم ربط أرشيف Google Drive بعد
                </p>
                <button
                  onClick={() => setEditMode(true)}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 mx-auto"
                >
                  <LinkIcon className="w-5 h-5" />
                  ربط Google Drive
                </button>
              </div>
            )}
          </div>
        )}

        {/* Instructions */}
        <div className="bg-gray-50 rounded-lg p-4 text-right">
          <h4 className="font-bold text-gray-900 mb-2">
            كيفية الحصول على الرابط:
          </h4>
          <ol className="text-sm text-gray-700 space-y-1 list-decimal list-inside">
            <li>افتح Google Drive</li>
            <li>انشئ مجلداً جديداً أو اختر مجلداً موجوداً</li>
            <li>انقر بزر الماوس الأيمن على المجلد واختر "الحصول على الرابط"</li>
            <li>
              تأكد من أن الإعدادات مضبوطة على "أي شخص لديه الرابط يمكنه الاطلاع"
            </li>
            <li>انسخ الرابط والصقه هنا</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
