"use client";
import React from "react";
import { Users, ChevronRight } from "lucide-react";

export function GroupsOverview({
  groups,
  students,
  payments,
  todayAttendance,
  thisMonth,
  onNavigateToAttendance,
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <h2 className="font-black text-gray-800 mb-4 flex items-center gap-2">
        <Users size={18} className="text-blue-600" /> مجموعاتي
      </h2>
      {groups.length === 0 ? (
        <p className="text-gray-400 text-center py-6">لا توجد مجموعات بعد</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {groups.map((g) => {
            const gs = students.filter((s) => s.group === g);
            const paid = gs.filter((s) =>
              payments.some(
                (p) => p.studentId === s.id && p.date?.startsWith(thisMonth),
              ),
            ).length;
            const present = gs.filter((s) =>
              todayAttendance.find(
                (a) =>
                  a.studentId === s.id &&
                  (a.status === "present" || a.status === "late"),
              ),
            ).length;
            return (
              <div
                key={g}
                className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100"
              >
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Users size={20} className="text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-gray-800 text-sm truncate">
                    {g}
                  </p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-gray-400">
                      {gs.length} طالب
                    </span>
                    <span className="text-xs text-green-600 font-medium">
                      ✓ {present} حضروا
                    </span>
                    <span className="text-xs text-blue-600 font-medium">
                      💳 {paid} دفعوا
                    </span>
                  </div>
                </div>
                <button
                  onClick={onNavigateToAttendance}
                  className="text-xs text-blue-600 font-bold hover:underline flex-shrink-0"
                >
                  تحضير <ChevronRight size={12} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
