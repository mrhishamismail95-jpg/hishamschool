import { Home, LogOut } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

export default function GlobalHeader({ title, onLogout, showLogout = true }) {
  const navigate = useNavigate();
  const location = useLocation();

  const isHomePage = location.pathname === "/";

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Title */}
          <h1 className="text-xl font-bold text-gray-900">
            {title || "أكاديمية هشام"}
          </h1>

          {/* Navigation Buttons */}
          <div className="flex items-center gap-3">
            {!isHomePage && (
              <button
                onClick={() => navigate("/")}
                className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <Home className="w-5 h-5" />
                <span className="font-medium hidden sm:inline">
                  الصفحة الرئيسية
                </span>
              </button>
            )}

            {showLogout && onLogout && (
              <button
                onClick={onLogout}
                className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium hidden sm:inline">
                  تسجيل الخروج
                </span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
